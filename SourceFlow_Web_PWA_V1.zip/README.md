# SourceFlow Web PWA V1 (chuyển từ cấu trúc dữ liệu SourceFlow Android V2.4)

## Phạm vi đã có
- Giao diện Safari/mobile responsive, PWA có thể thêm vào Màn hình chính từ HTTPS.
- Tạo / sửa / xem / tìm / lọc / lưu trữ / xóa nguồn hàng.
- Dữ liệu hồ sơ bám theo `Listing.toJson()` trong `lib/models.dart` của V2.4: `title, type, address, area, width, length, price, source, sourceUrl, owner, phone, verification, verificationEvidence, contactStatus, contractStatus, saleStatus, contractNumber, contractFee, exclusive, contractExpires, nextAction, nextDue, marketingNeedsAttention, archived, rawCapture, imagePaths, posts, offers, logs`, ...
- Lưu trên IndexedDB **của trình duyệt / Web App trên iPhone**, không đồng bộ máy chủ.
- Chọn/chụp nhiều ảnh, ảnh nén JPEG khi trình duyệt hỗ trợ; lưu Blob riêng trong IndexedDB; thư viện ảnh và xem phóng to.
- Thống kê (Tổng, Chưa liên hệ, Chưa ký, Đã ký), danh sách công việc cần xử lý theo quy tắc tham chiếu V2.4.
- Xuất bản sao lưu có ảnh `.sfbackup` dạng gzip nếu `CompressionStream` có sẵn, hoặc JSON nếu trình duyệt cũ.
- Khôi phục bản sao lưu schema 3 (`.sfbackup` từ SourceFlow Android V2.4 và từ Web) hoặc JSON nếu trình duyệt hỗ trợ `DecompressionStream`.
- Quản lý các hồ sơ cũ với `posts`, `offers`, `logs` được bảo toàn qua nhập / sửa / xuất, nhưng **chưa có giao diện riêng để quản lý bài đăng hay đề nghị mua**.

## Chưa có và giới hạn
- **Chưa thực hiện nhận dạng giọng nói hoặc OCR trên Safari**. Hai chức năng này là bước tiếp theo, sau khi kiểm thử quản lý dữ liệu/ảnh/sao lưu.
- Chưa có nhắc việc qua thông báo đẩy; hiện chỉ hiển thị danh sách "Cần xử lý" trong ứng dụng.
- Chưa có đăng nhập, đồng bộ giữa máy, mã hóa cơ sở dữ liệu bằng mật khẩu, khóa ứng dụng, hay backend. Không lưu dữ liệu kinh doanh quan trọng duy nhất trong browser.
- Trên iPhone, dữ liệu website có thể bị xóa khi người dùng dọn dữ liệu, xóa ứng dụng web, hoặc hệ điều hành giải phóng bộ nhớ. Safari và PWA đã cài có thể lưu riêng. **Sao lưu ra Tệp / iCloud Drive thường xuyên**.
- File sao lưu chứa tên, số điện thoại và ảnh ở dạng có thể giải nén/đọc; không gửi lên GitHub hay nơi công cộng.
- Khi sao lưu nhiều ảnh lớn, Safari có thể thiếu RAM. Trước mắt thử nghiệm 50, 200 rồi 500 nguồn; ưu tiên tệp ghi chú-only nếu cần. Không nên tin tưởng bản này để quản lý chính thức toàn bộ dữ liệu thực tế.
- `schema:3` và đường dẫn ảnh được tái tạo tương thích với logic Android: mỗi ảnh đặt dưới key `<listing-id>/<index>` trong `photos`. Chưa chạy kiểm thử import thực tế trên Safari iPhone.

## Triển khai MIỄN PHÍ bằng GitHub Pages
1. Nén **nội dung** thư mục này thành `SourceFlow_Web_PWA_V1.zip` (các tệp `index.html`, `app.js`... nằm ở gốc ZIP).
2. Upload ZIP vào gốc repo `lehuygiang1981-cell/SourceFlow-V2-Android`.
3. Upload tệp `SourceFlow_Web_PWA_deploy.yml` trong cùng bộ phát hành này vào `.github/workflows/`, đặt tên `sourceflow-web-pwa.yml`.
4. Ở GitHub Settings → Pages, chọn **Build and deployment → Source: GitHub Actions**.
5. Actions → `SourceFlow Web PWA - GitHub Pages` → đợi bước deploy hoàn tất.
6. Dự kiến địa chỉ: `https://lehuygiang1981-cell.github.io/SourceFlow-V2-Android/` **chỉ sau khi GitHub báo deploy thành công**. Không giả định trang đã hoạt động trước bước này.
7. iPhone Safari → mở link → Chia sẻ → Thêm vào Màn hình chính → Thêm.

GitHub Pages host các **tệp chương trình công khai**, không chứa bản sao lưu hay hồ sơ khách hàng; dữ liệu chỉ nằm trên thiết bị người dùng nếu người dùng không tự gửi đi.

## Phân biệt phiên bản
`SourceFlow V2.4` là phiên bản Android gốc. `SourceFlow Web PWA V1` là bản triển khai web mới giữ schema 3, **không phải** APK/IPA có thể cài trực tiếp và **không bảo đảm có toàn bộ tính năng Android**.

## Tự chạy cục bộ (nếu có máy tính)
`python -m http.server 8000` rồi mở `http://localhost:8000`. Để sử dụng thực tế qua iPhone cần máy chủ HTTPS như GitHub Pages.
