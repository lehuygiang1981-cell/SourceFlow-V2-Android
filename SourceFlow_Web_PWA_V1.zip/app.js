/* SourceFlow Web PWA — web adaptation of V2.4 Listing schema.
 * Records and photos stay in THIS browser's IndexedDB. No analytics, backend or network upload.
 * OCR and speech-to-text are deliberately NOT claimed as supported in this core release.
 */
'use strict';
const DB_NAME='sourceflow-web-v1', DB_VERSION=1;
const $=s=>document.querySelector(s);
const escapeHtml=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const uid=()=>globalThis.crypto?.randomUUID?.()||`${Date.now()}-${Math.floor(Math.random()*999999)}`;
const stamp=()=>new Date().toISOString();
const DAY=86400000;
const TYPES=['Nhà riêng','Nhà mặt tiền','Đất nền','Căn hộ','Nhà xưởng / kho','Khác'];
const SOURCES=['Khảo sát thực tế','Trang web','Người quen giới thiệu','Mạng xã hội','Khác'];
const CONTACTS=['Chưa liên hệ','Chưa liên hệ được','Đã liên hệ','Đã hẹn gặp','Đang đàm phán','Đã gặp / làm việc'];
const VERIFIED=['Chưa xác minh','Đã trao đổi, chưa đối chiếu','Cần kiểm tra thêm','Đã đối chiếu hồ sơ','Đã gặp và xác minh trực tiếp','Có dấu hiệu môi giới'];
const SALES=['Chưa chào bán','Chuẩn bị chào bán','Đang chào bán','Có khách quan tâm','Đã giao dịch'];
const CONTRACTS=['Chưa ký','Đã ký'];
const state={db:null,items:[],view:'dashboard',filter:'all',query:'',shown:40,selected:null,editing:null,draft:null,photoPending:[],photoRemoved:new Set(),formImageIds:[],objectUrls:[],busy:false};
let toastTimer=null;
function toast(message){const t=$('#toast');t.textContent=message;t.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>t.classList.remove('show'),4700);}
function errMessage(e){return e?.message||String(e);}
function runRequest(req){return new Promise((ok,fail)=>{req.onsuccess=()=>ok(req.result);req.onerror=()=>fail(req.error);});}
function txDone(tx){return new Promise((ok,fail)=>{tx.oncomplete=ok;tx.onerror=()=>fail(tx.error||new Error('Không ghi được dữ liệu'));tx.onabort=()=>fail(tx.error||new Error('Giao dịch dữ liệu bị hủy'));});}
async function openDB(){return new Promise((ok,fail)=>{if(!('indexedDB' in window)){fail(new Error('Trình duyệt không hỗ trợ IndexedDB'));return;}
 const req=indexedDB.open(DB_NAME,DB_VERSION);
 req.onupgradeneeded=()=>{const db=req.result;if(!db.objectStoreNames.contains('listings'))db.createObjectStore('listings',{keyPath:'id'});if(!db.objectStoreNames.contains('photos')){const p=db.createObjectStore('photos',{keyPath:'id'});p.createIndex('listingId','listingId');}};
 req.onsuccess=()=>ok(req.result);req.onerror=()=>fail(req.error);
});}
async function loadItems(){const tx=state.db.transaction('listings','readonly');const rows=await runRequest(tx.objectStore('listings').getAll());state.items=rows.sort((a,b)=>String(b.updatedAt??'').localeCompare(String(a.updatedAt??'')));}
async function readPhoto(id){const tx=state.db.transaction('photos','readonly');return runRequest(tx.objectStore('photos').get(id));}
async function removeListingHard(item){const tx=state.db.transaction(['listings','photos'],'readwrite'),done=txDone(tx);
 tx.objectStore('listings').delete(item.id);
 for(const id of item.imagePaths||[])tx.objectStore('photos').delete(id);
 await done;await loadItems();}
async function writeListing(item,newPhotos=[],deletedPhotos=[],skipReload=false){const tx=state.db.transaction(['listings','photos'],'readwrite'),done=txDone(tx);tx.objectStore('listings').put(item);
 for(const p of newPhotos)tx.objectStore('photos').put({id:p.id,listingId:item.id,blob:p.blob,mime:p.blob.type||'image/jpeg',name:p.name||'photo.jpg',createdAt:stamp()});
 for(const id of deletedPhotos)tx.objectStore('photos').delete(id);
 await done;if(!skipReload)await loadItems();}
function newListing(){const t=stamp();return {id:uid(),createdAt:t,updatedAt:t,title:'',type:'Nhà riêng',address:'',area:'',width:'',length:'',price:'',source:'Khảo sát thực tế',sourceUrl:'',owner:'',phone:'',verification:'Chưa xác minh',verificationEvidence:'',contactStatus:'Chưa liên hệ',contractStatus:'Chưa ký',saleStatus:'Chưa chào bán',contractNumber:'',contractFee:'',exclusive:false,contractExpires:null,posts:[],offers:[],nextAction:'',nextDue:null,marketingNeedsAttention:false,archived:false,rawCapture:'',imagePath:'',imagePaths:[],logs:[]};}
function clone(x){return JSON.parse(JSON.stringify(x));}
function when(x){if(!x)return 'Chưa đặt';const d=new Date(x);return Number.isNaN(d.getTime())?'Chưa đặt':d.toLocaleDateString('vi-VN');}
function whenShort(x){if(!x)return '';const d=new Date(x);return Number.isNaN(d.getTime())?'':d.toLocaleDateString('vi-VN');}
function dateInput(x){if(!x)return '';return String(x).slice(0,10);}
function attention(item){if(item.archived||item.saleStatus==='Đã giao dịch')return null;
 if(item.contractStatus==='Đã ký')return item.marketingNeedsAttention?{label:item.nextAction||'Xử lý biến động chào bán',priority:1}:null;
 if(item.contactStatus==='Chưa liên hệ')return {label:'Chưa liên hệ chủ – cần gọi xác minh',priority:0};
 if(item.nextDue){const due=new Date(String(item.nextDue).slice(0,10)+'T23:59:59');if(due.getTime()<Date.now()-DAY+1000)return {label:item.nextAction||'Công việc quá hạn',priority:0};}
 if(!item.nextAction)return {label:'Chưa ký hợp đồng – cần xác định bước tiếp theo',priority:2};
 const future=item.nextDue&&new Date(item.nextDue).getTime()>Date.now();return {label:future?`Theo dõi: ${item.nextAction} (${when(item.nextDue)})`:item.nextAction,priority:future?3:1};
}
function attentionList(){return state.items.map(item=>({item,a:attention(item)})).filter(x=>x.a).sort((x,y)=>x.a.priority-y.a.priority||String(y.item.updatedAt).localeCompare(String(x.item.updatedAt)));}
function header(){return `<header class="topbar"><div class="top-inner"><div class="mark">SF</div><div><div class="brand">SourceFlow</div><div class="subbrand">WEB • TƯƠNG THÍCH DỮ LIỆU V2.4</div></div><button class="top-action" data-action="new">+ Tạo mới</button></div></header>`;}
const NAV=[['dashboard','⌂','Tổng quan'],['list','▣','Nguồn hàng'],['attention','◷','Cần xử lý'],['data','☷','Sao lưu']];
function nav(){return `<nav class="bottomnav" aria-label="Điều hướng chính">${NAV.map(([key,ico,label])=>`<button data-action="nav" data-view="${key}" class="navitem ${state.view===key?'active':''}"><span>${ico}</span><span>${label}</span></button>`).join('')}</nav>`;}
function footer(){return `<p class="footer-note">SourceFlow Web thử nghiệm • Dữ liệu nằm trên thiết bị này • Hãy sao lưu định kỳ</p>`;}
function listingRow(p,a=null){const attrs=`data-action="detail" data-id="${escapeHtml(p.id)}"`;const photo=p.imagePaths?.[0];
 return `<button class="card card-btn listing-card" ${attrs}><div class="listing-icon">${photo?`<img alt="Ảnh nguồn hàng" data-photo-id="${escapeHtml(photo)}">`:'⌂'}</div><div class="listing-main"><h3>${escapeHtml(p.title||'Nguồn hàng chưa đặt tên')}</h3><p>${escapeHtml(p.address||'Chưa có địa chỉ')} ${p.area?'• '+escapeHtml(p.area):''}</p>${p.price?`<div class="price">${escapeHtml(p.price)}</div>`:''}<div class="listing-foot"><span class="pill ${p.contractStatus==='Đã ký'?'':'orange'}">${escapeHtml(p.contractStatus||'Chưa ký')}</span><span class="pill gray">${escapeHtml(p.contactStatus||'Chưa liên hệ')}</span>${p.archived?'<span class="pill red">Đã lưu trữ</span>':''}</div>${a?`<p style="margin-top:8px;color:#a66e11">◷ ${escapeHtml(a.label)}</p>`:''}</div><span style="color:#8ea8a5">›</span></button>`;}
function dashboard(){const active=state.items.filter(x=>!x.archived),uncalled=active.filter(x=>x.contactStatus==='Chưa liên hệ').length,unsigned=active.filter(x=>x.contractStatus!=='Đã ký').length,signed=active.filter(x=>x.contractStatus==='Đã ký').length,attention=attentionList();
 return `<section class="hero"><div class="eyebrow" style="color:#bfe9d5">QUẢN LÝ NGUỒN HÀNG</div><h1>Nguồn hàng trong tầm tay.</h1><p>Tạo hồ sơ, lưu ảnh và cập nhật công việc ngay trên iPhone. Không cần đăng nhập hay trả phí Apple Developer.</p><button class="primary" data-action="new">＋ Thêm nguồn hàng mới</button></section><section class="grid-stats" aria-label="Thống kê hồ sơ">
 ${[["Tổng nguồn",state.items.length,'all'],['Chưa liên hệ',uncalled,'uncalled'],['Chưa ký HĐ',unsigned,'unsigned'],['Đã ký HĐ',signed,'signed']].map(([label,val,f])=>`<button class="stat" data-action="filter" data-filter="${f}"><strong>${val}</strong><span>${label}</span><small>Xem danh sách →</small></button>`).join('')}
 </section><div class="section-title"><h2>Cần xử lý <span class="pill orange">${attention.length}</span></h2><button class="text-link" data-action="nav" data-view="attention">Xem tất cả →</button></div>${attention.length?attention.slice(0,5).map(x=>listingRow(x.item,x.a)).join(''):`<div class="empty"><div class="big">✓</div><h3>Không có việc cần chú ý</h3><p>Những hồ sơ cần xác minh và theo dõi sẽ xuất hiện tại đây.</p></div>`}
 <div class="note warning" style="margin-top:18px"><b>Quan trọng:</b> Dữ liệu được lưu cục bộ trong Safari/ứng dụng đã thêm vào Màn hình chính, không đồng bộ giữa các điện thoại. Hãy tạo bản sao lưu ngoài thiết bị sau mỗi đợt nhập nguồn hàng.</div>${footer()}`;}
function applies(p,filter){if(filter==='uncalled')return !p.archived&&p.contactStatus==='Chưa liên hệ';if(filter==='unsigned')return !p.archived&&p.contractStatus!=='Đã ký';if(filter==='signed')return !p.archived&&p.contractStatus==='Đã ký';if(filter==='archived')return !!p.archived;return filter==='all'||!p.archived;}
function matchQuery(p,q){if(!q)return true;return ['title','address','owner','phone','area','width','length','price','source','type'].some(k=>String(p[k]||'').toLocaleLowerCase('vi').includes(q));}
function filtered(){const q=state.query.trim().toLocaleLowerCase('vi');return state.items.filter(p=>applies(p,state.filter)&&matchQuery(p,q));}
function listResults(){const f=filtered();return `<div class="small-row" style="margin:6px 2px 12px"><span class="sm muted">Tìm thấy <b class="mono">${f.length}</b> hồ sơ</span><span class="sm muted">Mới cập nhật trước</span></div>${f.length?f.slice(0,state.shown).map(x=>listingRow(x)).join(''):'<div class="empty"><div class="big">⌕</div><h3>Chưa tìm thấy nguồn hàng</h3><p>Thử từ khóa khác hoặc tạo hồ sơ mới.</p></div>'}${f.length>state.shown?`<button class="secondary full" data-action="more">Xem thêm ${Math.min(40,f.length-state.shown)} hồ sơ</button>`:''}`;}
function listingScreen(){return `<div class="view-head"><div class="eyebrow">KHO NGUỒN HÀNG</div><h1>Danh sách tài sản</h1><p class="muted sm">Tìm theo tên, địa chỉ, điện thoại, giá hoặc kích thước.</p></div><div class="toolbar"><input class="search" id="search" type="search" placeholder="⌕ Tìm nguồn hàng..." value="${escapeHtml(state.query)}" autocomplete="off"><select id="filter" aria-label="Lọc nguồn hàng">${[['all','Tất cả'],['uncalled','Chưa liên hệ'],['unsigned','Chưa ký HĐ'],['signed','Đã ký HĐ'],['archived','Đã lưu trữ']].map(([v,t])=>`<option value="${v}" ${state.filter===v?'selected':''}>${t}</option>`).join('')}</select></div><div id="listResults">${listResults()}</div>${footer()}`;}
function attentionScreen(){const all=attentionList();return `<div class="view-head"><div class="eyebrow">THEO DÕI & XÁC MINH</div><h1>Công việc cần xử lý</h1><p class="muted sm">Gợi ý dựa trên trạng thái nguồn hàng V2.4; đây là danh sách trong ứng dụng, chưa phải thông báo đẩy trên iOS.</p></div><div class="tag-row"><span class="pill orange">${all.length} mục cần theo dõi</span></div>${all.length?all.map(x=>listingRow(x.item,x.a)).join(''):'<div class="empty"><div class="big">✓</div><h3>Danh sách đang trống</h3></div>'}${footer()}`;}
function dataScreen(){return `<div class="view-head"><div class="eyebrow">DỮ LIỆU & AN TOÀN</div><h1>Sao lưu và khôi phục</h1><p class="muted sm">Dữ liệu của bạn chỉ được lưu trong bộ nhớ của trình duyệt/ứng dụng web trên thiết bị này.</p></div>
 <section class="form-card"><h2>Xuất bản sao lưu</h2><p class="sm muted">Bao gồm hồ sơ, ghi chú, trạng thái, nhật ký và ảnh. Tương thích cấu trúc bản sao lưu SourceFlow V2.4 Android (<code>schema: 3</code>).</p><div class="data-actions"><button class="primary full" data-action="backup">↓ Sao lưu toàn bộ, gồm ảnh</button><button class="secondary full" data-action="backup-metadata">↓ Sao lưu thông tin (không ảnh)</button></div><p class="sm muted" style="margin:12px 0 0">Tệp sẽ được tải về mục Tệp (Files) trên iPhone. Giữ thêm một bản ở iCloud Drive hoặc nơi an toàn khác.</p></section>
 <section class="form-card"><h2>Nhập bản sao lưu</h2><p class="sm muted">Nhận <code>.sfbackup</code> (gzip) từ Android V2.4 / Web và <code>.json</code>. Các hồ sơ trùng ID sẽ được cập nhật theo tệp bạn chọn; hồ sơ không trùng được thêm mới.</p><button class="secondary full" data-action="restore">↑ Chọn file để khôi phục</button></section>
 <div class="note warning"><strong>Lưu ý về Safari:</strong> Nếu xóa dữ liệu website, gỡ ứng dụng web hoặc iOS dọn bộ nhớ, nguồn hàng có thể mất. Dữ liệu Safari và biểu tượng đã thêm vào Màn hình chính không phải lúc nào cũng chia sẻ chung kho lưu trữ. Hãy sao lưu trước khi đổi cách mở ứng dụng.</div>
 <div class="section-title"><h2>Tình trạng lưu trữ</h2></div><div class="card"><div class="kv"><dt>Số hồ sơ</dt><dd>${state.items.length}</dd></div><div class="kv"><dt>Lưu trữ</dt><dd>IndexedDB (trên iPhone)</dd></div><div class="kv"><dt>Đồng bộ đám mây</dt><dd>Chưa có</dd></div><div class="kv"><dt>OCR & giọng nói</dt><dd>Giai đoạn kế tiếp</dd></div><div class="kv"><dt>Phí sử dụng</dt><dd>0 đồng, không cần tài khoản Apple Developer</dd></div></div>${footer()}`;}
function kv(label,val){return `<div class="kv"><dt>${escapeHtml(label)}</dt><dd>${escapeHtml(val??'')||'—'}</dd></div>`;}
function detail(){const p=state.items.find(x=>x.id===state.selected);if(!p){state.view='list';return listingScreen();}
 const imgs=(p.imagePaths||[]).map((id,i)=>`<button class="photo" data-action="photo" data-photo-id="${escapeHtml(id)}" aria-label="Mở ảnh ${i+1}"><img data-photo-id="${escapeHtml(id)}" alt="Ảnh ${i+1}"></button>`).join('');
 return `<button class="back" data-action="nav" data-view="list">‹ Trở lại nguồn hàng</button><div class="small-row"><div class="eyebrow">CHI TIẾT NGUỒN HÀNG</div><span class="sm muted">${when(p.updatedAt)}</span></div><h1 class="detail-title">${escapeHtml(p.title||'Nguồn hàng chưa đặt tên')}</h1><div class="tag-row"><span class="pill">${escapeHtml(p.type)}</span><span class="pill orange">${escapeHtml(p.contractStatus)}</span><span class="pill gray">${escapeHtml(p.verification)}</span>${p.archived?'<span class="pill red">Lưu trữ</span>':''}</div>
 <div class="actions" style="margin:14px 0 17px"><button class="primary" data-action="edit" data-id="${escapeHtml(p.id)}">✎ Chỉnh sửa</button>${p.phone?`<a class="secondary" href="tel:${escapeHtml(p.phone.replace(/[^+0-9]/g,''))}">☎ Gọi chủ</a>`:`<button class="secondary" data-action="edit" data-id="${escapeHtml(p.id)}">＋ Điện thoại</button>`}</div>
 <section class="form-card"><h2>Thông tin tài sản</h2>${kv('Địa chỉ',p.address)}${kv('Diện tích',p.area)}${kv('Chiều ngang',p.width)}${kv('Chiều dài',p.length)}${kv('Giá chào',p.price)}${kv('Nguồn phát hiện',p.source)}${p.sourceUrl?`<div class="kv"><dt>Link nguồn</dt><dd><a href="${escapeHtml(safeUrl(p.sourceUrl))}" rel="noopener noreferrer" target="_blank">Mở tin gốc ↗</a></dd></div>`:''}</section>
 <section class="form-card"><h2>Chủ sở hữu & liên hệ</h2>${kv('Người liên hệ',p.owner)}${kv('Số điện thoại',p.phone)}${kv('Trạng thái liên hệ',p.contactStatus)}${kv('Xác minh chính chủ',p.verification)}${kv('Căn cứ xác minh',p.verificationEvidence)}</section>
 <section class="form-card"><h2>Hợp đồng & công việc</h2>${kv('Tình trạng hợp đồng',p.contractStatus)}${kv('Số hợp đồng',p.contractNumber)}${kv('Phí môi giới',p.contractFee)}${kv('Độc quyền',p.exclusive?'Có':'Không')}${kv('Hết hạn hợp đồng',p.contractExpires?when(p.contractExpires):'')}${kv('Trạng thái chào bán',p.saleStatus)}${kv('Công việc tiếp theo',p.nextAction)}${kv('Hạn công việc',p.nextDue?when(p.nextDue):'')}${kv('Cần xử lý biến động',p.marketingNeedsAttention?'Có':'Không')}</section>
 <section class="form-card"><h2>Ảnh tài sản <span class="pill">${(p.imagePaths||[]).length}</span></h2>${imgs?`<div class="photos">${imgs}</div>`:'<p class="muted sm">Chưa có ảnh cho nguồn hàng này.</p>'}</section>
 ${p.rawCapture?`<section class="form-card"><h2>Dữ liệu gốc / mô tả</h2><p class="sm" style="white-space:pre-wrap;overflow-wrap:anywhere">${escapeHtml(p.rawCapture)}</p></section>`:''}
 <section class="form-card"><h2>Nhật ký</h2>${(p.logs||[]).length?(p.logs||[]).slice(0,30).map(l=>`<div class="kv"><dt>${when(l.at)}</dt><dd><b>${escapeHtml(l.action)}</b><div class="sm muted" style="margin-top:5px">${escapeHtml(l.note)}</div></dd></div>`).join(''):'<p class="muted sm">Chưa có nhật ký.</p>'}</section>
 <div class="actions"><button class="secondary" data-action="archive" data-id="${escapeHtml(p.id)}">${p.archived?'↶ Khôi phục hồ sơ':'▤ Lưu trữ hồ sơ'}</button><button class="danger" data-action="delete" data-id="${escapeHtml(p.id)}">Xóa vĩnh viễn</button></div>${footer()}`;}
function safeUrl(u){try{const a=new URL(String(u));return ['http:','https:'].includes(a.protocol)?a.href:'#';}catch{return '#';}}
function field(key,label,p,opt={}){const type=opt.type||'text',v=type==='date'?dateInput(p[key]):String(p[key]??'');const placeholder=opt.placeholder?` placeholder="${escapeHtml(opt.placeholder)}"`:'';
 return `<label class="field"><span>${escapeHtml(label)}${opt.required?' *':''}</span>${opt.multiline?`<textarea name="${key}" rows="${opt.rows||3}"${placeholder}>${escapeHtml(v)}</textarea>`:`<input name="${key}" type="${type}" value="${escapeHtml(v)}"${placeholder}${opt.required?' required':''} autocomplete="off">`}</label>`;}
function selectField(key,label,p,choices){const current=p[key]??'';const opts=[...new Set([...choices,current].filter(x=>String(x).length))];return `<label class="field"><span>${escapeHtml(label)}</span><select name="${key}">${opts.map(x=>`<option value="${escapeHtml(x)}" ${x===current?'selected':''}>${escapeHtml(x)}</option>`).join('')}</select></label>`;}
function checkboxField(key,label,p){return `<label class="check"><input type="checkbox" name="${key}" ${p[key]?'checked':''}><span>${escapeHtml(label)}</span></label>`;}
function editor(){const p=state.draft;return `<button class="back" data-action="cancel-edit">‹ Hủy và quay lại</button><div class="view-head" style="padding-top:6px"><div class="eyebrow">NHẬP LIỆU THỦ CÔNG</div><h1>${state.editing?'Chỉnh sửa nguồn hàng':'Tạo nguồn hàng mới'}</h1><p class="muted sm">Thông tin được lưu trên iPhone. Chỉ điền những trường bạn đã xác thực.</p></div>
 <form id="listing-form"><section class="form-card"><h2><span class="step">PHẦN 01</span>Thông tin tài sản</h2>${field('title','Tên nguồn hàng',p,{required:true,placeholder:'Ví dụ: Nhà mặt tiền Đường 23'})}${selectField('type','Loại bất động sản',p,TYPES)}${field('address','Địa chỉ bất động sản',p)}<div class="twocol">${field('area','Diện tích',p,{placeholder:'120 m²'})}${field('price','Giá chào',p,{placeholder:'12 tỷ'})}</div><div class="twocol">${field('width','Chiều ngang',p,{placeholder:'6 m'})}${field('length','Chiều dài',p,{placeholder:'20 m'})}</div>${selectField('source','Nguồn phát hiện',p,SOURCES)}${field('sourceUrl','Link tin gốc',p,{type:'url',placeholder:'https://...'})}</section>
 <section class="form-card"><h2><span class="step">PHẦN 02</span>Chủ tài sản và liên hệ</h2>${field('owner','Tên người liên hệ / chủ tài sản',p)}${field('phone','Số điện thoại',p,{type:'tel',placeholder:'09xxxxxxxx'})}${selectField('contactStatus','Trạng thái liên hệ',p,CONTACTS)}${selectField('verification','Xác minh chính chủ',p,VERIFIED)}${field('verificationEvidence','Căn cứ xác minh',p,{multiline:true,rows:2})}</section>
 <section class="form-card"><h2><span class="step">PHẦN 03</span>Hình ảnh tài sản</h2><div class="small-row"><span class="sm muted">Đính kèm tối đa 40 ảnh / nguồn hàng</span><span class="pill gray" id="photoCount">0 ảnh</span></div><div id="editorPhotos" class="photos" style="margin-top:12px"></div><input type="file" id="photoFiles" accept="image/*" multiple hidden><input type="file" id="cameraFile" accept="image/*" capture="environment" hidden><p class="sm muted" style="margin:12px 0 0">Ảnh được nén để tiết kiệm dung lượng; không tải lên máy chủ. Chưa tự động OCR ở phiên bản web này.</p></section>
 <section class="form-card"><h2><span class="step">PHẦN 04</span>Hợp đồng & theo dõi</h2>${selectField('contractStatus','Trạng thái hợp đồng',p,CONTRACTS)}${field('contractNumber','Số hợp đồng môi giới',p)}${field('contractFee','Phí môi giới (%)',p)}${checkboxField('exclusive','Hợp đồng độc quyền',p)}${field('contractExpires','Ngày hết hạn hợp đồng',p,{type:'date'})}${selectField('saleStatus','Trạng thái chào bán',p,SALES)}${field('nextAction','Công việc tiếp theo',p)}${field('nextDue','Hạn xử lý',p,{type:'date'})}${checkboxField('marketingNeedsAttention','Có biến động cần xử lý',p)}</section>
 <section class="form-card"><h2><span class="step">PHẦN 05</span>Mô tả / dữ liệu gốc</h2>${field('rawCapture','Mô tả và ghi chú nguồn',p,{multiline:true,rows:5,placeholder:'Ghi chú hiện trạng, pháp lý, tiện ích...'})}<p class="note">Giọng nói và OCR sẽ được bổ sung sau khi phiên bản web quản lý dữ liệu ổn định. Không có dữ liệu nào tự được coi là “chính chủ” nếu chưa xác minh.</p></section>
 <div class="sticky-submit"><div class="actions"><button type="button" class="secondary" data-action="cancel-edit">Hủy</button><button type="submit" class="primary" id="saveButton">✓ Lưu nguồn hàng</button></div></div></form>${footer()}`;}
function busy(on,msg='Đang xử lý dữ liệu...'){state.busy=on;let el=$('#busyOverlay');if(on&&!el){el=document.createElement('div');el.id='busyOverlay';el.className='modal-bg';el.innerHTML=`<div class="card" style="max-width:300px;text-align:center"><div class="spinner"></div><p style="margin:14px 0">${escapeHtml(msg)}</p><span class="sm muted">Vui lòng không đóng trang</span></div>`;document.body.append(el);}else if(!on&&el){el.remove();}}
function releaseUrls(){for(const u of state.objectUrls)URL.revokeObjectURL(u);state.objectUrls=[];}
async function hydrateImages(root=document){const targets=Array.from(root.querySelectorAll('img[data-photo-id]'));for(const el of targets){const id=el.dataset.photoId;if(!id)continue;const pending=state.photoPending.find(p=>p.id===id);const photo=pending?{blob:pending.blob}:await readPhoto(id);if(!photo?.blob)continue;const url=URL.createObjectURL(photo.blob);state.objectUrls.push(url);el.src=url;}}
async function draw(){releaseUrls();const view=({dashboard,list:listingScreen,attention:attentionScreen,data:dataScreen,detail,form:editor})[state.view]||dashboard;
 $('#app').innerHTML=header()+`<main class="shell">${view()}</main>`+nav();
 if(state.view==='form')await renderEditorPhotos();else await hydrateImages($('#app'));
 window.scrollTo({top:0,behavior:'auto'});
}
async function show(view){state.view=view;await draw();}
async function showForm(id){state.editing=id||null;const src=id?state.items.find(x=>x.id===id):null;if(id&&!src){toast('Không tìm thấy hồ sơ');return;}state.draft=src?clone(src):newListing();state.photoPending=[];state.photoRemoved=new Set();state.formImageIds=Array.from(state.draft.imagePaths||[]);await show('form');}
async function renderEditorPhotos(){const el=$('#editorPhotos');if(!el)return;const count=state.formImageIds.length;$('#photoCount').textContent=`${count} ảnh`;
 el.innerHTML=state.formImageIds.map((id,i)=>`<div class="photo"><img alt="Ảnh ${i+1}" data-photo-id="${escapeHtml(id)}"><button type="button" data-action="remove-photo" data-photo-id="${escapeHtml(id)}" aria-label="Bỏ ảnh">×</button></div>`).join('')+`<button type="button" class="photo pick" data-action="pick-photos"><strong>＋</strong>Chọn ảnh</button><button type="button" class="photo pick" data-action="camera"><strong>◎</strong>Chụp ảnh</button>`;
 const oldUrls=state.objectUrls.splice(0);oldUrls.forEach(u=>URL.revokeObjectURL(u));await hydrateImages(el);
}
async function processImage(file){if(!file.type.startsWith('image/')&&!/\.(heic|heif|jpg|jpeg|png|webp)$/i.test(file.name)){throw new Error('Chỉ nhận tệp ảnh');}
 if(file.size>35*1024*1024)throw new Error('Ảnh quá lớn (>35 MB): '+file.name);
 // Downsize photos so large iPhone galleries don't exhaust storage. If Safari cannot decode HEIC, retain original.
 try{const src=URL.createObjectURL(file);try{const img=new Image();img.src=src;await img.decode();const max=1900,scale=Math.min(1,max/Math.max(img.naturalWidth,img.naturalHeight));if(!img.naturalWidth||!img.naturalHeight)throw new Error('Không đọc được kích thước');const canvas=document.createElement('canvas');canvas.width=Math.max(1,Math.round(img.naturalWidth*scale));canvas.height=Math.max(1,Math.round(img.naturalHeight*scale));canvas.getContext('2d').drawImage(img,0,0,canvas.width,canvas.height);const blob=await new Promise(ok=>canvas.toBlob(ok,'image/jpeg',.82));if(!blob)throw new Error('Không thể nén ảnh');return blob;}finally{URL.revokeObjectURL(src);}}catch{return file;}
}
async function addPhotos(fileList){const files=Array.from(fileList||[]);if(!files.length)return;if(state.formImageIds.length+files.length>40){toast('Tối đa 40 ảnh mỗi hồ sơ');return;}
 busy(true,'Đang chuẩn bị ảnh...');let ok=0;try{for(const f of files){try{const blob=await processImage(f);const id=`web-photo-${uid()}.${blob.type==='image/jpeg'?'jpg':(f.name.split('.').pop()||'jpg')}`;state.photoPending.push({id,blob,name:f.name});state.formImageIds.push(id);ok++;}catch(e){toast('Không đọc được '+f.name+': '+errMessage(e));}}}finally{busy(false);}await renderEditorPhotos();toast(`Đã thêm ${ok}/${files.length} ảnh. Nhấn Lưu nguồn hàng để ghi dữ liệu.`);}
async function saveForm(form){if(state.busy)return;const fd=new FormData(form);const p=state.draft;for(const key of ['title','type','address','area','width','length','price','source','sourceUrl','owner','phone','verification','verificationEvidence','contactStatus','contractStatus','saleStatus','contractNumber','contractFee','nextAction','rawCapture'])p[key]=String(fd.get(key)||'').trim();
 p.exclusive=fd.has('exclusive');p.marketingNeedsAttention=fd.has('marketingNeedsAttention');p.contractExpires=fd.get('contractExpires')?`${fd.get('contractExpires')}T12:00:00`:null;p.nextDue=fd.get('nextDue')?`${fd.get('nextDue')}T12:00:00`:null;
 if(!p.title){toast('Bạn cần nhập tên nguồn hàng');form.querySelector('[name=title]')?.focus();return;}
 p.imagePaths=[...state.formImageIds];p.imagePath=p.imagePaths[0]||'';p.updatedAt=stamp();p.logs=Array.isArray(p.logs)?p.logs:[];p.logs.unshift({id:uid(),at:stamp(),action:state.editing?'Cập nhật nguồn hàng':'Tạo nguồn hàng',note:`Đã lưu thông tin và ${p.imagePaths.length} ảnh (SourceFlow Web).`});
 busy(true,'Đang lưu hồ sơ và ảnh...');try{await writeListing(p,state.photoPending,Array.from(state.photoRemoved));state.photoPending=[];state.photoRemoved=new Set();state.selected=p.id;state.draft=null;state.editing=null;await show('detail');toast('Đã lưu nguồn hàng trên thiết bị.');}catch(e){toast('Lưu thất bại: '+errMessage(e));console.error(e);}finally{busy(false);}
}
function openPhoto(url){let overlay=document.createElement('div');overlay.className='modal-bg';overlay.id='lightbox';overlay.innerHTML=`<button class="modal-close" aria-label="Đóng ảnh" data-action="close-modal">×</button><div class="modal-content"><img src="${escapeHtml(url)}" alt="Ảnh tài sản phóng to"><small>Chạm × để đóng</small></div>`;document.body.append(overlay);}
async function photoModal(id){const pending=state.photoPending.find(p=>p.id===id),p=pending?{blob:pending.blob}:await readPhoto(id);if(!p?.blob){toast('Ảnh không còn trong bộ nhớ của thiết bị');return;}const url=URL.createObjectURL(p.blob);state.objectUrls.push(url);openPhoto(url);}
function triggerFileDownload(blob,name){const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),60000);}
function blobToB64(blob){return new Promise((ok,fail)=>{const reader=new FileReader();reader.onload=()=>ok(String(reader.result).split(',')[1]||'');reader.onerror=()=>fail(reader.error);reader.readAsDataURL(blob);});}
async function b64ToBlob(b64,type='image/jpeg'){if(!/^[a-zA-Z0-9+/=\s]*$/.test(b64))throw new Error('Dữ liệu ảnh không hợp lệ');const str=atob(b64.replace(/\s/g,'')),bytes=new Uint8Array(str.length);for(let i=0;i<str.length;i++)bytes[i]=str.charCodeAt(i);return new Blob([bytes],{type});}
async function exportBackup(withPhotos){if(state.busy)return;busy(true,'Đang xuất hồ sơ và ảnh...');try{
 const photos={},listings=state.items.map(clone);if(withPhotos){for(const p of listings){for(let i=0;i<(p.imagePaths||[]).length;i++){const record=await readPhoto(p.imagePaths[i]);if(record?.blob)photos[`${p.id}/${i}`]=await blobToB64(record.blob);}}}else{for(const p of listings){p.imagePaths=[];p.imagePath='';}}
 const payload=JSON.stringify({schema:3,createdAt:stamp(),source:'SourceFlow Web PWA',listings,photos});const name='sourceflow_web_'+new Date().toISOString().slice(0,10).replace(/-/g,'');let blob,ext;
 if('CompressionStream' in window){blob=await new Response(new Blob([payload],{type:'application/json'}).stream().pipeThrough(new CompressionStream('gzip'))).blob();ext='sfbackup';}else{blob=new Blob([payload],{type:'application/json'});ext='json';}
 triggerFileDownload(blob,`${name}${withPhotos?'_with_photos':'_records_only'}.${ext}`);toast(`Đã tạo bản sao lưu ${listings.length} hồ sơ. Hãy lưu ngoài thiết bị.`);
 }catch(e){toast('Không xuất được sao lưu: '+errMessage(e));console.error(e);}finally{busy(false);}}
async function unpackBackup(file){if(file.size>160*1024*1024)throw new Error('Tệp >160MB: quá lớn cho một lần khôi phục trên điện thoại');const magic=new Uint8Array(await file.slice(0,3).arrayBuffer());
 let text;
 if(magic[0]===0x1f&&magic[1]===0x8b){if(!('DecompressionStream' in window))throw new Error('Safari hiện tại không hỗ trợ giải nén .sfbackup. Hãy nâng cấp iOS/Safari hoặc cung cấp bản JSON.');text=await new Response(file.stream().pipeThrough(new DecompressionStream('gzip'))).text();}
 else{text=await file.text();}
 let root;try{root=JSON.parse(text);}catch{throw new Error('Tệp không phải sao lưu JSON/SourceFlow hợp lệ');}
 if(Array.isArray(root))root={listings:root,photos:{}};
 if(!root||typeof root!=='object'||!Array.isArray(root.listings))throw new Error('Không tìm thấy danh sách listings trong tệp');
 if(root.listings.length>50000)throw new Error('Tệp có quá 50.000 hồ sơ');
 return root;
}
async function importBackup(file){if(state.busy)return;busy(true,'Đang đọc và kiểm tra bản sao lưu...');try{const root=await unpackBackup(file),items=root.listings,photos=root.photos&&typeof root.photos==='object'?root.photos:{};busy(false);
 const proceed=window.confirm(`Khôi phục ${items.length} nguồn hàng từ ${file.name}?\n\nHồ sơ có ID trùng sẽ được CẬP NHẬT theo tệp sao lưu. Hồ sơ không trùng sẽ được thêm. Ảnh đính kèm có trong tệp sẽ được lưu trên thiết bị.\n\nHãy sao lưu dữ liệu hiện tại trước nếu chưa làm.`);if(!proceed)return;
 busy(true,`Đang khôi phục ${items.length} hồ sơ...`);let n=0,restoredImages=0;const currentById=new Map(state.items.map(x=>[x.id,x]));
 for(const entry of items){if(!entry||typeof entry!=='object')continue;const raw=clone(entry),id=String(raw.id||uid());const existing=currentById.get(id);const p={...newListing(),...existing,...raw,id};p.logs=Array.isArray(raw.logs)?raw.logs:[];p.posts=Array.isArray(raw.posts)?raw.posts:[];p.offers=Array.isArray(raw.offers)?raw.offers:[];const newPhotos=[],paths=[];
 let oldPaths=Array.isArray(raw.imagePaths)?raw.imagePaths:[];if(!oldPaths.length&&raw.imagePath)oldPaths=[raw.imagePath];
 for(let i=0;i<oldPaths.length;i++){const b64=photos[`${id}/${i}`];if(typeof b64==='string'&&b64.length){const ext=String(oldPaths[i]).toLowerCase();const type=ext.endsWith('.png')?'image/png':ext.endsWith('.webp')?'image/webp':'image/jpeg';const blob=await b64ToBlob(b64,type);const key=`web-photo-${uid()}.${type==='image/png'?'png':type==='image/webp'?'webp':'jpg'}`;newPhotos.push({id:key,blob,name:key});paths.push(key);restoredImages++;}else if(existing?.imagePaths?.[i]){const old=await readPhoto(existing.imagePaths[i]);if(old)paths.push(existing.imagePaths[i]);}}
 if(paths.length===0 && existing?.imagePaths?.length && !oldPaths.length){paths.push(...existing.imagePaths);}
 p.imagePaths=paths;p.imagePath=paths[0]||'';const oldImageIds=existing?.imagePaths?.filter(x=>!paths.includes(x))||[];
 await writeListing(p,newPhotos,oldImageIds,true);currentById.set(id,p);n++;
 }
 await loadItems();await show('data');toast(`Đã khôi phục ${n} hồ sơ và ${restoredImages} ảnh.`);
 }catch(e){toast('Khôi phục thất bại: '+errMessage(e));console.error(e);}finally{busy(false);}}
const app=$('#app');
app.addEventListener('click',async event=>{const t=event.target.closest('[data-action]');if(!t||state.busy)return;event.preventDefault();const action=t.dataset.action,id=t.dataset.id;
 try{if(action==='nav')await show(t.dataset.view);
 else if(action==='new')await showForm();
 else if(action==='filter'){state.filter=t.dataset.filter;state.query='';state.shown=40;await show('list');}
 else if(action==='more'){state.shown+=40;$('#listResults').innerHTML=listResults();await hydrateImages($('#listResults'));}
 else if(action==='detail'){state.selected=id;await show('detail');}
 else if(action==='edit')await showForm(id);
 else if(action==='cancel-edit'){const yes=window.confirm('Hủy nhập liệu và bỏ các thay đổi chưa lưu?');if(yes){state.photoPending=[];state.draft=null;await show(state.editing?'detail':'list');}}
 else if(action==='pick-photos')$('#photoFiles').click();
 else if(action==='camera')$('#cameraFile').click();
 else if(action==='remove-photo'){const photoId=t.dataset.photoId;state.formImageIds=state.formImageIds.filter(x=>x!==photoId);const pi=state.photoPending.findIndex(x=>x.id===photoId);if(pi>=0)state.photoPending.splice(pi,1);else state.photoRemoved.add(photoId);await renderEditorPhotos();}
 else if(action==='photo')await photoModal(t.dataset.photoId);
 else if(action==='close-modal'){$('#lightbox')?.remove();}
 else if(action==='archive'){const p=state.items.find(x=>x.id===id);if(p){p.archived=!p.archived;p.updatedAt=stamp();await writeListing(p);await show('detail');toast(p.archived?'Đã chuyển vào lưu trữ':'Đã phục hồi nguồn hàng');}}
 else if(action==='delete'){const p=state.items.find(x=>x.id===id);if(p&&window.confirm(`Xóa vĩnh viễn nguồn hàng “${p.title}” cùng toàn bộ ảnh trên máy? Hành động này không thể hoàn tác.`)){await removeListingHard(p);state.selected=null;await show('list');toast('Đã xóa hồ sơ và ảnh.');}}
 else if(action==='backup')await exportBackup(true);
 else if(action==='backup-metadata')await exportBackup(false);
 else if(action==='restore')$('#restoreFile').click();
 }catch(e){toast('Có lỗi: '+errMessage(e));console.error(e);}
});
app.addEventListener('submit',async e=>{if(e.target?.id!=='listing-form')return;e.preventDefault();await saveForm(e.target);});
app.addEventListener('change',async e=>{if(e.target.id==='filter'){state.filter=e.target.value;state.shown=40;$('#listResults').innerHTML=listResults();await hydrateImages($('#listResults'));}
 if(e.target.id==='photoFiles'||e.target.id==='cameraFile'){await addPhotos(e.target.files);e.target.value='';}});
app.addEventListener('input',e=>{if(e.target.id!=='search')return;state.query=e.target.value;state.shown=40;const r=$('#listResults');if(r){releaseUrls();r.innerHTML=listResults();hydrateImages(r).catch(console.error);}});
$('#restoreFile').addEventListener('change',async e=>{const f=e.target.files?.[0];e.target.value='';if(f)await importBackup(f);});
document.addEventListener('click',e=>{if(e.target?.id==='lightbox')$('#lightbox')?.remove();});
window.addEventListener('error',e=>{console.error(e.error);toast('Ứng dụng gặp lỗi. Hãy sao lưu nếu vẫn truy cập được dữ liệu.');});
(async()=>{try{state.db=await openDB();await loadItems();await draw();if('serviceWorker' in navigator&&location.protocol==='https:'){navigator.serviceWorker.register('./sw.js').catch(console.warn);}else if(location.hostname==='localhost'||location.hostname==='127.0.0.1'){navigator.serviceWorker?.register('./sw.js').catch(console.warn);}}
catch(e){console.error(e);$('#app').innerHTML=`<section class="shell" style="padding-top:40px"><div class="empty"><div class="big">!</div><h3>Không mở được bộ nhớ dữ liệu</h3><p>${escapeHtml(errMessage(e))}</p><p>Hãy thử mở bằng Safari thông thường hoặc kiểm tra chế độ duyệt web riêng tư.</p></div></section>`;}})();
