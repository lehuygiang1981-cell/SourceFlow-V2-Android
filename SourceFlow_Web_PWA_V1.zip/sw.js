const CACHE='sourceflow-web-v1-20261017b';
const SHELL=['./','./index.html','./styles.css','./app.js','./manifest.webmanifest','./icons/icon-192.png','./icons/icon-512.png'];
self.addEventListener('install',event=>{event.waitUntil(caches.open(CACHE).then(c=>c.addAll(SHELL)).then(()=>self.skipWaiting()));});
self.addEventListener('activate',event=>{event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim()));});
self.addEventListener('fetch',event=>{if(event.request.method!=='GET'||new URL(event.request.url).origin!==self.location.origin)return;
  event.respondWith(fetch(event.request).then(res=>{if(res.ok && (event.request.mode==='navigate'||SHELL.some(p=>new URL(p,self.registration.scope).href===event.request.url))) {const clone=res.clone();caches.open(CACHE).then(c=>c.put(event.request,clone));}return res;}).catch(()=>caches.match(event.request).then(r=>r||caches.match('./index.html'))));
});
