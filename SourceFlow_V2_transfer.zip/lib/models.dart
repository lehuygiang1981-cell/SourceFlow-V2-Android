import 'dart:math';

String newId() => '${DateTime.now().microsecondsSinceEpoch}-${Random().nextInt(999999)}';

String dateLabel(DateTime? d) => d == null ? 'Chưa đặt' : '${d.day.toString().padLeft(2,'0')}/${d.month.toString().padLeft(2,'0')}/${d.year}';

class WorkLog {
  final String id;
  final DateTime at;
  final String action;
  final String note;

  const WorkLog({required this.id, required this.at, required this.action, required this.note});
  Map<String, dynamic> toJson() => {'id': id, 'at': at.toIso8601String(), 'action': action, 'note': note};
  factory WorkLog.fromJson(Map<String, dynamic> x) => WorkLog(
    id: '${x['id'] ?? newId()}',
    at: DateTime.tryParse('${x['at']}') ?? DateTime.now(),
    action: '${x['action'] ?? ''}', note: '${x['note'] ?? ''}',
  );
}


class MarketingPost {
  final String channel, url, status;
  final DateTime added;
  MarketingPost({required this.channel, this.url='', this.status='Đang đăng',DateTime? added}):added=added??DateTime.now();
  Map<String,dynamic> toJson()=>{'channel':channel,'url':url,'status':status,'added':added.toIso8601String()};
  factory MarketingPost.fromJson(Map<String,dynamic> x)=>MarketingPost(channel:'${x['channel']??''}',
    url:'${x['url']??''}',status:'${x['status']??'Đang đăng'}',added:DateTime.tryParse('${x['added']}'));
}
class BuyerOffer {
  final String buyer,contact,offer,note;
  final DateTime added;
  BuyerOffer({required this.buyer,this.contact='',this.offer='',this.note='',DateTime? added}):added=added??DateTime.now();
  Map<String,dynamic> toJson()=>{'buyer':buyer,'contact':contact,'offer':offer,'note':note,'added':added.toIso8601String()};
  factory BuyerOffer.fromJson(Map<String,dynamic> x)=>BuyerOffer(buyer:'${x['buyer']??''}',
    contact:'${x['contact']??''}',offer:'${x['offer']??''}',note:'${x['note']??''}',added:DateTime.tryParse('${x['added']}'));
}

class Listing {
  final String id;
  DateTime createdAt;
  DateTime updatedAt;
  String title;
  String type;
  String address;
  String area;
  String price;
  String source;
  String sourceUrl;
  String owner;
  String phone;
  String verification;
  String verificationEvidence;
  String contactStatus;
  String contractStatus;
  String saleStatus;
  String contractNumber;
  String contractFee;
  bool exclusive;
  DateTime? contractExpires;
  List<MarketingPost> posts;
  List<BuyerOffer> offers;
  String nextAction;
  DateTime? nextDue;
  bool marketingNeedsAttention;
  bool archived;
  String rawCapture;
  String imagePath;
  List<WorkLog> logs;

  Listing({
    String? id, DateTime? createdAt, DateTime? updatedAt,
    this.title='', this.type='Nhà riêng', this.address='', this.area='', this.price='',
    this.source='Khảo sát thực tế', this.sourceUrl='', this.owner='', this.phone='',
    this.verification='Chưa xác minh', this.verificationEvidence='',
    this.contactStatus='Chưa liên hệ', this.contractStatus='Chưa ký',
    this.saleStatus='Chưa chào bán', this.contractNumber='', this.contractFee='',
    this.exclusive=false, this.contractExpires, List<MarketingPost>? posts, List<BuyerOffer>? offers,
    this.nextAction='', this.nextDue,
    this.marketingNeedsAttention=false, this.archived=false,
    this.rawCapture='', this.imagePath='', List<WorkLog>? logs,
  }) : id = id ?? newId(), createdAt = createdAt ?? DateTime.now(),
       updatedAt = updatedAt ?? DateTime.now(), logs = logs ?? [], posts=posts??[],offers=offers??[];

  void addLog(String action, String note) {
    logs.insert(0, WorkLog(id: newId(), at: DateTime.now(), action: action, note: note));
    updatedAt = DateTime.now();
  }

  Map<String, dynamic> toJson() => {
    'id':id,'createdAt':createdAt.toIso8601String(),'updatedAt':updatedAt.toIso8601String(),
    'title':title,'type':type,'address':address,'area':area,'price':price,
    'source':source,'sourceUrl':sourceUrl,'owner':owner,'phone':phone,
    'verification':verification,'verificationEvidence':verificationEvidence,
    'contactStatus':contactStatus,'contractStatus':contractStatus,'saleStatus':saleStatus,
    'contractNumber':contractNumber,'contractFee':contractFee,'exclusive':exclusive,
    'contractExpires':contractExpires?.toIso8601String(),
    'posts':posts.map((e)=>e.toJson()).toList(),'offers':offers.map((e)=>e.toJson()).toList(),
    'nextAction':nextAction,'nextDue':nextDue?.toIso8601String(),
    'marketingNeedsAttention':marketingNeedsAttention,'archived':archived,
    'rawCapture':rawCapture,'imagePath':imagePath,
    'logs':logs.map((e)=>e.toJson()).toList(),
  };

  factory Listing.fromJson(Map<String,dynamic> x) {
    String s(String key, String fallback) => (x[key] ?? fallback).toString();
    return Listing(
      id:s('id',newId()),
      createdAt:DateTime.tryParse(s('createdAt','')),
      updatedAt:DateTime.tryParse(s('updatedAt','')),
      title:s('title',''),type:s('type','Nhà riêng'),address:s('address',''),
      area:s('area',''),price:s('price',''),source:s('source','Khảo sát thực tế'),
      sourceUrl:s('sourceUrl',''),owner:s('owner',''),phone:s('phone',''),
      verification:s('verification','Chưa xác minh'),
      verificationEvidence:s('verificationEvidence',''),
      contactStatus:s('contactStatus','Chưa liên hệ'),
      contractStatus:s('contractStatus','Chưa ký'), saleStatus:s('saleStatus','Chưa chào bán'),
      contractNumber:s('contractNumber',''),contractFee:s('contractFee',''),
      exclusive:x['exclusive']==true,contractExpires:DateTime.tryParse(s('contractExpires','')),
      posts:(x['posts'] is List? x['posts'] as List:[]).whereType<Map>().map((e)=>MarketingPost.fromJson(Map<String,dynamic>.from(e))).toList(),
      offers:(x['offers'] is List? x['offers'] as List:[]).whereType<Map>().map((e)=>BuyerOffer.fromJson(Map<String,dynamic>.from(e))).toList(),
      nextAction:s('nextAction',''), nextDue:DateTime.tryParse(s('nextDue','')),
      marketingNeedsAttention:x['marketingNeedsAttention'] == true,
      archived:x['archived'] == true,
      rawCapture:s('rawCapture',''),imagePath:s('imagePath',''),
      logs:(x['logs'] is List ? x['logs'] as List : []).whereType<Map>().map((e)=>WorkLog.fromJson(Map<String,dynamic>.from(e))).toList(),
    );
  }
}

class Attention {
  final Listing listing;
  final String reason;
  final int priority;
  const Attention(this.listing,this.reason,this.priority);
}

/// Quét tất cả hồ sơ mỗi khi tải dữ liệu hoặc thay đổi một nguồn hàng.
/// Không nhắc trường hợp đã ký và chào bán ổn định; chưa ký luôn hiển thị,
/// kể cả khi lịch gọi lại là ngày tương lai (nhãn "theo dõi" không giả là quá hạn).
Attention? attentionFor(Listing p, DateTime now) {
  if (p.archived || p.saleStatus == 'Đã giao dịch') return null;
  if (p.contractStatus == 'Đã ký') {
    if (!p.marketingNeedsAttention) return null;
    return Attention(p,p.nextAction.isNotEmpty?p.nextAction:'Xử lý biến động chào bán',1);
  }
  if (p.contactStatus == 'Chưa liên hệ') return Attention(p,'Chưa liên hệ chủ – cần gọi xác minh',0);
  if (p.nextDue != null && p.nextDue!.isBefore(DateTime(now.year,now.month,now.day))) {
    return Attention(p,p.nextAction.isEmpty?'Công việc quá hạn':p.nextAction,0);
  }
  if (p.nextAction.isEmpty) return Attention(p,'Chưa ký hợp đồng – cần xác định bước tiếp theo',2);
  final future = p.nextDue != null && p.nextDue!.isAfter(DateTime(now.year,now.month,now.day,23,59,59));
  return Attention(p, future?'Theo dõi: ${p.nextAction} (${dateLabel(p.nextDue)})':p.nextAction,future?3:1);
}

List<Attention> attentionForAll(Iterable<Listing> items, DateTime now) {
  final list = items.map((x)=>attentionFor(x,now)).whereType<Attention>().toList();
  list.sort((a,b){final c=a.priority.compareTo(b.priority); return c != 0 ? c : b.listing.updatedAt.compareTo(a.listing.updatedAt);});
  return list;
}

class ParsedIntake {
  final String title, address, area, price, phone;
  const ParsedIntake({this.title='',this.address='',this.area='',this.price='',this.phone=''});
}

/// Chỉ bóc tách mẫu có căn cứ rõ từ văn bản OCR/giọng nói; không đoán giá trị còn thiếu.
ParsedIntake parseIntake(String input) {
  final t = input.replaceAll('\r','\n').trim();
  final lines = t.split('\n').map((e)=>e.trim()).where((e)=>e.isNotEmpty).toList();
  String area='',price='',phone='',address='';
  final areaMatch=RegExp(r'(\d{2,5}(?:[.,]\d+)?)\s*(?:m²|m2|mét vuông)',caseSensitive:false).firstMatch(t);
  if(areaMatch!=null) area='${areaMatch.group(1)} m²';
  final priceMatch=RegExp(r'(\d+(?:[.,]\d+)?)\s*(tỷ|triệu)',caseSensitive:false).firstMatch(t);
  if(priceMatch!=null) price='${priceMatch.group(1)} ${priceMatch.group(2)}';
  for(final m in RegExp(r'(?:\+84|0)[\d.\-\s]{8,16}').allMatches(t)) {
    var candidate=m.group(0)!.replaceAll(RegExp(r'[^0-9+]'),'');
    if(candidate.startsWith('+84')) candidate='0${candidate.substring(3)}';
    if(candidate.length==10 && candidate.startsWith('0')) { phone=candidate;break; }
  }
  for(final line in lines) {
    if(RegExp(r'^(địa chỉ|vị trí)\s*:',caseSensitive:false).hasMatch(line)){
      address=line.replaceFirst(RegExp(r'^(địa chỉ|vị trí)\s*:\s*',caseSensitive:false),'');break;
    }
  }
  String title = lines.isEmpty ? '' : lines.first;
  if (title.length>100) title=title.substring(0,100);
  return ParsedIntake(title:title,address:address,area:area,price:price,phone:phone);
}

const feedbackOptions = [
  'Đã gọi – chưa nghe máy',
  'Đã liên hệ – hẹn gọi lại',
  'Chủ đồng ý gặp',
  'Đang thương lượng ký hợp đồng',
  'Đã ký hợp đồng môi giới',
  'Chủ chưa đồng ý ký',
  'Có biến động chào bán',
  'Đã xử lý biến động chào bán',
  'Ngừng khai thác nguồn hàng',
];

/// Tự cập nhật tiến độ sau khi môi giới ghi nhận phản hồi, không tự xác minh chính chủ.
void applyFeedback(Listing p, String outcome, String note, {String? nextAction, DateTime? due}) {
  final now = DateTime.now();
  String suggested='';
  DateTime? suggestedDue;
  switch(outcome) {
    case 'Đã gọi – chưa nghe máy':
      p.contactStatus='Chưa liên hệ được'; suggested='Gọi lại chủ tài sản';
      suggestedDue=now.add(const Duration(days:1));
      break;
    case 'Đã liên hệ – hẹn gọi lại':
      p.contactStatus='Đã liên hệ'; suggested='Liên hệ lại chủ tài sản';
      suggestedDue=now.add(const Duration(days:3));
      break;
    case 'Chủ đồng ý gặp':
      p.contactStatus='Đã hẹn gặp'; suggested='Gặp chủ tài sản';
      suggestedDue=now.add(const Duration(days:1));
      break;
    case 'Đang thương lượng ký hợp đồng':
      p.contactStatus='Đang đàm phán'; suggested='Chốt điều kiện ký môi giới';
      suggestedDue=now.add(const Duration(days:2));
      break;
    case 'Đã ký hợp đồng môi giới':
      p.contactStatus='Đã gặp / làm việc'; p.contractStatus='Đã ký';
      p.saleStatus='Chuẩn bị chào bán'; p.marketingNeedsAttention=false;
      break;
    case 'Chủ chưa đồng ý ký':
      p.contactStatus='Đã liên hệ'; suggested='Hỏi lại chủ về hợp đồng';
      suggestedDue=now.add(const Duration(days:7));
      break;
    case 'Có biến động chào bán':
      p.marketingNeedsAttention=true;
      suggested='Kiểm tra thay đổi giá, trạng thái và nội dung chào bán';
      suggestedDue=now;
      break;
    case 'Đã xử lý biến động chào bán':
      p.marketingNeedsAttention=false; p.saleStatus='Đang chào bán';
      break;
    case 'Ngừng khai thác nguồn hàng':
      p.archived=true;
      break;
  }
  if (p.archived || (p.contractStatus=='Đã ký'&&!p.marketingNeedsAttention)) {
    p.nextAction=''; p.nextDue=null;
  } else {
    p.nextAction=(nextAction??'').trim().isNotEmpty ? nextAction!.trim() : suggested;
    p.nextDue=due ?? suggestedDue;
  }
  p.addLog(outcome,note.trim().isEmpty?'Không có ghi chú thêm':note.trim());
}
