import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:file_picker/file_picker.dart';
import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path/path.dart' as path;
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:speech_to_text/speech_to_text.dart';
import 'package:url_launcher/url_launcher.dart';
import 'models.dart';
import 'storage.dart';
import 'reminders.dart';

const brand=Color(0xff0a746a);
const bg=Color(0xfff5f8f7);

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const SourceFlowApp());
}

class SourceFlowApp extends StatelessWidget {
  const SourceFlowApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title:'SourceFlow V2', debugShowCheckedModeBanner:false,
    theme:ThemeData(useMaterial3:true,colorScheme:ColorScheme.fromSeed(seedColor:brand),
      scaffoldBackgroundColor:bg,
      appBarTheme:const AppBarTheme(backgroundColor:Colors.white,foregroundColor:Color(0xff19322e),centerTitle:false),
      cardTheme:CardThemeData(color:Colors.white,elevation:0,shape:RoundedRectangleBorder(
        borderRadius:BorderRadius.circular(16),side:const BorderSide(color:Color(0xffe0e8e5)))),
      inputDecorationTheme:InputDecorationTheme(border:OutlineInputBorder(borderRadius:BorderRadius.circular(12))),
    ),
    home:const Workspace(),
  );
}

class Workspace extends StatefulWidget {
  const Workspace({super.key});
  @override State<Workspace> createState()=>_WorkspaceState();
}

class _WorkspaceState extends State<Workspace> {
  final ListingStorage store=ListingStorage();
  final MorningReminder reminder=MorningReminder();
  List<Listing> listings=[];
  bool loading=true;
  int tab=0;
  String search='';
  @override void initState(){super.initState();_init();}
  Future<void> _init() async {
    try {
      await store.open();
      final data=await store.all();
      await reminder.initialize();
      await reminder.refresh(data);
      if(mounted) setState(() {listings=data;loading=false;});
    } catch(e) {
      if(mounted){setState(()=>loading=false);message('Không mở được dữ liệu: $e');}
    }
  }
  void message(String msg) {if(mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(msg)));}
  Future<void> save(Listing item) async {
    await store.save(item);
    final latest=await store.all();
    await reminder.refresh(latest);
    if(mounted) setState(()=>listings=latest);
  }
  Future<void> add() async {
    final result=await Navigator.push<Listing>(context,MaterialPageRoute(builder:(_)=>IntakePage(existing:listings)));
    if(result!=null){await save(result);message('Đã thêm nguồn hàng. Có thể mở hồ sơ để xử lý công việc.');}
  }
  Future<Listing?> edit(Listing p) async {
    final result=await Navigator.push<Listing>(context,MaterialPageRoute(builder:(_)=>IntakePage(existing:listings,original:p)));
    if(result!=null){await save(result);message('Đã cập nhật thông tin nguồn hàng');}
    return result;
  }
  void detail(Listing item) async {
    await Navigator.push(context,MaterialPageRoute(builder:(_)=>ListingDetail(listing:item,onSave:save,onEdit:()=>edit(item))));
    if(mounted) setState(() {});
  }
  List<Attention> get attention=>attentionForAll(listings,DateTime.now());
  @override Widget build(BuildContext context) {
    final titles=['Tổng quan','Nguồn hàng','Công việc','Dữ liệu'];
    return Scaffold(
      appBar:AppBar(title:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        const Text('SourceFlow',style:TextStyle(fontWeight:FontWeight.w800)),
        Text(titles[tab],style:const TextStyle(fontSize:12,fontWeight:FontWeight.w400)),
      ]),actions:[IconButton(onPressed:add,tooltip:'Thêm nguồn hàng',icon:const Icon(Icons.add_circle_outline)),const SizedBox(width:8)]),
      body:loading?const Center(child:CircularProgressIndicator()):
        IndexedStack(index:tab,children:[_dashboard(),_inventory(),_tasks(),_settings()]),
      floatingActionButton:tab==3?null:FloatingActionButton.extended(
        onPressed:add,icon:const Icon(Icons.add),label:const Text('Nhập nguồn')),
      bottomNavigationBar:NavigationBar(selectedIndex:tab,onDestinationSelected:(v)=>setState(()=>tab=v),
        destinations:const [
          NavigationDestination(icon:Icon(Icons.space_dashboard_outlined),selectedIcon:Icon(Icons.space_dashboard),label:'Tổng quan'),
          NavigationDestination(icon:Icon(Icons.home_work_outlined),selectedIcon:Icon(Icons.home_work),label:'Nguồn hàng'),
          NavigationDestination(icon:Icon(Icons.event_note_outlined),selectedIcon:Icon(Icons.event_note),label:'Công việc'),
          NavigationDestination(icon:Icon(Icons.settings_outlined),selectedIcon:Icon(Icons.settings),label:'Dữ liệu'),
        ]),
    );
  }
  Widget _dashboard() {
    final unsigned=listings.where((p)=>!p.archived&&p.contractStatus!='Đã ký').length;
    final uncalled=listings.where((p)=>!p.archived&&p.contactStatus=='Chưa liên hệ').length;
    final selling=listings.where((p)=>p.contractStatus=='Đã ký').length;
    return RefreshIndicator(onRefresh:()async {
      final data=await store.all();await reminder.refresh(data);if(mounted)setState(()=>listings=data);
    },child:ListView(padding:const EdgeInsets.all(16),children:[
      const Text('Bảng điều khiển hôm nay',style:TextStyle(fontSize:22,fontWeight:FontWeight.bold)),
      const SizedBox(height:5),
      const Text('Quét toàn bộ nguồn hàng và chỉ hiển thị công việc cần theo dõi.',style:TextStyle(color:Colors.black54)),
      const SizedBox(height:14),
      Row(children:[Expanded(child:_stat('Tổng nguồn',listings.length,Icons.inventory_2_outlined)),const SizedBox(width:8),Expanded(child:_stat('Chưa liên hệ',uncalled,Icons.call_outlined))]),
      const SizedBox(height:8),
      Row(children:[Expanded(child:_stat('Chưa ký HĐ',unsigned,Icons.edit_document)),const SizedBox(width:8),Expanded(child:_stat('Đã ký HĐ',selling,Icons.verified_outlined))]),
      const SizedBox(height:16),
      Card(child:Padding(padding:const EdgeInsets.all(15),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        Row(children:[const Icon(Icons.notifications_active_outlined,color:brand),const SizedBox(width:8),
          Expanded(child:Text('Nguồn cần theo dõi buổi sáng (${attention.length})',style:const TextStyle(fontWeight:FontWeight.bold,fontSize:16)))]),
        const SizedBox(height:5),
        const Text('Đã ký, chào bán ổn định: không nhắc. Hồ sơ chưa ký: vẫn theo dõi, dù lịch hẹn ở ngày sau.',
          style:TextStyle(fontSize:12,color:Colors.black54)),
        const SizedBox(height:10),
        if(attention.isEmpty)const Text('Không có hồ sơ nào cần nhắc.',style:TextStyle(color:brand)),
        ...attention.take(12).map(_attentionTile),
        if(attention.length>12)TextButton(onPressed:()=>setState(()=>tab=2),child:Text('Xem toàn bộ ${attention.length} hồ sơ →')),
      ]))),
      const SizedBox(height:80),
    ]));
  }
  Widget _stat(String label,int value,IconData icon)=>Card(child:Padding(padding:const EdgeInsets.all(13),child:Column(
    crossAxisAlignment:CrossAxisAlignment.start,children:[Icon(icon,color:brand),const SizedBox(height:7),
      Text('$value',style:const TextStyle(fontSize:28,fontWeight:FontWeight.w800)),Text(label,style:const TextStyle(fontSize:12,color:Colors.black54))])));
  Widget _attentionTile(Attention a) => Column(children:[
    ListTile(contentPadding:EdgeInsets.zero,dense:true,
      leading:CircleAvatar(backgroundColor:a.priority==0?const Color(0xffffe9d5):const Color(0xffe6f3f0),
        child:Icon(a.priority==0?Icons.priority_high:Icons.assignment_outlined,color:brand)),
      title:Text(a.listing.title,style:const TextStyle(fontWeight:FontWeight.w600),maxLines:2),
      subtitle:Text(a.reason,maxLines:2,overflow:TextOverflow.ellipsis),
      trailing:const Icon(Icons.chevron_right),onTap:()=>detail(a.listing)),
    const Divider(height:1)
  ]);
  Widget _inventory()=>ListView(padding:const EdgeInsets.all(16),children:[
    TextField(decoration:const InputDecoration(prefixIcon:Icon(Icons.search),hintText:'Tìm địa chỉ, tên chủ, số điện thoại...'),
      onChanged:(x)=>setState(()=>search=x)),const SizedBox(height:10),
    Text('${listings.length} nguồn hàng',style:const TextStyle(fontWeight:FontWeight.bold)),
    ...listings.where((p)=>('${p.title} ${p.address} ${p.owner} ${p.phone}').toLowerCase().contains(search.toLowerCase())).map((p)=>Card(
      child:ListTile(title:Text(p.title,style:const TextStyle(fontWeight:FontWeight.w600)),
        subtitle:Text('${p.address}\n${p.price.isEmpty?'Chưa có giá':p.price} • ${p.contractStatus}${p.archived?' • Dừng khai thác':''}'),
        isThreeLine:true,trailing:const Icon(Icons.chevron_right),onTap:()=>detail(p)))),
    const SizedBox(height:90),
  ]);
  Widget _tasks()=>ListView(padding:const EdgeInsets.all(16),children:[
    Text('${attention.length} nguồn hàng cần theo dõi',style:const TextStyle(fontSize:20,fontWeight:FontWeight.bold)),
    const SizedBox(height:5),
    const Text('Chọn từng hồ sơ để xem việc chưa làm và gửi phản hồi sau khi thực hiện.',style:TextStyle(color:Colors.black54)),
    const SizedBox(height:12),
    if(attention.isEmpty)const Card(child:Padding(padding:EdgeInsets.all(20),child:Text('Đã xử lý hết các nguồn cần theo dõi.'))),
    ...attention.map((e)=>Card(child:_attentionTile(e))),const SizedBox(height:90),
  ]);
  Future<void> backup() async {
    try {
      final dir=await getApplicationDocumentsDirectory();
      final file=File(path.join(dir.path,'sourceflow_v2_backup_${DateTime.now().millisecondsSinceEpoch}.json'));
      await file.writeAsString(jsonEncode({'schema':2,'createdAt':DateTime.now().toIso8601String(),
        'listings':listings.map((x)=>x.toJson()).toList()}));
      await SharePlus.instance.share(ShareParams(files:[XFile(file.path)],text:'Bản sao lưu SourceFlow V2 — bảo mật tệp này.'));
    } catch(e){message('Không xuất được sao lưu: $e');}
  }
  Future<void> restore() async {
    try {
      final pick=await FilePicker.platform.pickFiles(type:FileType.custom,allowedExtensions:['json'],withData:true);
      if(pick==null)return;
      final file=pick.files.single;
      if(file.size>15*1024*1024){message('Tệp vượt giới hạn 15MB');return;}
      final raw=file.bytes!=null ? utf8.decode(file.bytes!) : await File(file.path!).readAsString();
      final root=jsonDecode(raw);
      if(root is! Map || root['schema']!=2 || root['listings'] is! List) {message('Chỉ hỗ trợ sao lưu SourceFlow V2, chưa nhập trực tiếp bản V1.');return;}
      final incoming=(root['listings'] as List).whereType<Map>().map((e)=>Listing.fromJson(Map<String,dynamic>.from(e))).toList();
      if(incoming.length>50000){message('Quá nhiều hồ sơ.');return;}
      if(!mounted)return;
      final ok=await showDialog<bool>(context:context,builder:(c)=>AlertDialog(
        title:const Text('Nhập dữ liệu sao lưu?'),content:Text('Sẽ thêm/cập nhật ${incoming.length} hồ sơ. Hồ sơ ID trùng sẽ được thay thế. Dữ liệu khác giữ nguyên.'),
        actions:[TextButton(onPressed:()=>Navigator.pop(c,false),child:const Text('Hủy')),
          FilledButton(onPressed:()=>Navigator.pop(c,true),child:const Text('Đồng ý'))]));
      if(ok!=true)return;
      for(final item in incoming){await store.save(item);}
      final refreshed=await store.all();await reminder.refresh(refreshed);
      if(mounted)setState(()=>listings=refreshed);
      message('Đã nhập ${incoming.length} hồ sơ');
    }catch(e){message('Không đọc được tệp: $e');}
  }
  Widget _settings()=>ListView(padding:const EdgeInsets.all(16),children:[
    const Text('Dữ liệu & an toàn',style:TextStyle(fontSize:21,fontWeight:FontWeight.bold)),
    const SizedBox(height:10),
    Card(child:Column(children:[
      ListTile(leading:const Icon(Icons.download_outlined),title:const Text('Sao lưu danh sách và nhật ký'),
        subtitle:const Text('Xuất thông tin JSON (không gồm tệp ảnh) để lưu riêng an toàn.'),onTap:backup),
      const Divider(height:1),
      ListTile(leading:const Icon(Icons.upload_file_outlined),title:const Text('Nhập sao lưu SourceFlow V2'),
        subtitle:const Text('Thêm hoặc cập nhật hồ sơ từ tệp JSON.'),onTap:restore),
    ])),const SizedBox(height:8),
    const Card(child:Padding(padding:EdgeInsets.all(16),child:Text(
      'V2 thử nghiệm lưu cục bộ trên Android (SQLite). Chưa đồng bộ với Windows/iOS, chưa mã hóa cơ sở dữ liệu bằng khóa riêng, chưa đăng nhập và chưa tự động quét website. Không lưu ảnh giấy tờ định danh nhạy cảm nếu thiết bị chưa được bảo vệ. \n\nThông báo buổi sáng dự kiến vào khoảng 08:00; Android có thể trì hoãn do chế độ tiết kiệm pin, và phải cấp quyền thông báo. Mở ứng dụng sẽ luôn cập nhật danh sách theo trạng thái mới nhất.',
      style:TextStyle(height:1.5)))),const SizedBox(height:90),
  ]);
}

class ListingDetail extends StatefulWidget {
  final Listing listing;
  final Future<void> Function(Listing) onSave;
  final Future<Listing?> Function() onEdit;
  const ListingDetail({super.key,required this.listing,required this.onSave,required this.onEdit});
  @override State<ListingDetail> createState()=>_ListingDetailState();
}

class _ListingDetailState extends State<ListingDetail> {
  late Listing p;
  @override void initState(){super.initState();p=widget.listing;}
  Future<void> _feedback() async {
    final result=await showModalBottomSheet<FeedbackResult>(context:context,isScrollControlled:true,showDragHandle:true,
      builder:(_)=>const FeedbackSheet());
    if(result==null)return;
    applyFeedback(p,result.outcome,result.note,nextAction:result.nextAction,due:result.due);
    await widget.onSave(p);
    if(mounted)setState((){});
  }
  Future<void> _verify() async {
    String status=p.verification;
    final evidence=TextEditingController(text:p.verificationEvidence);
    final result=await showDialog<bool>(context:context,builder:(dialogContext)=>StatefulBuilder(builder:(ctx,setLocal)=>AlertDialog(
      title:const Text('Xác minh chủ tài sản'),content:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,children:[
        DropdownButtonFormField<String>(value:status,isExpanded:true,decoration:const InputDecoration(labelText:'Mức độ xác minh'),
          items:const ['Chưa xác minh','Đã trao đổi, chưa đối chiếu','Cần kiểm tra thêm','Đã đối chiếu hồ sơ','Đã gặp và xác minh trực tiếp','Có dấu hiệu môi giới'].map((e)=>DropdownMenuItem(value:e,child:Text(e,overflow:TextOverflow.ellipsis))).toList(),
          onChanged:(v)=>setLocal(()=>status=v??status)),
        const SizedBox(height:14),TextField(controller:evidence,maxLines:3,decoration:const InputDecoration(labelText:'Căn cứ xác minh (khi có)')),
      ])),actions:[TextButton(onPressed:()=>Navigator.pop(ctx,false),child:const Text('Hủy')),
        FilledButton(onPressed:()=>Navigator.pop(ctx,true),child:const Text('Lưu'))])));
    if(!mounted){evidence.dispose();return;}
    if(result==true){
      final proof=evidence.text.trim();
      if((status=='Đã đối chiếu hồ sơ'||status=='Đã gặp và xác minh trực tiếp')&&proof.isEmpty){
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Cần ghi rõ căn cứ để xác nhận chính chủ')));
      } else {
        p.verification=status;p.verificationEvidence=proof;p.addLog('Cập nhật xác minh chính chủ', '$status. $proof');
        await widget.onSave(p);if(mounted)setState((){});
      }
    }
    evidence.dispose();
  }
  Future<void> _editContract() async {
    final number=TextEditingController(text:p.contractNumber);
    final fee=TextEditingController(text:p.contractFee);
    bool signed=p.contractStatus=='Đã ký', exclusive=p.exclusive;
    DateTime? expiry=p.contractExpires;
    final ok=await showDialog<bool>(context:context,builder:(ctx)=>StatefulBuilder(builder:(c,update)=>AlertDialog(
      title:const Text('Hợp đồng môi giới'),content:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,children:[
        SwitchListTile(contentPadding:EdgeInsets.zero,title:const Text('Đã ký hợp đồng'),value:signed,onChanged:(v)=>update(()=>signed=v)),
        TextField(controller:number,decoration:const InputDecoration(labelText:'Số hợp đồng')),
        const SizedBox(height:9),TextField(controller:fee,decoration:const InputDecoration(labelText:'Phí môi giới (%)')),
        SwitchListTile(contentPadding:EdgeInsets.zero,title:const Text('Độc quyền'),value:exclusive,onChanged:(v)=>update(()=>exclusive=v)),
        OutlinedButton.icon(onPressed:()async{
          final x=await showDatePicker(context:ctx,initialDate:expiry??DateTime.now().add(const Duration(days:90)),
            firstDate:DateTime(2020),lastDate:DateTime(2100));
          if(x!=null)update(()=>expiry=x);
        },icon:const Icon(Icons.calendar_month),label:Text('Hết hạn: ${dateLabel(expiry)}')),
      ])),actions:[TextButton(onPressed:()=>Navigator.pop(ctx,false),child:const Text('Hủy')),
        FilledButton(onPressed:()=>Navigator.pop(ctx,true),child:const Text('Lưu hợp đồng'))])));
    if(ok==true){
      p.contractNumber=number.text.trim();p.contractFee=fee.text.trim();p.exclusive=exclusive;p.contractExpires=expiry;
      p.contractStatus=signed?'Đã ký':'Chưa ký';
      if(signed){p.marketingNeedsAttention=false;p.nextAction='';p.nextDue=null;
        if(p.saleStatus=='Chưa chào bán')p.saleStatus='Chuẩn bị chào bán';}
      p.addLog('Cập nhật hợp đồng', '${p.contractStatus}; Số: ${p.contractNumber}; Phí: ${p.contractFee}%');
      await widget.onSave(p);if(mounted)setState((){});
    }
    number.dispose();fee.dispose();
  }
  Future<void> _addMarketing() async {
    final channel=TextEditingController(),url=TextEditingController();
    final ok=await showDialog<bool>(context:context,builder:(ctx)=>AlertDialog(
      title:const Text('Ghi nhận đăng tin chào bán'),
      content:Column(mainAxisSize:MainAxisSize.min,children:[
        TextField(controller:channel,decoration:const InputDecoration(labelText:'Kênh đăng (website, mạng xã hội...)')),
        const SizedBox(height:9),TextField(controller:url,decoration:const InputDecoration(labelText:'Link tin đăng')),
      ]),actions:[TextButton(onPressed:()=>Navigator.pop(ctx,false),child:const Text('Hủy')),
        FilledButton(onPressed:()=>Navigator.pop(ctx,true),child:const Text('Lưu'))]));
    if(ok==true&&channel.text.trim().isNotEmpty){
      p.posts.insert(0,MarketingPost(channel:channel.text.trim(),url:url.text.trim()));
      p.saleStatus='Đang chào bán';
      p.addLog('Đã đăng tin chào bán', '${channel.text.trim()}: ${url.text.trim()}');
      await widget.onSave(p);if(mounted)setState((){});
    }
    channel.dispose();url.dispose();
  }
  Future<void> _addOffer() async {
    final buyer=TextEditingController(),contact=TextEditingController(),price=TextEditingController(),note=TextEditingController();
    final ok=await showDialog<bool>(context:context,builder:(ctx)=>AlertDialog(
      title:const Text('Ghi khách quan tâm / trả giá'),
      content:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,children:[
        TextField(controller:buyer,decoration:const InputDecoration(labelText:'Tên khách hoặc mã khách')),
        const SizedBox(height:8),TextField(controller:contact,decoration:const InputDecoration(labelText:'SĐT khách (nếu có)')),
        const SizedBox(height:8),TextField(controller:price,decoration:const InputDecoration(labelText:'Giá đề nghị')),
        const SizedBox(height:8),TextField(controller:note,decoration:const InputDecoration(labelText:'Phản hồi / nhu cầu'),maxLines:2),
      ])),actions:[TextButton(onPressed:()=>Navigator.pop(ctx,false),child:const Text('Hủy')),
        FilledButton(onPressed:()=>Navigator.pop(ctx,true),child:const Text('Lưu'))]));
    if(ok==true&&buyer.text.trim().isNotEmpty){
      p.offers.insert(0,BuyerOffer(buyer:buyer.text.trim(),contact:contact.text.trim(),offer:price.text.trim(),note:note.text.trim()));
      p.saleStatus='Có khách quan tâm';p.marketingNeedsAttention=true;
      p.nextAction='Phản hồi chủ tài sản về khách quan tâm/giá đề nghị';p.nextDue=DateTime.now();
      p.addLog('Có khách quan tâm / đề nghị mua','${buyer.text.trim()}: ${price.text.trim()}. ${note.text.trim()}');
      await widget.onSave(p);if(mounted)setState((){});
    }
    buyer.dispose();contact.dispose();price.dispose();note.dispose();
  }
  Future<void> _call() async {
    final tel=p.phone.replaceAll(RegExp(r'[^\d+]'),'');
    if(tel.isEmpty)return;
    final u=Uri(scheme:'tel',path:tel);
    if(await canLaunchUrl(u)){await launchUrl(u);}
  }
  @override Widget build(BuildContext context) {
    final att=attentionFor(p,DateTime.now());
    return Scaffold(appBar:AppBar(title:const Text('Hồ sơ nguồn hàng'),actions:[IconButton(onPressed:() async {final edited=await widget.onEdit(); if(mounted&&edited!=null)setState(()=>p=edited);},icon:const Icon(Icons.edit_outlined),tooltip:'Sửa nguồn')]),
      body:ListView(padding:const EdgeInsets.all(16),children:[
        Text(p.title,style:const TextStyle(fontSize:22,fontWeight:FontWeight.bold)),
        const SizedBox(height:5),Text(p.address.isEmpty?'Địa chỉ chưa nhập':p.address,style:const TextStyle(color:Colors.black54)),
        const SizedBox(height:10),Wrap(spacing:7,runSpacing:7,children:[Chip(label:Text(p.contractStatus)),Chip(label:Text(p.saleStatus)),Chip(label:Text(p.verification))]),
        if(p.imagePath.isNotEmpty&&File(p.imagePath).existsSync())Padding(padding:const EdgeInsets.only(top:10),child:ClipRRect(
          borderRadius:BorderRadius.circular(12),child:Image.file(File(p.imagePath),height:190,fit:BoxFit.cover))),
        const SizedBox(height:12),
        Card(child:Padding(padding:const EdgeInsets.all(15),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
          Row(children:[const Icon(Icons.pending_actions,color:brand),const SizedBox(width:7),
            const Expanded(child:Text('CÔNG VIỆC CHƯA THỰC HIỆN',style:TextStyle(fontWeight:FontWeight.bold)))]),
          const SizedBox(height:8),Text(att?.reason??'Không có việc cần nhắc buổi sáng. Nếu có thay đổi chào bán, hãy ghi phản hồi.',
            style:const TextStyle(height:1.45)),
          if(p.nextDue!=null)Text('Lịch dự kiến: ${dateLabel(p.nextDue)}',style:const TextStyle(color:Colors.black54)),
          const SizedBox(height:12),SizedBox(width:double.infinity,child:FilledButton.icon(
            onPressed:_feedback,icon:const Icon(Icons.rate_review_outlined),label:const Text('Đã thực hiện → Gửi phản hồi'))),
        ]))),
        Card(child:Column(children:[
          ListTile(leading:const Icon(Icons.person_outline),title:Text(p.owner.isEmpty?'Chưa có tên chủ':p.owner),
            subtitle:Text(p.phone.isEmpty?'Chưa có điện thoại':p.phone),trailing:p.phone.isEmpty?null:IconButton(onPressed:_call,icon:const Icon(Icons.call,color:brand))),
          const Divider(height:1),
          ListTile(leading:const Icon(Icons.fact_check_outlined),title:const Text('Xác minh chủ sở hữu'),
            subtitle:Text('${p.verification}${p.verificationEvidence.isEmpty?'':'\nCăn cứ: ${p.verificationEvidence}'}'),
            trailing:const Icon(Icons.edit_outlined),onTap:_verify),
          const Divider(height:1),
          ListTile(title:const Text('Diện tích / Giá / Nguồn'),subtitle:Text(
            '${p.area.isEmpty?'Chưa có diện tích':p.area} • ${p.price.isEmpty?'Chưa có giá':p.price}\nNguồn: ${p.source}')),
          if(p.sourceUrl.isNotEmpty)ListTile(leading:const Icon(Icons.link),title:const Text('Mở tin nguồn'),
            subtitle:Text(p.sourceUrl,maxLines:1,overflow:TextOverflow.ellipsis),onTap:()async{
              final u=Uri.tryParse(p.sourceUrl);if(u!=null&&(u.scheme=='https'||u.scheme=='http')) await launchUrl(u,mode:LaunchMode.externalApplication);
            }),
        ])),
        Card(child:Padding(padding:const EdgeInsets.all(12),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
          Row(children:[const Expanded(child:Text('HỢP ĐỒNG MÔI GIỚI',style:TextStyle(fontWeight:FontWeight.bold))),
            TextButton.icon(onPressed:_editContract,icon:const Icon(Icons.edit,size:18),label:const Text('Cập nhật'))]),
          Text('${p.contractStatus} • Số: ${p.contractNumber.isEmpty?'Chưa ghi':p.contractNumber}'),
          Text('Phí: ${p.contractFee.isEmpty?'Chưa ghi':p.contractFee+'%'} • ${p.exclusive?'Độc quyền':'Không độc quyền'} • Hết hạn: ${dateLabel(p.contractExpires)}',
            style:const TextStyle(fontSize:12,color:Colors.black54)),
        ]))),
        Card(child:Padding(padding:const EdgeInsets.all(12),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
          Row(children:[const Expanded(child:Text('KÊNH CHÀO BÁN',style:TextStyle(fontWeight:FontWeight.bold))),
            TextButton.icon(onPressed:_addMarketing,icon:const Icon(Icons.add,size:18),label:const Text('Đăng tin'))]),
          if(p.posts.isEmpty)const Text('Chưa ghi nhận tin chào bán.'),
          ...p.posts.map((post)=>ListTile(dense:true,contentPadding:EdgeInsets.zero,
            title:Text(post.channel),subtitle:Text('${post.status} • ${dateLabel(post.added)}\n${post.url}',maxLines:3))),
        ]))),
        Card(child:Padding(padding:const EdgeInsets.all(12),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
          Row(children:[const Expanded(child:Text('KHÁCH QUAN TÂM / TRẢ GIÁ',style:TextStyle(fontWeight:FontWeight.bold))),
            TextButton.icon(onPressed:_addOffer,icon:const Icon(Icons.add,size:18),label:const Text('Ghi khách'))]),
          if(p.offers.isEmpty)const Text('Chưa ghi nhận khách quan tâm.'),
          ...p.offers.map((offer)=>ListTile(dense:true,contentPadding:EdgeInsets.zero,
            title:Text('${offer.buyer} • ${offer.offer}'),subtitle:Text('${offer.contact}\n${offer.note}',maxLines:3))),
        ]))),
        if(p.rawCapture.isNotEmpty)Card(child:ExpansionTile(title:const Text('Dữ liệu gốc từ ảnh/giọng nói'),children:[
          Padding(padding:const EdgeInsets.all(14),child:SelectableText(p.rawCapture))])),
        const Padding(padding:EdgeInsets.symmetric(vertical:12),child:Text('NHẬT KÝ THEO THỜI GIAN',style:TextStyle(fontWeight:FontWeight.bold))),
        if(p.logs.isEmpty)const Text('Chưa có phản hồi nào.'),
        ...p.logs.map((e)=>Card(child:ListTile(leading:const Icon(Icons.history,color:brand),
          title:Text(e.action),subtitle:Text('${dateLabel(e.at)} • ${e.note}')))),
        const SizedBox(height:40),
      ]),
    );
  }
}

class FeedbackResult {
  final String outcome,note,nextAction;
  final DateTime? due;
  const FeedbackResult(this.outcome,this.note,this.nextAction,this.due);
}
class FeedbackSheet extends StatefulWidget {
  const FeedbackSheet({super.key});
  @override State<FeedbackSheet> createState()=>_FeedbackSheetState();
}
class _FeedbackSheetState extends State<FeedbackSheet> {
  String outcome=feedbackOptions.first;
  final note=TextEditingController(),next=TextEditingController();
  DateTime? due;
  @override void dispose(){note.dispose();next.dispose();super.dispose();}
  @override Widget build(BuildContext context) => Padding(
    padding:EdgeInsets.only(bottom:MediaQuery.viewInsetsOf(context).bottom+18,left:18,right:18),
    child:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,crossAxisAlignment:CrossAxisAlignment.start,children:[
      const Text('Phản hồi kết quả công việc',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold)),
      const SizedBox(height:12),DropdownButtonFormField<String>(isExpanded:true,value:outcome,
        decoration:const InputDecoration(labelText:'Kết quả thực hiện'),
        items:feedbackOptions.map((e)=>DropdownMenuItem(value:e,child:Text(e,overflow:TextOverflow.ellipsis))).toList(),
        onChanged:(v)=>setState(()=>outcome=v??outcome)),const SizedBox(height:12),
      TextField(controller:note,maxLines:3,decoration:const InputDecoration(labelText:'Ghi chú phản hồi',hintText:'Chủ nói gì? Có đồng ý? Điều kiện nào?')),
      const SizedBox(height:12),TextField(controller:next,decoration:const InputDecoration(labelText:'Việc tiếp theo (để trống = phần mềm gợi ý)')),
      const SizedBox(height:7),OutlinedButton.icon(onPressed:()async{
        final d=await showDatePicker(context:context,initialDate:due??DateTime.now(),firstDate:DateTime(2020),lastDate:DateTime(2100));
        if(d!=null)setState(()=>due=d);
      },icon:const Icon(Icons.calendar_today_outlined),label:Text(due==null?'Chọn hạn xử lý':dateLabel(due))),
      const SizedBox(height:12),SizedBox(width:double.infinity,child:FilledButton(onPressed:()=>Navigator.pop(context,
        FeedbackResult(outcome,note.text,next.text,due)),child:const Text('Ghi nhận & cập nhật tiến độ'))),
    ])),
  );
}

class IntakePage extends StatefulWidget {
  final List<Listing> existing;
  final Listing? original;
  const IntakePage({super.key,required this.existing,this.original});
  @override State<IntakePage> createState()=>_IntakePageState();
}
class _IntakePageState extends State<IntakePage> {
  late Listing draft;
  final formKey=GlobalKey<FormState>();
  final title=TextEditingController(), address=TextEditingController(), area=TextEditingController();
  final price=TextEditingController(), owner=TextEditingController(), phone=TextEditingController();
  final sourceUrl=TextEditingController(), raw=TextEditingController();
  final SpeechToText speech=SpeechToText();
  bool recognizing=false, listening=false, saving=false;
  int mode=0;
  @override void initState(){super.initState();
    draft=widget.original==null?Listing():Listing.fromJson(widget.original!.toJson());
    title.text=draft.title;address.text=draft.address;area.text=draft.area;price.text=draft.price;
    owner.text=draft.owner;phone.text=draft.phone;sourceUrl.text=draft.sourceUrl;raw.text=draft.rawCapture;
  }
  @override void dispose(){
    speech.stop();
    for(final c in [title,address,area,price,owner,phone,sourceUrl,raw]){c.dispose();}
    super.dispose();
  }
  void message(String msg) {if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(msg)));}
  void fillFrom(String text) {
    final parsed=parseIntake(text);
    setState((){
      // Chỉ gợi ý các trường chưa nhập, không ghi đè dữ liệu người dùng đã chỉnh.
      if(title.text.trim().isEmpty)title.text=parsed.title;
      if(address.text.trim().isEmpty)address.text=parsed.address;
      if(area.text.trim().isEmpty)area.text=parsed.area;
      if(price.text.trim().isEmpty)price.text=parsed.price;
      if(phone.text.trim().isEmpty)phone.text=parsed.phone;
    });
  }
  Future<void> pick(ImageSource source) async {
    try {
      final file=await ImagePicker().pickImage(source:source,imageQuality:85,maxWidth:2200);
      if(file==null)return;
      setState(()=>recognizing=true);
      final docs=await getApplicationDocumentsDirectory();
      final folder=Directory(path.join(docs.path,'photos'));
      if(!await folder.exists()) await folder.create(recursive:true);
      final dest=path.join(folder.path,'${newId()}.jpg');
      await File(file.path).copy(dest);
      draft.imagePath=dest;
      final recognizer=TextRecognizer(script:TextRecognitionScript.latin);
      String text='';
      try {text=(await recognizer.processImage(InputImage.fromFilePath(dest))).text;}
      finally {await recognizer.close();}
      if(!mounted)return;
      if(text.trim().isNotEmpty){
        raw.text=[raw.text,text.trim()].where((e)=>e.isNotEmpty).join('\n');
        fillFrom(text);
        message('Đã đọc chữ trên ảnh. Hãy kiểm tra các trường nhận dạng.');
      } else {message('Đã lưu ảnh, nhưng không tìm thấy chữ rõ để trích xuất. Bạn có thể nhập tay.');}
    } catch(e){message('Không đọc được ảnh hoặc chưa cấp quyền: $e');}
    finally{if(mounted)setState(()=>recognizing=false);}
  }
  Future<void> toggleVoice() async {
    if(listening){await speech.stop();if(mounted)setState(()=>listening=false);fillFrom(raw.text);return;}
    try {
      final available=await speech.initialize(onError:(e){if(mounted)message('Nhận dạng giọng nói: ${e.errorMsg}');});
      if(!available){message('Thiết bị chưa cấp quyền micro hoặc thiếu dịch vụ nhận dạng giọng nói.');return;}
      if(mounted)setState(()=>listening=true);
      await speech.listen(localeId:'vi_VN',listenFor:const Duration(seconds:55),pauseFor:const Duration(seconds:5),
        onResult:(r){
          if(!mounted)return;
          setState(()=>raw.text=r.recognizedWords);
          if(r.finalResult){fillFrom(raw.text);setState(()=>listening=false);}
        });
    } catch(e){message('Không dùng được micro: $e');if(mounted)setState(()=>listening=false);}
  }
  String _normalized(String text)=>text.toLowerCase().replaceAll(RegExp(r'\s+'),' ').trim();
  Future<void> save() async {
    if(!formKey.currentState!.validate())return;
    if(saving)return;
    final phoneValue=phone.text.replaceAll(RegExp(r'[^0-9+]'),'');
    final addressValue=_normalized(address.text);
    final existing=widget.existing.where((x)=>x.id!=draft.id &&
      ((phoneValue.isNotEmpty&&x.phone.replaceAll(RegExp(r'[^0-9+]'),'')==phoneValue)
        ||(addressValue.isNotEmpty&&_normalized(x.address)==addressValue))).toList();
    if(existing.isNotEmpty){
      final ok=await showDialog<bool>(context:context,builder:(ctx)=>AlertDialog(
        title:const Text('Có nguồn hàng trùng'),content:Text('Phát hiện ${existing.length} hồ sơ có cùng số điện thoại hoặc địa chỉ. Bạn vẫn muốn lưu?'),
        actions:[TextButton(onPressed:()=>Navigator.pop(ctx,false),child:const Text('Kiểm tra lại')),
          FilledButton(onPressed:()=>Navigator.pop(ctx,true),child:const Text('Vẫn lưu'))]));
      if(ok!=true)return;
    }
    setState(()=>saving=true);
    draft.title=title.text.trim();draft.address=address.text.trim();draft.area=area.text.trim();draft.price=price.text.trim();
    draft.owner=owner.text.trim();draft.phone=phone.text.trim();draft.sourceUrl=sourceUrl.text.trim();draft.rawCapture=raw.text.trim();
    draft.updatedAt=DateTime.now();
    draft.addLog(widget.original==null?'Tạo nguồn hàng':'Chỉnh sửa thông tin', 'Nhập bằng ${['tay','hình ảnh','giọng nói'][mode]}; nguồn: ${draft.source}.');
    if(mounted)Navigator.pop(context,draft);
  }
  Widget editField(TextEditingController controller,String label,{TextInputType? keyboard,int lines=1,String? hint, bool required=false}) =>
    Padding(padding:const EdgeInsets.only(bottom:12),child:TextFormField(controller:controller,keyboardType:keyboard,maxLines:lines,
      decoration:InputDecoration(labelText:label,hintText:hint),
      validator:required?(v)=>(v??'').trim().isEmpty?'Vui lòng nhập $label':null:null));
  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:Text(widget.original==null?'Nhập nguồn hàng mới':'Chỉnh sửa nguồn hàng')),
    body:Form(key:formKey,child:ListView(padding:const EdgeInsets.all(16),children:[
      const Text('Chọn cách nhập',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold)),const SizedBox(height:8),
      Wrap(spacing:7,children:[ChoiceChip(label:const Text('Nhập tay'),avatar:const Icon(Icons.edit_note,size:18),selected:mode==0,onSelected:(_)=>setState(()=>mode=0)),
        ChoiceChip(label:const Text('Hình ảnh'),avatar:const Icon(Icons.camera_alt_outlined,size:18),selected:mode==1,onSelected:(_)=>setState(()=>mode=1)),
        ChoiceChip(label:const Text('Giọng nói'),avatar:const Icon(Icons.mic_none,size:18),selected:mode==2,onSelected:(_)=>setState(()=>mode=2))]),
      const SizedBox(height:12),
      if(mode==1)Card(child:Padding(padding:const EdgeInsets.all(15),child:Column(children:[
        const Text('Chụp tin đăng, tờ rơi hoặc ảnh chứa thông tin. Ứng dụng thử đọc chữ từ ảnh (OCR).'),
        const SizedBox(height:10),Row(children:[Expanded(child:OutlinedButton.icon(onPressed:recognizing?null:()=>pick(ImageSource.camera),
          icon:const Icon(Icons.camera_alt_outlined),label:const Text('Chụp ảnh'))),const SizedBox(width:8),
          Expanded(child:OutlinedButton.icon(onPressed:recognizing?null:()=>pick(ImageSource.gallery),
            icon:const Icon(Icons.photo_library_outlined),label:const Text('Chọn ảnh')))]),
        if(recognizing)const Padding(padding:EdgeInsets.all(12),child:CircularProgressIndicator()),
        if(draft.imagePath.isNotEmpty&&File(draft.imagePath).existsSync())
          Padding(padding:const EdgeInsets.only(top:10),child:Image.file(File(draft.imagePath),height:110)),
        const Text('Ảnh công trình không có chữ vẫn được lưu, thông tin cần bổ sung bằng tay.',style:TextStyle(fontSize:12,color:Colors.black54)),
      ]))),
      if(mode==2)Card(child:Padding(padding:const EdgeInsets.all(15),child:Column(children:[
        const Text('Ví dụ: “Nhà mặt tiền đường 13, diện tích 120 mét vuông, giá 12 tỷ, số điện thoại 09...”'),
        const SizedBox(height:10),SizedBox(width:double.infinity,child:FilledButton.icon(onPressed:toggleVoice,
          icon:Icon(listening?Icons.stop_circle_outlined:Icons.mic_none),label:Text(listening?'Dừng và lấy nội dung':'Bắt đầu đọc tiếng Việt'))),
        const Text('Nhận dạng giọng nói phụ thuộc dịch vụ của điện thoại, có thể cần mạng.',
          style:TextStyle(fontSize:12,color:Colors.black54)),
      ]))),
      if(mode!=0)Padding(padding:const EdgeInsets.only(top:10),child:Column(children:[
        editField(raw,'Nội dung trích xuất — kiểm tra và sửa',lines:5),
        Align(alignment:Alignment.centerRight,child:TextButton.icon(onPressed:()=>fillFrom(raw.text),
          icon:const Icon(Icons.auto_fix_high),label:const Text('Gợi ý điền từ nội dung'))),
      ])),
      const SizedBox(height:10),
      const Text('Kiểm tra thông tin trước khi lưu',style:TextStyle(fontSize:16,fontWeight:FontWeight.bold)),const SizedBox(height:10),
      editField(title,'Tên nguồn hàng *',required:true,hint:'VD: Nhà mặt tiền đường 13'),
      DropdownButtonFormField<String>(value:draft.type,decoration:const InputDecoration(labelText:'Loại tài sản'),isExpanded:true,
        items:const ['Nhà riêng','Nhà mặt tiền','Đất nền','Căn hộ','Nhà xưởng / kho','Khác'].map((e)=>DropdownMenuItem(value:e,child:Text(e))).toList(),
        onChanged:(v)=>setState(()=>draft.type=v??draft.type)),const SizedBox(height:12),
      editField(address,'Địa chỉ bất động sản'),
      Row(children:[Expanded(child:editField(area,'Diện tích',hint:'120 m²')),const SizedBox(width:8),Expanded(child:editField(price,'Giá bán',hint:'12 tỷ'))]),
      DropdownButtonFormField<String>(value:draft.source,decoration:const InputDecoration(labelText:'Nguồn phát hiện'),isExpanded:true,
        items:const ['Khảo sát thực tế','Trang web','Người quen giới thiệu','Mạng xã hội','Khác'].map((e)=>DropdownMenuItem(value:e,child:Text(e))).toList(),
        onChanged:(v)=>setState(()=>draft.source=v??draft.source)),const SizedBox(height:12),
      editField(sourceUrl,'Link tin nguồn (nếu có)',keyboard:TextInputType.url),
      editField(owner,'Tên người liên hệ / chủ tài sản'),
      editField(phone,'Điện thoại',keyboard:TextInputType.phone),
      const Text('Lưu ý: Tên hoặc lời nói “chính chủ” không có giá trị xác minh. Cần đối chiếu và ghi bằng chứng riêng.',
        style:TextStyle(fontSize:12,color:Colors.black54)),
      const SizedBox(height:16),FilledButton.icon(onPressed:saving?null:save,icon:const Icon(Icons.save_outlined),
        label:Text(widget.original==null?'Lưu nguồn hàng':'Cập nhật hồ sơ')),
      const SizedBox(height:35),
    ])),
  );
}
