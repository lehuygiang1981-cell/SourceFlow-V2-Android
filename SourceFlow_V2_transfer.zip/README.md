# SOURCEFLOW V2 — ANDROID (MÃ NGUỒN THỬ NGHIỆM)

**Tình trạng bàn giao:** Đã xây dựng mã nguồn ứng dụng Flutter Android; **chưa có APK đã biên dịch hay xác nhận chạy trên thiết bị Android thật**. Môi trường thực hiện hiện không có Flutter SDK/Android SDK và không thể tải thêm các thành phần, nên không thể biên dịch ở đây. Không gọi dự án này là ứng dụng Android đã cài được.

## 1. Nội dung thực hiện theo yêu cầu

1. **Tổng hợp nhắc việc buổi sáng từ toàn bộ kho nguồn hàng**: tất cả hồ sơ chưa liên hệ hoặc chưa ký được đưa vào danh sách theo dõi. Hồ sơ đã ký môi giới và chào bán ổn định không bị nhắc; hồ sơ đã ký nhưng phát sinh biến động được nhắc lại. Mỗi dòng mở hồ sơ, chỉ rõ hành động còn phải thực hiện, cho phép ghi phản hồi và thay đổi trạng thái tự động. Có nhật ký, lịch xử lý và sắp xếp mức ưu tiên.
2. **Nhập nguồn bằng ba cách**: nhập biểu mẫu; ảnh camera/thư viện + OCR chữ Latin/Vietnamese với ML Kit; giọng nói tiếng Việt qua dịch vụ nhận dạng trên điện thoại. Mọi dữ liệu nhận diện chỉ mang tính gợi ý, phải kiểm tra và sửa trước khi lưu. Ảnh được lưu trong thư mục riêng của ứng dụng.
3. **Chưa có tự động quét website**, để cho phiên bản sau.

## 2. Đặc điểm phiên bản này

- Phần mềm Flutter native shell (không phải trang web/PWA), lưu thông tin trong SQLite trên điện thoại.
- Thông báo buổi sáng *khoảng 08:00* qua Android local notification **nếu cấp quyền**; giờ thực tế có thể trễ vì hệ thống tiết kiệm pin. Nội dung thông báo được tạo lại sau mỗi thay đổi hồ sơ khi ứng dụng đang chạy; không có quá trình quét server nền.
- Ghi phản hồi: gọi chưa bắt máy, hẹn lại, hẹn gặp, thương lượng, ký hợp đồng, chưa đồng ý, phát sinh biến động chào bán, xử lý biến động, dừng khai thác. Tự gợi ý công việc/hạn tiếp theo; có thể đổi tùy ý.
- Xác minh chính chủ độc lập với trạng thái gọi và trạng thái hợp đồng, yêu cầu căn cứ khi chọn đã đối chiếu hồ sơ / gặp xác minh trực tiếp.
- Kiểm tra trùng theo số điện thoại hoặc địa chỉ.
- Xuất JSON sao lưu bằng Android Sharesheet; nhập lại tệp JSON V2, không nhập trực tiếp sao lưu V1. **Ảnh chỉ được lưu cục bộ và KHÔNG được đóng gói trong bản sao lưu JSON**, cần giữ ảnh gốc riêng.
- Các mục V1 về hợp đồng (số, tỷ lệ phí, hạn, độc quyền), kênh đăng tin và khách trả giá được duy trì trong chi tiết hồ sơ. Khách trả giá mới được xem là một biến động chào bán cần phản hồi.
- Gọi điện qua ứng dụng điện thoại chỉ mở trình quay số, không tự ghi âm hoặc đọc nhật ký cuộc gọi.
- Dữ liệu chỉ lưu trên máy, chưa có tài khoản, đồng bộ máy tính/iPhone, mã hóa riêng hay tích hợp AI web. Không dùng để lưu tài liệu định danh/pháp lý nhạy cảm trong giai đoạn thử nghiệm.

## 3. Cách biên dịch APK trên Windows

**Yêu cầu:** Windows 10/11, Flutter SDK bản ổn định tương thích Dart >=3.8, Android Studio + Android SDK, Java 17, kết nối mạng tải các package từ pub.dev. Bật Developer Options hoặc USB Debugging trên điện thoại Android nếu muốn chạy trực tiếp từ Flutter.

1. Giải nén thư mục `SourceFlow_V2_Android` (đừng chỉ mở từng tệp `.dart`).
2. Cài Flutter SDK, Android Studio và Android SDK; mở PowerShell và xác nhận lệnh `flutter doctor` chạy được. Chấp nhận giấy phép Android SDK khi được yêu cầu: `flutter doctor --android-licenses`.
3. Bấm đúp `build_android_windows.bat`. Script tạo Android project Flutter, áp dụng AndroidManifest, cấu hình minSdk 23, compileSdk 36 và core library desugaring, tải thư viện, chạy unit test, rồi build APK release.
4. Nếu build thành công, file nằm tại `build\app\outputs\flutter-apk\app-release.apk`.
5. Chép APK sang Android và cài đặt (có thể cần bật quyền cài ứng dụng từ nguồn này). **APK release mặc định chỉ được ký bằng khóa phát triển/debug nếu template tạo ra vậy; không dùng để phát hành chính thức**.

Tham khảo hướng dẫn build chính thức: https://docs.flutter.dev/deployment/android

Nếu lỗi môi trường build/plugin, kỹ thuật viên chạy `flutter pub get`, `flutter test`, `flutter build apk --release` để xem nguyên nhân, chỉnh cấu hình theo bản Flutter/Gradle được cài.

## 4. Quy tắc nhắc việc cần nghiệm thu

| Nguồn hàng | Hiển thị buổi sáng? |
|---|---|
| Mới nhập, chưa gọi | Có, ưu tiên cao nhất |
| Đã gọi, đang đàm phán hợp đồng | Có |
| Chưa ký, đã hẹn gọi tương lai | Có trong phần theo dõi, ghi rõ ngày hẹn |
| Đã ký, chào bán ổn định | Không |
| Đã ký, xuất hiện thay đổi giá/trạng thái mới | Có, đến khi ghi nhận đã xử lý |
| Đã giao dịch xong / dừng khai thác | Không |

## 5. Kiến trúc và việc còn lại trước khi sử dụng thật

- `lib/models.dart`: dữ liệu và quy tắc nhắc việc / xử lý phản hồi / trích xuất mẫu.
- `lib/storage.dart`: SQLite.
- `lib/reminders.dart`: lịch thông báo Android.
- `lib/main.dart`: giao diện Android, nhập liệu, OCR, nhận dạng lời nói, sao lưu.
- `test/workflow_test.dart`: kiểm thử bộ quy tắc.
- `android_patch/AndroidManifest.xml`: quyền Android và các receiver notification.
- `scripts/prepare_android.ps1`: tạo scaffold, cập nhật Gradle/Manifest.

**Việc cần làm trước khi triển khai thật:** build+test trên Android thực, xác minh xử lý cuộc gọi không bắt máy, thử OCR tin rao tiếng Việt, hiệu chuẩn số diện tích/giá/địa chỉ, bảo vệ CSDL cục bộ, khôi phục khi mất máy, chuyển đổi sao lưu V1, xử lý xung đột đồng bộ và đảm bảo lịch nhắc hoạt động dưới chính sách pin của từng hãng Android.

## 6. Quy trình nhận APK qua cloud

Để build trên GitHub Actions, xem `HUONG_DAN_TAO_APK_WINDOWS_GITHUB.md`. Workflow `.github/workflows/android-apk.yml` xây APK trên môi trường Windows có bộ công cụ Flutter/Android và lưu file trong artifact khi build thành công. Chưa có APK do gói mã nguồn này tự tạo.
