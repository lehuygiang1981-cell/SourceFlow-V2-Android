import 'models.dart';
import 'legacy_admin.dart';

class HunterLead {
  final String id, url, title, snippet, source, queryTarget;
  final DateTime discoveredAt;
  final DateTime? indexDate;
  /// Facts derived from page body (not a claim of ownership).
  final String dateEvidence, posterCountEvidence, sourceMethod;
  /// Detail text from the listing itself, NOT a global website summary.
  final String detailText, posterProfileUrl, posterCountSource;
  String status, evidence, method, listingId, reviewNote, qualification, filterReason;
  DateTime? reviewedAt;

  HunterLead({required this.url, required this.title, required this.source,
    this.snippet='', this.queryTarget='', DateTime? discoveredAt,
    this.indexDate, String? id, this.dateEvidence='',this.posterCountEvidence='',
    this.sourceMethod='Trang web công khai',
    this.detailText='',this.posterProfileUrl='',this.posterCountSource='',this.status='pending',
    this.evidence='',this.method='',this.listingId='',this.reviewNote='',this.qualification='potential',this.filterReason='',this.reviewedAt})
    : id=id ?? canonicalLeadUrl(url),discoveredAt=discoveredAt??DateTime.now();

  Map<String,dynamic> toJson()=>{
    'id':id,'url':url,'title':title,'snippet':snippet,'source':source,
    'queryTarget':queryTarget,'discoveredAt':discoveredAt.toIso8601String(),
    'indexDate':indexDate?.toIso8601String(),
    'dateEvidence':dateEvidence,'posterCountEvidence':posterCountEvidence,
    'detailText':detailText,'posterProfileUrl':posterProfileUrl,
    'posterCountSource':posterCountSource,
    'sourceMethod':sourceMethod,'status':status,'evidence':evidence,
    'method':method,'listingId':listingId,'reviewNote':reviewNote,
    'qualification':qualification,'filterReason':filterReason,
    'reviewedAt':reviewedAt?.toIso8601String(),
  };
  factory HunterLead.fromJson(Map<String,dynamic> x)=>HunterLead(
    id:'${x['id']??''}',url:'${x['url']??''}',title:'${x['title']??''}',
    snippet:'${x['snippet']??''}',source:'${x['source']??''}',
    queryTarget:'${x['queryTarget']??''}',
    discoveredAt:DateTime.tryParse('${x['discoveredAt']}'),
    indexDate:DateTime.tryParse('${x['indexDate']}'),
    dateEvidence:'${x['dateEvidence']??''}',posterCountEvidence:'${x['posterCountEvidence']??''}',
    detailText:'${x['detailText']??''}',posterProfileUrl:'${x['posterProfileUrl']??''}',
    posterCountSource:'${x['posterCountSource']??''}',
    sourceMethod:'${x['sourceMethod']??'Trang web công khai'}',
    status:'${x['status']??'pending'}',evidence:'${x['evidence']??''}',
    method:'${x['method']??''}',listingId:'${x['listingId']??''}',
    reviewNote:'${x['reviewNote']??''}',
    qualification:'${x['qualification']??'potential'}',filterReason:'${x['filterReason']??''}',reviewedAt:DateTime.tryParse('${x['reviewedAt']}'),
  );
  ParsedIntake get parsed {
    final base=parseIntake('$title\n${detailText.isNotEmpty?detailText:snippet}');
    final lines=detailText.split('\n').map((x)=>x.trim()).where((x)=>x.isNotEmpty).toList();
    String? labeled(String pattern){
      final re=RegExp('^(?:$pattern)\\s*[:：]\\s*(.+)\$',caseSensitive:false);
      for(final line in lines){
        final m=re.firstMatch(_leadFold(line));
        if(m!=null){
          final original=line.substring(line.indexOf(':')>=0?line.indexOf(':')+1:line.indexOf('：')+1).trim();
          if(original.isNotEmpty && original.length<170)return original;
        }
      }
      return null;
    }
    final rawAddress=labeled('dia chi|vi tri|dia diem');
    final rawType=labeled('loai tin rao|loai hinh|loai bat dong san');
    final address=(rawAddress!=null && RegExp(r'(?:duong|phuong|quan|thu duc|ho chi minh|\d{1,5}\s)',caseSensitive:false).hasMatch(_leadFold(rawAddress)))
      ?rawAddress:base.address;
    final rawPrice=labeled('gia ban|gia chao|gia');
    final rawArea=labeled('dien tich dat|dien tich|dt');
    // The site's labeled property facts take precedence over conflicting
    // figures in the headline (e.g. BDS68 title 74m² vs detail 73m²).
    final area=rawArea!=null &&
        RegExp(r'\d+(?:[.,]\d+)?\s*(?:m2|m²|met vuong|ha)(?=\s|$|\(|,|;)',
          caseSensitive:false).hasMatch(_leadFold(rawArea))
        ?rawArea:base.area;
    // An external direct listing URL outranks text from a screenshot.
    final url=this.url;
    final price=rawPrice!=null && RegExp(r'\d+[.,]?\d*\s*(?:ty|trieu)',caseSensitive:false).hasMatch(_leadFold(rawPrice))
      ?rawPrice:base.price;
    // Dimensions are valid only when directly labeled as a land-plot size.
    // 'sân sau 2m', 'đường vào 5m' and other nearby dimensions must not
    // become the plot length or frontage.
    final sizeText=labeled('kich thuoc dat|kich thuoc|dien tich dat')??'';
    final dimension=RegExp(r'(\d+(?:[.,]\d+)?)\s*[x×]\s*(\d+(?:[.,]\d+)?)').firstMatch(sizeText);
    final width=labeled('chieu ngang|ngang|mat tien')??
        (dimension==null?base.width:'${dimension.group(1)} m');
    final length=labeled('chieu dai|chieu sau')??
        (dimension==null?'':'${dimension.group(2)} m');
    final headline=_leadFold(title);
    final kind=_leadFold(rawType??'');
    // Never guess type from incidental description/related advertisements.
    String verifiedType=base.type;
    if(RegExp(r'\b(nha xuong|kho xuong|nha kho)\b').hasMatch(kind)){
      verifiedType='Nhà xưởng / kho';
    }else if(RegExp(r'\b(nha rieng|ban nha|nha pho|nha hxh)\b').hasMatch(kind)){
      verifiedType='Nhà riêng';
    }else if(RegExp(r'\b(nha mat tien)\b').hasMatch(kind)){
      verifiedType='Nhà mặt tiền';
    }else if(RegExp(r'\b(nha rieng|ban nha|ban can nha|nha hxh|can nha)\b').hasMatch(headline)){
      verifiedType='Nhà riêng';
    }else if(RegExp(r'\b(nha xuong|kho xuong|nha kho)\b').hasMatch(headline)){
      verifiedType='Nhà xưởng / kho';
    }
    return ParsedIntake(title:base.title,address:address,area:area,
      width:width,length:length,price:price,phone:base.phone,owner:base.owner,
      type:verifiedType,sourceUrl:url);
  }
  List<String> get reviewFlags {
    final content='$title $snippet'.toLowerCase();
    final flags=<String>[];
    if (content.contains('sổ chung')||content.contains('so chung')) flags.add('Có dấu hiệu sổ chung');
    if (['môi giới','ký gửi','chủ gửi','làm việc chính chủ','chủ thiện chí']
        .any(content.contains)) flags.add('Có dấu hiệu trung gian, cần kiểm tra');
    if (dateEvidence.isEmpty) flags.add('Chưa kiểm chứng ngày đăng tại tin gốc');
    if (posterCountSource!='seller_profile_verified' && posterCountSource!='human_verified') flags.add('Số tin người đăng chưa được xác minh từ hồ sơ cá nhân');
    flags.add('Danh tính và quyền sở hữu chưa được xác minh');
    return flags;
  }
}

String canonicalLeadUrl(String value) {
  final uri=Uri.tryParse(value.trim());
  if(uri==null || (uri.scheme!='https'&&uri.scheme!='http') || uri.host.isEmpty)return '';
  final host=uri.host.toLowerCase().replaceFirst(RegExp(r'^www\.'),'');
  final segments=uri.path.replaceAll(RegExp(r'/+'),'/').replaceFirst(RegExp(r'/$'),'');
  final params=<String,String>{};
  for(final key in ['id','listingId','postId','tin']) {
    if(uri.queryParameters.containsKey(key))params[key]=uri.queryParameters[key]!;
  }
  return Uri(scheme:'https',host:host,path:segments.isEmpty?'/':segments,
    queryParameters:params.isEmpty?null:params).toString();
}

class HunterSettings {
  final String location, keywords, propertyType;
  final List<String> districts, wards, streets, excludedTerms, sites;
  final bool autoScan, excludeBroker, excludeSharedTitle, excludeApartments, ownerHintsOnly;
  final int recentDays, maxPosterListings;
  const HunterSettings({
    this.location='Thành phố Hồ Chí Minh', this.keywords='bán nhà',
    this.propertyType='Tất cả',this.districts=const ['Thành phố Thủ Đức'],
    this.wards=const [],this.streets=const [],this.excludedTerms=const [],
    this.sites=const ['batdongsan.com.vn','nhatot.com','muaban.net','bds68.com.vn','guland.vn'],
    this.autoScan=true,this.recentDays=5,this.maxPosterListings=3,
    this.excludeBroker=true,this.excludeSharedTitle=true,
    this.excludeApartments=false,this.ownerHintsOnly=false,
  });
  /// Legacy helper: older R2 tests/users can still inspect selected locations.
  List<String> get areas => [...districts, ...wards];
  List<String> get targets => [...wards,...streets].toSet().toList();
  Map<String,dynamic> toJson()=>{
    'location':location,'keywords':keywords,'propertyType':propertyType,
    'districts':districts,'wards':wards,'streets':streets,
    'excludedTerms':excludedTerms,'sites':sites,'autoScan':autoScan,
    'recentDays':recentDays,'maxPosterListings':maxPosterListings,
    'excludeBroker':excludeBroker,'excludeSharedTitle':excludeSharedTitle,
    'excludeApartments':excludeApartments,'ownerHintsOnly':ownerHintsOnly,
  };
  factory HunterSettings.fromJson(Map<String,dynamic> x) {
    List<String> sl(String key, List<String> fallback) => x[key] is List
        ? (x[key] as List).whereType<String>().toList() : fallback;
    int positive(String key,int fallback){final p=int.tryParse('${x[key]}');return p!=null&&p>0?p:fallback;}
    // R2.3 location + arbitrary area text are not safe to silently map to
    // checkbox wards. Migrate known ward names only; always show the choices.
    const defaults=['Thành phố Thủ Đức'];
    final legacy=sl('areas',const []);
    final wards=sl('wards',legacy.where((a)=>
      LegacyAdmin.formerThuDucWards.contains(a)).toList());
    final ds=sl('districts', defaults);
    return HunterSettings(
      location:'${x['location']??'Thành phố Hồ Chí Minh'}',
      keywords:'${x['keywords']??'bán nhà'}',
      propertyType:'${x['propertyType']??'Tất cả'}',
      districts:ds,wards:wards,streets:sl('streets',const []),
      excludedTerms:sl('excludedTerms',const []),
      sites:sl('sites',const ['batdongsan.com.vn','nhatot.com','muaban.net','bds68.com.vn','guland.vn']),
      autoScan:x['autoScan']!=false, recentDays:positive('recentDays',5),
      maxPosterListings:positive('maxPosterListings',3),
      excludeBroker:true,
      excludeSharedTitle:x['excludeSharedTitle']!=false,
      excludeApartments:x['excludeApartments']==true,
      ownerHintsOnly:x['ownerHintsOnly']==true,
    );
  }
}

class SourceScanStat {
  final String domain,status,message;
  final int raw,matched,discarded;
  const SourceScanStat(this.domain,this.status,this.message,{this.raw=0,this.matched=0,this.discarded=0});
  Map<String,dynamic> toJson()=>{'domain':domain,'status':status,'message':message,
      'raw':raw,'matched':matched,'discarded':discarded};
  factory SourceScanStat.fromJson(Map<String,dynamic> x)=>SourceScanStat(
    '${x['domain']??''}','${x['status']??''}','${x['message']??''}',
    raw:(x['raw'] as num?)?.toInt()??0,matched:(x['matched'] as num?)?.toInt()??0,
    discarded:(x['discarded'] as num?)?.toInt()??0);
}
class HunterSnapshot {
  final int total,pending,confirmed,rejected;
  final DateTime? lastScan;
  final String message;
  final List<String> errors;
  final List<SourceScanStat> sources;
  const HunterSnapshot({this.total=0,this.pending=0,this.confirmed=0,
    this.rejected=0,this.lastScan,this.message='',this.errors=const [],this.sources=const []});
}

String _leadFold(String text){
  var s=text.toLowerCase().replaceAll('đ','d');
  const groups={'a':'àáạảãâầấậẩẫăằắặẳẵ','e':'èéẹẻẽêềếệểễ',
    'i':'ìíịỉĩ','o':'òóọỏõôồốộổỗơờớợởỡ',
    'u':'ùúụủũưừứựửữ','y':'ỳýỵỷỹ'};
  for(final e in groups.entries){for(final c in e.value.split('')){s=s.replaceAll(c,e.key);}}
  return s;
}
