import 'dart:async';
import 'dart:convert';
import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';
import 'hunter_models.dart';

/// Supply Hunter's separate offline database. Never modify the main inventory DB.
/// WorkManager runs on a background Flutter engine/isolate. A separate SQLite
/// handle avoids its close() invalidating the foreground's cached connection.
class HunterStorage {
  Database? _db;
  Future<Database>? _opening;

  Future<Database> _database() async {
    final current = _db;
    if (current != null && current.isOpen) return current;
    if (_opening != null) return _opening!;
    final future = _openFresh();
    _opening = future;
    try {
      return await future;
    } finally {
      _opening = null;
    }
  }

  Future<Database> _openFresh() async {
    final root = await getDatabasesPath();
    final db = await openDatabase(
      p.join(root, 'sourceflow_hunter.sqlite'),
      version: 1,
      singleInstance: false,
      onConfigure: (database) async {
        await database.execute('PRAGMA busy_timeout = 5000');
      },
      onCreate: (database, version) async {
        await database.execute('CREATE TABLE leads (id TEXT PRIMARY KEY, url_key TEXT UNIQUE NOT NULL, discovered INTEGER NOT NULL, status TEXT NOT NULL, content TEXT NOT NULL)');
        await database.execute('CREATE TABLE settings (key TEXT PRIMARY KEY, value TEXT NOT NULL)');
        await database.execute('CREATE TABLE scan_history (id INTEGER PRIMARY KEY AUTOINCREMENT, timestamp INTEGER NOT NULL, content TEXT NOT NULL)');
      },
      onOpen: (database) async {
        // Non-destructive schema extension for users upgrading from R2/R2.3.
        await database.execute('CREATE TABLE IF NOT EXISTS scan_history (id INTEGER PRIMARY KEY AUTOINCREMENT, timestamp INTEGER NOT NULL, content TEXT NOT NULL)');
      },
    );
    _db = db;
    return db;
  }

  /// Retry only once when another isolate/lifecycle transition closed a handle.
  /// Do not retry writes for arbitrary SQLite errors: they could be non-idempotent.
  Future<T> _run<T>(Future<T> Function(Database db) action) async {
    var db = await _database();
    try {
      return await action(db);
    } on DatabaseException catch (error) {
      if (!error.toString().contains('database_closed')) rethrow;
      if (identical(_db, db)) _db = null;
      db = await _database();
      return action(db);
    }
  }

  Future<void> open() async { await _database(); }

  Future<HunterSettings> settings() => _run((db) async {
    final rows = await db.query('settings', where: 'key=?', whereArgs: ['options'], limit: 1);
    if (rows.isEmpty) return const HunterSettings();
    return HunterSettings.fromJson(Map<String, dynamic>.from(jsonDecode(rows.first['value'] as String)));
  });

  Future<void> saveSettings(HunterSettings value) => _run((db) async {
    await db.insert('settings', {'key': 'options', 'value': jsonEncode(value.toJson())},
      conflictAlgorithm: ConflictAlgorithm.replace);
  });

  Future<List<HunterLead>> leads() => _run((db) async {
    final rows = await db.query('leads', orderBy: 'discovered DESC');
    return rows.map((row) => HunterLead.fromJson(
      Map<String, dynamic>.from(jsonDecode(row['content'] as String)))).toList();
  });

  Future<int> addDiscovered(Iterable<HunterLead> items) => _run((db) async {
    var count = 0;
    await db.transaction((tx) async {
      for (final item in items) {
        final key = canonicalLeadUrl(item.url);
        if (key.isEmpty) continue;
        final rows = await tx.query('leads', columns: ['id','status','content'], where: 'url_key=?',
          whereArgs: [key], limit: 1);
        if (rows.isNotEmpty) {
          // Recheck stale R3.5.2 pending entries on future scans. Previously
          // duplicates were never enriched, even when newly verified as broker.
          // Imported/rejected/human-reviewed entries remain untouched.
          if ('${rows.first['status']}' == 'pending' && item.detailText.isNotEmpty) {
            final prior=Map<String,dynamic>.from(
              jsonDecode(rows.first['content'] as String));
            final fresh=Map<String,dynamic>.from(item.toJson());
            fresh['id']=prior['id'];
            fresh['discoveredAt']=prior['discoveredAt'];
            for (final field in ['reviewNote','reviewedAt','method','evidence','listingId']) {
              if ('${prior[field]??''}'.isNotEmpty) fresh[field]=prior[field];
            }
            // Never erase verified evidence because one network fetch failed.
            if ((fresh['posterCountSource']??'')!='seller_profile_verified' &&
                (prior['posterCountSource']??'')=='seller_profile_verified') {
              fresh['posterCountSource']=prior['posterCountSource'];
              fresh['posterCountEvidence']=prior['posterCountEvidence'];
            }
            if ('${fresh['dateEvidence']??''}'.isEmpty) {
              fresh['dateEvidence']=prior['dateEvidence'];
            }
            await tx.update('leads',{
              'status':fresh['status'], 'content':jsonEncode(fresh),
            },where:'id=?',whereArgs:[rows.first['id']]);
          }
          continue;
        }
        final id = await tx.insert('leads', {
          'id': item.id, 'url_key': key, 'discovered': item.discoveredAt.millisecondsSinceEpoch,
          'status': item.status, 'content': jsonEncode(item.toJson()),
        }, conflictAlgorithm: ConflictAlgorithm.ignore);
        if (id != 0) count++;
      }
    });
    return count;
  });

  Future<void> updateLead(HunterLead item) => _run((db) async {
    await db.update('leads', {'status': item.status, 'content': jsonEncode(item.toJson())},
      where: 'id=?', whereArgs: [item.id]);
  });

  /// A scan is persisted BEFORE any network call. A killed Flutter engine
  /// therefore leaves an auditable interrupted session instead of "no scan".
  static const scanLease = Duration(minutes: 8);

  Future<int?> beginScan({required String mode}) => _run((db) async {
    final now = DateTime.now();
    return db.transaction<int?>((tx) async {
      final rows = await tx.query('settings',
        columns: ['value'], where: 'key=?', whereArgs: ['lastScan'], limit: 1);
      if (rows.isNotEmpty) {
        final previous = Map<String, dynamic>.from(jsonDecode(rows.first['value'] as String));
        final began = DateTime.tryParse('${previous['timestamp']}');
        if (previous['state'] == 'running' && began != null &&
            now.difference(began) < scanLease &&
            now.difference(began) >= Duration.zero) {
          return null; // Foreground and WorkManager cannot start duplicate runs.
        }
        if (previous['state'] == 'running') {
          await _interruptTransaction(tx, previous, now);
        }
      }
      final record = <String, dynamic>{
        'timestamp': now.toIso8601String(), 'startedAt': now.toIso8601String(),
        'state': 'running', 'mode': mode, 'progress': 'Đã khởi tạo phiên; đang kết nối nguồn',
        'raw': 0, 'found': 0, 'added': 0, 'searched': 0,
        'discarded': 0, 'errors': <String>[], 'sources': <dynamic>[],
      };
      final id = await tx.insert('scan_history', {
        'timestamp': now.millisecondsSinceEpoch, 'content': jsonEncode(record),
      });
      record['sessionId'] = id;
      final encoded = jsonEncode(record);
      await tx.update('scan_history', {'content': encoded},where: 'id=?',whereArgs:[id]);
      await tx.insert('settings', {'key': 'lastScan', 'value': encoded},
        conflictAlgorithm: ConflictAlgorithm.replace);
      await _pruneScans(tx);
      return id;
    });
  });

  static Future<void> _pruneScans(Transaction tx) async {
    await tx.rawDelete('DELETE FROM scan_history WHERE id NOT IN (SELECT id FROM scan_history ORDER BY id DESC LIMIT 100)');
  }

  static Future<void> _interruptTransaction(Transaction tx,
      Map<String, dynamic> previous, DateTime now) async {
    final interrupted = <String, dynamic>{...previous,
      'state': 'interrupted', 'finishedAt': now.toIso8601String(),
      'progress': 'Phiên bị gián đoạn (Android đóng tác vụ hoặc quá thời gian)',
      'errors': <String>['Phiên quét trước chưa hoàn thành; có thể bị hệ thống đóng hoặc quá hạn 8 phút'],
    };
    final id = (previous['sessionId'] as num?)?.toInt();
    if (id != null) {
      await tx.update('scan_history', {'content': jsonEncode(interrupted)},
        where: 'id=?', whereArgs: [id]);
    }
    await tx.insert('settings', {'key':'lastScan','value':jsonEncode(interrupted)},
      conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<void> recoverInterruptedScan() => _run((db) async {
    await db.transaction((tx) async {
      final rows = await tx.query('settings',where:'key=?',whereArgs:['lastScan'],limit:1);
      if (rows.isEmpty) return;
      final previous = Map<String,dynamic>.from(jsonDecode(rows.first['value'] as String));
      if (previous['state'] != 'running') return;
      final at=DateTime.tryParse('${previous['timestamp']}');
      final now=DateTime.now();
      if (at==null || now.difference(at)>=scanLease || now.isBefore(at)) {
        await _interruptTransaction(tx,previous,now);
      }
    });
  });

  Future<void> updateScanProgress(int sessionId, String progress) => _run((db) async {
    await db.transaction((tx) async {
      final rows=await tx.query('scan_history',where:'id=?',whereArgs:[sessionId],limit:1);
      if(rows.isEmpty)return;
      final record=Map<String,dynamic>.from(jsonDecode(rows.first['content'] as String));
      if(record['state']!='running')return;
      record['progress']=progress;
      record['updatedAt']=DateTime.now().toIso8601String();
      final encoded=jsonEncode(record);
      await tx.update('scan_history',{'content':encoded},where:'id=?',whereArgs:[sessionId]);
      await tx.insert('settings',{'key':'lastScan','value':encoded},
        conflictAlgorithm:ConflictAlgorithm.replace);
    });
  });

  Future<void> finishScan(int sessionId, {required int found, required int added,
    required List<String> errors, int searched=0, int discarded=0,
    int raw=0, List<SourceScanStat> sources=const [], bool failed=false}) => _run((db) async {
    await db.transaction((tx) async {
      final rows=await tx.query('scan_history',where:'id=?',whereArgs:[sessionId],limit:1);
      if(rows.isEmpty)throw StateError('Không tìm thấy mã phiên quét $sessionId');
      final report=Map<String,dynamic>.from(jsonDecode(rows.first['content'] as String));
      if(report['state']!='running')return; // idempotent finish.
      final allFailed=sources.isEmpty || sources.every((s)=>
        s.status=='error' || s.status=='unsupported');
      report.addAll(<String,dynamic>{
        'finishedAt':DateTime.now().toIso8601String(),
        'state':failed || allFailed && errors.isNotEmpty?'failed':
          errors.isNotEmpty?'partial':'completed',
        'progress':failed?'Lỗi khi chạy bộ quét':
          allFailed && errors.isNotEmpty?'Không đọc được dữ liệu từ nguồn':
          'Đã hoàn thành lượt quét',
        'found':found,'added':added,'searched':searched,'discarded':discarded,
        'errors':errors,'raw':raw,'sources':sources.map((s)=>s.toJson()).toList(),
      });
      final encoded=jsonEncode(report);
      await tx.update('scan_history',{'content':encoded},where:'id=?',whereArgs:[sessionId]);
      await tx.insert('settings',{'key':'lastScan','value':encoded},
        conflictAlgorithm:ConflictAlgorithm.replace);
      await _pruneScans(tx);
    });
  });

  /// Backwards compatible reporting API for legacy callers.
  Future<void> recordScan({required int found, required int added,
    required List<String> errors, int searched=0, int discarded=0,
    int raw=0, List<SourceScanStat> sources=const []}) async {
    final id=await beginScan(mode:'legacy');
    if(id==null)throw StateError('Một phiên quét khác đang hoạt động');
    await finishScan(id, found:found,added:added,errors:errors,
      searched:searched,discarded:discarded,raw:raw,sources:sources);
  }

  Future<HunterSnapshot> snapshot() => _run((db) async {
    final counts = await db.rawQuery('SELECT status, COUNT(*) AS total FROM leads GROUP BY status');
    final totals = <String, int>{};
    for (final row in counts) totals['${row['status']}'] = (row['total'] as int?) ?? 0;
    final rows = await db.query('settings', where: 'key=?', whereArgs: ['lastScan'], limit: 1);
    DateTime? at;
    String message = 'Chưa có phiên quét';
    List<String> errors = [];
    List<SourceScanStat> sources = [];
    if (rows.isNotEmpty) {
      final report = Map<String, dynamic>.from(jsonDecode(rows.first['value'] as String));
      at = DateTime.tryParse('${report['timestamp']}');
      errors = (report['errors'] is List) ? (report['errors'] as List).map((x) => '$x').toList() : [];
      sources = report['sources'] is List ? (report['sources'] as List)
        .whereType<Map>().map((x)=>SourceScanStat.fromJson(Map<String,dynamic>.from(x))).toList():[];
      final state='${report['state']??'completed'}';
      final label=<String,String>{'running':'ĐANG QUÉT','completed':'HOÀN TẤT',
        'partial':'HOÀN TẤT CÓ LỖI','failed':'THẤT BẠI',
        'interrupted':'BỊ GIÁN ĐOẠN'}[state]??'ĐÃ GHI NHẬN';
      message = state=='running' ? '$label · ${report['progress']??''}' :
        '$label · Tin thô ${report['raw'] ?? 0} · Phát hiện ${report['found'] ?? 0} · Mới ${report['added'] ?? 0}'
        ' · Loại ${report['discarded'] ?? 0}'
        '${errors.isEmpty ? '' : ' · ${errors.length} lỗi'}';
    }
    return HunterSnapshot(
      total: totals.values.fold<int>(0, (a, b) => a + b),
      pending: totals['pending'] ?? 0, confirmed: totals['imported'] ?? 0,
      rejected: totals['rejected'] ?? 0, lastScan: at,
      message: message, errors: errors, sources: sources,
    );
  });

  Future<List<Map<String,dynamic>>> scanHistory() => _run((db) async {
    final rows=await db.query('scan_history',orderBy:'id DESC',limit:25);
    return rows.map((r)=>Map<String,dynamic>.from(
      jsonDecode(r['content'] as String))).toList();
  });

  Future<List<String>?> cachedWards(String district) => _run((db) async {
    final result=await db.query('settings',columns:['value'],where:'key=?',
      whereArgs:['wards:$district'],limit:1);
    if(result.isEmpty)return null;
    return (jsonDecode(result.first['value'] as String) as List)
      .whereType<String>().toList();
  });

  Future<void> cacheWards(String district,List<String> values)=>_run((db) async {
    await db.insert('settings',{'key':'wards:$district','value':jsonEncode(values)},
      conflictAlgorithm:ConflictAlgorithm.replace);
  });

  Future<void> close() async {
    final waiting = _opening;
    if (waiting != null) {
      try { await waiting; } catch (_) { /* already failed to open */ }
    }
    final db = _db;
    _db = null;
    if (db != null && db.isOpen) await db.close();
  }
}
