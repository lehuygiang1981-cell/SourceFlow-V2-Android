# SourceFlow R3.5.3 BuildFix4

Reason for fix: GitHub Actions run 41304981310 failed because a legacy smoke test expected status `ok` despite a deliberately incomplete detail response. The scanner correctly reports `partial`, and rejects this lead.

Changes from BuildFix3:
- test/hunter_test.dart expects `partial` for an incomplete detail, consistent with the hard gate.
- pubspec.yaml increments build to 3.5.3+56.
- Production filtering/parsing code remains byte-for-byte unchanged.

The new workflow requires all existing regression gates and static analysis to succeed before producing the release APK.
