# SourceFlow R3.5.8 — OCR address extraction correction

## Fixed
- Real address: **Đường số 12, Phường Hiệp Bình Chánh (Quận Thủ Đức cũ), Thành phố Thủ Đức, Tp Hồ Chí Minh** is extracted even without the literal "Địa chỉ" label.
- Prevents marketing phrases such as "Khu nhà ở biệt thự - dân trí cao" from being misfiled as the property address.
- Distinguishes full street+ward/city from generic "Vị trí: 5 phút tới ..." directions.
- Handles address on next OCR line, multi-line city continuation, and post-address price/area lines.
- Preserves numbered Vietnamese addresses "23/6c đường số 5" and "68 Bưng Ông Thoàn" even without a street prefix.
- Recognizes "BÁN ĐẤT ... KHU NHÀ Ở BIỆT THỰ" as a land listing instead of a house listing when a land transaction leads the title.

## Preserved
- R3.5.7 broker signals, poster count filters, two-stage saved-for-review verification, owner checks, deduplication, SQLite and OCR original text.
- Existing user-edited form values are **not overwritten** by a new OCR suggestion. To refresh an incorrectly filled field, clear it before using "Điền gợi ý vào các ô trống".

## Tests
- `test/hunter_r358_address_extraction_test.dart`: screenshot-derived BDS68, multi-line OCR, labeled/no-label addresses, anti-overcapture, Rio Vista and legacy regression inputs.
- Existing regression suites remain in the workflow and run before release APK compilation.

## Build status
The source ZIP and YAML were checked for integrity. Flutter SDK is not available in this container. This source is **not yet GitHub-built**; passing GitHub Actions is required before claiming a working APK.
