import 'dart:ui' show DartPluginRegistrant;
import 'package:flutter/widgets.dart';
import 'package:workmanager/workmanager.dart';
import 'hunter_search.dart';
import 'hunter_storage.dart';

const hunterJob = 'sourceflow_hunter_r2_scan';
const hunterWorkName = 'sourceflow_personal_r2_hunter';

@pragma('vm:entry-point')
void hunterCallbackDispatcher() {
  Workmanager().executeTask((task, inputData) async {
    if (task != hunterJob) return true;
    WidgetsFlutterBinding.ensureInitialized();
    DartPluginRegistrant.ensureInitialized();
    final storage = HunterStorage();
    final search = HunterSearch();
    int? sessionId;
    try {
      await storage.open();
      await storage.recoverInterruptedScan();
      final settings = await storage.settings();
      if (!settings.autoScan) return true;
      sessionId=await storage.beginScan(mode:'background');
      final id=sessionId;
      if(id==null)return true; // Foreground already owns the scan lease.
      final result=await search.scan(settings,onProgress:(progress) =>
        storage.updateScanProgress(id,progress))
        .timeout(const Duration(minutes:4));
      final added=await storage.addDiscovered(result.leads);
      await storage.finishScan(id,found:result.leads.length,added:added,
        errors:result.errors,searched:result.queries,
        discarded:result.discarded,raw:result.raw,sources:result.sources);
      return true;
    } catch (error) {
      search.close();
      if(sessionId!=null){
        try {
          await storage.finishScan(sessionId!,found:0,added:0,
            errors:['Lỗi tác vụ nền: $error'],failed:true);
        } catch (_) { /* recovery marks interrupted on next app open */ }
      }
      return false;
    } finally {
      search.close();
      // Separate DB handle: safe to close without invalidating foreground.
      await storage.close();
    }
  });
}

Future<void> configureHunterBackground(bool enabled) async {
  final manager = Workmanager();
  await manager.initialize(hunterCallbackDispatcher);
  if (enabled) {
    await manager.registerPeriodicTask(hunterWorkName, hunterJob,
      frequency: const Duration(hours: 2),
      constraints: Constraints(networkType: NetworkType.connected),
      existingWorkPolicy: ExistingPeriodicWorkPolicy.update,
    );
  } else {
    await manager.cancelByUniqueName(hunterWorkName);
  }
}
