# SourceFlow R3.5.4 - Giữ nguồn thiếu dữ liệu để xác minh

- Mặc định tab **Chờ xác minh** hiển thị mọi tin chưa loại gồm Đạt sơ bộ và Thiếu dữ liệu. 10 tin thiếu dữ liệu từ R3.5.3 lưu SQLite sẽ không phải quét lại để hiển thị.
- Tab Đạt bộ lọc, Thiếu dữ liệu, Đã loại, Đã lưu tạm, Đã xác minh & lưu, Tất cả vẫn có riêng. Lưu tạm không làm tăng số đếm Đã xác minh.
- Tin thiếu dữ liệu có nút **Lưu chờ xác minh**, lưu vào kho Nguồn hàng với trạng thái **Chưa xác minh**, Chưa liên hệ; người dùng chủ động xác minh sau. Không tự đánh dấu chính chủ.
- Tin bị loại theo bằng chứng môi giới, số tin đã xác thực >3 hoặc ngày đăng quá hạn vẫn bị loại theo bộ lọc.
- Sao chép báo cáo sẽ gồm cả tin thiếu dữ liệu và link gốc.
- Cập nhật tên hiển thị R3.5.4.
- Bổ sung test hồi quy cho nhóm pending và tiêu chí loại cứng.

Lưu ý: Bản mã nguồn này cần GitHub Actions biên dịch và kiểm thử trước khi có APK. Không tự nhận đã sửa lỗi OCR trên ảnh.
