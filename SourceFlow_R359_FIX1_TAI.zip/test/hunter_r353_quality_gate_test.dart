import 'package:flutter_test/flutter_test.dart';
import 'package:html/parser.dart' as html;
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:sourceflow_android/hunter_models.dart';
import 'package:sourceflow_android/hunter_search.dart';

void main() {
  String day() {
    final n=DateTime.now();
    return '${n.day.toString().padLeft(2,'0')}/${n.month.toString().padLeft(2,'0')}/${n.year}';
  }

  test('Seller count 10 and 24 excludes owner-language ads', () {
    for(final n in [10,24]){
      final doc=html.parse('<main><section class="seller-info">'
        '<h3>Người đăng</h3><div>Tổng số tin đăng <b>$n</b></div>'
        '</section></main>');
      final count=HunterSearch.sellerCountFromSellerCard(doc,'bds68.com.vn');
      expect(count,'$n');
      final lead=HunterLead(
        url:'https://bds68.com.vn/ban-nha-$n-31293473.html',
        title:'Chính chủ bán nhà 4 tầng ở Thủ Đức',source:'bds68.com.vn',
        dateEvidence:day(),posterCountEvidence:count,
        posterCountSource:'seller_profile_verified',
        detailText:'Tiêu đề: Chính chủ bán nhà 4 tầng, diện tích 73m2, giá 9,6 tỷ.'
          ' Địa chỉ đường 35 Hiệp Bình Chánh.');
      expect(HunterSearch.classifyLead(lead,const HunterSettings(maxPosterListings:3)),'rejected');
    }
  });

  test('BDS68 detail area 73m² outranks headline 74m²', () {
    final lead=HunterLead(url:'https://bds68.com.vn/ban-nha-31293473.html',
      source:'bds68.com.vn',
      title:'Bán nhà 4 tầng 74m2 đường 35 hiệp bình chánh',
      detailText:'Diện tích: 73 m2\nGiá: 9,6 tỷ\n'
        'Mặt tiền: 4,3 m\nLoại Tin Rao: Nhà Riêng');
    expect(lead.parsed.area,'73 m2');
    expect(lead.parsed.price,contains('9,6'));
  });

  test('Batdongsan seller count excludes unrelated suggested listings', () {
    final doc=html.parse('''<main>
      <section><h2>Thông tin người đăng</h2><div class="user-info">
      <h3>Huynh</h3><a>Xem thêm 1 tin khác</a></div></section>
      <section class="recommended"><a>Xem thêm 24 tin khác</a></section>
      </main>''');
    expect(HunterSearch.sellerCountFromSellerCard(doc,'batdongsan.com.vn'),'2');
    final other=html.parse('<section class="recommended">Xem thêm 24 tin khác</section>');
    expect(HunterSearch.sellerCountFromSellerCard(other,'batdongsan.com.vn'),isEmpty);
  });

  test('Explicit property specs extract fully without guessing plot length', () {
    final doc=html.parse('''<html><head><meta name="description"
      content="Chính chủ bán nhà HXH 79m2 tại Thủ Đức"></head><body>
      <h1>Chính chủ bán nhà HXH, sổ hồng, 79m2, 3 tầng</h1>
      <div class="re__pr-short-description">56, Đường Bình Chiểu, Phường Bình Chiểu, Thành phố Thủ Đức</div>
      <table>
      <tr><td>Loại Tin Rao</td><td>Nhà Riêng</td></tr>
      <tr><td>Giá</td><td>7 tỷ</td></tr>
      <tr><td>Diện tích</td><td>79 m²</td></tr>
      <tr><td>Mặt tiền</td><td>4,5 m</td></tr>
      <tr><td>Đường vào</td><td>5 m</td></tr>
      </table>
      <section class="re__pr-description"><p>Nhà rất đẹp, trệt làm văn phòng công ty,</p>
      <p>sân trước 2,4m, sân sau 2m, có hệ thống điện mặt trời.</p></section>
      <section><h3>Thông tin người đăng</h3><div class="user-info">Huynh - Xem thêm 1 tin khác</div></section>
      <p>Ngày đăng: ${day()}</p></body></html>''');
    final text=HunterSearch.extractDetailText(doc);
    final lead=HunterLead(url:'https://batdongsan.com.vn/ban-nha-rieng-thu-duc-pr12345678',
      source:'batdongsan.com.vn',
      title:HunterSearch.extractDetailTitle(doc,'Chính chủ bán nhà'),
      detailText:text,dateEvidence:day(),
      posterCountEvidence:HunterSearch.sellerCountFromSellerCard(doc,'batdongsan.com.vn'),
      posterCountSource:'seller_profile_verified');
    expect(lead.parsed.type,'Nhà riêng');
    expect(lead.parsed.area,'79 m²');
    expect(lead.parsed.price,contains('7'));
    expect(lead.parsed.address,contains('Bình Chiểu'));
    expect(lead.parsed.width,'4,5 m');
    expect(lead.parsed.length,isEmpty);
    expect(lead.parsed.sourceUrl,lead.url);
    expect(HunterSearch.classifyLead(lead,const HunterSettings()),'qualified');
  });

  test('Broker advertisement at bottom of long description cannot be lost', () {
    final long=List<String>.filled(430,'Ngôi nhà đã được hoàn công đầy đủ. ').join();
    final doc=html.parse('<body><h1>Bán nhà mặt tiền kinh doanh</h1>'
      '<section class="re__pr-description">$long '
      'Chuyên bán mặt tiền kinh doanh Thủ Đức, tư vấn định giá miễn phí.'
      '</section></body>');
    final details=HunterSearch.extractDetailText(doc);
    final lead=HunterLead(url:'https://bds68.com.vn/ban-nha-21559123.html',
      title:'Bán nhà mặt tiền kinh doanh',source:'bds68.com.vn',detailText:details);
    expect(HunterSearch.brokerEvidence(lead),isNotNull);
  });

  test('Very long listing must retain broker disclaimer at its end', () {
    final long=List<String>.filled(1100,'Nhà bán đầy đủ nội thất, sổ hồng hoàn công. ').join();
    final doc=html.parse('<main><section class="re__pr-description">'
        '$long Chuyên bán mặt tiền kinh doanh và tư vấn định giá miễn phí.'
        '</section></main>');
    final details=HunterSearch.extractDetailText(doc);
    expect(details,contains('Chuyên bán mặt tiền kinh doanh'));
    final lead=HunterLead(url:'https://batdongsan.com.vn/ban-nha-rieng-a-pr98765432',
      title:'Bán nhà riêng 3 tầng',source:'batdongsan.com.vn',detailText:details);
    expect(HunterSearch.brokerEvidence(lead),isNotNull);
  });

  test('Unknown seller total never reaches the accepted group', () {
    final lead=HunterLead(url:'https://bds68.com.vn/ban-nha-12345678.html',
      title:'Chính chủ bán nhà diện tích 80m2',source:'bds68.com.vn',
      dateEvidence:day(),detailText:'Giá 8 tỷ, nhà đẹp, chính chủ bán nhà số 12 đường 35 Thủ Đức');
    expect(HunterSearch.classifyLead(lead,const HunterSettings()),'potential');
  });

  test('403 source never fabricates filtered seller results', () async {
    final fake=MockClient((request) async {
      if(request.url.path.endsWith('.html'))return http.Response('Forbidden',403);
      return http.Response('''<html><body><a href="/ban-nha-31293473.html">
        <h3>Bán nhà 4 tầng 74m2 đường 35 Hiệp Bình Chánh, giá 9,6 tỷ</h3>
        </a></body></html>''',200,headers:{'content-type':'text/html; charset=utf-8'});
    });
    final scanner=HunterSearch(client:fake);
    final result=await scanner.scan(const HunterSettings(sites:['bds68.com.vn']));
    expect(result.raw,1);
    expect(result.leads,isEmpty);
    expect(result.errors,isNotEmpty);
    scanner.close();
  });
}
