import 'package:flutter_test/flutter_test.dart';
import 'package:html/parser.dart' as html;
import 'package:sourceflow_android/hunter_models.dart';
import 'package:sourceflow_android/hunter_search.dart';
import 'package:sourceflow_android/models.dart';

void main() {
  test('BDS68: seller with 10 posts (over 3) is rejected', () {
    final doc=html.parse('<section><h3>Trung Hữu Nguyễn</h3>'
      '<div>Tổng số tin đăng <strong>10</strong></div></section>');
    final count=HunterSearch.sellerCountOnDetail(doc,'bds68.com.vn');
    expect(count,'10');
    final lead=HunterLead(url:'https://bds68.com.vn/ban-nha-31293473.html',
      source:'bds68.com.vn',title:'Bán nhà 4 tầng đường 35',
      detailText:'Bán nhà 4 tầng 74m2 hiệp bình chánh, giá 9.6 tỷ, liên hệ Trung xem nhà trực tiếp, làm việc chính chủ',
      posterCountEvidence:count,posterCountSource:'seller_profile_verified');
    expect(HunterSearch.classifyLead(lead,const HunterSettings(maxPosterListings:3)), 'rejected');
    expect(HunterSearch.brokerEvidence(lead),isNotNull);
  });
  test('BDS68: 24 posts + brokerage advertising rejected despite owner claim', () {
    final doc=html.parse('<section><b>Trần Vững</b><span>Tổng số tin đăng</span><b>24</b></section>');
    final count=HunterSearch.sellerCountOnDetail(doc,'bds68.com.vn');
    expect(count,'24');
    final lead=HunterLead(url:'https://bds68.com.vn/ban-nha-21559123.html',
      source:'bds68.com.vn',title:'Bán mặt tiền Võ Văn Ngân',
      detailText:'Chuyên bán mặt tiền kinh doanh TP Thủ Đức. Chính chủ 100%. Tư vấn định giá miễn phí.',
      posterCountEvidence:count,posterCountSource:'seller_profile_verified');
    expect(HunterSearch.classifyLead(lead,const HunterSettings(maxPosterListings:3)), 'rejected');
    expect(HunterSearch.brokerEvidence(lead),isNotNull);
  });
  test('Batdongsan: one other post means 2 total', () {
    final doc=html.parse('<section><h2>Thông tin người đăng</h2>'
      '<div><b>Huynh</b> <span>Xem thêm 1 tin khác</span></div></section>');
    expect(HunterSearch.sellerCountOnDetail(doc,'batdongsan.com.vn'),'2');
  });
  test('Batdongsan house details are not classified as warehouse', () {
    const detail='''Tiêu đề: Chính chủ bán nhà HXH, sổ hồng, 79m2, 3 tầng trệt làm VP công ty
Loại Tin Rao: Nhà Riêng
Giá: 7 tỷ
Địa chỉ: 56, Đường Bình Chiểu, Phường Bình Chiểu, Thành phố Thủ Đức
Diện tích: 79 m2
Mặt tiền: 4,5 m
Số tầng: 3
Pháp lý: Sổ đỏ/ Sổ hồng
Sân trước 2,4m, sân sau 2m, có kho hàng gia đình''';
    final lead=HunterLead(url:'https://batdongsan.com.vn/ban-nha-rieng-thu-duc-pr12345678',
      source:'batdongsan.com.vn',title:'Chính chủ bán nhà HXH, sổ hồng, 79m2, 3 tầng',detailText:detail);
    expect(lead.parsed.type,'Nhà riêng');
    expect(lead.parsed.address,contains('Bình Chiểu'));
    expect(lead.parsed.price,contains('7'));
    expect(lead.parsed.width,'4,5 m');
    expect(lead.parsed.length,isEmpty);
    expect(lead.parsed.sourceUrl,lead.url);
  });
  test('OCR does not mistake backyard for plot length', () {
    final parsed=parseIntake('Bán nhà diện tích 79m2 ngang 4,5m, sân sau 2m, giá 7 tỷ');
    expect(parsed.width,'4,5 m');
    expect(parsed.length,isEmpty);
  });
}
