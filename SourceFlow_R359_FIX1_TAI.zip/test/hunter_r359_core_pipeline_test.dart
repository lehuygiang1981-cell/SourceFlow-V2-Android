import 'package:flutter_test/flutter_test.dart';
import 'package:html/parser.dart' as html;
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:sourceflow_android/hunter_models.dart';
import 'package:sourceflow_android/hunter_search.dart';
import 'package:sourceflow_android/models.dart';

void main() {
  const root='https://muaban.net/bat-dong-san/ban-nha-quan-thu-duc-ho-chi-minh';
  final now=DateTime.now();
  final today='${now.day.toString().padLeft(2,'0')}/${now.month.toString().padLeft(2,'0')}/${now.year}';

  test('MuaBan poster name includes broker branding, not misread as property title', () {
    const cardHtml='''
      <article class="listing-card"><a href="/bat-dong-san/ban-nha-id71325198"><h3>Bán nhà Hiệp Bình Chánh 170m²</h3></a>
      <div class="poster-info"><strong>Hoàng Anh chuyên nhà Thủ Đức</strong></div></article>
    ''';
    final lead=HunterSearch.parseListingHtml(cardHtml,Uri.parse(root),'muaban.net');
    expect(lead.length,1);
    expect(lead.single.posterName,'Hoàng Anh chuyên nhà Thủ Đức');
    expect(HunterSearch.brokerEvidence(lead.single),isNotNull);
    expect(HunterSearch.classifyLead(lead.single,const HunterSettings()),'rejected');
  });

  test('MuaBan owner profile: 17 Tin đăng / 9 tháng is 17, not 9', () {
    final doc=html.parse('''
      <html><head><title>Trang cá nhân của Nguyễn Gia Hưng | MuaBan</title></head><body>
        <section class="profile-header"><b>Nguyễn Gia Hưng</b>
        <div class="stats"><span>17</span><span>Tin đăng</span></div>
        <div class="stats"><span>9 tháng</span><span>Tham gia</span></div></section>
      </body></html>''');
    expect(HunterSearch.sellerCountFromProfilePage(doc),'17');
    expect(HunterSearch.sellerNameFromProfilePage(doc),'nguyen gia hung');
  });

  test('List cards are isolated: 2 Tin đăng belongs to seller A, 19 to seller B',(){
    final doc='''<html><body><main>
      <article class="listing-card"><a href="/ban-nha-id71325198"><h3>Bán nhà 90m² giá 9 tỷ</h3></a>
        <div class="poster-info"><b>Nguyễn Gia Hưng</b> <small>2 Tin đăng</small></div></article>
      <article class="listing-card"><a href="/ban-nha-id71325199"><h3>Bán nhà 80m² giá 8 tỷ</h3></a>
        <div class="poster-info"><b>Trần Văn Hai</b> <small>19 Tin đăng</small></div></article>
      <aside>1.500 tin bất động sản</aside>
    </main></body></html>''';
    final leads=HunterSearch.parseListingHtml(doc,Uri.parse(root),'muaban.net');
    expect(leads.length,2);
    expect(leads[0].posterCountEvidence,'2');
    expect(leads[1].posterCountEvidence,'19');
  });

  test('Full pipeline: fetch seller profile, reject verified 17-post author', () async {
    final client=MockClient((req) async {
      if(req.url.path.contains('/trang-ca-nhan/')){
        return http.Response('''<html><head><title>Trang cá nhân của Nguyễn Gia Hưng | MuaBan</title></head>
          <body><section class="profile-header"><b>Nguyễn Gia Hưng</b>
          <div><strong>17</strong><span>Tin đăng</span></div><div>9 tháng Tham gia</div>
          </section></body></html>''',200,headers:{'content-type':'text/html; charset=utf-8'});
      }
      if(req.url.path.contains('-id71325198')){
        return http.Response('''<html><body>
          <h1>Bán nhà Hiệp Bình Chánh diện tích 170m²</h1>
          <section class="detail-description">Bán căn nhà riêng có 3 phòng ngủ, sổ hồng riêng và vị trí đẹp gần chợ.</section>
          <div class="poster-info"><a href="/trang-ca-nhan/nguyen-gia-hung">Nguyễn Gia Hưng</a></div>
          <p>Ngày bắt đầu: $today</p></body></html>''',200,headers:{'content-type':'text/html; charset=utf-8'});
      }
      return http.Response('''<html><body><article class="listing-card">
        <a href="/bat-dong-san/ban-nha-id71325198"><h3>Bán nhà Hiệp Bình Chánh diện tích 170m²</h3></a>
        <div class="poster-info">Người đăng: Nguyễn Gia Hưng</div>
      </article></body></html>''',200,headers:{'content-type':'text/html; charset=utf-8'});
    });
    final scanner=HunterSearch(client:client);
    final result=await scanner.scan(const HunterSettings(sites:['muaban.net'],maxPosterListings:3));
    expect(result.leads.length,1);
    expect(result.leads.single.posterName,'Nguyễn Gia Hưng');
    expect(result.leads.single.posterCountEvidence,'17');
    expect(result.leads.single.posterCountSource,'seller_profile_verified');
    expect(result.leads.single.qualification,'rejected');
    scanner.close();
  });

  test('Unreadable detail stays in missing-data, not silently dropped', () async {
    final client=MockClient((req) async {
      if(req.url.path.contains('-id71325198')){
        return http.Response('<html><body><h1>Temporarily unavailable</h1></body></html>',200);
      }
      return http.Response('''<html><body><article class="listing-card">
        <a href="/bat-dong-san/ban-nha-id71325198"><h3>Bán nhà riêng Thủ Đức 90m² giá 8 tỷ</h3></a>
      </article></body></html>''',200,headers:{'content-type':'text/html; charset=utf-8'});
    });
    final scanner=HunterSearch(client:client);
    final result=await scanner.scan(const HunterSettings(sites:['muaban.net']));
    expect(result.leads.length,1);
    expect(result.leads.single.qualification,'potential');
    expect(hunterLeadInView(result.leads.single,'needs_data'),isTrue);
    scanner.close();
  });

  test('Exact agency phrases and income wording are rejected; generic owner viewing remains reviewable', () {
    HunterLead lead(String body)=>HunterLead(url:'https://bds68.com.vn/ban-dat-99999.html',
      source:'bds68.com.vn',title:'Bán nhà sổ hồng riêng',detailText:body);
    for(final evidence in [
      'Liên hệ để làm việc trực tiếp với chủ nhà',
      'Liên hệ để xem nhà, thương lượng chính chủ',
      'Liên hệ Zalo 0903917322 để xem đất và làm việc trực tiếp',
      'Khai thác dòng tiền 50 triệu mỗi tháng',
      'Thu nhập hàng tháng từ cho thuê',
      'Nhận ký gửi và tư vấn định giá miễn phí',
    ]){
      expect(HunterSearch.brokerEvidence(lead(evidence)),isNotNull,reason:evidence);
      expect(HunterSearch.classifyLead(lead(evidence),const HunterSettings()),'rejected',reason:evidence);
    }
    expect(HunterSearch.brokerEvidence(lead('Liên hệ em Phương xem nhà ngay')),isNull);
  });

  test('Structured address excludes 5-minute marketing field and prefers real road',(){
    final lead=HunterLead(url:'https://bds68.com.vn/ban-dat-pr31371301',
      source:'bds68.com.vn',title:'BÁN ĐẤT KDC SÔNG ĐÀ - KHU NHÀ Ở BIỆT THỰ',
      detailText:'''
      Vị trí: 5 phút đến Gigamall, 20 phút đến sân bay TSN.
      Địa chỉ: Đường số 12, Phường Hiệp Bình Chánh, Thành phố Thủ Đức, TP Hồ Chí Minh
      Diện tích: 220m² trong mô tả bán đất.
      Diện tích đất: 200m²
      Giá bán: 16,5 tỷ
      ''');
    expect(lead.parsed.address,contains('Đường số 12'));
    expect(lead.parsed.address,isNot(contains('phút')));
    expect(lead.parsed.area,'200m²');
    expect(lead.parsed.price,contains('16,5'));
    expect(lead.parsed.type,'Đất nền');
  });

  test('Asking price reduced from 18 to 14.9 and legal area from CN 145',(){
    final parsed=parseIntake('''Bán biệt thự Hiệp Bình Chánh Thủ Đức
      Diện tích 10x17m (CN 145m²).
      Giá giảm 18 tỷ còn14.9 tỷ – thương lượng nhẹ.''');
    expect(parsed.area,'145 m²');
    expect(parsed.width,'10 m');
    expect(parsed.length,'17 m');
    expect(parsed.price,'14.9 tỷ');
  });

  test('Dimension labels diện tích and DT parse 10x17 without area confusion',(){
    for (final body in [
      'Bán biệt thự. Diện tích 10x17m (CN 145m²). Giá 14.9 tỷ.',
      'Bán biệt thự. DT: 10x17m, công nhận 145m². Giá bán 14,9 tỷ.',
      'Bán biệt thự. Kích thước: 10x17m, diện tích công nhận 145m².',
    ]) {
      final parsed=parseIntake(body);
      expect(parsed.width,'10 m',reason:body);
      expect(parsed.length,'17 m',reason:body);
      expect(parsed.area,'145 m²',reason:body);
    }
  });

  test('Explicit 170m² overrides legal area 145m² in same ad',(){
    final parsed=parseIntake('''Bán nhà sổ riêng
      Diện tích: 170 m², công nhận 145m²
      Giá bán: 14,9 tỷ''');
    expect(parsed.area,'170 m²');
  });

  test('OCR retains address label and brackets around area/price',(){
    final text=ocrFieldsText([
      'Đặc điểm bất động sản',
      'BÁN ĐẤT KDC SÔNG ĐÀ - KHU NHÀ Ở BIỆT THỰ',
      'Địa chỉ bất động sản',
      'Đường số 12, Phường Hiệp Bình Chánh, Thành phố Thủ Đức',
      'Diện tích: [200m² – ngang 10m x dài 20m]',
      'Giá bán: [16,5tỷ] – thương lượng chính chủ',
    ]);
    expect(text,contains('Địa chỉ bất động sản'));
    final parsed=parseIntake(text);
    expect(parsed.type,'Đất nền');
    expect(parsed.address,contains('Đường số 12'));
    expect(parsed.area,'200 m²');
    expect(parsed.price,'16,5 tỷ');
    expect(parsed.width,'10 m');
    expect(parsed.length,'20 m');
  });
}
