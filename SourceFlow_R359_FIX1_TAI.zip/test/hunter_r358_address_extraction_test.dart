import 'package:flutter_test/flutter_test.dart';
import 'package:sourceflow_android/models.dart';

void main() {
  const correctAddress = 'Đường số 12, Phường Hiệp Bình Chánh (Quận Thủ Đức cũ), Thành phố Thủ Đức, Tp Hồ Chí Minh';

  test('BDS68: preserve complete standalone street address, never villa-description text', () {
    final parsed = parseIntake('''🏡 BÁN ĐẤT KDC SÔNG ĐÀ - KHU NHÀ Ở BIỆT THỰ - DÂN TRÍ CAO
Giá: 16.5 tỷ
$correctAddress
Diện tích: 200m²
Chính chủ cần bán lô đất nằm trong khu dân cư hiện hữu.
✨ Ưu điểm nổi bật: Khu dân cư văn minh, nhiều nhà đẹp đã xây dựng.
📐 Diện tích: [200m² – ngang 10m x dài 20m]
💰 Giá bán: [16,5 tỷ] – thương lượng chính chủ.''');
    expect(parsed.address,correctAddress);
    expect(parsed.area,'200 m²');
    expect(parsed.price,'16.5 tỷ');
    expect(parsed.type,'Đất nền');
  });

  test('OCR: unlabeled address survives field-only hint preprocessing', () {
    final hints=ocrFieldsText(['BÁN ĐẤT KDC SÔNG ĐÀ - KHU NHÀ Ở BIỆT THỰ',
      'Đặc điểm bất động sản',correctAddress,'Diện tích: 200m2','Giá bán: 16,5 tỷ']);
    expect(parseIntake(hints).address,correctAddress);
  });

  test('OCR: line-break between address label and value is recognized', () {
    final parsed=parseIntake('''Chính chủ bán nhà Rio Vista hai mặt tiền
Địa chỉ bất động sản
Rio Vista, Đường Dương Đình Hội, Phường Phước Long B, Thành phố Thủ Đức, TP Hồ Chí Minh
Diện tích đất: 119 m²
Giá bán: 13 tỷ
Chiều ngang: 5m''');
    expect(parsed.address,'Rio Vista, Đường Dương Đình Hội, Phường Phước Long B, Thành phố Thủ Đức, TP Hồ Chí Minh');
    expect(parsed.area,'119 m²');
    expect(parsed.price,'13 tỷ');
    expect(parsed.width,'5 m');
  });

  test('standalone road address wins over generic promotional vị trí field', () {
    final parsed=parseIntake('''BÁN ĐẤT KDC SÔNG ĐÀ - KHU NHÀ Ở BIỆT THỰ - DÂN TRÍ CAO
Vị trí: TP Thủ Đức, 5 phút đến Gigamall - 20 phút đến sân bay.
$correctAddress
Diện tích: 200m²''');
    expect(parsed.address,correctAddress);
  });

  test('the vague words "nhà ở biệt thự" do not constitute an address', () {
    final parsed=parseIntake('''BÁN ĐẤT KDC SÔNG ĐÀ - KHU NHÀ Ở BIỆT THỰ - DÂN TRÍ CAO
Đất vuông vức, thích hợp xây biệt thự, khu nhà ở dân trí cao.
Diện tích 200 m², giá 16.5 tỷ.''');
    expect(parsed.address,isEmpty);
  });

  test('address field is not contaminated by following price on the same line', () {
    final parsed=parseIntake('Địa chỉ: Đường số 12, Phường Hiệp Bình Chánh, TP Hồ Chí Minh Giá bán: 16.5 tỷ');
    expect(parsed.address,'Đường số 12, Phường Hiệp Bình Chánh, TP Hồ Chí Minh');
  });

  test('OCR may wrap the full street address across lines', () {
    final parsed=parseIntake('''Đất nền KDC Sông Đà
Đường số 12, Phường Hiệp Bình Chánh (Quận Thủ Đức cũ),
Thành phố Thủ Đức, Tp Hồ Chí Minh
Diện tích: 200 m²''');
    expect(parsed.address,correctAddress);
  });
  test('legacy: preserve house number before the road name', () {
    final p=parseIntake('''CHÍNH CHỦ BÁN NHÀ
Địa chỉ
23/6c đường số 5 phường Linh Xuân
Diện tích: 60m²''');
    expect(p.address,'23/6c đường số 5 phường Linh Xuân');
  });

  test('legacy: labeled numbered street without the word đường is accepted', () {
    final p=parseIntake('''BÁN NHÀ MẶT TIỀN
Địa chỉ: 68 Bưng Ông Thoàn, Long Trường
Diện tích: 130 m²''');
    expect(p.address,'68 Bưng Ông Thoàn, Long Trường');
  });

  test('single-line spoken address stops before owner and area labels', () {
    final p=parseIntake('Nhà 23/6c đường số 5 phường Linh Xuân chủ là chị Lan diện tích 60 mét vuông giá 5 tỷ');
    expect(p.address,'23/6c đường số 5 phường Linh Xuân');
  });

}
