import 'package:flutter_test/flutter_test.dart';
import 'package:sourceflow_android/hunter_search.dart';
import 'package:sourceflow_android/hunter_models.dart';
import 'package:sourceflow_android/models.dart';

void main() {
  const filter = HunterSettings(maxPosterListings:3,excludeBroker:true);
  HunterLead candidate(String detail,{String poster='',String count='',String origin=''}) =>
      HunterLead(url:'https://bds68.com.vn/ban-dat-thu-duc-pr99999999',
        title:'Bán đất Thủ Đức',source:'bds68.com.vn',detailText:detail,
        posterName:poster,posterCountEvidence:count,posterCountSource:origin);

  test('owner negotiation and contact-for-showing are hard agent signals', () {
    for (final phrase in [
      'Giá 16,5 tỷ – thương lượng chính chủ.',
      'Liên hệ để làm việc trực tiếp.',
      'Liên hệ để xem nhà.',
      'Liên hệ để xem đất và trao đổi.',
      'Liên hệ để thương lượng với chủ.',
      'Để xem đất, liên hệ để gặp chủ nhà.',
    ]) {
      final lead = candidate('Đất có sổ hồng, $phrase');
      expect(HunterSearch.brokerEvidence(lead),isNotNull,reason:phrase);
      expect(HunterSearch.classifyLead(lead,filter),'rejected',reason:phrase);
    }
  });

  test('advertising income is flagged per user owner-only policy', () {
    for (final phrase in [
      'Nhà dòng tiền 60 triệu mỗi tháng',
      'Dòng thu nhập hàng tháng ổn định',
      'Tài sản tạo dòng tiền',
      'Cho thuê doanh thu cho thuê ổn định',
    ]) {
      final lead=candidate('Nhà chính chủ, $phrase');
      expect(HunterSearch.brokerEvidence(lead),isNotNull,reason:phrase);
    }
  });

  test('poster account named specialty agent is hard evidence', () {
    final x=candidate('Nhà đất 120m2 sổ riêng',
      poster:'Hoàng Anh chuyên nhà Thủ Đức');
    expect(HunterSearch.brokerEvidence(x),isNotNull);
    expect(HunterSearch.classifyLead(x,filter),'rejected');
  });

  test('independent ordinary name is not an automatic broker identity', () {
    final x=candidate('Nhà 120m2, giá 8 tỷ, sổ riêng',poster:'Nguyễn Quang Linh');
    expect(HunterSearch.brokerEvidence(x),isNull);
    expect(HunterSearch.classifyLead(x,filter),'potential');
  });

  test('verified 17 listing profile violates maximum three', () {
    final x=candidate('Nhà 120m2, giá 8 tỷ, sổ riêng',
      poster:'Nguyễn Gia Hưng',count:'17',origin:'seller_profile_verified');
    expect(HunterSearch.classifyLead(x,filter),'rejected');
  });

  test('saved draft is exclusive; upgrading changes one existing listing ID', () {
    final saved=HunterLead(url:'https://bds68.com.vn/ban-nha-7878',
      title:'Nhà Thủ Đức',source:'bds68.com.vn',status:'saved_for_review',
      qualification:'potential');
    expect(hunterLeadInView(saved,'saved_for_review'),isTrue);
    expect(hunterLeadInView(saved,'needs_data'),isFalse);
    final draft=Listing(id:'existing-saved-id', title:'Nguồn đã kiểm tra',
      sourceUrl:saved.url,verification:'Chưa xác minh');
    final upgraded=Listing.fromJson(draft.toJson());
    upgraded.verification='Đã xác minh trực tiếp với chủ tài sản';
    expect(upgraded.id,draft.id);
    expect(upgraded.verification,'Đã xác minh trực tiếp với chủ tài sản');
  });
}
