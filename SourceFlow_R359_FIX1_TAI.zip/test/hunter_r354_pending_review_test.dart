import 'package:flutter_test/flutter_test.dart';
import 'package:sourceflow_android/hunter_search.dart';
import 'package:sourceflow_android/hunter_models.dart';

void main() {
  const criteria=HunterSettings(maxPosterListings:3,recentDays:5,excludeBroker:true);
  test('Incomplete listing without owner wording remains for human review', () {
    final x=HunterLead(url:'https://bds68.com.vn/ban-nha-pr3521001',
      title:'Bán nhà Thủ Đức gần đường lớn',source:'bds68.com.vn',
      detailText:'Nhà hai tầng tại Thủ Đức, diện tích 80 m2, giá 7 tỷ, sổ riêng.',
      posterCountSource:'',posterCountEvidence:'');
    expect(HunterSearch.brokerEvidence(x),isNull);
    expect(HunterSearch.classifyLead(x,criteria),'potential');
    expect(x.status,'pending');
  });
  test('Known broker signal is still excluded', () {
    final x=HunterLead(url:'https://bds68.com.vn/ban-nha-pr3521002',
      title:'Bán nhà Thủ Đức',source:'bds68.com.vn',
      detailText:'Nhà gần đường lớn. Nhận ký gửi nhà đất, tư vấn và quảng cáo.');
    expect(HunterSearch.classifyLead(x,criteria),'rejected');
  });
  test('Verified poster count above three is still excluded', () {
    final x=HunterLead(url:'https://bds68.com.vn/ban-nha-pr3521003',
      title:'Bán nhà Thủ Đức',source:'bds68.com.vn',
      posterCountSource:'seller_profile_verified',posterCountEvidence:'4',
      detailText:'Nhà hai tầng tại Thủ Đức, diện tích 80 m2, sổ riêng.');
    expect(HunterSearch.classifyLead(x,criteria),'rejected');
  });
  test('Seller count unknown does not become qualified', () {
    final today=DateTime.now();
    final d='${today.day.toString().padLeft(2,'0')}/${today.month.toString().padLeft(2,'0')}/${today.year}';
    final x=HunterLead(url:'https://bds68.com.vn/ban-nha-pr3521004',
      title:'Chính chủ bán nhà Thủ Đức',source:'bds68.com.vn',
      dateEvidence:d,
      detailText:'Chính chủ bán nhà ở đường số 6, Thủ Đức, diện tích 80 m2, giá 7 tỷ.');
    expect(HunterSearch.classifyLead(x,criteria),'potential');
  });
}
