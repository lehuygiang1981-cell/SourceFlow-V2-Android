# SourceFlow R3.5.3 — sửa hồi quy bộ lọc và trích xuất

## Vấn đề được phản ánh ngày 01/11/2026

- R3.5.2 chỉ tải tối đa 6 trang chi tiết mỗi nguồn nhưng vẫn lưu cả tin chưa mở trang chi tiết, nên không thể xác minh số tin người đăng và dấu hiệu môi giới.
- Tin BDS68 có người đăng 10 tin và 24 tin (mặc dù giới hạn 3 tin) không được chặn đúng ở tất cả trường hợp.
- OCR/tách thông tin đôi khi lấy số đo sân sau làm chiều dài thửa và suy diễn sai loại bất động sản.

## Thay đổi chính

1. Chỉ tin đã thực sự tải và trích xuất trang chi tiết mới đưa vào danh sách đã quét; tin chưa xem giữ trong thống kê tin thô, không âm thầm lọt sang nhóm chờ.
2. Giới hạn đọc chi tiết tăng từ 6 lên 24 tin/nguồn, vẫn có ngân sách thời gian để tránh quét treo. Đây là giới hạn MẪU TRONG MỖI PHIÊN; không tuyên bố đã quét hết tin của website.
3. BDS68 đọc nhãn "Tổng số tin đăng"; Batdongsan.com.vn hỗ trợ nhãn "Xem thêm N tin khác" trong khối người đăng (N+1 tin). Không đủ bằng chứng => chưa xác minh; không đưa vào đạt chuẩn.
4. Loại ngay nếu chứng minh số tin người đăng > tiêu chí, bất kể có câu "chính chủ". Tin chờ cũ được tái đánh giá khi quét lại; bản ghi đã lưu hoặc do con người loại không bị ghi đè.
5. Bổ sung tín hiệu môi giới "chuyên bán mặt tiền" và "tư vấn định giá miễn phí".
6. Ưu tiên loại BĐS từ tiêu đề / nhãn loại tin; không lấy số đo sân trước/sân sau làm chiều dài; trích thêm nhãn giá, vị trí, thông tin ngắn trên trang web; nhận diện ảnh chụp web qua tên miền mà không tự đặt link giả.
7. Vẫn giữ cơ chế ghi nhận phiên quét SQLite và khôi phục phiên bị gián đoạn từ R3.5.2.

## Kiểm thử

Chạy Flutter CI và các test `hunter_r353_regressions_test.dart`, `hunter_r352_scan_bounds_test.dart` cùng những bộ kiểm thử cũ. Phải xác minh thử nghiệm thực tế trên Android và các website trước khi kết luận hiệu quả quét. Chưa thêm tính năng camera quét liên tục.

### Giới hạn

Nguồn tải bằng JavaScript, trang chặn HTTP 403/429 và số liệu hồ sơ không được công khai sẽ không thể xác minh từ HTML. Khi đó giữ nguyên "chưa xác minh" hoặc báo lỗi nguồn, không tự suy đoán, không cố bỏ bảo vệ website. Quét trang lớn chỉ xử lý tới giới hạn thời gian/mẫu để tránh treo; cần tiếp tục thiết kế quét phân trang có lưu con trỏ nếu muốn bao phủ tất cả tin.
