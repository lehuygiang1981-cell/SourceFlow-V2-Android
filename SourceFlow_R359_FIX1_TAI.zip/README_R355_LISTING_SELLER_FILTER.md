# SourceFlow R3.5.5 — Xác minh số tin người đăng từ 2 lớp HTML

- Giữ nguyên nhóm **Thiếu dữ liệu** và quy trình **Lưu chờ xác minh** R3.5.4. Không xóa các tin chưa chứng minh môi giới và chưa có tổng số tin xác thực.
- Trên danh sách: đọc số tin trong subwidget **người đăng** riêng của từng thẻ tin, không dùng số lượt xem, diện tích, các tin liên quan hay tổng kết quả tìm kiếm. Ghi `listing_card_verified`.
- Trên trang chi tiết và hồ sơ: đọc như trước; nếu chi tiết không có số thì giữ số đã xác minh từ danh sách. Nếu số liệu mâu thuẫn giữa hai nơi, để nhóm thiếu dữ liệu cho người dùng xác minh; không đánh dấu đủ bộ lọc.
- Tin đã xác minh người đăng >3 vẫn loại; tin chưa biết số tin vẫn giữ.
- Phát hiện thêm quảng cáo dẫn khách đi xem nhà kèm website/danh mục hàng; trường hợp ngôn ngữ nghi vấn đơn lẻ như "liên hệ em Phương xem nhà" để chờ xác minh, không kết luận khi thiếu chứng cứ.
- Số tin và nguồn đọc được hiện trên thẻ tin; vẫn cần người dùng xác minh chính chủ thủ công.
- Giữ 5 ngày và tối đa 3 tin/người theo tiêu chí người dùng thiết lập.
- Nâng phiên bản R3.5.5+59; không tự nhận đã sửa OCR ảnh.
- Bổ sung bộ test `hunter_r355_listing_count_broker_test.dart`, bao gồm mock HTTP quét danh sách và chi tiết.

**Chưa chạy Flutter hoặc build APK cục bộ; yêu cầu GitHub Actions xác minh.**
