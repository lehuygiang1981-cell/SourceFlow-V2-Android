# SourceFlow R3.5.6 — cập nhật dựa trên phản hồi kiểm thử 03/11/2026

Bản này được xây từ `SourceFlow_R355_SellerCount_BrokerFilter_Source.zip`. Không thay đổi dữ liệu SQLite hiện có hoặc cơ chế công việc/giọng nói.

## Thay đổi

1. Các tab báo cáo Quét web được phân nhóm **không giao nhau**: Đạt bộ lọc, Thiếu dữ liệu, Đã lưu tạm, Đã xác minh & lưu, Đã loại, Tất cả. Bỏ tab Chờ xác minh tổng hợp gây lặp hiển thị. Mặc định sau khi quét mở **Thiếu dữ liệu**; giữ nguyên dữ liệu thiếu để bấm mở tin gốc và lưu tạm.
2. Thêm `posterName` (người đăng) độc lập với trường `owner` (chủ tài sản được con người xác minh). Chỉ khi người dùng xác nhận là chính chủ mới dùng tên người đăng đã đọc từ khối người đăng của chính tin đó làm tên chủ trong bản lưu. Trường hợp lưu tạm chỉ lưu tên người đăng vào ghi chú xác minh, không tự tuyên bố họ là chủ.
3. Mở rộng trích số tin trong khối tác giả/tài khoản thuộc đúng một card bên **trang danh sách** và giữ dữ liệu danh sách khi trang chi tiết không có số. Các số liệu mâu thuẫn vẫn vào Thiếu dữ liệu; không lấy số của tin gợi ý/khối tin khác.
4. OCR: tránh nhầm tiêu đề mục “Đặc điểm bất động sản” là tên nguồn; ưu tiên nhãn diện tích và giá trên cùng một dòng; tránh nhập 13 tỷ 119 triệu do nối các dòng khác nhau; nhận tên người đăng khi có nhãn rõ ràng; không tự suy đoán chính chủ.
5. Bổ sung dấu hiệu mạnh của đơn vị môi giới và dấu hiệu mềm cần người dùng đối chiếu. Không tự loại chỉ vì thiếu bằng chứng, không đổi giới hạn 3 tin/người và 5 ngày.

## Giới hạn kiểm chứng

- Bản mã nguồn đã kiểm tra cấu trúc ZIP và khai báo workflow. Flutter test/analyze, build APK chưa được chạy tại môi trường tạo file. GitHub Actions sẽ chạy bộ kiểm thử cũ cùng `hunter_r356_identity_groups_test.dart` trước khi build.
- Nếu một website chỉ vẽ số tin bằng JavaScript sau khi tải, HTML công khai mà bộ quét dùng có thể không chứa số tin. Khi không có chứng cứ đọc được, vẫn giữ tin ở Thiếu dữ liệu, không tự coi số là <=3.
- Không tự thay đổi dữ liệu đã lưu ở các phiên bản cũ. Các hồ sơ nhập liệu trước đây cần người dùng chỉnh lại trường sai.
