# SourceFlow R3.5.2 — Scan session / hung scan repair (2026-11-01)

This release prioritizes the broken Supply Hunter scan-session lifecycle. It does not add live camera OCR.

## Changes
- Creates an auditable SQLite `scan_history` row BEFORE contacting any site (`beginScan`). A session is never inferred from the presence or absence of leads.
- Foreground/background scans share one atomic lease, status, progress, error reporting, and one completion method (`finishScan`). Double runs are suppressed.
- Recovers scans abandoned by Android after 8 minutes: `interrupted`, not a false `completed` or `no scan`.
- Limits first-pass listing processing to 80 listings per source page and network detail enrichment to 6 per source, with 40 s/source and 150 s/session soft deadlines and 4-min hard Future timeout. Later detail enrichment remains available on import. All unverified evidence stays unverified; no claim of verified ownership.
- Reports progress, per-domain errors, 0-result and interrupted sessions. A blocked/JS-only website is a source error rather than proof of zero results.
- Provides a manual stop control and preserves fetched candidate results where possible.
- Version 3.5.2+52; package/application ID unchanged; old SQLite data retained by the app during upgrades **only if Android accepts the APK signature**.

## Verification
- New Flutter regression `test/hunter_r352_scan_bounds_test.dart` checks upper bounds on detail requests and cancellation.
- CI workflow runs existing broker/qualification tests plus R3.5.2 regression and compiles release APK.
- Local working environment lacks Flutter/Dart SDK, so no successful Dart test or APK build can be claimed before GitHub Actions is run.

## Installation and signing warning
- Prior workflows may produce release APKs signed with Android's *ephemeral debug keystore*. If the signing certificate differs, Android will refuse to update in place. Do not uninstall a working SourceFlow before exporting its offline data, and do not claim an APK is an in-place update until its signing certificate is verified.

## Acceptance on handset
1. Press Scan: `Lần quét` and one `ĐANG QUÉT` history item appear immediately.
2. When it ends with 0 results (or HTML/CAPTCHA/403 failure), history still shows a terminal state, timestamp and per-source evidence.
3. Force-close during a scan, reopen after >8 minutes: record becomes `GIÁN ĐOẠN`.
4. Check background scans after a night, keeping in mind Android WorkManager scheduling is best-effort, not guaranteed exact 2-hour delivery.

## Build fix 1 (2026-11-01)
- Corrects the UTF-8 content-type of HTTP mock responses in R3.5.2 tests; fixture titles contain Vietnamese characters outside Latin-1.
- Cancellation now produces a stable `Người dùng đã dừng quét` error and corresponding source note, instead of only a source note.
- R3.5.2 build fix must pass the GitHub Actions Flutter tests and build, which have NOT yet been re-run for this ZIP.
