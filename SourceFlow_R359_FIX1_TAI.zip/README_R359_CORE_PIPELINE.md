# SourceFlow R3.5.9 — Seller identity, count evidence, broker rules, OCR field separation

This patch is based directly on R3.5.8 and changes only targeted source/scan/OCR code.

## Corrections
1. Seller name: capture agency-style account names (e.g. `Hoàng Anh chuyên nhà Thủ Đức`) from the per-listing seller widget. Previously name detection excluded text containing `nhà`, losing the strongest broker signal.
2. Poster count: keep counts from individual listing cards; recognize single poster-profile links and read numeric `17 Tin đăng` even when displayed in separate HTML elements. Count is accepted only if the seller identity on listing and profile matches. This does **not** bypass JavaScript-only pages or HTTP block.
3. Broker exclusion: phrase filters check full detail, heading, snippet and seller name; support bounded contact phrases with filler words (`liên hệ Zalo ... để xem nhà`) and financial marketing. Known broker language is rejected under the chosen strict owner-only policy.
4. Unreadable but HTTP 200 detail: put into `Thiếu dữ liệu`, never `Đạt bộ lọc`. HTTP 403/429 still recorded as source block without claiming inspection.
5. Address: reject time-to-amenities marketing (`Vị trí: 5 phút...`) as address, keep verified street+ward; prefer structured `Diện tích đất` over title figures.
6. OCR: do NOT discard the `Địa chỉ bất động sản` field label; handle square-bracketed area and price, type when a screen heading precedes the sale title, price-reduction `còn`, and `CN 145m²` when only dimensions and certified area are provided.
7. Existing tabs, saved-for-review promotion, offline SQLite, voice and import remain intact.

## Verification
- Added `test/hunter_r359_core_pipeline_test.dart` with 10 cases including mock HTTP end-to-end list -> detail -> profile -> >3 rejection, list-seller isolation, broker phrase variants, unreadable detail, OCR/address/area/price.
- Workflow runs this plus all R3.5.8-and-earlier regression tests and the Flutter analyzer before building APK.
- Flutter SDK unavailable in authoring environment. **No claim of passing tests or working APK before GitHub Actions validates it.**
- Only publicly served HTML can be inspected; JS-only account data may remain in `Thiếu dữ liệu`.
