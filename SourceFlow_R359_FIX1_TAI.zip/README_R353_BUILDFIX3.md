# SourceFlow R3.5.3 Build Fix 3 — 01/11/2026

CI diagnosis: run #41283898455 failed in an outdated smoke test (`test/hunter_test.dart`) expecting an accepted/potential lead from a mock detail with only `1 tin đăng`. The current R3.5.3 hard gate correctly omits a listing when detail text is insufficient.

Changes:
- Align this obsolete smoke test with the R3.5.3 strict rule: no accepted or potential lead from an unreadable detail. Retain the raw count and no-Bing assertions.
- Keep every existing broker, seller-count, source-validation, extraction, and time-bound regression test unchanged.
- Bump Android build number to `3.5.3+55` so it can install as an upgrade.
- CI workflow references this exact ZIP and only uploads the APK if every test and build succeeds.

Limitations: This package has not been compiled/tested locally. GitHub Actions must pass before it can be called a working APK. Do not equate passing fixture tests with full production crawling or owner verification.
