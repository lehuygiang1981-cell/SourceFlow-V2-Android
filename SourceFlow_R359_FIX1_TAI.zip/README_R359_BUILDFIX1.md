# SourceFlow R3.5.9 BuildFix1 (+64)

- Bản gốc: R3.5.9 GIAO_LAI (+63), GitHub run 41578796116.
- Lỗi thực tế trong log: 9/10 core tests passed; OCR kích thước `Diện tích 10x17m (CN 145m²)` không tách được ngang=10m, dài=17m.
- Sửa 1 regex trong `lib/models.dart`, bổ sung test cho `Diện tích`, `DT`, `Kích thước`, thêm sổ quy trình `SOURCEFLOW_PROJECT_RULES.md`.
- Chưa chạy Flutter cục bộ, không được tuyên bố test tất cả đã đạt trước khi GitHub chạy.
