# SourceFlow R3.5.7 — broker evidence + promote saved draft

## Changes

1. Extended strict owner-only brokerage policy to agent contact/viewing/owner-negotiation and rental-income sales terms. Checks accented and unaccented Vietnamese across title, description and snippet.
2. Added seller-name check for agency handles, e.g. `Hoàng Anh chuyên nhà Thủ Đức`. Ordinary personal names are not rejected from identity alone.
3. Added `Đã xác minh & lưu` button to each `Đã lưu tạm` lead. Requires explicit owner verification and a verified count of 1–3 (if the website count is unavailable, user must enter the count they checked). Known broker or confirmed >3 is blocked. The same Listing ID is updated; no new duplicate is created.
4. Shows `ĐÃ LƯU TẠM — CHỜ XÁC MINH` on the saved card and shows outstanding data conditions without hiding the record.
5. Preserved HTML public-source scanning, manual review queues, 5-day and 3-post user controls, SQLite persistence, voice and OCR workstream as before.

## Validation

A `hunter_r357_broker_promotion_test.dart` regression suite is bundled. The final APK and end-to-end tests require GitHub Actions Flutter runner; local Flutter SDK is not available in this environment.

## Guardrails

* Marketing language by itself is evidence for *user-defined owner-only filtering*, not independently confirmed legal brokerage status.
* Seller profile counts must belong to the actual listing author. A 17-listing profile of a different user cannot be applied to another ad.
* Keep partial/unavailable data in `Thiếu dữ liệu` rather than guessing.
* Manually entered poster count is a user attestation and is recorded as such, not falsely labeled as scraped or independently verified.
