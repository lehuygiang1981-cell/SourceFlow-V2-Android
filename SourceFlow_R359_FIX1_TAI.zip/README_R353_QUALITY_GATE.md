# SourceFlow R3.5.3 — Quality Gate patch (01/11/2026)

This package replaces the earlier *unbuilt* R3.5.3 ZIP. It retains the R3.5.2 scan-session audit trail in SQLite but hides the verbose scan history and per-source error dump in the Quét web UI. The app shows a short scan status only.

## Fixes

- Seller-count hard gate: a verified profile with **more than 3** ads (or the user's chosen threshold) is rejected even if the ad says "chính chủ". Test fixtures cover BDS68 10/24 ads and Batdongsan.com.vn's "Xem thêm 1 tin khác" (= 2 ads). Counts must be taken from the seller card/profile, not from recommendations. Missing count remains in a separate **Thiếu dữ liệu** group and is not accepted.
- Revalidate all pending records from earlier releases when opening the scan view. Old premature `qualified` records lose that label unless they meet all current evidence gates. Already-imported or human-rejected assets are not silently overwritten.
- Prevent automatic import of records with unknown seller count or a verified seller count exceeding the configured limit. Repeat the checks immediately before importing.
- Use full property detail description and scoped structured fields; preserve labeled area, price, address, type and frontage, preferring explicit specs over a conflicting headline. Do not misinterpret a backyard, front garden or road width as land length. The final source URL is the actual external listing URL.
- Avoid misclassifying the standalone phrase "chủ nhà bán" as proof of brokerage. Keep strong brokerage signals (ký gửi, làm việc chính chủ, nhân viên môi giới, chuyên bán mặt tiền, tư vấn định giá…). A positive owner claim alone does not overcome a proven broker signal or >3 ads.
- Separate preliminary accepted listings (**Đạt bộ lọc**) and records missing evidence (**Thiếu dữ liệu**). Copy report exports only the preliminary accepted set. Neither group constitutes proof of ownership; human verification is still required.
- Keep a finite scan timeout and treat HTTP 403/429 / JS-rendered or blocked pages as errors. No CAPTCHA or access-control bypass. An unreadable detail is not silently treated as inspected.

## Mandatory CI checks

Run `flutter test test/hunter_r353_quality_gate_test.dart` and existing hunter regression suites, then build a release APK. This package was statically inspected and ZIP integrity tested, but the Flutter compiler and device tests must still pass on GitHub Actions. Do not claim a functioning APK before that result.

## Known limitations

- One scan examines a bounded number of detail pages per source; **this is not a full crawl of every listing**. Sites returning HTTP 403/429 or dynamically loading details without public HTML will remain unavailable in this connector. Neither accurate extraction of inaccessible content nor identification of all undisclosed brokers can be guaranteed.
- Keep a backup of the installed inventory before upgrading. The `sourceflow_hunter.sqlite` database stays intact (no destructive schema migration).
