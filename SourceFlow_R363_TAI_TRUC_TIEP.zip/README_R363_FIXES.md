# SourceFlow R3.6.3 — Sửa lỗi thực tế 06/11/2026

Bản nguồn từ R3.6.2 Fix2, chỉ sửa những lỗi đã phát hiện qua ảnh kiểm thử:

- Nhận diện loại môi giới khi người liên hệ (gọi Phương / liên hệ Nguyen Kyei) dẫn xem nhà, tư vấn và giới thiệu thêm nhiều căn; tên người đăng có định danh thương hiệu nhà đất; hỗ trợ công chứng kèm người liên hệ.
- Mở rộng đọc tên tài khoản nguồn ở các class account-name/contact-name, và đọc chi tiết lại khi người dùng lưu tạm nếu nguồn thiếu tên/thiếu nội dung. Không suy đoán tên chủ tài sản và không tự xác minh sở hữu.
- Giá đất không nối các con số thuộc diện tích/PN/tầng thành triệu đồng sau chữ “tỷ”. Ưu tiên giá có nhãn trong tin gốc và giữ chính xác giảm giá.
- Địa chỉ không lấy “cách 1 căn ra đường số 9” hoặc tiêu đề quảng cáo “Tỉnh lộ 43 – 220m² – full nội thất” làm địa chỉ tài sản; lấy trường vị trí được ghi rõ trên website khi hiện diện.
- Vẫn yêu cầu số nhà + tên đường đối với nhóm Đạt bộ lọc; thiếu thì Thiếu dữ liệu. Dấu hiệu môi giới được loại ngay khi có đủ bằng chứng trong nội dung đã đọc.

Kiểm thử mới: `test/hunter_r363_real_screenshots_test.dart`.

Toàn bộ kiểm thử R3.6.2 cùng các phiên bản trước vẫn có trong workflow. Chưa kết luận bản build thành công khi chưa có kết quả GitHub Actions và kiểm tra APK thực tế.
