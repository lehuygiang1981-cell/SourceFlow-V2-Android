import 'package:flutter_test/flutter_test.dart';
import 'package:html/parser.dart' as html;
import 'package:sourceflow_android/hunter_models.dart';
import 'package:sourceflow_android/hunter_search.dart';
import 'package:sourceflow_android/models.dart';

void main() {
  HunterLead ad(String copy,{String title='Bán nhà riêng 45m² tại Hiệp Bình',String seller=''}) =>
    HunterLead(url:'https://muaban.net/bat-dong-san/ban-nha-id71313053',
      source:'muaban.net',title:title,posterName:seller,detailText:copy);

  test('R3.6.3: Phuong offers another property catalogue; reject before saving',(){
    final lead=ad('''Dòng tiền: Cho thuê 6 triệu/tháng.
Giá bán: 2,25 tỷ, thương lượng cho khách thiện chí.
Anh chị đang tìm nhà khu vực Hiệp Bình, gần Quốc lộ 13,
gọi Phương để xem nhà thực tế và tham khảo thêm các căn cùng phân khúc giá.''');
    expect(HunterSearch.brokerEvidence(lead),isNotNull);
    expect(HunterSearch.classifyLead(lead,const HunterSettings()),'rejected');
  });

  test('R3.6.3: sales catalogue and external website are brokerage',(){
    final lead=ad('''Giá bán: 14 tỷ – thương lượng trực tiếp.
Liên hệ: Nguyen Kyei để được tư vấn và xem nhà thực tế.
Tham khảo thêm nhà phố tại: https://daudat.vercel.app/''');
    expect(HunterSearch.brokerEvidence(lead),isNotNull);
    expect(HunterSearch.classifyLead(lead,const HunterSettings()),'rejected');
  });

  test('R3.6.3: agency account overrides owner claims; personal name does not',(){
    final agent=ad('Bán nhà riêng sổ hồng, chính chủ tự đăng.',
      seller:'Hoàng Anh chuyên nhà Thủ Đức');
    expect(HunterSearch.brokerEvidence(agent),isNotNull);
    final person=ad('Tôi là chủ sở hữu nhà và trực tiếp bán.',seller:'Yến Trinh Phan');
    expect(HunterSearch.brokerEvidence(person),isNull);
  });

  test('R3.6.3: contact plus title transfer services is excluded',(){
    final lead=ad('Hỗ trợ công chứng, sang tên nhanh chóng. Giá 9,9 tỷ. LH: Uyên');
    expect(HunterSearch.brokerEvidence(lead),isNotNull);
  });

  test('R3.6.3: price cannot absorb next area or floor count',(){
    expect(parseIntake('''Bán nhà riêng tại Hiệp Bình
Giá bán: 2,25 tỷ
Diện tích: 26 m²''').price,'2,25 tỷ');
    expect(parseIntake('''Bán nhà riêng tại Tỉnh lộ 43
Giá bán: 14 tỷ
3 tầng
Diện tích: 210 m²''').price,'14 tỷ');
    final source=ad('''Địa chỉ: Đường Linh Đông, phường Linh Đông
Giá bán: 14 tỷ
Diện tích đất: 210 m²''');
    expect(source.parsed.price,'14 tỷ');
    expect(source.parsed.area,'210 m²');
  });

  test('R3.6.3: roadside proximity is not property address',(){
    final parsed=parseIntake('''Bán nhà ngay trung tâm Thủ Đức, 48m²
Đường Đặng Văn Bi, phường Linh Chiểu, TP Thủ Đức
Cách 1 căn ra mặt tiền đường Số 9. * Vị trí thuận tiện kinh doanh.
Giá bán: 4,7 tỷ''');
    expect(parsed.address.contains('Đặng Văn Bi'),isTrue,reason:parsed.address);
    expect(parsed.address.contains('Vị trí thuận tiện'),isFalse);
    final noAddress=parseIntake('''Bán nhà tỉnh lộ 43 – 220m² – FULL NỘI THẤT GỖ – HẺM Ô TÔ
Giá bán: 14 tỷ''');
    expect(HunterSearch.hasHouseNumberAndStreet(noAddress.address),isFalse);
    expect(noAddress.address.contains('FULL NỘI THẤT'),isFalse);
  });

  test('R3.6.3: seller visible under account name is not lost',(){
    final doc=html.parse('''<html><body><h1>Bán nhà đường Đặng Văn Bi 48m²</h1>
    <div class="account-header"><span class="account-name">Yến Trinh Phan</span></div>
    <div class="notification">Nhận email tin mới</div></body></html>''');
    expect(HunterSearch.sellerNameFromDetail(doc),'Yến Trinh Phan');
    final broker=html.parse('''<html><body><div class="account-header">
      <span class="account-name">Hoàng Anh chuyên nhà Thủ Đức</span>
      </div></body></html>''');
    final name=HunterSearch.sellerNameFromDetail(broker);
    expect(name,'Hoàng Anh chuyên nhà Thủ Đức');
    expect(HunterSearch.brokerEvidence(ad('Sổ hồng riêng',seller:name)),isNotNull);
  });
}
