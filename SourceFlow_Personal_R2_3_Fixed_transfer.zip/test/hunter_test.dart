import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:sourceflow_android/hunter_models.dart';
import 'package:sourceflow_android/hunter_search.dart';

const feed='''<?xml version="1.0" encoding="utf-8"?>
<rss version="2.0"><channel>
  <item><title>Bán nhà chính chủ ngang 5m dài 20m giá 10 tỷ</title>
    <link>https://batdongsan.com.vn/ban-nha-rieng-phuong-linh-dong-pr123?utm_source=rss</link>
    <description><![CDATA[Diện tích 100 m2. Địa chỉ: Linh Đông, Thủ Đức]]></description></item>
  <item><title>Bán nhà chính chủ ngang 5m dài 20m giá 10 tỷ</title>
    <link>https://www.batdongsan.com.vn/ban-nha-rieng-phuong-linh-dong-pr123?utm_campaign=abc</link>
    <description>Trùng URL</description></item>
  <item><title>Đường dẫn sang nguồn ngoài</title>
    <link>https://example.org/ban-nha-rieng-phuong-linh-dong-pr123</link></item>
  <item><title>Trang tìm kiếm không phải một tin cụ thể</title>
    <link>https://batdongsan.com.vn/tim-kiem/ban-nha</link></item>
</channel></rss>''';

void main(){
  test('Chỉ lấy ứng viên với URL thuộc đúng website và chống trùng UTM',(){
    final entries=HunterSearch.readRss(feed,'batdongsan.com.vn',now:DateTime(2026,10,22));
    expect(entries.length,1);
    expect(entries.first.source,'batdongsan.com.vn');
    expect(entries.first.status,'pending');
    expect(entries.first.parsed.width,'5 m');
    expect(entries.first.parsed.length,'20 m');
    expect(entries.first.parsed.area,'100 m²');
  });
  test('Không coi tin từ kết quả web là bằng chứng chính chủ',(){
    final lead=HunterLead(url:'https://nhatot.com/mua-ban-123',
      title:'CHÍNH CHỦ cần bán',source:'nhatot.com');
    expect(lead.status,'pending');
    expect(lead.evidence,isEmpty);
    expect(lead.listingId,isEmpty);
  });
  test('Dữ liệu người duyệt được ghi đủ khi serialize',(){
    final lead=HunterLead(url:'https://muaban.net/ban-nha-777',
      title:'Bán nhà mặt tiền',source:'muaban.net')
      ..status='imported'..evidence='Đã kiểm tra hồ sơ trực tiếp'
      ..method='Đã đối chiếu hồ sơ'..listingId='listing-id';
    final restored=HunterLead.fromJson(lead.toJson());
    expect(restored.status,'imported');
    expect(restored.evidence,'Đã kiểm tra hồ sơ trực tiếp');
    expect(restored.listingId,'listing-id');
  });
  test('Tác vụ RSS báo lỗi theo nguồn, không tự bịa nguồn khi request lỗi',()async{
    final fake=MockClient((req)async{
      if(req.url.queryParameters['q']!.contains('batdongsan.com.vn')){
        return http.Response(feed,200,headers:{'content-type':'application/xml; charset=utf-8'});
      }
      return http.Response('unavailable',503);
    });
    final search=HunterSearch(client:fake);
    final report=await search.scan(const HunterSettings(areas:[], sites:['batdongsan.com.vn','nhatot.com']));
    expect(report.searched,2);
    expect(report.leads.length,1);
    expect(report.errors.length,1);
    search.close();
  });
  test('Bộ lọc khu vực, tuyến đường được tạo thành các truy vấn riêng', () {
    const config = HunterSettings(location: 'TP.HCM', keywords: 'bán đất',
      areas: ['Linh Xuân', 'Long Trường'], streets: ['Ka Vạn Cân']);
    expect(config.targets, ['Linh Xuân','Long Trường','Ka Vạn Cân']);
    expect(HunterSearch.queryUrl(config, 'nhatot.com', target: 'Ka Vạn Cân')
      .queryParameters['q'], contains('Ka Vạn Cân'));
  });
  test('Loại từ khóa môi giới và sổ chung mà không khẳng định chính chủ', () {
    const s = HunterSettings();
    final broker = HunterLead(url:'https://nhatot.com/a',source:'nhatot.com',
      title:'Chủ gửi bán nhà 5 tỷ');
    final joint = HunterLead(url:'https://nhatot.com/b',source:'nhatot.com',
      title:'Bán đất sổ chung giá rẻ');
    final unknown = HunterLead(url:'https://nhatot.com/c',source:'nhatot.com',
      title:'Nhà diện tích 100m2 giá 6 tỷ');
    expect(HunterSearch.matchesCriteria(broker,s), false);
    expect(HunterSearch.matchesCriteria(joint,s), false);
    expect(HunterSearch.matchesCriteria(unknown,s), true);
    expect(unknown.evidence, isEmpty);
  });
  test('Cấu hình R2 cũ đọc được, cấu hình mới khôi phục được', () {
    final old = HunterSettings.fromJson({'location':'Linh Xuân',
      'keywords':'bán nhà','sites':['nhatot.com'],'autoScan':true});
    expect(old.areas, isEmpty);
    expect(old.recentDays, 5);
    expect(old.maxPosterListings, 3);
    final current = const HunterSettings(areas:['Linh Đông'],streets:['Đường 37'],
      excludedTerms:['vi bằng'],recentDays:7,excludeApartments:true);
    final restored = HunterSettings.fromJson(current.toJson());
    expect(restored.targets, ['Linh Đông','Đường 37']);
    expect(restored.recentDays, 7);
    expect(restored.excludeApartments, true);
  });
  test('Lưu nguồn tìm cùng dấu vết địa bàn', () {
    final source = HunterLead(url:'https://bds68.com.vn/a',title:'Bán nhà Linh Xuân',
      source:'bds68.com.vn',queryTarget:'Linh Xuân');
    expect(HunterLead.fromJson(source.toJson()).queryTarget, 'Linh Xuân');
  });

}
