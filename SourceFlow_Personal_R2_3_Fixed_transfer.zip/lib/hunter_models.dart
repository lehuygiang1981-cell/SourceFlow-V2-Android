import 'models.dart';

/// A web-search hit is a lead, NOT evidence that the seller owns the property.
class HunterLead {
  final String id, url, title, snippet, source, queryTarget;
  final DateTime discoveredAt;
  final DateTime? indexDate;
  String status, evidence, method, listingId, reviewNote;
  DateTime? reviewedAt;

  HunterLead({required this.url, required this.title, required this.source,
    this.snippet='', this.queryTarget='', DateTime? discoveredAt, this.indexDate, String? id,
    this.status='pending',this.evidence='',this.method='',this.listingId='',this.reviewNote='',this.reviewedAt})
    : id=id ?? canonicalLeadUrl(url),discoveredAt=discoveredAt??DateTime.now();

  Map<String,dynamic> toJson()=>{
    'id':id,'url':url,'title':title,'snippet':snippet,'source':source,
    'queryTarget':queryTarget,
    'discoveredAt':discoveredAt.toIso8601String(),'indexDate':indexDate?.toIso8601String(),
    'status':status,'evidence':evidence,'method':method,'listingId':listingId,
    'reviewNote':reviewNote,'reviewedAt':reviewedAt?.toIso8601String(),
  };
  factory HunterLead.fromJson(Map<String,dynamic> x)=>HunterLead(
    id:'${x['id']??''}',url:'${x['url']??''}',title:'${x['title']??''}',
    snippet:'${x['snippet']??''}',source:'${x['source']??''}',
    queryTarget:'${x['queryTarget']??''}',
    discoveredAt:DateTime.tryParse('${x['discoveredAt']}'),
    indexDate:DateTime.tryParse('${x['indexDate']}'),
    status:'${x['status']??'pending'}',evidence:'${x['evidence']??''}',
    method:'${x['method']??''}',listingId:'${x['listingId']??''}',
    reviewNote:'${x['reviewNote']??''}',reviewedAt:DateTime.tryParse('${x['reviewedAt']}'),
  );
  ParsedIntake get parsed=>parseIntake('$title\n$snippet');
  List<String> get reviewFlags {
    final content='$title $snippet'.toLowerCase();
    final flags=<String>[];
    if(content.contains('sổ chung')||content.contains('so chung'))flags.add('Có dấu hiệu sổ chung');
    if(content.contains('môi giới')||content.contains('moi gioi')||
      content.contains('ký gửi')||content.contains('ky gui')||
      content.contains('chủ gửi')||content.contains('chu gui')||
      content.contains('làm việc chính chủ'))flags.add('Có dấu hiệu trung gian/môi giới');
    flags.add('Chưa kiểm chứng ngày đăng và số tin của người đăng');
    return flags;
  }
}

String canonicalLeadUrl(String value) {
  final uri=Uri.tryParse(value.trim());
  if(uri==null || (uri.scheme!='https'&&uri.scheme!='http') || uri.host.isEmpty)return '';
  final host=uri.host.toLowerCase().replaceFirst(RegExp(r'^www\.'),'');
  final segments=uri.path.replaceAll(RegExp(r'/+'),'/').replaceFirst(RegExp(r'/$'),'');
  // Tracking parameters do not change identity; retain query parameters that
  // may identify a property listing (id, listingId, postId, tin).
  final params=<String,String>{};
  for(final key in ['id','listingId','postId','tin']){
    if(uri.queryParameters.containsKey(key))params[key]=uri.queryParameters[key]!;
  }
  return Uri(scheme:'https',host:host,path:segments.isEmpty?'/':segments,
    queryParameters:params.isEmpty?null:params).toString();
}

/// User-editable scanning criteria. New keys are backwards-compatible with R2.
class HunterSettings {
  final String location, keywords, propertyType;
  final List<String> areas, streets, excludedTerms, sites;
  final bool autoScan, excludeBroker, excludeSharedTitle, excludeApartments, ownerHintsOnly;
  final int recentDays, maxPosterListings;
  const HunterSettings({
    this.location = 'Thành phố Thủ Đức',
    this.keywords = 'bán nhà chính chủ',
    this.propertyType = 'Tất cả',
    this.areas = const ['Quận 2 cũ', 'Quận 9 cũ', 'Thủ Đức cũ'],
    this.streets = const [],
    this.excludedTerms = const [],
    this.sites = const ['batdongsan.com.vn','nhatot.com','muaban.net','bds68.com.vn','guland.vn'],
    this.autoScan = true, this.recentDays = 5, this.maxPosterListings = 3,
    this.excludeBroker = true, this.excludeSharedTitle = true,
    this.excludeApartments = false, this.ownerHintsOnly = false,
  });

  List<String> get targets {
    final distinct = <String>[];
    for (final item in [...areas, ...streets]) {
      final trimmed = item.trim();
      if (trimmed.isNotEmpty && !distinct.contains(trimmed)) distinct.add(trimmed);
    }
    return distinct.isEmpty ? [''] : distinct;
  }

  Map<String,dynamic> toJson() => {
    'location': location, 'keywords': keywords, 'propertyType': propertyType,
    'areas': areas, 'streets': streets, 'excludedTerms': excludedTerms,
    'sites': sites, 'autoScan': autoScan, 'recentDays': recentDays,
    'maxPosterListings': maxPosterListings, 'excludeBroker': excludeBroker,
    'excludeSharedTitle': excludeSharedTitle, 'excludeApartments': excludeApartments,
    'ownerHintsOnly': ownerHintsOnly,
  };

  factory HunterSettings.fromJson(Map<String,dynamic> x) {
    List<String> stringList(String key, List<String> fallback) =>
      x[key] is List ? (x[key] as List).whereType<String>().toList() : fallback;
    int positiveInt(String key, int fallback) {
      final parsed = x[key] is int ? x[key] as int : int.tryParse('${x[key]}');
      return parsed != null && parsed > 0 ? parsed : fallback;
    }
    return HunterSettings(
      location: '${x['location']??'Thành phố Thủ Đức'}',
      keywords: '${x['keywords']??'bán nhà chính chủ'}',
      propertyType: '${x['propertyType']??'Tất cả'}',
      // Existing R2 users keep their old single-location scan until they set regions.
      areas: stringList('areas', const []), streets: stringList('streets', const []),
      excludedTerms: stringList('excludedTerms', const []),
      sites: stringList('sites', const ['batdongsan.com.vn','nhatot.com','muaban.net','bds68.com.vn','guland.vn']),
      autoScan: x['autoScan'] != false,
      recentDays: positiveInt('recentDays', 5),
      maxPosterListings: positiveInt('maxPosterListings', 3),
      excludeBroker: x['excludeBroker'] != false,
      excludeSharedTitle: x['excludeSharedTitle'] != false,
      excludeApartments: x['excludeApartments'] == true,
      ownerHintsOnly: x['ownerHintsOnly'] == true,
    );
  }
}

class HunterSnapshot {
  final int total, pending, confirmed, rejected;
  final DateTime? lastScan;
  final String message;
  final List<String> errors;
  const HunterSnapshot({this.total=0, this.pending=0, this.confirmed=0,
    this.rejected=0, this.lastScan, this.message='', this.errors=const []});
}
