import 'dart:async';
import 'dart:convert';
import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';
import 'hunter_models.dart';

/// Supply Hunter's separate offline database. Never modify the main inventory DB.
/// WorkManager runs on a background Flutter engine/isolate. A separate SQLite
/// handle avoids its close() invalidating the foreground's cached connection.
class HunterStorage {
  Database? _db;
  Future<Database>? _opening;

  Future<Database> _database() async {
    final current = _db;
    if (current != null && current.isOpen) return current;
    if (_opening != null) return _opening!;
    final future = _openFresh();
    _opening = future;
    try {
      return await future;
    } finally {
      _opening = null;
    }
  }

  Future<Database> _openFresh() async {
    final root = await getDatabasesPath();
    final db = await openDatabase(
      p.join(root, 'sourceflow_hunter.sqlite'),
      version: 1,
      singleInstance: false,
      onConfigure: (database) async {
        await database.execute('PRAGMA busy_timeout = 5000');
      },
      onCreate: (database, version) async {
        await database.execute('CREATE TABLE leads (id TEXT PRIMARY KEY, url_key TEXT UNIQUE NOT NULL, discovered INTEGER NOT NULL, status TEXT NOT NULL, content TEXT NOT NULL)');
        await database.execute('CREATE TABLE settings (key TEXT PRIMARY KEY, value TEXT NOT NULL)');
      },
    );
    _db = db;
    return db;
  }

  /// Retry only once when another isolate/lifecycle transition closed a handle.
  /// Do not retry writes for arbitrary SQLite errors: they could be non-idempotent.
  Future<T> _run<T>(Future<T> Function(Database db) action) async {
    var db = await _database();
    try {
      return await action(db);
    } on DatabaseException catch (error) {
      if (!error.toString().contains('database_closed')) rethrow;
      if (identical(_db, db)) _db = null;
      db = await _database();
      return action(db);
    }
  }

  Future<void> open() async { await _database(); }

  Future<HunterSettings> settings() => _run((db) async {
    final rows = await db.query('settings', where: 'key=?', whereArgs: ['options'], limit: 1);
    if (rows.isEmpty) return const HunterSettings();
    return HunterSettings.fromJson(Map<String, dynamic>.from(jsonDecode(rows.first['value'] as String)));
  });

  Future<void> saveSettings(HunterSettings value) => _run((db) async {
    await db.insert('settings', {'key': 'options', 'value': jsonEncode(value.toJson())},
      conflictAlgorithm: ConflictAlgorithm.replace);
  });

  Future<List<HunterLead>> leads() => _run((db) async {
    final rows = await db.query('leads', orderBy: 'discovered DESC');
    return rows.map((row) => HunterLead.fromJson(
      Map<String, dynamic>.from(jsonDecode(row['content'] as String)))).toList();
  });

  Future<int> addDiscovered(Iterable<HunterLead> items) => _run((db) async {
    var count = 0;
    await db.transaction((tx) async {
      for (final item in items) {
        final key = canonicalLeadUrl(item.url);
        if (key.isEmpty) continue;
        final rows = await tx.query('leads', columns: ['id'], where: 'url_key=?',
          whereArgs: [key], limit: 1);
        if (rows.isNotEmpty) continue;
        final id = await tx.insert('leads', {
          'id': item.id, 'url_key': key, 'discovered': item.discoveredAt.millisecondsSinceEpoch,
          'status': item.status, 'content': jsonEncode(item.toJson()),
        }, conflictAlgorithm: ConflictAlgorithm.ignore);
        if (id != 0) count++;
      }
    });
    return count;
  });

  Future<void> updateLead(HunterLead item) => _run((db) async {
    await db.update('leads', {'status': item.status, 'content': jsonEncode(item.toJson())},
      where: 'id=?', whereArgs: [item.id]);
  });

  Future<void> recordScan({required int found, required int added,
    required List<String> errors, int searched = 0, int discarded = 0}) => _run((db) async {
    final report = <String, dynamic>{
      'timestamp': DateTime.now().toIso8601String(), 'found': found, 'added': added,
      'searched': searched, 'discarded': discarded, 'errors': errors,
    };
    await db.insert('settings', {'key': 'lastScan', 'value': jsonEncode(report)},
      conflictAlgorithm: ConflictAlgorithm.replace);
  });

  Future<HunterSnapshot> snapshot() => _run((db) async {
    final counts = await db.rawQuery('SELECT status, COUNT(*) AS total FROM leads GROUP BY status');
    final totals = <String, int>{};
    for (final row in counts) totals['${row['status']}'] = (row['total'] as int?) ?? 0;
    final rows = await db.query('settings', where: 'key=?', whereArgs: ['lastScan'], limit: 1);
    DateTime? at;
    String message = 'Chưa có phiên quét';
    List<String> errors = [];
    if (rows.isNotEmpty) {
      final report = Map<String, dynamic>.from(jsonDecode(rows.first['value'] as String));
      at = DateTime.tryParse('${report['timestamp']}');
      errors = (report['errors'] is List) ? (report['errors'] as List).map((x) => '$x').toList() : [];
      message = 'Phát hiện ${report['found'] ?? 0} · Mới ${report['added'] ?? 0}'
        ' · Loại bởi bộ lọc ${report['discarded'] ?? 0}'
        '${errors.isEmpty ? '' : ' · ${errors.length} lỗi nguồn'}';
    }
    return HunterSnapshot(
      total: totals.values.fold<int>(0, (a, b) => a + b),
      pending: totals['pending'] ?? 0, confirmed: totals['imported'] ?? 0,
      rejected: totals['rejected'] ?? 0, lastScan: at,
      message: message, errors: errors,
    );
  });

  Future<void> close() async {
    final waiting = _opening;
    if (waiting != null) {
      try { await waiting; } catch (_) { /* already failed to open */ }
    }
    final db = _db;
    _db = null;
    if (db != null && db.isOpen) await db.close();
  }
}
