import 'dart:ui' show DartPluginRegistrant;
import 'package:flutter/widgets.dart';
import 'package:workmanager/workmanager.dart';
import 'hunter_search.dart';
import 'hunter_storage.dart';

const hunterJob = 'sourceflow_hunter_r2_scan';
const hunterWorkName = 'sourceflow_personal_r2_hunter';

@pragma('vm:entry-point')
void hunterCallbackDispatcher() {
  Workmanager().executeTask((task, inputData) async {
    if (task != hunterJob) return true;
    WidgetsFlutterBinding.ensureInitialized();
    DartPluginRegistrant.ensureInitialized();
    final storage = HunterStorage();
    final search = HunterSearch();
    try {
      await storage.open();
      final settings = await storage.settings();
      if (!settings.autoScan) return true;
      final result = await search.scan(settings);
      final added = await storage.addDiscovered(result.leads);
      await storage.recordScan(found: result.leads.length, added: added,
        errors: result.errors, searched: result.queries,
        discarded: result.discarded);
      // Partial RSS provider errors are logged; don't rapidly retry them.
      return true;
    } catch (error) {
      try {
        await storage.recordScan(found: 0, added: 0,
          errors: ['Lỗi tác vụ nền: $error']);
      } catch (_) { /* Database may be unavailable. */ }
      return false;
    } finally {
      search.close();
      // Separate DB handle: safe to close without invalidating foreground.
      await storage.close();
    }
  });
}

Future<void> configureHunterBackground(bool enabled) async {
  final manager = Workmanager();
  await manager.initialize(hunterCallbackDispatcher);
  if (enabled) {
    await manager.registerPeriodicTask(hunterWorkName, hunterJob,
      frequency: const Duration(hours: 2),
      constraints: Constraints(networkType: NetworkType.connected),
      existingWorkPolicy: ExistingPeriodicWorkPolicy.update,
    );
  } else {
    await manager.cancelByUniqueName(hunterWorkName);
  }
}
