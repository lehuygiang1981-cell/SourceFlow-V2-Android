import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';
import 'hunter_models.dart';
import 'hunter_search.dart';
import 'hunter_storage.dart';
import 'models.dart';

class HunterPage extends StatefulWidget {
  final HunterStorage storage;
  final Future<void> Function(Listing) onImport;
  final bool Function(String) sourceExists;
  final ValueChanged<HunterSnapshot> onChanged;
  final Future<void> Function(bool) onAutoChanged;
  const HunterPage({super.key,required this.storage,required this.onImport,
    required this.sourceExists,required this.onChanged,required this.onAutoChanged});
  @override State<HunterPage> createState()=>_HunterPageState();
}

class _HunterPageState extends State<HunterPage> with WidgetsBindingObserver {
  List<HunterLead> leads=[];
  HunterSettings settings=const HunterSettings();
  HunterSnapshot snapshot=const HunterSnapshot();
  final location = TextEditingController();
  final keywords = TextEditingController();
  final areas = TextEditingController();
  final streets = TextEditingController();
  final excluded = TextEditingController();
  final Set<String> selectedSites = {};
  String propertyType = 'Tất cả';
  int recentDays = 5, maxPosterListings = 3;
  bool excludeBroker = true, excludeSharedTitle = true;
  bool excludeApartments = false, ownerHintsOnly = false;
  bool busy = false, loaded = false;
  String filter = 'pending', notice = '';

  @override void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    refresh(initial: true);
  }

  @override void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) refresh(catchUp: true);
  }

  @override void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    for (final controller in [location, keywords, areas, streets, excluded]) {
      controller.dispose();
    }
    super.dispose();
  }

  String when(DateTime? d) {
    if (d == null) return 'Chưa có';
    String two(int n) => n.toString().padLeft(2, '0');
    return '${two(d.day)}/${two(d.month)}/${d.year} ${two(d.hour)}:${two(d.minute)}';
  }

  void message(String value) {
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(value)));
  }

  List<String> parseLines(String source) => source.split(RegExp(r'[\n;]+'))
    .map((s) => s.trim()).where((s) => s.isNotEmpty).toSet().toList();

  void loadEditors(HunterSettings s) {
    location.text = s.location;
    keywords.text = s.keywords;
    areas.text = s.areas.join('\n');
    streets.text = s.streets.join('\n');
    excluded.text = s.excludedTerms.join('\n');
    propertyType = s.propertyType;
    recentDays = s.recentDays;
    maxPosterListings = s.maxPosterListings;
    excludeBroker = s.excludeBroker;
    excludeSharedTitle = s.excludeSharedTitle;
    excludeApartments = s.excludeApartments;
    ownerHintsOnly = s.ownerHintsOnly;
    selectedSites..clear()..addAll(s.sites);
  }

  HunterSettings editorSettings({bool? autoScan}) => HunterSettings(
    location: location.text.trim(), keywords: keywords.text.trim(),
    areas: parseLines(areas.text), streets: parseLines(streets.text),
    excludedTerms: parseLines(excluded.text),
    propertyType: propertyType, recentDays: recentDays,
    maxPosterListings: maxPosterListings,
    sites: selectedSites.toList(),
    autoScan: autoScan ?? settings.autoScan,
    excludeBroker: excludeBroker,
    excludeSharedTitle: excludeSharedTitle,
    excludeApartments: excludeApartments, ownerHintsOnly: ownerHintsOnly,
  );

  String? checkCriteria(HunterSettings s) {
    if (s.location.isEmpty || s.keywords.isEmpty) {
      return 'Cần nhập tỉnh/thành phố và từ khóa.';
    }
    if (s.sites.isEmpty) return 'Hãy chọn ít nhất một website nguồn.';
    if (s.targets.length > 10) {
      return 'Tối đa 10 khu vực hoặc tuyến đường trong mỗi bộ lọc.';
    }
    return null;
  }

  Future<void> refresh({bool initial = false, bool catchUp = false}) async {
    try {
      final s = await widget.storage.settings();
      final l = await widget.storage.leads();
      final snap = await widget.storage.snapshot();
      if (!mounted) return;
      setState(() {
        settings = s; leads = l; snapshot = snap; loaded = true;
        if (initial) loadEditors(s);
      });
      widget.onChanged(snap);
      // On first open or app resume, catch up if Android postponed the task.
      if ((initial || catchUp) && s.autoScan && !busy &&
          (snap.lastScan == null || DateTime.now().difference(snap.lastScan!) >=
            const Duration(hours: 2))) {
        Future<void>.microtask(scan);
      }
    } catch (e) {
      if (mounted) {
        setState(() { loaded = true; notice = 'Lỗi tải nguồn web: $e'; });
      }
    }
  }

  Future<void> saveSettings() async {
    final options = editorSettings();
    final validation = checkCriteria(options);
    if (validation != null) { message(validation); return; }
    try {
      await widget.storage.saveSettings(options);
      if (mounted) setState(() => settings = options);
      if (options.autoScan) await widget.onAutoChanged(true);
      message('Đã lưu tiêu chí và khu vực quét.');
    } catch (e) { message('Chưa lưu được tiêu chí: $e'); }
  }

  Future<void> autoToggle(bool enabled) async {
    final options = editorSettings(autoScan: enabled);
    final validation = checkCriteria(options);
    if (validation != null) { message(validation); return; }
    try {
      await widget.storage.saveSettings(options);
      if (mounted) setState(() => settings = options);
      await widget.onAutoChanged(enabled);
      message(enabled ? 'Đã đăng ký tác vụ quét nền (theo lịch Android).' :
        'Đã tắt tác vụ quét nền.');
    } catch (e) {
      message('Không cập nhật được lịch tự quét: $e');
    }
  }

  Future<void> scan() async {
    if (busy || !mounted) return;
    final options = editorSettings();
    final validation = checkCriteria(options);
    if (validation != null) { message(validation); return; }
    setState(() {busy = true; notice = 'Đang tìm tin từ các nguồn công khai…';});
    final scanner = HunterSearch();
    try {
      await widget.storage.saveSettings(options);
      final outcome = await scanner.scan(options);
      final added = await widget.storage.addDiscovered(outcome.leads);
      await widget.storage.recordScan(found: outcome.leads.length,
        added: added, searched: outcome.queries, discarded: outcome.discarded,
        errors: outcome.errors);
      await refresh();
      if (!mounted) return;
      setState(() {
        filter = 'pending';
        notice = 'Đã thử ${outcome.queries} lượt tìm kiếm trên ${outcome.searched} website; '
          'thu được ${outcome.leads.length} ứng viên, $added tin mới, '
          'loại ${outcome.discarded} kết quả theo bộ lọc.'
          '${outcome.errors.isNotEmpty ? ' ${outcome.errors.length} truy vấn lỗi — xem chi tiết bên dưới.' : ''}';
      });
    } catch (e) {
      try {
        await widget.storage.recordScan(found: 0, added: 0, errors: ['$e']);
      } catch (_) { /* preserve original error */ }
      if (mounted) setState(() => notice = 'Không thực hiện được lượt quét: $e');
    } finally {
      scanner.close();
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> openSource(HunterLead lead)async{
    final uri=Uri.tryParse(lead.url);
    if(uri==null||!await launchUrl(uri,mode:LaunchMode.externalApplication)){
      message('Không mở được liên kết nguồn.');
    }
  }
  Future<void> reject(HunterLead lead)async{
    final reason=TextEditingController();
    final ok=await showDialog<bool>(context:context,builder:(ctx)=>AlertDialog(
      title:const Text('Loại khỏi danh sách chờ'),
      content:Column(mainAxisSize:MainAxisSize.min,children:[
        const Text('Tin này sẽ được giữ trong lịch sử, không hiện lại như tin mới khi quét trùng.'),
        const SizedBox(height:10),TextField(controller:reason,decoration:const InputDecoration(labelText:'Lý do (không bắt buộc)'))]),
      actions:[TextButton(onPressed:()=>Navigator.pop(ctx,false),child:const Text('Hủy')),
        FilledButton(onPressed:()=>Navigator.pop(ctx,true),child:const Text('Loại tin'))]));
    if(ok==true){lead.status='rejected';lead.reviewNote=reason.text.trim();lead.reviewedAt=DateTime.now();
      await widget.storage.updateLead(lead);await refresh();}
    reason.dispose();
  }
  Future<void> approve(HunterLead lead)async {
    if(widget.sourceExists(lead.url)){
      message('Tin này đã có trong kho nguồn hàng. Không nhập trùng.');return;
    }
    final method=ValueNotifier<String>('Đã đối chiếu hồ sơ');
    final evidence=TextEditingController();
    final note=TextEditingController();
    final confirmed=await showDialog<bool>(context:context,builder:(ctx)=>AlertDialog(
      title:const Text('Xác nhận nguồn hàng chính chủ'),
      content:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,
        crossAxisAlignment:CrossAxisAlignment.start,children:[
        Text(lead.title,style:const TextStyle(fontWeight:FontWeight.w600)),
        const SizedBox(height:9),const Text('Hãy đối chiếu tin gốc và liên hệ trước khi xác nhận. Dấu hiệu từ web KHÔNG đủ để kết luận chính chủ.',style:TextStyle(fontSize:12)),
        const SizedBox(height:13),ValueListenableBuilder<String>(valueListenable:method,builder:(_,value,__)=>
          DropdownButtonFormField<String>(value:value,decoration:const InputDecoration(labelText:'Cách xác minh'),
            items:const [DropdownMenuItem(value:'Đã đối chiếu hồ sơ',child:Text('Đã đối chiếu hồ sơ')),
              DropdownMenuItem(value:'Đã gặp và xác minh trực tiếp',child:Text('Đã gặp chủ trực tiếp'))],
            onChanged:(v){if(v!=null)method.value=v;})),
        const SizedBox(height:12),TextField(controller:evidence,maxLines:3,
          decoration:const InputDecoration(labelText:'Căn cứ xác minh (bắt buộc)',
            hintText:'Ví dụ: Đã đối chiếu sổ và căn cước với chủ tại địa chỉ...')),
        const SizedBox(height:12),TextField(controller:note,maxLines:2,
          decoration:const InputDecoration(labelText:'Ghi chú kiểm tra / thông tin cần bổ sung')),
      ])),actions:[TextButton(onPressed:()=>Navigator.pop(ctx,false),child:const Text('Hủy')),
        FilledButton(onPressed:()=>Navigator.pop(ctx,true),child:const Text('Xác nhận & lưu'))]));
    if(confirmed!=true){method.dispose();evidence.dispose();note.dispose();return;}
    if(evidence.text.trim().length<8){
      message('Cần ghi căn cứ xác minh cụ thể, tối thiểu 8 ký tự.');
      method.dispose();evidence.dispose();note.dispose();return;
    }
    final parsed=lead.parsed;
    final property=Listing(title:parsed.title.isEmpty?lead.title:parsed.title,
      type:parsed.type.isEmpty?'Nhà riêng':parsed.type,address:parsed.address,
      area:parsed.area,width:parsed.width,length:parsed.length,price:parsed.price,
      phone:parsed.phone,owner:parsed.owner,source:'Supply Hunter: ${lead.source}',
      sourceUrl:lead.url,verification:method.value,verificationEvidence:evidence.text.trim(),
      rawCapture:'${lead.title}\n${lead.snippet}',nextAction:'Kiểm tra bổ sung thông tin nguồn hàng',
      contactStatus:'Đã liên hệ');
    property.addLog('Nhập nguồn đã xác minh qua Supply Hunter',
      '${method.value}: ${evidence.text.trim()}. ${note.text.trim()} | ${lead.url}');
    try{
      await widget.onImport(property); // Never claim imported before successful source-flow save.
      lead.status='imported';lead.listingId=property.id;lead.method=method.value;
      lead.evidence=evidence.text.trim();lead.reviewNote=note.text.trim();
      lead.reviewedAt=DateTime.now();
      await widget.storage.updateLead(lead);
      await refresh();message('Đã lưu nguồn hàng đã xác minh vào kho cá nhân.');
    }catch(e){message('Chưa lưu được nguồn hàng: $e');}
    method.dispose();evidence.dispose();note.dispose();
  }
  Future<void> copyReport() async {
    final header='SOURCEFLOW SUPPLY HUNTER — BÁO CÁO TIN CHỜ KIỂM TRA\n'
      'Địa bàn: ${settings.location} | Khu vực: ${settings.areas.join(', ')} | Đường: ${settings.streets.join(', ')}\n'
      'Từ khóa: ${settings.keywords} | Ngày đăng cần kiểm: ${settings.recentDays} | Tối đa tin/người: ${settings.maxPosterListings}\n'
      'Thời điểm báo cáo: ${DateTime.now()}\n'
      'Ngày đăng và danh tính chủ sở hữu chưa được xác minh từ kết quả tìm kiếm.\n\n';
    final lines=leads.where((p)=>p.status=='pending').toList();
    final text=header+lines.asMap().entries.map((entry){
      final l=entry.value;final p=l.parsed;
      return '${entry.key+1}. ${l.title}\nNguồn: ${l.source}\n'
        '${p.area.isEmpty?'':'Diện tích: ${p.area}\n'}'
        '${p.price.isEmpty?'':'Giá: ${p.price}\n'}'
        'Link: ${l.url}\nTrạng thái: Chờ kiểm tra\n';
    }).join('\n');
    await Clipboard.setData(ClipboardData(text:text));message('Đã sao chép ${lines.length} nguồn chờ kiểm tra.');
  }
  Widget _leadCard(HunterLead lead)=>Card(child:Padding(padding:const EdgeInsets.all(12),child:Column(
    crossAxisAlignment:CrossAxisAlignment.start,children:[
      Text(lead.title,style:const TextStyle(fontWeight:FontWeight.w700)),
      const SizedBox(height:5),Text('${lead.source} • Tìm thấy: ${when(lead.discoveredAt)}',style:const TextStyle(fontSize:12,color:Colors.black54)),
      if(lead.queryTarget.isNotEmpty)Text('Khu vực/tuyến tìm: ${lead.queryTarget}',style:const TextStyle(fontSize:12,color:Colors.black54)),
      if(lead.indexDate!=null)const Text('Có ngày từ chỉ mục RSS; KHÔNG phải ngày đăng đã xác minh.',style:TextStyle(fontSize:11,color:Colors.deepOrange)),
      if(lead.snippet.isNotEmpty)Padding(padding:const EdgeInsets.only(top:7),child:Text(lead.snippet,maxLines:4,overflow:TextOverflow.ellipsis)),
      Text('Cần kiểm tra ngày đăng ≤ ${settings.recentDays} ngày và người đăng ≤ ${settings.maxPosterListings} tin tại website gốc.',style:const TextStyle(fontSize:11,color:Colors.deepOrange)),
      for(final flag in lead.reviewFlags)Padding(padding:const EdgeInsets.only(top:3),child:Text('• $flag',style:const TextStyle(fontSize:11,color:Colors.deepOrange))),
      const SizedBox(height:7),SelectableText(lead.url,style:const TextStyle(fontSize:12,color:Colors.teal)),
      if(lead.status=='imported')const Padding(padding:EdgeInsets.only(top:5),child:Text('Đã xác minh và lưu vào kho',style:TextStyle(color:Colors.green,fontWeight:FontWeight.bold))),
      if(lead.status=='rejected')const Padding(padding:EdgeInsets.only(top:5),child:Text('Đã loại',style:TextStyle(color:Colors.deepOrange))),
      const SizedBox(height:10),Wrap(spacing:6,runSpacing:6,children:[
        OutlinedButton.icon(onPressed:()=>openSource(lead),icon:const Icon(Icons.open_in_new,size:17),label:const Text('Xem tin gốc')),
        if(lead.status=='pending')...[
          FilledButton.icon(onPressed:()=>approve(lead),icon:const Icon(Icons.verified_user_outlined,size:17),label:const Text('Xác minh & lưu')),
          TextButton.icon(onPressed:()=>reject(lead),icon:const Icon(Icons.close,size:17),label:const Text('Loại')),
        ],
      ]),
    ])));
  @override Widget build(BuildContext context) {
    final visible=leads.where((p)=>filter=='all'||p.status==filter).toList();
    return !loaded?const Center(child:CircularProgressIndicator()):RefreshIndicator(onRefresh:refresh,child:ListView(
      padding:const EdgeInsets.all(14),children:[
        const Text('Supply Hunter · Nguồn web',style:TextStyle(fontSize:21,fontWeight:FontWeight.w800)),
        const SizedBox(height:5),const Text('Tin từ kết quả tìm kiếm chỉ là ứng viên. Mở link gốc, kiểm tra và tự xác minh trước khi lưu.',style:TextStyle(color:Colors.black54)),
        const SizedBox(height:12),Wrap(spacing:8,runSpacing:8,children:[
          Chip(label:Text('Chờ kiểm tra: ${snapshot.pending}')),
          Chip(label:Text('Đã lưu: ${snapshot.confirmed}')),
          Chip(label:Text('Đã loại: ${snapshot.rejected}')),
        ]),
        Text('Lần quét: ${snapshot.lastScan==null?'Chưa có':when(snapshot.lastScan)} • ${snapshot.message}',style:const TextStyle(fontSize:12)),
        const SizedBox(height:8),
        Card(child:Padding(padding: const EdgeInsets.all(12), child: Column(
          crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('THIẾT LẬP BỘ QUÉT', style: TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height:12),
          TextField(controller: location, decoration: const InputDecoration(
            labelText: 'Tỉnh/thành phố hoặc địa bàn',
            hintText: 'Ví dụ: Thành phố Thủ Đức, TP.HCM',
            prefixIcon: Icon(Icons.location_city))),
          const SizedBox(height:10),
          TextField(controller: areas, minLines: 2, maxLines: 4,
            decoration: const InputDecoration(
              labelText: 'Khu vực quét (mỗi dòng một khu vực)',
              hintText: 'Linh Xuân\nThảo Điền\nLong Trường',
              helperText: 'Để trống để quét toàn địa bàn')),
          const SizedBox(height:10),
          TextField(controller: streets, minLines: 2, maxLines: 4,
            decoration: const InputDecoration(
              labelText: 'Địa điểm / tuyến đường ưu tiên',
              hintText: 'Ka Vạn Cân\nLã Xuân Oai',
              helperText: 'Mỗi tuyến đường được tìm riêng')),
          const SizedBox(height:10),
          TextField(controller: keywords, decoration: const InputDecoration(
            labelText: 'Từ khóa cần quét', prefixIcon: Icon(Icons.search))),
          const SizedBox(height:10),
          DropdownButtonFormField<String>(value: propertyType,
            decoration: const InputDecoration(labelText: 'Loại bất động sản'),
            items: const ['Tất cả','Nhà','Đất','Nhà xưởng'].map((v) =>
              DropdownMenuItem(value: v, child: Text(v))).toList(),
            onChanged: (v) { if (v != null) setState(() => propertyType = v); }),
          const SizedBox(height:12),
          const Text('NGUỒN WEBSITE', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 12)),
          Wrap(spacing: 5, runSpacing: 0, children: [
            for (final site in HunterSearch.allowedHosts)
              FilterChip(label: Text(site, style: const TextStyle(fontSize: 11)),
                selected: selectedSites.contains(site),
                onSelected: (v) => setState(() {
                  if (v) {selectedSites.add(site);} else {selectedSites.remove(site);}
                })),
          ]),
          const SizedBox(height:8),
          Row(children: [
            Expanded(child: DropdownButtonFormField<int>(value: recentDays,
              decoration: const InputDecoration(labelText: 'Tin trong N ngày'),
              items: const [3,5,7,14,30].map((v) =>
                DropdownMenuItem(value: v, child: Text('$v ngày'))).toList(),
              onChanged: (v) {if (v != null) setState(() => recentDays = v);})),
            const SizedBox(width:8),
            Expanded(child: DropdownButtonFormField<int>(value: maxPosterListings,
              decoration: const InputDecoration(labelText: 'Số tin/người tối đa'),
              items: const [1,2,3,5].map((v) =>
                DropdownMenuItem(value: v, child: Text('$v tin'))).toList(),
              onChanged: (v) {if (v != null) setState(() => maxPosterListings = v);})),
          ]),
          const SizedBox(height:9),
          TextField(controller: excluded, minLines: 1, maxLines: 3,
            decoration: const InputDecoration(labelText: 'Từ khóa loại trừ (mỗi dòng một cụm)',
              hintText: 'Ví dụ: vi bằng')),
          SwitchListTile(contentPadding: EdgeInsets.zero, dense: true,
            title: const Text('Loại dấu hiệu môi giới'),
            value: excludeBroker,
            onChanged: (v) => setState(() => excludeBroker = v)),
          SwitchListTile(contentPadding: EdgeInsets.zero, dense: true,
            title: const Text('Loại dấu hiệu sổ chung'),
            value: excludeSharedTitle,
            onChanged: (v) => setState(() => excludeSharedTitle = v)),
          SwitchListTile(contentPadding: EdgeInsets.zero, dense: true,
            title: const Text('Loại chung cư, căn hộ'),
            value: excludeApartments,
            onChanged: (v) => setState(() => excludeApartments = v)),
          SwitchListTile(contentPadding: EdgeInsets.zero, dense: true,
            title: const Text('Chỉ giữ tin có cụm từ gợi ý chính chủ'),
            value: ownerHintsOnly,
            onChanged: (v) => setState(() => ownerHintsOnly = v)),
          const Text('Bộ lọc ngày đăng, số tin/người và chứng cứ chính chủ là yêu cầu kiểm tra tại tin gốc. RSS không đủ dữ liệu để xác minh tự động.',
            style: TextStyle(fontSize: 11, color: Colors.deepOrange)),
          const SizedBox(height:10),
          Row(children: [
            const Expanded(child: Text('Tự quét khoảng 2 giờ/lần khi có mạng',
              style: TextStyle(fontSize: 12))),
            Switch(value: settings.autoScan, onChanged: busy ? null : autoToggle),
          ]),
          const Text('Android có thể trì hoãn hoặc bỏ lỡ lịch do tiết kiệm pin. Ứng dụng sẽ quét bù khi được mở lại nếu đã quá 2 giờ.',
            style: TextStyle(fontSize: 11, color: Colors.black54)),
          const SizedBox(height:12),
          Row(children: [
            OutlinedButton(onPressed: busy ? null : saveSettings,
              child: const Text('Lưu tiêu chí')),
            const SizedBox(width:8),
            Expanded(child: FilledButton.icon(onPressed: busy ? null : scan,
              icon: busy ? const SizedBox(height:15,width:15,
                child:CircularProgressIndicator(strokeWidth:2)) : const Icon(Icons.travel_explore),
              label: Text(busy ? 'Đang quét' : 'Quét web ngay'))),
          ]),
        ]))),
        if(snapshot.errors.isNotEmpty) Card(child: ExpansionTile(
          title: Text('Chi tiết lỗi truy vấn (${snapshot.errors.length})'),
          children: [for(final error in snapshot.errors)
            ListTile(dense: true, title: SelectableText(error,
              style: const TextStyle(fontSize:12)))],
        )),
        if(notice.isNotEmpty)Padding(padding:const EdgeInsets.symmetric(vertical:8),child:SelectableText(notice,style:const TextStyle(fontSize:12))),
        const SizedBox(height:7),Row(children:[
          const Expanded(child:Text('BÁO CÁO NGUỒN TÌM ĐƯỢC',style:TextStyle(fontWeight:FontWeight.w700))),
          IconButton(onPressed:copyReport,tooltip:'Sao chép danh sách có link',icon:const Icon(Icons.copy_all_outlined)),
          IconButton(onPressed:refresh,tooltip:'Tải lại dữ liệu',icon:const Icon(Icons.refresh)),
        ]),
        Wrap(spacing:6,children:[
          for(final state in const [('pending','Chờ kiểm tra'),('imported','Đã lưu'),('rejected','Đã loại'),('all','Tất cả')])
            ChoiceChip(label:Text(state.$2),selected:filter==state.$1,
              onSelected:(_)=>setState(()=>filter=state.$1)),
        ]),
        if(visible.isEmpty)const Card(child:Padding(padding:EdgeInsets.all(20),child:Text('Chưa có tin trong nhóm này. Bấm Quét web ngay, hoặc mở lại để nhận kết quả từ tác vụ nền.'))),
        ...visible.map(_leadCard),
        const SizedBox(height:90),
      ]));
  }
}
