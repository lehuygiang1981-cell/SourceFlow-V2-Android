import 'package:http/http.dart' as http;
import 'package:xml/xml.dart';
import 'hunter_models.dart';

/// Search-index leads are not verified real-estate listings.
/// Publication date and poster history must be checked at the original site.
class HunterSearchResult {
  final List<HunterLead> leads;
  final List<String> errors;
  final int searched, discarded, queries;
  const HunterSearchResult(this.leads, this.errors, this.searched,
    {this.discarded = 0, this.queries = 0});
}

class HunterSearch {
  final http.Client client;
  HunterSearch({http.Client? client}): client = client ?? http.Client();

  static const allowedHosts = {
    'batdongsan.com.vn','nhatot.com','muaban.net','bds68.com.vn','guland.vn',
  };

  static bool directSourceUrl(String link, String expectedHost) {
    final url = Uri.tryParse(link);
    if (url == null || !['http','https'].contains(url.scheme)) return false;
    final host = url.host.toLowerCase();
    if (!(host == expectedHost || host.endsWith('.$expectedHost'))) return false;
    if (url.path == '/' || url.path.isEmpty) return false;
    if (RegExp(r'/(tim-kiem|search|dang-nhap|login|thanh-vien|tin-tuc)(/|$)')
        .hasMatch(url.path.toLowerCase())) return false;
    return true;
  }

  static Uri queryUrl(HunterSettings settings, String domain, {String target = ''}) {
    // One search per selected area/road, rather than AND-ing all locations.
    final terms = <String>['site:$domain', settings.location.trim()];
    if (target.trim().isNotEmpty) terms.add(target.trim());
    if (settings.propertyType != 'Tất cả') terms.add(settings.propertyType);
    if (settings.keywords.trim().isNotEmpty) terms.add(settings.keywords.trim());
    return Uri.https('www.bing.com', '/search', {'q': terms.join(' '), 'format': 'rss'});
  }

  static String textContent(String html) => html.replaceAll(RegExp(r'<[^>]+>'), ' ')
    .replaceAll('&nbsp;', ' ').replaceAll('&amp;', '&')
    .replaceAll('&quot;', '"').replaceAll('&#39;', "'")
    .replaceAll(RegExp(r'\s+'), ' ').trim();

  static List<HunterLead> readRss(String xml, String domain,
      {DateTime? now, String queryTarget = ''}) {
    final document = XmlDocument.parse(xml);
    final out = <HunterLead>[];
    final seen = <String>{};
    for (final item in document.findAllElements('item')) {
      String field(String name) {
        final tags = item.findElements(name);
        return tags.isEmpty ? '' : tags.first.innerText.trim();
      }
      final url = field('link');
      if (!directSourceUrl(url, domain)) continue;
      final canonical = canonicalLeadUrl(url);
      if (canonical.isEmpty || !seen.add(canonical)) continue;
      final title = textContent(field('title'));
      if (title.length < 8) continue;
      out.add(HunterLead(url: url, title: title,
        snippet: textContent(field('description')),
        source: domain, indexDate: DateTime.tryParse(field('pubDate')),
        discoveredAt: now, queryTarget: queryTarget));
    }
    return out;
  }

  static bool matchesCriteria(HunterLead lead, HunterSettings settings) {
    final content = '${lead.title} ${lead.snippet}'.toLowerCase();
    if (settings.excludedTerms.any((v) => v.trim().isNotEmpty &&
        content.contains(v.trim().toLowerCase()))) return false;
    if (settings.excludeSharedTitle &&
        (content.contains('sổ chung') || content.contains('so chung') ||
         content.contains('đồng sở hữu') || content.contains('dong so huu'))) return false;
    if (settings.excludeApartments &&
        (content.contains('chung cư') || content.contains('chung cu') ||
         content.contains('căn hộ') || content.contains('can ho'))) return false;
    if (settings.excludeBroker &&
        ['ký gửi', 'ky gui', 'chủ gửi', 'chu gui', 'nhận ký gửi',
          'làm việc chính chủ', 'chủ thiện chí', 'hoa hồng môi giới']
          .any(content.contains)) return false;
    if (settings.ownerHintsOnly &&
        !['chính chủ', 'chinh chu', 'tôi bán', 'toi ban',
          'tôi cần bán', 'toi can ban', 'miễn trung gian']
          .any(content.contains)) return false;
    // Do NOT filter by recentDays or maxPosterListings here: RSS does not
    // reliably provide the website posting date or poster's account history.
    return true;
  }

  Future<HunterSearchResult> scan(HunterSettings settings) async {
    final results = <HunterLead>[];
    final errors = <String>[];
    final seen = <String>{};
    var discarded = 0;
    var queries = 0;
    final domains = settings.sites.toSet().toList();
    final targets = settings.targets;

    // Separate domain tasks can run concurrently, while searches per domain
    // are sequential to avoid a burst of requests to the same RSS provider.
    final perDomain = await Future.wait(domains.map((domain) async {
      final items = <HunterLead>[];
      final localErrors = <String>[];
      var localQueries = 0;
      var localDiscarded = 0;
      if (!allowedHosts.contains(domain)) {
        return (items, ['$domain: nguồn chưa hỗ trợ'], localQueries, localDiscarded);
      }
      for (final target in targets) {
        localQueries++;
        try {
          final response = await client.get(queryUrl(settings, domain, target: target),
            headers: {
              'Accept': 'application/rss+xml, application/xml, text/xml',
              'User-Agent': 'SourceFlowPersonal/2.3 (public RSS candidates)',
            }).timeout(const Duration(seconds: 12));
          if (response.statusCode != 200) throw Exception('HTTP ${response.statusCode}');
          if (!response.body.contains('<rss') && !response.body.contains('<item')) {
            throw const FormatException('Nguồn tìm kiếm không trả RSS');
          }
          for (final lead in readRss(response.body, domain, queryTarget: target)) {
            if (!matchesCriteria(lead, settings)) {
              localDiscarded++;
            } else {
              items.add(lead);
            }
          }
        } catch (e) {
          localErrors.add('$domain / ${target.isEmpty ? settings.location : target}: $e');
        }
      }
      return (items, localErrors, localQueries, localDiscarded);
    }));

    for (final batch in perDomain) {
      queries += batch.$3;
      discarded += batch.$4;
      errors.addAll(batch.$2);
      for (final lead in batch.$1) {
        if (seen.add(lead.id)) results.add(lead);
      }
    }
    return HunterSearchResult(results, errors, domains.length,
      discarded: discarded, queries: queries);
  }

  void close() => client.close();
}
