# SourceFlow Personal R2.3 — SQLite & Supply Hunter sửa lỗi

**Nguồn gốc:** SourceFlow Personal R2 SupplyHunter Fix APK Syntax. Phiên bản `2.2.3+23`, cùng Android applicationId `vn.sourceflow.sourceflow_personal_r2`.

## Các bản sửa

1. Lỗi `DatabaseException(database_closed 2)`: SQLite Hunter dùng `singleInstance:false` để worker không đóng handle foreground, mở database lazy/serial, kiểm tra `isOpen` và retry đúng một lần nếu database bị đóng. Không sửa database nguồn hàng `sourceflow_v2.sqlite`; giữ nguyên schema R2 `sourceflow_hunter.sqlite`.
2. Thêm cấu hình: địa bàn/tỉnh thành, nhiều khu vực, nhiều đường/địa điểm, từ khóa, loại BĐS, chọn trong 5 website, loại trừ nội dung, tùy chọn lọc dấu hiệu môi giới/sổ chung/chung cư, chế độ chỉ giữ tin có cụm gợi ý chính chủ.
3. Tuỳ chọn ngày đăng tối đa (3/5/7/14/30 ngày) và số tin đăng/người (1/2/3/5). **Quan trọng:** chỉ là tiêu chí để người dùng đối chiếu ở trang nguồn; RSS không có bằng chứng đáng tin để tự động kết luận hai tiêu chí này.
4. Tự quét nền Android bằng WorkManager mỗi khoảng 2 giờ (không chính xác tuyệt đối); khi app mở lại và lần quét gần nhất đã quá 2 giờ sẽ quét bù. Lưu lỗi theo từng truy vấn trong SQLite, hiện chi tiết lỗi để kiểm tra.
5. Tin trùng URL không ghi đè lựa chọn duyệt/loại trước đó. Người dùng phải nhập chứng cứ mới được xác minh và lưu kho.

## Thực thi

- Giải nén mã nguồn vào thư mục dự án trên Windows đã cài Flutter SDK & Android SDK.
- Chạy `./scripts/prepare_android.ps1` từ PowerShell. Script tạo/cập nhật phần Android, giữ applicationId bản R2 cũ.
- Chạy `flutter test` rồi `flutter build apk --release`.
- APK nằm tại `build/app/outputs/flutter-apk/app-release.apk`.
- **Sao lưu dữ liệu từ app R2 trước khi cài bản mới.** Không gỡ cài đặt bản R2 khi nâng cấp. Bản R2.3 cài đè nếu chữ ký APK trùng và `applicationId` trùng. Nếu chữ ký khác, Android có thể từ chối cập nhật; tuyệt đối đừng gỡ app cũ khi chưa sao lưu.

## Giới hạn cần kiểm chứng

- Chưa chạy được `flutter test` hoặc build APK tại môi trường tạo mã nguồn do không có Flutter/Android SDK.
- Chưa xác nhận quét RSS thành công ngoài mạng hoặc trên điện thoại thật. Có thể gặp RSS 429, giới hạn truy cập, trả về 0 ứng viên hoặc trang tìm kiếm không trả RSS.
- Quét chỉ các website công khai qua chỉ mục RSS; không vượt đăng nhập, CAPTCHA hay điều khoản truy cập. Tin thu về là ứng viên, không được coi là xác minh chính chủ.
- Android hạn chế tác vụ nền tùy thiết bị/pin; không cam kết đúng phút giờ quét.
