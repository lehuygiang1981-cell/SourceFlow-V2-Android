# SourceFlow R3.0 - Supply Hunter

## Release identity
- App version: 3.0.0+30
- App title: SourceFlow Personal R3.0
- Supply Hunter title: SourceFlow R3.0

## Changes
- Derived from R2.9 BuildFix source; preserves three-group classification and editable property detail import.
- Corrects stale R2.7 app title.
- R3.0 CI explicitly extracts the R3.0 source ZIP, avoiding the old R2.9 ZIP being built accidentally.
- Regression test expects potential listing retention rather than zero retained leads.

## Limitations
Flutter tests and release APK build must pass GitHub Actions before this is considered validated. Website access restrictions (HTTP 403/JS) remain independent issues.
