# SourceFlow R2.8 – Strict filter fix

Root cause observed on R2.7: Guland seller profile `/tin-da-dang-475813/...` was incorrectly classified as a property URL, resulting in names such as `Đinh Ngọc Trung 16` shown as listings. R2.7 also allowed unknown publication date and seller listing count through `matchesCriteria`.

Changes:
- Exclude Guland seller-profile URLs at the URL classifier; reject seller-like headlines.
- Require detail text from the actual listing, valid original publication date within configured window, and verified seller-profile listing count within limit before accepting a result.
- Include detail text in exclusion checks; preserve manual human verification for ownership.
- Add R2.8 regression tests; update old tests that previously expected unknown dates/counts to pass.
- Preserve existing SQLite schema and storage logic; version 2.8.0+28.

Limitations: strict verification can result in **zero accepted leads** when a site does not expose seller counts or dates publicly. This is intentional rather than falsely passing unverified posts. A future UI should display a separate review queue for unverified posts, not mix them with accepted leads. No Flutter SDK is installed in the preparation environment, so compilation and live-site tests are not verified here. Back up SQLite data before uninstalling an existing app.
