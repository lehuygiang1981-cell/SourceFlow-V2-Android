Restore scanner controls; remove fixed-height nested settings ListView; lazy result cards; no database schema changes. Requires Flutter and device testing.
