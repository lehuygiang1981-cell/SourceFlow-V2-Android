# SourceFlow R3.4.2 — Broker Filter Patch 2

Only `lib/hunter_search.dart` and `test/hunter_r342_filter_test.dart` changed compared with Patch 1.

- Added detection of public Guland seller profile links and alternate Nha Tot profile links.
- Fixed calendar-day calculation for 5-day freshness checks, avoiding time-of-day boundary drift.
- Added regression cases: verified seller >3 listings rejected; unverified count stays pending; invalid calendar date rejected.

Limits: no Dart/Flutter test execution in this environment; site-specific seller profile HTML and HTTP access not yet validated. Do not claim full broker removal or APK readiness.
