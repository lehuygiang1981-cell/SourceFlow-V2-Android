# SourceFlow R3.4.2 – broker filter build package

This is a ZIP-first GitHub Actions build. The workflow extracts the source archive at repository root.

Scope: broker signals, seller profile count, freshness evidence, pending vs rejected, regression tests.

- Do not promote generic “chủ nhà bán” to owner proof.
- Seller count > configured maximum rejected for verified profile or human-verified evidence.
- Unknown profile count/date/address remains pending, never automatically confirmed owner.
- Only preliminary qualification; final owner verification requires human review.
- No UI redesign or unrelated feature changes.

Limitations: Flutter SDK unavailable in packaging environment. No successful build or live website scan is claimed.
