import 'dart:convert';
import 'package:http/http.dart' as http;

/// Administrative names used by property websites before 1 July 2025.
/// No external service is needed for the 34 former Thu Duc wards.
/// Other HCMC wards are retrieved on demand from a public legacy-address
/// directory and can be cached in the existing separate Hunter SQLite DB.
class OldDistrict {
  final String name, code;
  const OldDistrict(this.name, this.code);
}

class LegacyAdmin {
  static const province = 'Thành phố Hồ Chí Minh';
  static const thuDuc = 'Thành phố Thủ Đức';
  static const districtList = <OldDistrict>[
    OldDistrict('Thành phố Thủ Đức', '769'),
    OldDistrict('Quận 1', '760'), OldDistrict('Quận 3', '770'),
    OldDistrict('Quận 4', '773'), OldDistrict('Quận 5', '774'),
    OldDistrict('Quận 6', '775'), OldDistrict('Quận 7', '778'),
    OldDistrict('Quận 8', '776'), OldDistrict('Quận 10', '771'),
    OldDistrict('Quận 11', '772'), OldDistrict('Quận 12', '761'),
    OldDistrict('Quận Bình Tân', '777'), OldDistrict('Quận Bình Thạnh', '765'),
    OldDistrict('Quận Gò Vấp', '764'), OldDistrict('Quận Phú Nhuận', '768'),
    OldDistrict('Quận Tân Bình', '766'), OldDistrict('Quận Tân Phú', '767'),
    OldDistrict('Huyện Bình Chánh', '785'), OldDistrict('Huyện Cần Giờ', '787'),
    OldDistrict('Huyện Củ Chi', '783'), OldDistrict('Huyện Hóc Môn', '784'),
    OldDistrict('Huyện Nhà Bè', '786'),
  ];
  static const formerThuDucWards = <String>[
    'An Khánh','An Lợi Đông','An Phú','Bình Chiểu','Bình Thọ',
    'Bình Trưng Đông','Bình Trưng Tây','Cát Lái','Hiệp Bình Chánh',
    'Hiệp Bình Phước','Hiệp Phú','Linh Chiểu','Linh Đông','Linh Tây',
    'Linh Trung','Linh Xuân','Long Bình','Long Phước','Long Thạnh Mỹ',
    'Long Trường','Phú Hữu','Phước Bình','Phước Long A','Phước Long B',
    'Tam Bình','Tam Phú','Tăng Nhơn Phú A','Tăng Nhơn Phú B','Tân Phú',
    'Thảo Điền','Thạnh Mỹ Lợi','Thủ Thiêm','Trường Thạnh','Trường Thọ',
  ];
  static const formerDistrictGroup = <String,List<String>>{
    'Quận 2 cũ': ['An Khánh','An Lợi Đông','An Phú','Bình Trưng Đông',
      'Bình Trưng Tây','Cát Lái','Thảo Điền','Thạnh Mỹ Lợi','Thủ Thiêm'],
    'Quận 9 cũ': ['Hiệp Phú','Long Bình','Long Phước','Long Thạnh Mỹ',
      'Long Trường','Phú Hữu','Phước Bình','Phước Long A','Phước Long B',
      'Tân Phú','Tăng Nhơn Phú A','Tăng Nhơn Phú B','Trường Thạnh'],
    'Quận Thủ Đức cũ': ['Bình Chiểu','Bình Thọ','Hiệp Bình Chánh',
      'Hiệp Bình Phước','Linh Chiểu','Linh Đông','Linh Tây','Linh Trung',
      'Linh Xuân','Tam Bình','Tam Phú','Trường Thọ'],
  };

  static String? codeFor(String name) {
    for (final d in districtList) {
      if (d.name == name) return d.code;
    }
    return null;
  }

  /// No secret/token; no aggressive retries; request only on explicit picker
  /// interaction. Source: tinhthanhpho.com legacy administrative open API.
  static Future<List<String>> loadWards(String district, {http.Client? client}) async {
    if (district == thuDuc) return formerThuDucWards;
    final code = codeFor(district);
    if (code == null) throw StateError('Không có mã quận/huyện cũ: $district');
    final own = client == null;
    final c = client ?? http.Client();
    try {
      final endpoint = Uri.https('www.tinhthanhpho.com',
        '/api/v1/districts/$code/wards', {'limit': '200'});
      final response = await c.get(endpoint, headers: {'Accept':'application/json'})
        .timeout(const Duration(seconds: 12));
      if (response.statusCode != 200) throw StateError('API địa danh: HTTP ${response.statusCode}');
      final payload = jsonDecode(utf8.decode(response.bodyBytes));
      if (payload is! Map || payload['data'] is! List) {
        throw const FormatException('Không đọc được danh mục phường/xã');
      }
      final values = <String>[];
      for (final entry in payload['data'] as List) {
        if (entry is! Map) continue;
        final name = '${entry['name'] ?? ''}'.trim();
        if (name.isNotEmpty && !values.contains(name)) values.add(name);
      }
      if (values.isEmpty) throw const FormatException('Danh mục phường/xã trả về rỗng');
      return values;
    } finally {
      if (own) c.close();
    }
  }
}
