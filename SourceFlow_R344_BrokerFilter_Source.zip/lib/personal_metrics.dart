import 'models.dart';

/// Metrics computed entirely from the personal offline SQLite records.
/// A "verified" property is counted only after the user sets an evidenced
/// verification status. Automatic OCR or listing crawls never verify owners.
class PersonalMetrics {
  final int total, created, modified, verifiedTotal, verifiedInPeriod;
  final int activities, contacts, posts, buyers, pending, due, ocrInputs, voiceInputs;
  final List<int> newByDay;
  const PersonalMetrics({required this.total,required this.created,required this.modified,
    required this.verifiedTotal,required this.verifiedInPeriod,
    required this.activities,required this.contacts,required this.posts,
    required this.buyers,required this.pending,required this.due,required this.ocrInputs,required this.voiceInputs,required this.newByDay});

  static PersonalMetrics fromListings(Iterable<Listing> listings,DateTime now,{int days=7}) {
    if(days<1)throw ArgumentError.value(days,'days');
    final midnight=DateTime(now.year,now.month,now.day);
    final from=midnight.subtract(Duration(days:days-1));
    final end=midnight.add(const Duration(days:1));
    bool during(DateTime d)=>!d.isBefore(from)&&d.isBefore(end);
    final active=listings.where((p)=>!p.archived).toList();
    int created=0,edited=0,verified=0,verifiedWindow=0;
    int activities=0,contacts=0,posts=0,buyers=0,due=0,ocrInputs=0,voiceInputs=0;
    final chart=List<int>.filled(days,0);
    for(final p in active){
      final confirmed=(p.verification=='Đã đối chiếu hồ sơ'||
        p.verification=='Đã gặp và xác minh trực tiếp')&&p.verificationEvidence.trim().isNotEmpty;
      if(confirmed)verified++;
      if(p.nextDue!=null && p.nextDue!.isBefore(end) && p.saleStatus!='Đã giao dịch' &&
         (p.nextAction.isNotEmpty||p.marketingNeedsAttention))due++;
      if(during(p.createdAt)){
        created++;
        final bucket=DateTime(p.createdAt.year,p.createdAt.month,p.createdAt.day).difference(from).inDays;
        if(bucket>=0&&bucket<days)chart[bucket]++;
      }
      for(final entry in p.logs){
        if(!during(entry.at))continue;
        activities++;
        final action=entry.action.toLowerCase();
        if(action.contains('chỉnh sửa'))edited++;
        if(entry.note.contains('OCR: có')||entry.note.contains('Nhập bằng hình ảnh'))ocrInputs++;
        if(entry.note.contains('Giọng nói: có')||entry.note.contains('Nhập bằng giọng nói'))voiceInputs++;
        if(action.contains('xác minh') && confirmed)verifiedWindow++;
        if(action.contains('gọi')||action.contains('liên hệ')||action.contains('hẹn'))contacts++;
        if(action.contains('đăng tin'))posts++;
        if(action.contains('khách quan tâm')||action.contains('đề nghị mua'))buyers++;
      }
    }
    return PersonalMetrics(total:active.length,created:created,modified:edited,
      verifiedTotal:verified,verifiedInPeriod:verifiedWindow,activities:activities,
      contacts:contacts,posts:posts,buyers:buyers,
      pending:active.where(needsOwnerVerification).length,due:due,ocrInputs:ocrInputs,voiceInputs:voiceInputs,newByDay:chart);
  }
}
