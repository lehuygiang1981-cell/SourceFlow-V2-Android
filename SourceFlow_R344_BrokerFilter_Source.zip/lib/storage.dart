import 'dart:convert';
import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';
import 'models.dart';

class ListingStorage {
  Database? _db;
  Future<void> open() async {
    final root = await getDatabasesPath();
    _db = await openDatabase(p.join(root, 'sourceflow_v2.sqlite'), version:1,
      onCreate:(db,v) async => db.execute('CREATE TABLE listings (id TEXT PRIMARY KEY, updated INTEGER NOT NULL, content TEXT NOT NULL)'));
  }
  Future<List<Listing>> all() async {
    final rows=await _db!.query('listings',orderBy:'updated DESC');
    return rows.map((e)=>Listing.fromJson(Map<String,dynamic>.from(jsonDecode(e['content'] as String)))).toList();
  }
  Future<void> save(Listing x) async {
    await _db!.insert('listings', {'id':x.id,'updated':x.updatedAt.millisecondsSinceEpoch,
      'content':jsonEncode(x.toJson())},conflictAlgorithm:ConflictAlgorithm.replace);
  }
  Future<void> close() async => _db?.close();
}
