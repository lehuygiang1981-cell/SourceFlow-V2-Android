import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest_all.dart' as tzdb;
import 'package:timezone/timezone.dart' as tz;
import 'models.dart';

class MorningReminder {
  final FlutterLocalNotificationsPlugin _plugin = FlutterLocalNotificationsPlugin();
  bool ready=false;
  static const id=8100;
  Future<void> initialize() async {
    try {
      tzdb.initializeTimeZones();
      tz.setLocalLocation(tz.getLocation('Asia/Ho_Chi_Minh'));
      await _plugin.initialize(const InitializationSettings(
        android: AndroidInitializationSettings('@mipmap/ic_launcher')));
      final android=_plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
      await android?.requestNotificationsPermission();
      ready=true;
    } catch (_) { ready=false; }
  }

  Future<void> refresh(List<Listing> all) async {
    if(!ready) return;
    try {
      await _plugin.cancel(id);
      final pending=attentionForAll(all,DateTime.now());
      if(pending.isEmpty) return;
      final now=tz.TZDateTime.now(tz.local);
      var next=tz.TZDateTime(tz.local,now.year,now.month,now.day,8,0);
      if(!next.isAfter(now)) next=next.add(const Duration(days:1));
      await _plugin.zonedSchedule(
        id,'SourceFlow • Tổng hợp nguồn hàng',
        '${pending.length} hồ sơ cần theo dõi. Nhấn để xem việc còn tồn đọng.',next,
        const NotificationDetails(android:AndroidNotificationDetails(
          'sourceflow_morning','Nhắc nguồn hàng buổi sáng',
          channelDescription:'Danh sách hồ sơ chưa ký hoặc có biến động cần xử lý',
          importance:Importance.defaultImportance, priority:Priority.defaultPriority,
        )),
        androidScheduleMode:AndroidScheduleMode.inexactAllowWhileIdle,
        matchDateTimeComponents:DateTimeComponents.time,
      );
    } catch (_) { /* thiết bị từ chối quyền: bảng việc trong app vẫn hoạt động */ }
  }
}
