import 'package:flutter_test/flutter_test.dart';
import 'package:sourceflow_android/hunter_search.dart';
import 'package:sourceflow_android/hunter_models.dart';

void main() {
  HunterLead lead(String description) => HunterLead(
    url: 'https://bds68.com.vn/nha-dat-ban/ban-nha-123456.html',
    title: 'Bán nhà Thủ Đức', source: 'bds68.com.vn', detailText: description,
  );
  test('broker agency and consignments are rejected', () {
    expect(HunterSearch.classifyLead(lead('Nhận ký gửi nhà đất, hoa hồng môi giới 2%.'), const HunterSettings()), 'rejected');
  });
  test('seller branded as myland is rejected', () {
    expect(HunterSearch.classifyLead(lead('Do Thanh An thanhan.myland. Còn 1 căn hiếm, liên hệ.'), const HunterSettings()), 'rejected');
  });
  test('generic owner text does not imply broker', () {
    expect(HunterSearch.brokerEvidence(lead('Nhà chính chủ bán gấp, hỗ trợ xem nhà, có sổ riêng.')), isNull);
  });
  test('broker exclusion may be explicitly disabled', () {
    expect(HunterSearch.classifyLead(lead('Nhận ký gửi nhà đất, hoa hồng môi giới 2%.'), const HunterSettings(excludeBroker: false)), isNot('rejected'));
  });
}
