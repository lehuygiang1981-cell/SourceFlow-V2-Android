import 'package:flutter_test/flutter_test.dart';
import 'package:sourceflow_android/models.dart';

void main(){
 test('OCR giữ nguyên dòng số và bỏ nút giao diện khỏi gợi ý',(){
   const lines=['Tạo người liên hệ mới','Diện tích','301 m²','Ngang 5,5m','Dài 20m',
      'SĐT: 0901 234 567','Thêm vào một người liên hệ'];
   final complete=retainAllOcrLines(lines);
   expect(complete,contains('Tạo người liên hệ mới'));
   expect(complete,contains('0901 234 567'));
   final hints=ocrFieldsText(lines);
   expect(hints,contains('301 m²'));
   expect(hints,contains('0901 234 567'));
   expect(hints, isNot(contains('Tạo người liên hệ mới')));
   final x=parseIntake(hints);
   expect(x.area,'301 m²');
   expect(x.width,'5,5 m');
   expect(x.length,'20 m');
   expect(x.phone,'0901234567');
 });
 test('Sửa nhãn OCR có kiểm soát, không sửa tên đường',(){
   final text=ocrFieldsText(['Điện tích: 80 m2','Số điện thoai: 0901234567',
     'Đường Hàng Tre']);
   expect(text,contains('Diện tích: 80 m2'));
   expect(text,contains('Đường Hàng Tre'));
 });
 test('Số điện thoại bị che không được tự đoán',(){
   expect(parseIntake('Liên hệ 0901 23****').phone,isEmpty);
 });
 test('Số điện thoại +84 và dấu cách',(){
   expect(parseIntake('SĐT: +84 901 234 567').phone,'0901234567');
 });
 test('Không suy luận kích thước nếu chỉ có diện tích',(){
   final x=parseIntake('Bán nhà Đường Hàng Tre 301 m² giá 15,5 tỷ');
   expect(x.width,isEmpty);expect(x.length,isEmpty);
 });
}
