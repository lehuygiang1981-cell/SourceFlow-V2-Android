import 'package:flutter_test/flutter_test.dart';
import 'package:sourceflow_android/models.dart';
import 'package:sourceflow_android/personal_metrics.dart';

void main(){
  group('SourceFlow Personal OCR co chon loc',(){
    test('Chi lay cac dong co nhan, bo dong quang cao',(){
      final selected=selectRelevantOcrLines([
        '🔥 TIN HOT - MUA NGAY KẺO LỠ',
        'Địa chỉ:',
        '68 Bưng Ông Thoàn, phường Long Trường',
        'Ngang: 5 m',
        'Dài: 20 m',
        'Diện tích: 100 m²',
        'CAM KẾT LỢI NHUẬN 30% MỖI NĂM',
        'Giá bán: 10,5 tỷ',
        'SĐT: 090 123 4567',
        'Liên hệ ngay để nhận ưu đãi',
      ]);
      expect(selected,contains('Ngang: 5 m'));
      expect(selected,contains('68 Bưng Ông Thoàn'));
      expect(selected,contains('10,5 tỷ'));
      expect(selected,contains('090 123 4567'));
      expect(selected, isNot(contains('CAM KẾT LỢI NHUẬN')));
      expect(selected, isNot(contains('TIN HOT')));
      final parsed=parseIntake(selected);
      expect(parsed.width,'5 m');
      expect(parsed.length,'20 m');
      expect(parsed.area,'100 m²');
      expect(parsed.price,'10,5 tỷ');
      expect(parsed.phone,'0901234567');
    });
    test('Khong doan ngang dai tu dien tich',(){
      final input=selectRelevantOcrLines(['Diện tích','100 m²','Vui lòng liên hệ sau']);
      final x=parseIntake(input);
      expect(x.area,'100 m²');
      expect(x.width,isEmpty);expect(x.length,isEmpty);
    });
    test('Khong lay so 5x20 neu khong co nhan kich thuoc',(){
      final x=parseIntake('Mã sản phẩm 5x20; Giá bán 9 tỷ');
      expect(x.width,isEmpty);expect(x.length,isEmpty);
    });
    test('Chuan hoa dau Unicode dang combining',(){
      final original='Diện tích: 120 m2';
      final normal=normalizeVietnameseUnicode(original);
      expect(normal,contains('Diện tích'));
      expect(parseIntake(normal).area,'120 m²');
    });
    test('Khong ket luan chinh chu tu tin dang',(){
      final parsed=parseIntake('Chính chủ cần bán nhà, diện tích 55 m2, giá 5 tỷ');
      expect(parsed.area,'55 m²');
      expect(Listing().verification,'Chưa xác minh');
    });
  });
  group('Giong noi tu nhien',(){
    test('Doc ngan rong dai theo chu',(){
      final x=parseIntake(normalizeVoiceTranscript(
        'Bán nhà địa chỉ 25 đường số 9, ngang năm mét, dài hai mươi mét, '
        'diện tích một trăm mét vuông, giá mười tỷ'));
      expect(x.width,'5 m');
      expect(x.length,'20 m');
      expect(x.area,'100 m²');
      expect(x.price,'10 tỷ');
    });
    test('Doc ngang nam phay nam, dai hai muoi',(){
      final x=parseIntake('Chiều ngang năm phẩy năm mét, chiều dài hai mươi mét, giá 8 tỷ');
      expect(x.width,'5,5 m');expect(x.length,'20 m');
    });
    test('Khong doi ten rieng va so dien thoai',(){
      final text=normalizeVoiceTranscript('Số điện thoại 0901234567 chủ là anh Tý');
      expect(text,contains('0901234567'));
      expect(text,contains('Tý'));
    });
  });
  test('Dashboard chi tinh cong viec co thoi gian, can cu xac minh',(){
    final now=DateTime(2026,10,22,12);
    final verified=Listing(title:'Nhà A',createdAt:DateTime(2026,10,22,9),
      verification:'Đã đối chiếu hồ sơ',verificationEvidence:'Đã xem sổ hồng',logs:[
        WorkLog(id:'a',at:DateTime(2026,10,22,11),action:'Cập nhật xác minh chính chủ',note:'Đã đối chiếu hồ sơ'),
        WorkLog(id:'b',at:DateTime(2026,10,22,11),action:'Đã gọi chủ',note:'Phản hồi'),
      ]);
    final unverified=Listing(title:'Nhà B',createdAt:DateTime(2026,10,22,8),
      verification:'Đã gặp và xác minh trực tiếp',verificationEvidence:'');
    final metrics=PersonalMetrics.fromListings([verified,unverified],now,days:1);
    expect(metrics.created,2);
    expect(metrics.verifiedTotal,1);
    expect(metrics.verifiedInPeriod,1);
    expect(metrics.contacts,1);
    expect(metrics.newByDay,[2]);
  });
}
