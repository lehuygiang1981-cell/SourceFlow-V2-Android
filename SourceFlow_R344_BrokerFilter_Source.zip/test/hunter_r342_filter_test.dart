import 'package:flutter_test/flutter_test.dart';
import 'package:sourceflow_android/hunter_search.dart';
import 'package:sourceflow_android/hunter_models.dart';

void main() {
  HunterLead lead(String t) => HunterLead(url: 'https://bds68.com.vn/ban-nha/example', source: 'bds68.com.vn', title: 'Bán nhà tại Thủ Đức', detailText: t);
  test('broker signal at end of description is detected', () {
    expect(HunterSearch.brokerEvidence(lead('Nhà đẹp. Làm việc chính chủ')), isNotNull);
  });
  test('broker signal in middle of description is detected', () {
    expect(HunterSearch.brokerEvidence(lead('Nhận ký gửi nhà đất, giá tốt')), isNotNull);
  });
  test('broker account name detected', () {
    expect(HunterSearch.brokerEvidence(lead('Liên hệ hungthinhvuongrealty167')), isNotNull);
  });
  test('numeric real estate seller handle is rejected', () {
    expect(HunterSearch.brokerEvidence(lead('Nguyễn Hoàng Mỹ Tiên hungthinhvuongreal167')), isNotNull);
  });
  test('ordinary real word does not trigger broker rejection', () {
    expect(HunterSearch.brokerEvidence(lead('Nhà thật, hình real 100%, gia đình tự bán')), isNull);
  });
  test('plain direct seller not rejected', () {
    expect(HunterSearch.brokerEvidence(lead('Tôi bán căn nhà của gia đình, địa chỉ rõ ràng')), isNull);
  });
  test('verified seller with four listings is rejected', () {
    final x=HunterLead(url:'https://bds68.com.vn/ban-nha/123456.html',source:'bds68.com.vn',
      title:'Bán nhà Thủ Đức',detailText:'Nhà gia đình đang bán, diện tích 100 m2, sổ riêng',
      posterCountSource:'seller_profile_verified',posterCountEvidence:'4');
    expect(HunterSearch.classifyLead(x,const HunterSettings()),'rejected');
  });
  test('unverified seller count must not qualify or be treated as verified', () {
    final x=HunterLead(url:'https://bds68.com.vn/ban-nha/123456.html',source:'bds68.com.vn',
      title:'Bán nhà Thủ Đức',detailText:'Chính chủ bán nhà gia đình, diện tích 100 m2, sổ riêng',
      posterCountSource:'snippet_unverified',posterCountEvidence:'2');
    expect(HunterSearch.classifyLead(x,const HunterSettings()),'potential');
  });
  test('invalid future date is not accepted as evidence', () {
    expect(HunterSearch.dateFromEvidence('31/02/2026'),isNull);
  });
  test('generic owner wording does not qualify a listing', () {
    final x=HunterLead(url:'https://bds68.com.vn/ban-nha/123456.html',source:'bds68.com.vn',
      title:'Bán nhà Thủ Đức',detailText:'Chủ nhà bán căn nhà tại số 12 đường 5, Thủ Đức, sổ riêng đầy đủ',
      posterCountSource:'seller_profile_verified',posterCountEvidence:'1',dateEvidence:'27/10/2026');
    expect(HunterSearch.brokerEvidence(x),isNotNull);
    expect(HunterSearch.classifyLead(x,const HunterSettings()),'rejected');
  });
  test('four verified posts rejected even when seller says direct owner', () {
    final x=HunterLead(url:'https://bds68.com.vn/ban-nha/123456.html',source:'bds68.com.vn',
      title:'Bán nhà Thủ Đức',detailText:'Tôi là chủ căn nhà, bán trực tiếp, có sổ riêng',
      posterCountSource:'human_verified',posterCountEvidence:'4');
    expect(HunterSearch.classifyLead(x,const HunterSettings()),'rejected');
  });

}
