import 'package:flutter_test/flutter_test.dart';
import 'package:html/parser.dart' as parser;
import 'package:sourceflow_android/hunter_search.dart';
import 'package:sourceflow_android/hunter_models.dart';
void main(){
  test('Date on BDS68 card is captured and old posts rejected',(){
    final doc='<article><a href="/ban-nha-rieng/ho-chi-minh/thu-duc/duong-so-5/tin-chinh-chu-pr31275175"><h3>CHÍNH CHỦ CẦN BÁN NHÀ GẦN HOÀNG DIỆU 2</h3></a><p>14/10/2026 Cao Danh</p></article>';
    final found=HunterSearch.parseListingHtml(doc,Uri.parse('https://bds68.com.vn/nha-dat-ban/ho-chi-minh/thu-duc'),'bds68.com.vn');
    expect(found.single.snippet,contains('2 14/10/2026'));
    expect(found.single.dateEvidence,'14/10/2026');
    expect(HunterSearch.matchesCriteria(found.single,const HunterSettings()),isFalse);
  });
  test('Count is not guessed from an unrelated 10 tin snippet',(){
    final doc='<article><a href="/ban-nha-rieng/ho-chi-minh/thu-duc/duong-so-5/tin-chinh-chu-pr31275175"><h3>Chính chủ bán nhà 80m2</h3></a><p>Khuyến mại 10 tin đăng miễn phí</p></article>';
    final found=HunterSearch.parseListingHtml(doc,Uri.parse('https://bds68.com.vn/nha-dat-ban/ho-chi-minh/thu-duc'),'bds68.com.vn');
    expect(found.single.posterCountEvidence,'');
    expect(found.single.posterCountSource,'snippet_unverified');
  });
  test('Lead full detail is persisted and used for parsed fields',(){
    final lead=HunterLead(url:'https://bds68.com.vn/ban-nha-rieng/pr12345555',
      title:'Bán nhà Linh Xuân',source:'bds68.com.vn',
      detailText:'Diện tích: 80 m². Ngang 5 m dài 16 m. Giá bán: 6 tỷ. SĐT: 0912345678.');
    final roundTrip=HunterLead.fromJson(lead.toJson());
    expect(roundTrip.parsed.area,contains('80'));
    expect(roundTrip.parsed.phone,'0912345678');
    expect(roundTrip.parsed.width,contains('5'));
  });
  test('Ignore search results that request buying or renting',(){
    const cfg=HunterSettings();
    expect(HunterSearch.matchesCriteria(HunterLead(url:'https://muaban.net/x',title:'Cần mua nhà Thủ Đức',source:'muaban.net'),cfg),isFalse);
    expect(HunterSearch.matchesCriteria(HunterLead(url:'https://muaban.net/y',title:'Cho thuê nhà Thủ Đức',source:'muaban.net'),cfg),isFalse);
  });
  test('Direct HTML parser ignores non-real-estate scripts',(){
    final doc=parser.parse('<html><body><main><article><h1>Bán nhà phố</h1><p>Diện tích: 90m². Giá bán: 9 tỷ.</p></article></main></body></html>');
    final text=HunterSearch.extractDetailText(doc);
    expect(text,contains('Diện tích'));
  });
}
