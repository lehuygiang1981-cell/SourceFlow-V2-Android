import 'package:flutter_test/flutter_test.dart';
import 'package:sourceflow_android/models.dart';

void main() {
  test('Chua lien he luon nam trong danh sach nhac', () {
    final p=Listing(title:'Nha A');
    expect(attentionFor(p,DateTime(2026,10,16)),isNotNull);
    expect(attentionFor(p,DateTime(2026,10,16))!.priority,0);
  });
  test('Da ky va dang chao ban on dinh khong nhac', () {
    final p=Listing(title:'Nha B',contractStatus:'Đã ký',saleStatus:'Đang chào bán');
    expect(attentionFor(p,DateTime(2026,10,16)),isNull);
  });
  test('Da ky nhung co bien dong phai nhac', () {
    final p=Listing(title:'Nha C',contractStatus:'Đã ký',marketingNeedsAttention:true);
    expect(attentionFor(p,DateTime(2026,10,16)),isNotNull);
    applyFeedback(p,'Đã xử lý biến động chào bán','Đã chỉnh sửa giá');
    expect(attentionFor(p,DateTime.now()),isNull);
  });
  test('Phan hoi da ky tu dong ngat nhac va co nhat ky', () {
    final p=Listing(title:'Nha D',contactStatus:'Đã liên hệ');
    applyFeedback(p,'Đã ký hợp đồng môi giới','Đã ký tại văn phòng');
    expect(p.contractStatus,'Đã ký');
    expect(p.logs.first.action,'Đã ký hợp đồng môi giới');
    expect(attentionFor(p,DateTime.now()),isNull);
  });
  test('Chua ky nhung hen tuong lai van hien trong danh sach theo doi', () {
    final p=Listing(title:'Nha E',contactStatus:'Đã liên hệ',nextAction:'Gọi lại',nextDue:DateTime(2026,11,5));
    final a=attentionFor(p,DateTime(2026,10,16));
    expect(a,isNotNull); expect(a!.reason,contains('Theo dõi'));
  });
  test('V2 old photo path survives migration to imagePaths', () {
    final old=Listing.fromJson({'title':'Old listing','imagePath':'/old/photo.jpg'});
    expect(old.imagePaths,['/old/photo.jpg']);
    final newFormat=Listing.fromJson(old.toJson());
    expect(newFormat.imagePaths.length,1);
    newFormat.imagePaths.add('/new/photo2.jpg');
    final copy=Listing.fromJson(newFormat.toJson());
    expect(copy.imagePaths.length,2);
    expect(copy.imagePath,'/old/photo.jpg');
  });
  test('Unverified list excludes only evidenced owner checks', () {
    final p=Listing(verification:'Đã trao đổi, chưa đối chiếu');
    expect(needsOwnerVerification(p),isTrue);
    p.verification='Đã đối chiếu hồ sơ';
    expect(needsOwnerVerification(p),isFalse);
  });
  test('OCR labels propose editable field values', () {
    final parsed=parseIntake('Nhà mặt tiền đường 13\nĐịa chỉ: 123 đường 13, Thủ Đức\nDiện tích: 120 m2\nGiá: 12,5 tỷ\nChủ nhà: Anh Minh\nSĐT: 0901234567');
    expect(parsed.address,'123 đường 13, Thủ Đức');
    expect(parsed.area,'120 m²');
    expect(parsed.price,contains('12,5 tỷ'));
    expect(parsed.phone,'0901234567');
    expect(parsed.owner,'Anh Minh');
    expect(parsed.type,'Nhà mặt tiền');
  });
  test('Chup hinh hoac giong noi chi goi y, khong auto xac minh chu', () {
    final p=Listing(title:'Dat F');
    final input=parseIntake('Đất đường số 9\nDiện tích 120 m2 giá 9 tỷ\nLiên hệ 0901234567');
    expect(input.area,'120 m²');expect(input.price,'9 tỷ');expect(input.phone,'0901234567');
    expect(p.verification,'Chưa xác minh');
  });
  group('V2.2 - Tự tách trường từ ảnh OCR và giọng nói', () {
    test('Tin đăng đa dòng trích xuất đủ địa chỉ, diện tích, giá, chủ, điện thoại', () {
      final x=parseIntake('''CHÍNH CHỦ ĐĂNG BÁN CĂN NHÀ
Địa chỉ
23/6c đường số 5 phường Linh Xuân
Diện tích
60m2
Giá bán: 5,2 tỷ
Chủ nhà: Anh Minh
Số điện thoại: 0901 234 567''');
      expect(x.title,contains('CĂN NHÀ'));
      expect(x.address,contains('23/6c'));
      expect(x.area,'60 m²');
      expect(x.price,'5,2 tỷ');
      expect(x.owner,'Anh Minh');
      expect(x.phone,'0901234567');
    });
    test('Giọng nói tự nhiên không có dấu hai chấm', () {
      final x=parseIntake('Nhà 23/6c đường số 5 phường Linh Xuân chủ là chị Lan '
        'diện tích 60 mét vuông giá 5 tỷ 200 triệu số điện thoại 0901234567');
      expect(x.address,contains('23/6c đường số 5'));
      expect(x.area,'60 m²');
      expect(x.price,'5 tỷ 200 triệu');
      expect(x.owner,'chị Lan');
      expect(x.phone,'0901234567');
    });
    test('Diện tích và giá đọc bằng chữ tiếng Việt', () {
      final x=parseIntake('Bán nhà tại 68 Bưng Ông Thoàn, Long Trường '
        'diện tích sáu mươi mét vuông giá năm tỷ hai trăm triệu '
        'chủ là anh Nam');
      expect(x.area,'60 m²');
      expect(x.price,'5 tỷ 200 triệu');
      expect(x.owner,'anh Nam');
    });
    test('Nhiều ảnh OCR nối nội dung từ các nguồn khác nhau', () {
      final x=parseIntake('Nhà mặt tiền đường 23\nĐịa chỉ: 25 đường 23, Thủ Đức\n'
        'Diện tích: 120 m²\nGiá 17,5 tỷ\nChủ nhà: cô Mai\n'
        'Liên hệ: +84 901 234 567');
      expect(x.area,'120 m²');
      expect(x.price,'17,5 tỷ');
      expect(x.phone,'0901234567');
      expect(x.owner,'cô Mai');
      expect(x.address,contains('25 đường 23'));
    });
    test('Giọng nói đọc giá theo cách 5 tỷ 2', () {
      final x=parseIntake('bán nhà địa chỉ 17 đường 13 diện tích 70m2 giá 5 tỷ 2');
      expect(x.area,'70 m²');
      expect(x.price,'5,2 tỷ');
    });
    test('Không phỏng đoán giá hoặc chủ từ ảnh không có dữ liệu', () {
      final x=parseIntake('HÌNH ẢNH MẶT TIỀN CÔNG TRÌNH ĐẸP');
      expect(x.price,isEmpty);
      expect(x.phone,isEmpty);
      expect(x.owner,isEmpty);
      expect(x.area,isEmpty);
      expect(Listing().verification,'Chưa xác minh');
    });
  });

  group('V2.3 - Kích thước và luồng nhập OCR', () {
    test('Ảnh có nhãn ngang dài độc lập với diện tích', () {
      final x=parseIntake('Địa chỉ: 15 Đường số 13, Thủ Đức\n'
        'Diện tích: 100 m2\nNgang: 5m, Dài: 20m\nGiá: 8 tỷ');
      expect(x.area,'100 m²');
      expect(x.width,'5 m');
      expect(x.length,'20 m');
      expect(x.price,'8 tỷ');
    });
    test('Ảnh ghi KT: 5 x 20 hoặc 6×18,5', () {
      final a=parseIntake('Bán đất mặt tiền. KT: 5 x 20. Giá 9 tỷ');
      expect(a.width,'5 m');
      expect(a.length,'20 m');
      final b=parseIntake('Nhà riêng kích thước 6×18,5 diện tích 111m2');
      expect(b.width,'6 m');
      expect(b.length,'18,5 m');
      expect(b.area,'111 m²');
    });
    test('Thiếu ngang dài thì không tự đoán từ diện tích', () {
      final x=parseIntake('Diện tích: 100 m2, giá 7 tỷ');
      expect(x.area,'100 m²');
      expect(x.width,isEmpty);
      expect(x.length,isEmpty);
    });
    test('Sao lưu và mở dữ liệu V2.2 giữ thông tin mới và đọc hồ sơ cũ', () {
      final old=Listing.fromJson({'id':'old','title':'Nhà cũ','area':'75 m²'});
      expect(old.width,isEmpty);
      expect(old.length,isEmpty);
      final saved=Listing(title:'Nhà mới',area:'100 m²',width:'5 m',length:'20 m');
      final restored=Listing.fromJson(saved.toJson());
      expect(restored.width,'5 m');
      expect(restored.length,'20 m');
      expect(restored.area,'100 m²');
    });
    test('OCR nhiều dòng tách diện tích ngang dài giá và liên hệ', () {
      final x=parseIntake('BÁN NHÀ MẶT TIỀN ĐƯỜNG SỐ 9\n'
        'Địa chỉ: 68 Bưng Ông Thoàn, Long Trường\nDT: 130 m2\n'
        'Ngang 6.5m dài 20m\nGiá bán 9 tỷ\nLiên hệ 0901234567');
      expect(x.address,contains('68 Bưng Ông Thoàn'));
      expect(x.area,'130 m²');
      expect(x.width,'6,5 m');
      expect(x.length,'20 m');
      expect(x.price,'9 tỷ');
      expect(x.phone,'0901234567');
    });
  });
}

