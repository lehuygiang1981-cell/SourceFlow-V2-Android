import 'package:flutter_test/flutter_test.dart';
import 'package:sourceflow_android/hunter_search.dart';
import 'package:sourceflow_android/hunter_models.dart';
void main(){
  final settings=HunterSettings();
  HunterLead lead({String text='Bán nhà chính chủ đường số 9 Thủ Đức diện tích 90 m2 giá 8 tỷ',String date='',String count='',String countSource=''})=>
    HunterLead(url:'https://bds68.com.vn/nha-dat-ban/ban-nha-123456.html',title:'Bán nhà đường số 9 Thủ Đức',source:'bds68.com.vn',detailText:text,dateEvidence:date,posterCountEvidence:count,posterCountSource:countSource);
  test('unknown date and count retained as potential',(){expect(HunterSearch.classifyLead(lead(),settings),'potential');});
  test('clear broker excluded',(){expect(HunterSearch.classifyLead(lead(text:'Công ty môi giới ký gửi bán nhà đường số 9 diện tích 90 m2 giá 8 tỷ'),settings),'rejected');});
  test('seller count above threshold excluded',(){final n=DateTime.now();final d='${n.day}/${n.month}/${n.year}';expect(HunterSearch.classifyLead(lead(date:d,count:'4',countSource:'seller_profile_verified'),settings),'rejected');});
  test('Guland seller profile excluded from listings',(){expect(HunterSearch.parseListingHtml('<a href="/tin-da-dang-475813/abc">Đinh Ngọc Trung 16</a>',Uri.parse('https://guland.vn/mua-ban-bat-dong-san-thanh-pho-thu-duc-tp-ho-chi-minh'),'guland.vn'),isEmpty);});
  test('non-property wiki URLs excluded',(){expect(HunterSearch.parseListingHtml('<a href="https://muaban.net/wiki/dieu-khoan-su-dung-muabannet/">Điều khoản sử dụng</a>',Uri.parse('https://muaban.net/bat-dong-san/ban-nha-ho-chi-minh'),'muaban.net'),isEmpty);});
}
