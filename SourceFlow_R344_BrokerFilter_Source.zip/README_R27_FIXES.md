# SourceFlow R2.7 – Supply Hunter repair (source candidate)

Changes compared to R2.6:
- Read up to 30 detail pages per source instead of 8; each URL is read individually.
- Extract headline from detail page h1 / OpenGraph / Twitter metadata; do not treat a seller's name as property title.
- Show extracted address, area and price on scan cards when available.
- Rename misleading 'Khu vực/tuyến tìm' URL label to 'Nguồn tìm kiếm'.
- Preserve whitespace between DOM text nodes for detail extraction.
- Prioritize actual description elements over generic article containers.
- Reject implausible future dates; retain unknown dates as pending verification.
- Keep manual ownership verification and existing SQLite data model unchanged.

LIMITATIONS: No Flutter SDK is installed in this environment, so this is a source-code patch, not a compiled or device-tested APK. HTML-only websites may still block access or require JavaScript. Never label a lead as verified without human evidence. Back up app data before uninstalling the previous APK.
