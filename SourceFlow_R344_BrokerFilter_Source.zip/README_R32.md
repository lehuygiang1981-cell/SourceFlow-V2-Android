# SourceFlow R3.2 — results-first UI + explicit rejected state

- Results are shown immediately at top in a bounded lazy ListView.builder; settings collapsed below.
- All scanned results remain accessible in All; automatically rejected leads appear in Rejected, not Pending.
- Keeps existing SQLite filename and schema; no data deletion/migration.
- Existing extraction, evidence-based classification, and owner-only verification are preserved.
- IMPORTANT: No Flutter SDK is installed in the authoring environment. CI compilation and Android device performance tests are still required.
- Direct public HTML scraping is best-effort. JS-only sites, login walls, 403/429, or changed markup cannot be guaranteed.
