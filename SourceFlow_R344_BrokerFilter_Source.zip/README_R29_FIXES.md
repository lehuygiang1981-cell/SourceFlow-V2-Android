# SourceFlow R2.9 – bộ lọc ba nhóm

- Giao diện phiên bản R2.9; pubspec 2.9.0+29.
- Mỗi tin đã đọc được phân loại `qualified`, `potential`, `rejected` và giữ trong kho quét với lý do.
- Thiếu bằng chứng ngày đăng hoặc số tin người đăng => potential, KHÔNG bị xóa khỏi danh sách.
- Dấu hiệu môi giới rõ ràng, sổ chung (nếu bật), số tin > giới hạn đã xác minh hoặc tin quá hạn => rejected.
- Qualified chỉ là đạt sơ bộ, KHÔNG tự xác minh quyền sở hữu.
- Màn hình nhập vẫn đọc lại trang gốc, điền địa chỉ, diện tích, ngang, dài, giá, số liên hệ, tên liên hệ để chỉnh sửa trước khi lưu.
- Không sửa cấu trúc SQLite; dữ liệu cũ vẫn đọc được, các bản ghi cũ mặc định `potential`.
- Lỗi HTTP 403 và nguồn JavaScript không thể tự giải quyết bằng bộ lọc; vẫn ghi nhật ký nguồn riêng.
- Không có Flutter SDK trong môi trường tạo bản này: cần CI Flutter analyze/test/build và kiểm thử thực tế trên điện thoại.
