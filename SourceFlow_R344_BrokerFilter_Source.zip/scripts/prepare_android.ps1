# SourceFlow V2 Android: run on Windows with Flutter SDK and Android SDK installed.
$ErrorActionPreference = 'Stop'
Set-Location (Join-Path $PSScriptRoot '..')
if (-not (Get-Command flutter -ErrorAction SilentlyContinue)) {
  throw 'Chua tim thay flutter trong PATH. Cai Flutter SDK + Android Studio truoc khi build.'
}
if (-not (Test-Path 'android\app\build.gradle.kts')) {
  & flutter create --platforms=android --org vn.sourceflow --project-name sourceflow_android .
  if ($LASTEXITCODE -ne 0) { throw 'flutter create that bai' }
}
# Flutter create co the them test mac dinh tham chieu MyApp. V2 khong dung test mau do.
if (Test-Path 'test\widget_test.dart') { Remove-Item 'test\widget_test.dart' -Force }
Copy-Item 'android_patch\AndroidManifest.xml' 'android\app\src\main\AndroidManifest.xml' -Force
$gradle = 'android\app\build.gradle.kts'
$body = Get-Content $gradle -Raw
# Install separately from V2 / V2.1 / V2.2 trial so the existing app and its data are not overwritten.
$body = $body -replace 'applicationId\s*=\s*"[^"]+"', 'applicationId = "vn.sourceflow.sourceflow_personal_r2"'
$body = $body -replace 'minSdk\s*=\s*flutter\.minSdkVersion', 'minSdk = 23'
$body = $body -replace 'compileSdk\s*=\s*flutter\.compileSdkVersion', 'compileSdk = 36'
if ($body -notmatch 'compileOptions\s*\{') { throw 'Khong tim thay compileOptions trong build.gradle.kts cua Android.' }
if ($body -notmatch 'isCoreLibraryDesugaringEnabled') {
  $body = [regex]::Replace($body, 'compileOptions\s*\{', "compileOptions {`n        isCoreLibraryDesugaringEnabled = true")
}
if ($body -notmatch 'coreLibraryDesugaring\("com\.android\.tools:desugar_jdk_libs') {
  $body = $body + "`n`ndependencies {`n    coreLibraryDesugaring(`"com.android.tools:desugar_jdk_libs:2.1.4`")`n}`n"
}
# R2.6: Diagnose Android release OCR crash observed on user device.
# Disable R8/minification and resource shrinking: ML Kit internal reflection
# must not be removed/renamed by the release optimizer during this trial.
# This is a controlled diagnostic build, NOT proof that R8 caused the crash.
if ($body -notmatch 'release\s*\{') { throw 'Khong tim thay release trong build.gradle.kts.' }
if ($body -notmatch 'isMinifyEnabled\s*=\s*false') {
  $body = [regex]::new('release\s*\{').Replace($body, "release {`n            isMinifyEnabled = false`n            isShrinkResources = false", 1)
}
if ($body -notmatch 'isMinifyEnabled\s*=\s*false' -or $body -notmatch 'isShrinkResources\s*=\s*false') {
  throw 'Khong tat duoc thu gon ma/tài nguyen release.'
}
# Ghi UTF-8 khong BOM de Gradle Kotlin DSL doc on dinh tren PowerShell 5.1/7.
$gradlePath = (Resolve-Path $gradle).Path
[System.IO.File]::WriteAllText($gradlePath, $body, [System.Text.UTF8Encoding]::new($false))
Write-Host 'Da tao/bo sung cau hinh Android: minSdk 23, desugaring, microphone, notification, OCR, R8 release OFF.'
& flutter pub get
if ($LASTEXITCODE -ne 0) { throw 'flutter pub get that bai. Xem lai phien ban SDK/phu thuoc.' }

# R3.4.4: file_picker 10.3.3 sets Kotlin JVM target 1.8 while Java uses 11.
# Align the plugin Kotlin target with Java 11 before Gradle compilation.
$pubCache = if ($env:PUB_CACHE) { $env:PUB_CACHE } else { Join-Path $env:LOCALAPPDATA 'Pub\Cache' }
$pluginDirs = @(Get-ChildItem -Path (Join-Path $pubCache 'hosted\pub.dev') -Directory -Filter 'file_picker-*' -ErrorAction SilentlyContinue)
if ($pluginDirs.Count -eq 0) { throw 'Khong tim thay file_picker trong Pub cache sau flutter pub get.' }
foreach ($pluginDir in $pluginDirs) {
  foreach ($gradleFile in @('build.gradle', 'build.gradle.kts')) {
    $pluginGradle = Join-Path $pluginDir.FullName ("android\" + $gradleFile)
    if (-not (Test-Path $pluginGradle)) { continue }
    $pluginBody = [System.IO.File]::ReadAllText($pluginGradle)
    $updated = [regex]::Replace($pluginBody, '(jvmTarget\s*=\s*["' + "'" + '])1\.8(["' + "'" + '])', '${1}11${2}')
    $updated = [regex]::Replace($updated, '(jvmTarget\.set\(\s*JvmTarget\.JVM_)1_8(\s*\))', '${1}11${2}')
    if ($updated -ne $pluginBody) {
      [System.IO.File]::WriteAllText($pluginGradle, $updated, [System.Text.UTF8Encoding]::new($false))
      Write-Host "Aligned file_picker Kotlin JVM target to 11: $pluginGradle"
    } else {
      Write-Host "file_picker has no explicit JVM 1.8 target in $pluginGradle; checking compatibility at Gradle build."
    }
  }
}

Write-Host 'Chuan bi thanh cong. Tiep theo: flutter build apk --release'
