# SourceFlow V2.2 — Tự điền thông tin từ ảnh và giọng nói

## Lỗi từ thử nghiệm V2.1 và thay đổi trong mã V2.2

- **Ảnh:** Khi chọn 1 hoặc nhiều ảnh, ứng dụng xử lý OCR từng ảnh. Sau khi có chữ, bộ phân tích tiếng Việt được gọi **tự động**, lấy nội dung ảnh để điền **những ô chưa có thông tin**. Không cần bấm nút "Điền gợi ý" nữa (nút vẫn còn để dùng nếu chỉnh văn bản trích xuất). Hiển thị tóm tắt các ô đã tự điền.
- **Giọng nói:** Khi Android trả kết quả hoàn tất một đoạn nhận dạng, ứng dụng ghép đoạn vào văn bản và **tự điền ngay**; đồng thời phân tích toàn bộ văn bản lần nữa khi người dùng dừng hoặc hết thời lượng. Vẫn hỗ trợ các phiên 2, 3 hoặc 5 phút, nhưng mỗi lượt lắng nghe có thể bị Android/dịch vụ giọng nói ngắt sớm.
- **Một bộ phân tích chung:** Hỗ trợ tin đăng có nhiều dòng hoặc không dấu, cách đọc tiếng Việt thông thường, địa chỉ hẻm/số nhà, diện tích `m2`, `m²`, `mét vuông`, giá `5,2 tỷ`, `5 tỷ 200 triệu`, `5 tỷ 2`, diện tích nói bằng chữ "sáu mươi mét vuông", điện thoại có dấu cách hoặc dấu chấm, tên chủ có nhãn như "chủ là", "chủ nhà", "tên chủ", và liên kết web.
- **Không ghi đè sửa tay:** Tự điền vào các ô trống; người dùng xem và chỉnh từng trường trước khi lưu. Chức năng OCR/giọng nói không tự xác minh danh tính chủ sở hữu.
- **Giữ các cải tiến V2.1:** Bộ lọc nguồn hàng ở trang tổng quan, chọn nhiều ảnh, xem ảnh toàn màn hình, chỉnh sửa hồ sơ, sao lưu/khôi phục.

## Giới hạn cần kiểm thử

- OCR chỉ đọc **chữ trong ảnh**. Nếu ảnh chỉ chụp căn nhà, không có chữ nêu địa chỉ, giá, số điện thoại thì không thể suy ra các trường này.
- Tiếng nói và OCR có thể nhận sai dấu câu, con số hoặc tên đường; phải kiểm tra lại đặc biệt **giá, diện tích và số điện thoại** trước khi lưu.
- Số đọc bằng chữ được xử lý theo mẫu phổ biến; cách diễn đạt rất tự do có thể cần chỉnh tay. Không giả định các thông tin không có trong dữ liệu gốc.
- Đây là mã nguồn, chưa xác nhận APK V2.2 hoạt động trên thiết bị trước khi GitHub Actions và người dùng kiểm thử.

## Cài đặt và dữ liệu

- `applicationId` V2.2: `vn.sourceflow.sourceflow_android_v22`. V2.2 **cài song song với V2.1** để tránh lỗi chữ ký APK thử nghiệm và nguy cơ mất dữ liệu hiện tại.
- Dữ liệu V2.1 không tự chuyển sang V2.2. **Không xóa V2.1** trước khi xuất `.sfbackup` từ V2.1 và nhập/kiểm tra khôi phục trên V2.2.
- Không đưa dữ liệu khách hàng thật hoặc tệp sao lưu chứa số điện thoại, địa chỉ, hình ảnh lên GitHub, nhất là repo Public.

## Biên dịch qua GitHub Actions bằng điện thoại

1. Upload `SourceFlow_V2_2_transfer.zip` vào thư mục gốc repo `lehuygiang1981-cell/SourceFlow-V2-Android`.
2. Trong `.github/workflows/android-apk.yml`, thay `Expand-Archive -LiteralPath 'SourceFlow_V2_1_transfer.zip'` thành `Expand-Archive -LiteralPath 'SourceFlow_V2_2_transfer.zip'`; giữ nguyên các phần build Kotlin và R8 đã hoạt động thành công. Hoặc thay bằng `SourceFlow_V2_2_workflow.yml` kèm gói này.
3. Commit và xem lần chạy mới ở Actions. Đảm bảo 2 bước **Build APK** và **Upload APK** thành công mới tải bản V2.2.

## Kiểm thử thực tế

1. Tạo nguồn hàng mới; chọn 2 ảnh thử chứa tin đăng có địa chỉ, diện tích, giá, số điện thoại. Xác nhận các trường tự điền mà không bấm nút gợi ý.
2. Sửa giá bằng tay, chọn thêm ảnh chứa giá khác; xác nhận giá đã chỉnh **không bị ghi đè**.
3. Chuyển sang giọng nói, đọc "Nhà 23/6c đường số 5, phường Linh Xuân, diện tích sáu mươi mét vuông, giá năm tỷ hai trăm triệu, chủ là anh Nam, số điện thoại 0901234567". Xác nhận có gợi ý các trường sau một đoạn và khi dừng nghe.
4. Lưu nguồn hàng, đóng rồi mở app, kiểm tra dữ liệu/ảnh, thao tác sửa hồ sơ. Nếu có dữ liệu V2.1, thử `.sfbackup` bằng hồ sơ mẫu.
