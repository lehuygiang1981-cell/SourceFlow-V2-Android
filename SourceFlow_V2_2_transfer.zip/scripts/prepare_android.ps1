# SourceFlow V2 Android: run on Windows with Flutter SDK and Android SDK installed.
$ErrorActionPreference = 'Stop'
Set-Location (Join-Path $PSScriptRoot '..')
if (-not (Get-Command flutter -ErrorAction SilentlyContinue)) {
  throw 'Chua tim thay flutter trong PATH. Cai Flutter SDK + Android Studio truoc khi build.'
}
if (-not (Test-Path 'android\app\build.gradle.kts')) {
  & flutter create --platforms=android --org vn.sourceflow --project-name sourceflow_android .
  if ($LASTEXITCODE -ne 0) { throw 'flutter create that bai' }
}
# Flutter create co the them test mac dinh tham chieu MyApp. V2 khong dung test mau do.
if (Test-Path 'test\widget_test.dart') { Remove-Item 'test\widget_test.dart' -Force }
Copy-Item 'android_patch\AndroidManifest.xml' 'android\app\src\main\AndroidManifest.xml' -Force
$gradle = 'android\app\build.gradle.kts'
$body = Get-Content $gradle -Raw
# Install separately from V2 / V2.1 trial so the existing app and its data are not overwritten.
$body = $body -replace 'applicationId\s*=\s*"[^"]+"', 'applicationId = "vn.sourceflow.sourceflow_android_v22"'
$body = $body -replace 'minSdk\s*=\s*flutter\.minSdkVersion', 'minSdk = 23'
$body = $body -replace 'compileSdk\s*=\s*flutter\.compileSdkVersion', 'compileSdk = 36'
if ($body -notmatch 'compileOptions\s*\{') { throw 'Khong tim thay compileOptions trong build.gradle.kts cua Android.' }
if ($body -notmatch 'isCoreLibraryDesugaringEnabled') {
  $body = [regex]::Replace($body, 'compileOptions\s*\{', "compileOptions {`n        isCoreLibraryDesugaringEnabled = true")
}
if ($body -notmatch 'coreLibraryDesugaring\("com\.android\.tools:desugar_jdk_libs') {
  $body = $body + "`n`ndependencies {`n    coreLibraryDesugaring(`"com.android.tools:desugar_jdk_libs:2.1.4`")`n}`n"
}
# Ghi UTF-8 khong BOM de Gradle Kotlin DSL doc on dinh tren PowerShell 5.1/7.
$gradlePath = (Resolve-Path $gradle).Path
[System.IO.File]::WriteAllText($gradlePath, $body, [System.Text.UTF8Encoding]::new($false))
Write-Host 'Da tao/bo sung cau hinh Android: minSdk 23, desugaring, microphone, notification, OCR.'
& flutter pub get
if ($LASTEXITCODE -ne 0) { throw 'flutter pub get that bai. Xem lai phien ban SDK/phu thuoc.' }
Write-Host 'Chuan bi thanh cong. Tiep theo: flutter build apk --release'
