# SourceFlow V2.1 — sửa lỗi trải nghiệm và nhập liệu

## Đã cập nhật mã nguồn

1. **Chỉ số tổng quan có thể nhấn:** Tổng nguồn hàng, chưa liên hệ, chưa ký hợp đồng, đã ký hợp đồng, chưa xác minh chính chủ. Mỗi chỉ số mở danh sách tương ứng, có tìm kiếm và vào được hồ sơ; trở về danh sách sẽ tính lại theo dữ liệu mới.
2. **Ảnh:** chọn nhiều ảnh cùng lúc (`pickMultiImage`), chụp bổ sung không giới hạn một ảnh (giới hạn an toàn hiện tại 40 ảnh/hồ sơ), quản lý nhiều đường dẫn ảnh, xem ảnh lớn/vuốt/phóng to, xóa ảnh khỏi hồ sơ, giữ tương thích dữ liệu ảnh đơn của V2.
3. **OCR từ ảnh:** chạy nhận dạng chữ trên **từng** ảnh, nối văn bản nhận được, gợi ý tên tài sản, địa chỉ có nhãn, diện tích, giá, số điện thoại, tên liên hệ, loại bất động sản và URL nếu có. Chỉ điền những ô trống, tránh ghi đè nội dung đã được người dùng sửa. Chỉ chữ có trong ảnh mới được OCR; ảnh chụp công trình không có chữ không thể suy ra giấy tờ/địa chỉ/giá bán. OCR tiếng Việt cần thử trên thiết bị thực tế.
4. **Giọng nói:** chọn tổng thời lượng **2, 3, hoặc 5 phút**, giữ các đoạn đã nhận qua lần ngắt của dịch vụ nhận dạng Android; tự thử khởi động phiên nghe mới. Android có thể hạn chế thời lượng mỗi phiên nghe; không thể cam kết thu liên tục 5 phút trên mọi thiết bị/phiên bản hệ điều hành.
5. **Chỉnh sửa/bổ sung:** sửa từng trường qua nút bút, cả trường nhập tay và trường OCR/giọng nói; chỉnh sửa ở màn hình chi tiết; bổ sung xác minh, tiến độ, hợp đồng và lịch xử lý. Tình trạng chính chủ không tự xác nhận bằng AI hoặc lời rao.
6. **Sao lưu ảnh:** V2.1 xuất `.sfbackup` chứa JSON và ảnh được nén gzip; đọc lại `.sfbackup` hoặc backup `.json` cũ (JSON cũ **không có ảnh**).

## Dữ liệu và bảo mật

- Mã ứng dụng V2.1 thay đổi thành `vn.sourceflow.sourceflow_android_v21` để bản dùng thử mới **cài song song** với SourceFlow V2. Không gỡ V2 cũ nếu còn dữ liệu.
- Khi dùng V2.1, bạn cần tạo dữ liệu thử riêng hoặc nhập tệp `.json` do V2 cũ xuất. Tệp `.json` V2 không chứa ảnh, nên V2.1 không thể khôi phục ảnh bị thất lạc chỉ từ JSON cũ.
- Giữ file backup tại nơi riêng tư; backup gồm số điện thoại, địa chỉ và ảnh.
- Không đưa dữ liệu thật của khách hàng vào GitHub. Kho repository của bạn hiện đang ở chế độ Public; nên chuyển sang Private.

## Cách biên dịch APK trên GitHub (qua điện thoại)

1. Tải `SourceFlow_V2_1_transfer.zip` trong cuộc trò chuyện và tải **tệp ZIP này vào thư mục gốc** của `lehuygiang1981-cell/SourceFlow-V2-Android` qua Add file > Upload files > Commit changes. **Giữ nguyên ZIP, không cần giải nén trên điện thoại.**
2. Mở `.github/workflows/android-apk.yml`, thay dòng `Expand-Archive -LiteralPath 'SourceFlow_V2_transfer.zip'` thành `Expand-Archive -LiteralPath 'SourceFlow_V2_1_transfer.zip'`. Giữ các quy tắc sửa Kotlin và R8 của lần chạy số 4. Có thể thay toàn bộ bằng `SourceFlow_V2_1_workflow.yml` được chuẩn bị kèm theo.
3. Commit. Chọn tab Actions, mở lần chạy mới. Chỉ tải từ Artifacts nếu **Build APK** và **Upload APK** thành công.
4. Đây là mã nguồn được sửa trong môi trường không có Flutter SDK, **chưa được biên dịch/kiểm thử APK V2.1**. GitHub Actions phải xác nhận kết quả thực tế trước khi cài.

## Các bước thử sau khi có APK

- Tạo 2–3 nguồn mẫu; nhấn “Tổng nguồn” / “Chưa xác minh” và mở hồ sơ tương ứng.
- Chọn 3 ảnh từ thư viện, chạm từng ảnh để phóng to; xác nhận ảnh vẫn còn sau khi đóng mở ứng dụng.
- Dùng ảnh chứa chữ như tin đăng (không chứa dữ liệu nhạy cảm) thử OCR, xem gợi ý và sửa trực tiếp các ô.
- Đọc giọng nói 2 phút và kiểm tra nhiều đoạn được cộng lại, không bị ghi đè.
- Lưu/sửa thông tin một nguồn hàng từ màn hình chi tiết và kiểm tra cập nhật danh sách.
- Tạo một bản `.sfbackup`, thử khôi phục ở bản dùng thử và kiểm tra ảnh.
