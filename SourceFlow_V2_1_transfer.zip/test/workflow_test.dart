import 'package:flutter_test/flutter_test.dart';
import 'package:sourceflow_android/models.dart';

void main() {
  test('Chua lien he luon nam trong danh sach nhac', () {
    final p=Listing(title:'Nha A');
    expect(attentionFor(p,DateTime(2026,10,16)),isNotNull);
    expect(attentionFor(p,DateTime(2026,10,16))!.priority,0);
  });
  test('Da ky va dang chao ban on dinh khong nhac', () {
    final p=Listing(title:'Nha B',contractStatus:'Đã ký',saleStatus:'Đang chào bán');
    expect(attentionFor(p,DateTime(2026,10,16)),isNull);
  });
  test('Da ky nhung co bien dong phai nhac', () {
    final p=Listing(title:'Nha C',contractStatus:'Đã ký',marketingNeedsAttention:true);
    expect(attentionFor(p,DateTime(2026,10,16)),isNotNull);
    applyFeedback(p,'Đã xử lý biến động chào bán','Đã chỉnh sửa giá');
    expect(attentionFor(p,DateTime.now()),isNull);
  });
  test('Phan hoi da ky tu dong ngat nhac va co nhat ky', () {
    final p=Listing(title:'Nha D',contactStatus:'Đã liên hệ');
    applyFeedback(p,'Đã ký hợp đồng môi giới','Đã ký tại văn phòng');
    expect(p.contractStatus,'Đã ký');
    expect(p.logs.first.action,'Đã ký hợp đồng môi giới');
    expect(attentionFor(p,DateTime.now()),isNull);
  });
  test('Chua ky nhung hen tuong lai van hien trong danh sach theo doi', () {
    final p=Listing(title:'Nha E',contactStatus:'Đã liên hệ',nextAction:'Gọi lại',nextDue:DateTime(2026,11,5));
    final a=attentionFor(p,DateTime(2026,10,16));
    expect(a,isNotNull); expect(a!.reason,contains('Theo dõi'));
  });
  test('V2 old photo path survives migration to imagePaths', () {
    final old=Listing.fromJson({'title':'Old listing','imagePath':'/old/photo.jpg'});
    expect(old.imagePaths,['/old/photo.jpg']);
    final newFormat=Listing.fromJson(old.toJson());
    expect(newFormat.imagePaths.length,1);
    newFormat.imagePaths.add('/new/photo2.jpg');
    final copy=Listing.fromJson(newFormat.toJson());
    expect(copy.imagePaths.length,2);
    expect(copy.imagePath,'/old/photo.jpg');
  });
  test('Unverified list excludes only evidenced owner checks', () {
    final p=Listing(verification:'Đã trao đổi, chưa đối chiếu');
    expect(needsOwnerVerification(p),isTrue);
    p.verification='Đã đối chiếu hồ sơ';
    expect(needsOwnerVerification(p),isFalse);
  });
  test('OCR labels propose editable field values', () {
    final parsed=parseIntake('Nhà mặt tiền đường 13\nĐịa chỉ: 123 đường 13, Thủ Đức\nDiện tích: 120 m2\nGiá: 12,5 tỷ\nChủ nhà: Anh Minh\nSĐT: 0901234567');
    expect(parsed.address,'123 đường 13, Thủ Đức');
    expect(parsed.area,'120 m²');
    expect(parsed.price,contains('12,5 tỷ'));
    expect(parsed.phone,'0901234567');
    expect(parsed.owner,'Anh Minh');
    expect(parsed.type,'Nhà mặt tiền');
  });
  test('Chup hinh hoac giong noi chi goi y, khong auto xac minh chu', () {
    final p=Listing(title:'Dat F');
    final input=parseIntake('Đất đường số 9\nDiện tích 120 m2 giá 9 tỷ\nLiên hệ 0901234567');
    expect(input.area,'120 m²');expect(input.price,'9 tỷ');expect(input.phone,'0901234567');
    expect(p.verification,'Chưa xác minh');
  });
}

