import 'dart:math';

String newId() => '${DateTime.now().microsecondsSinceEpoch}-${Random().nextInt(999999)}';

String dateLabel(DateTime? d) => d == null ? 'Chưa đặt' : '${d.day.toString().padLeft(2,'0')}/${d.month.toString().padLeft(2,'0')}/${d.year}';

class WorkLog {
  final String id;
  final DateTime at;
  final String action;
  final String note;

  const WorkLog({required this.id, required this.at, required this.action, required this.note});
  Map<String, dynamic> toJson() => {'id': id, 'at': at.toIso8601String(), 'action': action, 'note': note};
  factory WorkLog.fromJson(Map<String, dynamic> x) => WorkLog(
    id: '${x['id'] ?? newId()}',
    at: DateTime.tryParse('${x['at']}') ?? DateTime.now(),
    action: '${x['action'] ?? ''}', note: '${x['note'] ?? ''}',
  );
}


class MarketingPost {
  final String channel, url, status;
  final DateTime added;
  MarketingPost({required this.channel, this.url='', this.status='Đang đăng',DateTime? added}):added=added??DateTime.now();
  Map<String,dynamic> toJson()=>{'channel':channel,'url':url,'status':status,'added':added.toIso8601String()};
  factory MarketingPost.fromJson(Map<String,dynamic> x)=>MarketingPost(channel:'${x['channel']??''}',
    url:'${x['url']??''}',status:'${x['status']??'Đang đăng'}',added:DateTime.tryParse('${x['added']}'));
}
class BuyerOffer {
  final String buyer,contact,offer,note;
  final DateTime added;
  BuyerOffer({required this.buyer,this.contact='',this.offer='',this.note='',DateTime? added}):added=added??DateTime.now();
  Map<String,dynamic> toJson()=>{'buyer':buyer,'contact':contact,'offer':offer,'note':note,'added':added.toIso8601String()};
  factory BuyerOffer.fromJson(Map<String,dynamic> x)=>BuyerOffer(buyer:'${x['buyer']??''}',
    contact:'${x['contact']??''}',offer:'${x['offer']??''}',note:'${x['note']??''}',added:DateTime.tryParse('${x['added']}'));
}

class Listing {
  final String id;
  DateTime createdAt;
  DateTime updatedAt;
  String title;
  String type;
  String address;
  String area;
  String width;
  String length;
  String price;
  String source;
  String sourceUrl;
  String owner;
  String phone;
  String verification;
  String verificationEvidence;
  String contactStatus;
  String contractStatus;
  String saleStatus;
  String contractNumber;
  String contractFee;
  bool exclusive;
  DateTime? contractExpires;
  List<MarketingPost> posts;
  List<BuyerOffer> offers;
  String nextAction;
  DateTime? nextDue;
  bool marketingNeedsAttention;
  bool archived;
  String rawCapture;
  String imagePath; // Legacy: kept for V2 compatibility
  List<String> imagePaths;
  List<WorkLog> logs;

  Listing({
    String? id, DateTime? createdAt, DateTime? updatedAt,
    this.title='', this.type='Nhà riêng', this.address='', this.area='',
    this.width='', this.length='', this.price='',
    this.source='Khảo sát thực tế', this.sourceUrl='', this.owner='', this.phone='',
    this.verification='Chưa xác minh', this.verificationEvidence='',
    this.contactStatus='Chưa liên hệ', this.contractStatus='Chưa ký',
    this.saleStatus='Chưa chào bán', this.contractNumber='', this.contractFee='',
    this.exclusive=false, this.contractExpires, List<MarketingPost>? posts, List<BuyerOffer>? offers,
    this.nextAction='', this.nextDue,
    this.marketingNeedsAttention=false, this.archived=false,
    this.rawCapture='', this.imagePath='', List<String>? imagePaths, List<WorkLog>? logs,
  }) : id = id ?? newId(), createdAt = createdAt ?? DateTime.now(),
       updatedAt = updatedAt ?? DateTime.now(), logs = logs ?? [], posts=posts??[],offers=offers??[],
       imagePaths = imagePaths ?? (imagePath.isEmpty ? [] : [imagePath]);

  void addLog(String action, String note) {
    logs.insert(0, WorkLog(id: newId(), at: DateTime.now(), action: action, note: note));
    updatedAt = DateTime.now();
  }

  Map<String, dynamic> toJson() => {
    'id':id,'createdAt':createdAt.toIso8601String(),'updatedAt':updatedAt.toIso8601String(),
    'title':title,'type':type,'address':address,'area':area,'width':width,'length':length,'price':price,
    'source':source,'sourceUrl':sourceUrl,'owner':owner,'phone':phone,
    'verification':verification,'verificationEvidence':verificationEvidence,
    'contactStatus':contactStatus,'contractStatus':contractStatus,'saleStatus':saleStatus,
    'contractNumber':contractNumber,'contractFee':contractFee,'exclusive':exclusive,
    'contractExpires':contractExpires?.toIso8601String(),
    'posts':posts.map((e)=>e.toJson()).toList(),'offers':offers.map((e)=>e.toJson()).toList(),
    'nextAction':nextAction,'nextDue':nextDue?.toIso8601String(),
    'marketingNeedsAttention':marketingNeedsAttention,'archived':archived,
    'rawCapture':rawCapture,'imagePath':imagePaths.isNotEmpty?imagePaths.first:imagePath,
    'imagePaths':imagePaths,
    'logs':logs.map((e)=>e.toJson()).toList(),
  };

  factory Listing.fromJson(Map<String,dynamic> x) {
    String s(String key, String fallback) => (x[key] ?? fallback).toString();
    return Listing(
      id:s('id',newId()),
      createdAt:DateTime.tryParse(s('createdAt','')),
      updatedAt:DateTime.tryParse(s('updatedAt','')),
      title:s('title',''),type:s('type','Nhà riêng'),address:s('address',''),
      area:s('area',''),width:s('width',''),length:s('length',''),
      price:s('price',''),source:s('source','Khảo sát thực tế'),
      sourceUrl:s('sourceUrl',''),owner:s('owner',''),phone:s('phone',''),
      verification:s('verification','Chưa xác minh'),
      verificationEvidence:s('verificationEvidence',''),
      contactStatus:s('contactStatus','Chưa liên hệ'),
      contractStatus:s('contractStatus','Chưa ký'), saleStatus:s('saleStatus','Chưa chào bán'),
      contractNumber:s('contractNumber',''),contractFee:s('contractFee',''),
      exclusive:x['exclusive']==true,contractExpires:DateTime.tryParse(s('contractExpires','')),
      posts:(x['posts'] is List? x['posts'] as List:[]).whereType<Map>().map((e)=>MarketingPost.fromJson(Map<String,dynamic>.from(e))).toList(),
      offers:(x['offers'] is List? x['offers'] as List:[]).whereType<Map>().map((e)=>BuyerOffer.fromJson(Map<String,dynamic>.from(e))).toList(),
      nextAction:s('nextAction',''), nextDue:DateTime.tryParse(s('nextDue','')),
      marketingNeedsAttention:x['marketingNeedsAttention'] == true,
      archived:x['archived'] == true,
      rawCapture:s('rawCapture',''),imagePath:s('imagePath',''),
      imagePaths:x['imagePaths'] is List ? (x['imagePaths'] as List).whereType<String>().where((v)=>v.trim().isNotEmpty).toList() : null,
      logs:(x['logs'] is List ? x['logs'] as List : []).whereType<Map>().map((e)=>WorkLog.fromJson(Map<String,dynamic>.from(e))).toList(),
    );
  }
}

class Attention {
  final Listing listing;
  final String reason;
  final int priority;
  const Attention(this.listing,this.reason,this.priority);
}

/// Quét tất cả hồ sơ mỗi khi tải dữ liệu hoặc thay đổi một nguồn hàng.
/// Không nhắc trường hợp đã ký và chào bán ổn định; chưa ký luôn hiển thị,
/// kể cả khi lịch gọi lại là ngày tương lai (nhãn "theo dõi" không giả là quá hạn).
Attention? attentionFor(Listing p, DateTime now) {
  if (p.archived || p.saleStatus == 'Đã giao dịch') return null;
  if (p.contractStatus == 'Đã ký') {
    if (!p.marketingNeedsAttention) return null;
    return Attention(p,p.nextAction.isNotEmpty?p.nextAction:'Xử lý biến động chào bán',1);
  }
  if (p.contactStatus == 'Chưa liên hệ') return Attention(p,'Chưa liên hệ chủ – cần gọi xác minh',0);
  if (p.nextDue != null && p.nextDue!.isBefore(DateTime(now.year,now.month,now.day))) {
    return Attention(p,p.nextAction.isEmpty?'Công việc quá hạn':p.nextAction,0);
  }
  if (p.nextAction.isEmpty) return Attention(p,'Chưa ký hợp đồng – cần xác định bước tiếp theo',2);
  final future = p.nextDue != null && p.nextDue!.isAfter(DateTime(now.year,now.month,now.day,23,59,59));
  return Attention(p, future?'Theo dõi: ${p.nextAction} (${dateLabel(p.nextDue)})':p.nextAction,future?3:1);
}

List<Attention> attentionForAll(Iterable<Listing> items, DateTime now) {
  final list = items.map((x)=>attentionFor(x,now)).whereType<Attention>().toList();
  list.sort((a,b){final c=a.priority.compareTo(b.priority); return c != 0 ? c : b.listing.updatedAt.compareTo(a.listing.updatedAt);});
  return list;
}

class ParsedIntake {
  final String title, address, area, width, length, price, phone, owner, type, sourceUrl;
  const ParsedIntake({this.title='',this.address='',this.area='',this.width='',this.length='',this.price='',
    this.phone='',this.owner='',this.type='',this.sourceUrl=''});
}

// Chuan hoa to hop dau Unicode cua OCR/giọng nói (NFD -> NFC), giu nguyen noi dung.
// Khong "doan" dau hay tu ngu khi may OCR da doc sai tu goc.
const Map<String,String> _vietnameseComposition = {
  // R2_CI_OCR_FIX: support both ordering variants of combining tone marks.
  'Ậ': 'Ậ',
  'Ặ': 'Ặ',
  'Ệ': 'Ệ',
  'Ḝ': 'Ḝ',
  'Ờ': 'Ờ',
  'Ớ': 'Ớ',
  'Ộ': 'Ộ',
  'Ỡ': 'Ỡ',
  'Ǭ': 'Ǭ',
  'Ở': 'Ở',
  'Ợ': 'Ợ',
  'Ừ': 'Ừ',
  'Ứ': 'Ứ',
  'Ữ': 'Ữ',
  'Ử': 'Ử',
  'Ự': 'Ự',
  'ậ': 'ậ',
  'ặ': 'ặ',
  'ệ': 'ệ',
  'ḝ': 'ḝ',
  'ờ': 'ờ',
  'ớ': 'ớ',
  'ộ': 'ộ',
  'ỡ': 'ỡ',
  'ǭ': 'ǭ',
  'ở': 'ở',
  'ợ': 'ợ',
  'ừ': 'ừ',
  'ứ': 'ứ',
  'ữ': 'ữ',
  'ử': 'ử',
  'ự': 'ự',
  'Ầ': 'Ầ',
  'Ấ': 'Ấ',
  'Ẫ': 'Ẫ',
  'Ẩ': 'Ẩ',
  'Ằ': 'Ằ',
  'Ắ': 'Ắ',
  'Ẵ': 'Ẵ',
  'Ẳ': 'Ẳ',
  'Ǡ': 'Ǡ',
  'Ǟ': 'Ǟ',
  'Ǻ': 'Ǻ',
  'Ậ': 'Ậ',
  'Ặ': 'Ặ',
  'Ề': 'Ề',
  'Ế': 'Ế',
  'Ễ': 'Ễ',
  'Ể': 'Ể',
  'Ḕ': 'Ḕ',
  'Ḗ': 'Ḗ',
  'Ệ': 'Ệ',
  'Ḝ': 'Ḝ',
  'Ḯ': 'Ḯ',
  'Ồ': 'Ồ',
  'Ố': 'Ố',
  'Ỗ': 'Ỗ',
  'Ổ': 'Ổ',
  'Ṍ': 'Ṍ',
  'Ȭ': 'Ȭ',
  'Ṏ': 'Ṏ',
  'Ṑ': 'Ṑ',
  'Ṓ': 'Ṓ',
  'Ȱ': 'Ȱ',
  'Ȫ': 'Ȫ',
  'Ờ': 'Ờ',
  'Ớ': 'Ớ',
  'Ỡ': 'Ỡ',
  'Ở': 'Ở',
  'Ợ': 'Ợ',
  'Ộ': 'Ộ',
  'Ǭ': 'Ǭ',
  'Ṹ': 'Ṹ',
  'Ṻ': 'Ṻ',
  'Ǜ': 'Ǜ',
  'Ǘ': 'Ǘ',
  'Ǖ': 'Ǖ',
  'Ǚ': 'Ǚ',
  'Ừ': 'Ừ',
  'Ứ': 'Ứ',
  'Ữ': 'Ữ',
  'Ử': 'Ử',
  'Ự': 'Ự',
  'ầ': 'ầ',
  'ấ': 'ấ',
  'ẫ': 'ẫ',
  'ẩ': 'ẩ',
  'ằ': 'ằ',
  'ắ': 'ắ',
  'ẵ': 'ẵ',
  'ẳ': 'ẳ',
  'ǡ': 'ǡ',
  'ǟ': 'ǟ',
  'ǻ': 'ǻ',
  'ậ': 'ậ',
  'ặ': 'ặ',
  'ề': 'ề',
  'ế': 'ế',
  'ễ': 'ễ',
  'ể': 'ể',
  'ḕ': 'ḕ',
  'ḗ': 'ḗ',
  'ệ': 'ệ',
  'ḝ': 'ḝ',
  'ḯ': 'ḯ',
  'ồ': 'ồ',
  'ố': 'ố',
  'ỗ': 'ỗ',
  'ổ': 'ổ',
  'ṍ': 'ṍ',
  'ȭ': 'ȭ',
  'ṏ': 'ṏ',
  'ṑ': 'ṑ',
  'ṓ': 'ṓ',
  'ȱ': 'ȱ',
  'ȫ': 'ȫ',
  'ờ': 'ờ',
  'ớ': 'ớ',
  'ỡ': 'ỡ',
  'ở': 'ở',
  'ợ': 'ợ',
  'ộ': 'ộ',
  'ǭ': 'ǭ',
  'ṹ': 'ṹ',
  'ṻ': 'ṻ',
  'ǜ': 'ǜ',
  'ǘ': 'ǘ',
  'ǖ': 'ǖ',
  'ǚ': 'ǚ',
  'ừ': 'ừ',
  'ứ': 'ứ',
  'ữ': 'ữ',
  'ử': 'ử',
  'ự': 'ự',
  'À': 'À',
  'Á': 'Á',
  'Â': 'Â',
  'Ã': 'Ã',
  'Ā': 'Ā',
  'Ă': 'Ă',
  'Ȧ': 'Ȧ',
  'Ä': 'Ä',
  'Ả': 'Ả',
  'Å': 'Å',
  'Ǎ': 'Ǎ',
  'Ȁ': 'Ȁ',
  'Ȃ': 'Ȃ',
  'Ạ': 'Ạ',
  'Ḁ': 'Ḁ',
  'Ą': 'Ą',
  'È': 'È',
  'É': 'É',
  'Ê': 'Ê',
  'Ẽ': 'Ẽ',
  'Ē': 'Ē',
  'Ĕ': 'Ĕ',
  'Ė': 'Ė',
  'Ë': 'Ë',
  'Ẻ': 'Ẻ',
  'Ě': 'Ě',
  'Ȅ': 'Ȅ',
  'Ȇ': 'Ȇ',
  'Ẹ': 'Ẹ',
  'Ȩ': 'Ȩ',
  'Ę': 'Ę',
  'Ḙ': 'Ḙ',
  'Ḛ': 'Ḛ',
  'Ì': 'Ì',
  'Í': 'Í',
  'Î': 'Î',
  'Ĩ': 'Ĩ',
  'Ī': 'Ī',
  'Ĭ': 'Ĭ',
  'İ': 'İ',
  'Ï': 'Ï',
  'Ỉ': 'Ỉ',
  'Ǐ': 'Ǐ',
  'Ȉ': 'Ȉ',
  'Ȋ': 'Ȋ',
  'Ị': 'Ị',
  'Į': 'Į',
  'Ḭ': 'Ḭ',
  'Ò': 'Ò',
  'Ó': 'Ó',
  'Ô': 'Ô',
  'Õ': 'Õ',
  'Ō': 'Ō',
  'Ŏ': 'Ŏ',
  'Ȯ': 'Ȯ',
  'Ö': 'Ö',
  'Ỏ': 'Ỏ',
  'Ő': 'Ő',
  'Ǒ': 'Ǒ',
  'Ȍ': 'Ȍ',
  'Ȏ': 'Ȏ',
  'Ơ': 'Ơ',
  'Ọ': 'Ọ',
  'Ǫ': 'Ǫ',
  'Ù': 'Ù',
  'Ú': 'Ú',
  'Û': 'Û',
  'Ũ': 'Ũ',
  'Ū': 'Ū',
  'Ŭ': 'Ŭ',
  'Ü': 'Ü',
  'Ủ': 'Ủ',
  'Ů': 'Ů',
  'Ű': 'Ű',
  'Ǔ': 'Ǔ',
  'Ȕ': 'Ȕ',
  'Ȗ': 'Ȗ',
  'Ư': 'Ư',
  'Ụ': 'Ụ',
  'Ṳ': 'Ṳ',
  'Ų': 'Ų',
  'Ṷ': 'Ṷ',
  'Ṵ': 'Ṵ',
  'Ỳ': 'Ỳ',
  'Ý': 'Ý',
  'Ŷ': 'Ŷ',
  'Ỹ': 'Ỹ',
  'Ȳ': 'Ȳ',
  'Ẏ': 'Ẏ',
  'Ÿ': 'Ÿ',
  'Ỷ': 'Ỷ',
  'Ỵ': 'Ỵ',
  'à': 'à',
  'á': 'á',
  'â': 'â',
  'ã': 'ã',
  'ā': 'ā',
  'ă': 'ă',
  'ȧ': 'ȧ',
  'ä': 'ä',
  'ả': 'ả',
  'å': 'å',
  'ǎ': 'ǎ',
  'ȁ': 'ȁ',
  'ȃ': 'ȃ',
  'ạ': 'ạ',
  'ḁ': 'ḁ',
  'ą': 'ą',
  'è': 'è',
  'é': 'é',
  'ê': 'ê',
  'ẽ': 'ẽ',
  'ē': 'ē',
  'ĕ': 'ĕ',
  'ė': 'ė',
  'ë': 'ë',
  'ẻ': 'ẻ',
  'ě': 'ě',
  'ȅ': 'ȅ',
  'ȇ': 'ȇ',
  'ẹ': 'ẹ',
  'ȩ': 'ȩ',
  'ę': 'ę',
  'ḙ': 'ḙ',
  'ḛ': 'ḛ',
  'ì': 'ì',
  'í': 'í',
  'î': 'î',
  'ĩ': 'ĩ',
  'ī': 'ī',
  'ĭ': 'ĭ',
  'ï': 'ï',
  'ỉ': 'ỉ',
  'ǐ': 'ǐ',
  'ȉ': 'ȉ',
  'ȋ': 'ȋ',
  'ị': 'ị',
  'į': 'į',
  'ḭ': 'ḭ',
  'ò': 'ò',
  'ó': 'ó',
  'ô': 'ô',
  'õ': 'õ',
  'ō': 'ō',
  'ŏ': 'ŏ',
  'ȯ': 'ȯ',
  'ö': 'ö',
  'ỏ': 'ỏ',
  'ő': 'ő',
  'ǒ': 'ǒ',
  'ȍ': 'ȍ',
  'ȏ': 'ȏ',
  'ơ': 'ơ',
  'ọ': 'ọ',
  'ǫ': 'ǫ',
  'ù': 'ù',
  'ú': 'ú',
  'û': 'û',
  'ũ': 'ũ',
  'ū': 'ū',
  'ŭ': 'ŭ',
  'ü': 'ü',
  'ủ': 'ủ',
  'ů': 'ů',
  'ű': 'ű',
  'ǔ': 'ǔ',
  'ȕ': 'ȕ',
  'ȗ': 'ȗ',
  'ư': 'ư',
  'ụ': 'ụ',
  'ṳ': 'ṳ',
  'ų': 'ų',
  'ṷ': 'ṷ',
  'ṵ': 'ṵ',
  'ỳ': 'ỳ',
  'ý': 'ý',
  'ŷ': 'ŷ',
  'ȳ': 'ȳ',
  'ẏ': 'ẏ',
  'ÿ': 'ÿ',
  'ỷ': 'ỷ',
  'ẙ': 'ẙ',
  'ỵ': 'ỵ',
};

String normalizeVietnameseUnicode(String input) {
  var output = input;
  for(final entry in _vietnameseComposition.entries) {
    output=output.replaceAll(entry.key,entry.value);
  }
  return output;
}

/// OCR van phai quet anh de tim vi tri chu. Tuy nhien ta chi GIU va TRICH
/// nhung dong co dau hieu nhan biet truong + dong gia tri gan lien neu can.
/// Anh quang cao, cam ket, footer, mo ta khong lien quan se bi bo qua.
String selectRelevantOcrLines(Iterable<String> recognizedLines) {
  final lines = recognizedLines.map((s)=>normalizeVietnameseUnicode(s).trim())
      .where((s)=>s.isNotEmpty).toList();
  final selected=<String>[];
  final fieldLabel=RegExp(
    r'(?:^|\b)(?:dia chi|dia diem|vi tri|so nha|so thua|duong|hem|'
    r'dien tich|dtcn|dt dat|dt\b|ngang|chieu ngang|rong|chieu rong|'
    r'chieu dai|dai|chieu sau|sau|kich thuoc|\bkt\b|mat tien|'
    r'gia ban|gia chao|gia|don gia|'
    r'so dien thoai|dien thoai|\bsdt\b|lien he|chu nha|chu dat|'
    r'ten chu|nguoi ban|nguoi lien he|nguon tin|link tin|url|http)',
    caseSensitive:false);
  final header=RegExp(r'\b(?:ban nha|ban dat|can ban nha|can ban dat|nha xuong|can ho|chung cu)\b');
  final hasValue=RegExp(r'[0-9]|m²|m2|met|ty|trieu|duong|phuong|hem|quan|\b(?:anh|chi|ong|ba)\b');
  for(var i=0;i<lines.length;i++) {
    final line=lines[i];
    final folded=_foldVi(line);
    final isLabel=fieldLabel.hasMatch(folded);
    final isTitle=i==0 && header.hasMatch(folded);
    // Do not treat promotional calls to action as a field just because they
    // contain "lien he"; a real contact field must have a value or bare label.
    final bareLabel=RegExp(
      r'^(?:dia chi|dia diem|vi tri|so nha|so thua|duong|hem|'
      r'dien tich|dtcn|dt dat|dt|ngang|chieu ngang|rong|chieu rong|'
      r'chieu dai|dai|chieu sau|sau|kich thuoc|kt|mat tien|'
      r'gia ban|gia chao|gia|don gia|so dien thoai|dien thoai|sdt|'
      r'lien he|chu nha|chu dat|ten chu|nguoi ban|nguoi lien he|'
      r'nguon tin|link tin|url)\s*$', caseSensitive:false).hasMatch(folded);
    final labelNeedsNext=bareLabel || RegExp(r'[:=-]\s*$').hasMatch(line);
    if(!isLabel&&!isTitle)continue;
    if(folded.startsWith('lien he ngay') && !RegExp(r'\d').hasMatch(folded))continue;
    // Chan doan van ban dai co nhieu noi dung khong lien quan.
    final cropped=line.length>220?line.substring(0,220):line;
    selected.add(cropped);
    // OCR tach nhan ("Ngang") va gia tri ("5m") ra hai dong.
    if(isLabel && i+1<lines.length) {
      final next=lines[i+1];
      final foldedNext=_foldVi(next);
      if(next.length<=100 && !fieldLabel.hasMatch(foldedNext)
          && hasValue.hasMatch(foldedNext)
          && labelNeedsNext) {
        selected.add(next);
        i++;
      }
    }
  }
  return selected.join('\n');
}


/// Giữ NGUYÊN TOÀN BỘ văn bản OCR để đối chiếu sau khi tự điền.
/// Không chặn dòng chỉ có số (nang/dai/điện thoại/giá).
String retainAllOcrLines(Iterable<String> lines) => lines
    .map((s)=>normalizeVietnameseUnicode(s).trim())
    .where((s)=>s.isNotEmpty).join('\n');

/// Văn bản dùng để GỢI Ý các trường, tách riêng khỏi bản OCR gốc.
/// Chỉ bỏ các nút điều khiển UI đã biết, không bỏ dòng số hoặc nhãn rời.
String ocrFieldsText(Iterable<String> lines) {
  const uiOnly={
    'Tạo người liên hệ mới','Thêm vào một người liên hệ',
    'Chọn ảnh','Mở ảnh','Đóng','Lưu','Chia sẻ','Xem thêm','Đăng nhập',
    'Thêm liên hệ','Sao chép','Báo cáo','Tất cả','Gửi','Bỏ qua',
  };
  String fixFieldLabels(String value){
    var s=normalizeVietnameseUnicode(value).trim();
    // Only a tiny whitelist of real-estate FIELD LABELS may be corrected.
    // Never auto-correct names, addresses or arbitrary descriptive content.
    const labels=<String,String>{
      'dien tich':'Diện tích','dien tích':'Diện tích',
      'điện tích':'Diện tích','chiêu ngang':'Chiều ngang',
      'chiêu dai':'Chiều dài','nganq':'Ngang',
      'sô điện thoại':'Số điện thoại',
      'số điện thoai':'Số điện thoại',
      'điện thoai':'Điện thoại','gia ban':'Giá bán',
    };
    for(final entry in labels.entries){
      if(s.toLowerCase().startsWith(entry.key)){
        s=entry.value+s.substring(entry.key.length);
        break;
      }
    }
    // OCR sometimes confuses O and zero inside a labeled phone number.
    if(RegExp(r'^(?:sđt|số điện thoại|điện thoại|liên hệ|zalo)\b',
      caseSensitive:false).hasMatch(s)){
      s=s.replaceAllMapped(RegExp(r'[O0](?:[0-9O .-]{8,16})',caseSensitive:false),
        (m)=>m.group(0)!.replaceAll('O','0').replaceAll('o','0'));
    }
    return s;
  }
  final kept=lines.map(fixFieldLabels)
    .where((x)=>x.isNotEmpty && !uiOnly.contains(x)).toList();
  return kept.join('\n');
}

/// Chuẩn hóa những cách nói phổ biến, không tự suy đoán tên đường/chủ.
String normalizeVoiceTranscript(String s) {
  var value=normalizeVietnameseUnicode(s).replaceAll(RegExp(r'\s+'),' ').trim();
  const glossary={
    'dien tich':'diện tích', 'chieu ngang':'chiều ngang',
    'chieu rong':'chiều rộng', 'chieu dai':'chiều dài',
    'chieu sau':'chiều sâu', 'mat tien':'mặt tiền',
    'met vuong':'mét vuông', 'so dien thoai':'số điện thoại',
    'gia ban':'giá bán', 'phap ly':'pháp lý', 'so hong':'sổ hồng',
  };
  for(final item in glossary.entries){
    value=value.replaceAll(RegExp('\\b${item.key}\\b',caseSensitive:false),item.value);
  }
  return value;
}

/// Phân tích văn bản OCR hoặc giọng nói tiếng Việt thành GỢI Ý có thể sửa.
/// Không kết luận chính chủ; không tự đoán các thông tin không xuất hiện trong chữ/giọng nói.
String _foldVi(String text) {
  var s=normalizeVietnameseUnicode(text).toLowerCase();
  const families={
    'a':'àáạảãâầấậẩẫăằắặẳẵ',
    'e':'èéẹẻẽêềếệểễ',
    'i':'ìíịỉĩ',
    'o':'òóọỏõôồốộổỗơờớợởỡ',
    'u':'ùúụủũưừứựửữ',
    'y':'ỳýỵỷỹ',
    'd':'đ',
  };
  for (final entry in families.entries) {
    for (final char in entry.value.split('')) {
      s=s.replaceAll(char,entry.key);
    }
  }
  return s;
}

String _tidyVi(String s) => s.replaceAll(RegExp(r'\s+'),' ').trim()
    .replaceAll(RegExp(r'^[\s:;,\.\-–]+|[\s:;,\.\-–]+$'),'');

/// Giữ nguyên nội dung nguồn, nhưng dò nhãn theo bản không dấu, giúp xử lý
/// tiếng Việt thiếu dấu do OCR và các câu nói không có dấu câu.
String _afterLabel(String original, List<String> labels,
    {int maxLength=125, List<String> stopExtra=const []}) {
  final flat=_tidyVi(original);
  final normalized=_foldVi(flat);
  final labelRe=RegExp('(?:^|\\s)(?:${labels.join('|')})(?:\\s+(?:la|o|tai|co|khoang))?\\s*[:=–-]?\\s*',caseSensitive:false);
  final match=labelRe.firstMatch(normalized);
  if(match==null)return '';
  final start=match.end;
  if(start>=flat.length)return '';
  var end=(start+maxLength).clamp(start,flat.length).toInt();
  final remaining=normalized.substring(start,end);
  final stops=<String>[
    'dia chi', 'vi tri', 'dien tich', 'dt ', 'gia ban', 'gia chao',
    'gia ', 'ban gia', 'sdt', 'so dien thoai', 'dien thoai',
    'lien he', 'ngang', 'chieu ngang', 'dai', 'chieu dai', 'chieu rong',
    'rong', 'kich thuoc', 'nguoi ban', 'chu nha', 'chu dat', 'chu so huu',
    'chu la', 'ten chu', 'chinh chu', 'so hong', 'phap ly', 'mo ta',
    'nhan tin', 'hoa hong', 'ket cau', ...stopExtra
  ];
  for (final stop in stops) {
    final escaped=RegExp.escape(stop.trim());
    final cut=RegExp('(?:\\s|[,;])(?:$escaped)(?:\\s|[:=-]|\$)',caseSensitive:false).firstMatch(remaining);
    if(cut!=null && cut.start>0 && start+cut.start<end)end=start+cut.start;
  }
  final newline=flat.substring(start,end).indexOf('\n');
  if(newline>=0)end=start+newline;
  return _tidyVi(flat.substring(start,end));
}

const _numWords=<String,int>{
  'khong':0,'mot':1,'hai':2,'ba':3,'bon':4,'tu':4,
  'nam':5,'lam':5,'sau':6,'bay':7,'tam':8,'chin':9,
};

/// Hỗ trợ cách đọc "sáu mươi", "hai trăm năm mươi" từ voice.
int? _viNumber(String phrase) {
  final v=_foldVi(phrase).trim();
  if(RegExp(r'^\d+$').hasMatch(v))return int.tryParse(v);
  final tokens=v.split(RegExp(r'\s+'));
  if(tokens.isEmpty || tokens.length>14)return null;
  var current=0,total=0;
  var seen=false;
  for(final w in tokens){
    if(_numWords.containsKey(w)){current+=_numWords[w]!;seen=true;}
    else if(w=='muoi') {current=(current==0?1:current)*10;seen=true;}
    else if(w=='tram') {current=(current==0?1:current)*100;seen=true;}
    else if(w=='nghin'||w=='ngan') {total+=(current==0?1:current)*1000;current=0;seen=true;}
    else if(w=='linh'||w=='le') {continue;}
    else return null;
  }
  return seen?total+current:null;
}

/// Tìm số hoặc cụm số được đọc ngay trước một đơn vị, thay vì cần nhãn cứng.
String _quantityBeforeUnit(String flat,String folded,RegExp unit,{int maxTokens=10}) {
  for(final match in unit.allMatches(folded)){
    final prefix=folded.substring(0,match.start);
    final words=RegExp(r'[a-z0-9.,]+').allMatches(prefix).map((m)=>m.group(0)!).toList();
    final candidates=<String>[];
    for(final w in words.reversed.take(maxTokens)){
      final clean=w.replaceAll(RegExp(r'[.,]$'),'');
      if(RegExp(r'^\d+(?:[.,]\d+)?$').hasMatch(clean)||
          _numWords.containsKey(clean)||
          const ['muoi','tram','nghin','ngan','linh','le','phay'].contains(clean)) {
        candidates.insert(0,clean);
      }else{break;}
    }
    if(candidates.isEmpty)continue;
    final wordsAsString=candidates.join(' ');
    final n=double.tryParse(wordsAsString.replaceAll(',','.'));
    if(n!=null&&n>0)return n.toString().replaceAll(RegExp(r'\.0$'),'');
    final parsed=_viNumber(wordsAsString);
    if(parsed!=null&&parsed>0)return '$parsed';
    // Ví dụ "diện tích khoảng sáu mươi", nhưng OCR có thể thừa từ.
    for(var k=1;k<candidates.length;k++){
      final small=candidates.sublist(k).join(' ');
      final parsedSmall=_viNumber(small);
      if(parsedSmall!=null&&parsedSmall>0)return '$parsedSmall';
    }
  }
  return '';
}

/// Chỉ đọc kích thước được nêu rõ, không suy đoán ngang/dài từ diện tích.
class _Dimensions {
  final String width;
  final String length;
  const _Dimensions(this.width,this.length);
}

String _dimension(String? input) {
  if(input==null)return '';
  final normalized=input.trim().replaceAll(',', '.');
  final value=double.tryParse(normalized);
  if(value==null||value<0.5||value>1000)return '';
  final formatted=value==value.roundToDouble()?value.toInt().toString():
      value.toString().replaceAll('.', ',');
  return '$formatted m';
}

_Dimensions _findDimensions(String folded) {
  // Ignore amenities: "sân sau 2 m" is NOT plot depth.
  final source=folded.replaceAll(RegExp(
    r'\b(?:san sau|san truoc|duong vao|loi di)\s*(?:rong|dai)?\s*[:=]?\s*\d{1,4}(?:[.,]\d+)?\s*(?:m|met)\b'), ' ');
  // Ví dụ: "ngang 5m dài 20m", "rộng 5m, sâu 20m".
  final labeled=RegExp(
    r'(?:ngang|rong|mat tien|chieu ngang)\s*[:=]?\s*(\d{1,4}(?:[.,]\d+)?)\s*(?:m|met)?\b.{0,35}?(?:dai|sau|chieu dai|chieu sau)\s*[:=]?\s*(\d{1,4}(?:[.,]\d+)?)\s*(?:m|met)?\b')
    .firstMatch(source);
  if(labeled!=null)return _Dimensions(_dimension(labeled.group(1)),_dimension(labeled.group(2)));
  final reverse=RegExp(
    r'(?:dai|sau|chieu dai|chieu sau)\s*[:=]?\s*(\d{1,4}(?:[.,]\d+)?)\s*(?:m|met)?\b.{0,35}?(?:ngang|rong|mat tien|chieu ngang)\s*[:=]?\s*(\d{1,4}(?:[.,]\d+)?)\s*(?:m|met)?\b')
    .firstMatch(source);
  if(reverse!=null)return _Dimensions(_dimension(reverse.group(2)),_dimension(reverse.group(1)));
  // Ví dụ: "KT: 5x20", "kích thước 5 × 20 m", "5 m x 20 m".
  final pair=RegExp(
    r'(?:kich thuoc|kt|ngang|rong|dat|nha|dt)\s*[:=]?\s*(\d{1,4}(?:[.,]\d+)?)\s*(?:m|met)?\s*[x×*]\s*(\d{1,4}(?:[.,]\d+)?)\s*(?:m|met)?\b')
    .firstMatch(source);
  if(pair!=null)return _Dimensions(_dimension(pair.group(1)),_dimension(pair.group(2)));
  final unitPair=RegExp(r'\b(\d{1,4}(?:[.,]\d+)?)\s*m\s*[x×*]\s*(\d{1,4}(?:[.,]\d+)?)\s*m\b').firstMatch(source);
  if(unitPair!=null)return _Dimensions(_dimension(unitPair.group(1)),_dimension(unitPair.group(2)));
  // Không tự diễn giải "5x20" không có nhãn: có thể là số hiệu sản phẩm.
  // Có thể nhận từng trường nếu ảnh chỉ có "ngang 5m" mà không ghi chiều dài.
  final w=RegExp(r'(?:ngang|rong|mat tien|chieu ngang)\s*[:=]?\s*(\d{1,4}(?:[.,]\d+)?)\s*(?:m|met)?\b').firstMatch(source);
  final l=RegExp(r'(?:dai|sau|chieu dai|chieu sau)\s*[:=]?\s*(\d{1,4}(?:[.,]\d+)?)\s*(?:m|met)?\b').firstMatch(source);
  final wValue=_dimension(w?.group(1));
  final lValue=_dimension(l?.group(1));
  return _Dimensions(wValue.isNotEmpty?wValue:_spokenDimension(source,true),
    lValue.isNotEmpty?lValue:_spokenDimension(source,false));
}

String _spokenDimension(String folded,bool isWidth) {
  final prefix=isWidth?r'(?:ngang|chieu ngang|rong|chieu rong|mat tien)':
    r'(?:dai|chieu dai|sau|chieu sau)';
  const token=r'(?:khong|mot|hai|ba|bon|tu|nam|lam|sau|bay|tam|chin|muoi|tram|linh|le|phay|nghin|ngan)';
  final re=RegExp('$prefix\\s*(?:la|khoang)?\\s*[:=-]?\\s*($token(?:\\s+$token){0,9})\\s*(?:m|met)?\\b');
  final match=re.firstMatch(folded);
  if(match==null)return '';
  final phrase=match.group(1)!.trim();
  final parts=phrase.split(RegExp(r'\s+phay\s+'));
  double? n;
  if(parts.length==1) {
    n=_viNumber(parts.first)?.toDouble();
  }else if(parts.length==2){
    final major=_viNumber(parts.first), minor=_viNumber(parts.last);
    if(major!=null && minor!=null){
      final decimalDigits=minor.toString().length;
      n=major+minor/(decimalDigits==1?10:decimalDigits==2?100:1000);
    }
  }
  return n==null?'':_dimension(n.toString());
}

String _findArea(String flat,String folded) {
  // Dien tich co nhan moi la gia tri chinh; khong lay nham dien tich san,
  // phong, khoang cach trong ban tin quang cao.
  final labeled=RegExp(
    r'(?:dien tich(?: dat| cong nhan| su dung)?|\bdtcn\b|\bdt\b)\s*(?:la|khoang|:|=|-)*\s*(\d{1,6}(?:[.,]\d+)?)\s*(?:m\s*[²2]|met\s*vuong)?(?![a-z0-9]|\s*(?:m\s*)?[x×*])')
    .firstMatch(folded);
  if(labeled!=null){
    final qty=labeled.group(1)!;
    final val=double.tryParse(qty.replaceAll(',','.'));
    if(val!=null && val>0 && val<1000000) return '$qty m²';
  }
  // Legal-area shorthand: "10x17m (CN 145m²)". Use only when the
  // ad has no explicit area label, so dimensional frontage is not 10 m².
  final legal=RegExp(r'\b(?:cn|cong nhan)\s*[:=( ]*\s*(\d{1,6}(?:[.,]\d+)?)\s*m\s*[²2](?![a-z0-9])')
      .firstMatch(folded);
  if(legal!=null)return '${legal.group(1)} m²';
  final wordsLabel=RegExp(r'(?:dien tich(?: dat)?|\bdt\b)\s*(?:la|khoang|:|=|-)*\s*((?:(?:mot|hai|ba|bon|tu|nam|lam|sau|bay|tam|chin|muoi|tram|linh|le|nghin|ngan)\s*){1,12})\s+met\s*vuong')
      .firstMatch(folded);
  if(wordsLabel!=null){
    final n=_viNumber(wordsLabel.group(1)!.trim());
    if(n!=null && n>0)return '$n m²';
  }
  // Một ảnh quảng cáo có thể chỉ in "301 m²" cạnh giá và tiêu đề BÁN NHÀ.
  // Chỉ dùng giá trị diện tích đơn lẻ khi có ngữ cảnh tài sản rõ ràng.
  if (RegExp(r'(?:ban nha|ban dat|nha rieng|bat dong san|nha dat)').hasMatch(folded)) {
    final candidates=RegExp(r'(?<![\d/])(\d{1,5}(?:[.,]\d+)?)\s*m\s*[²2](?![a-z0-9])').allMatches(folded);
    for (final m in candidates) {
      final left=folded.substring((m.start-12).clamp(0,m.start),m.start);
      if(left.contains('trieu/')||left.contains('ty/'))continue;
      final amount=double.tryParse(m.group(1)!.replaceAll(',','.'));
      if(amount!=null&&amount>=5&&amount<=100000)return '${m.group(1)!} m²';
    }
  }
  // Voice co the noi "dien tich 60 met vuong"; neu khong co nhan,
  // KHONG lay so met vuong bat ky trong noi dung OCR.
  return '';
}

String _findPrice(String flat,String folded) {
  // Old asking/offer price is not the CURRENT price. E.g.
  // "Giá giảm 18 tỷ còn 14,9 tỷ" -> 14,9 tỷ, not 18 tỷ.
  final current=RegExp(
    r'\b(?:gia\s+(?:giam|cu|ban dau)|giam tu)\b.{0,50}\bcon\s*(\d{1,4}(?:[.,]\d+)?)\s*(ty|ti|trieu)\b')
    .firstMatch(folded);
  if(current!=null)return '${current.group(1)} ${current.group(2)=='trieu'?'triệu':'tỷ'}';
  final unit=RegExp(r'(?:ty|ti|trieu)(?!\w)');
  // Chi nhan so tien SAU nhan gia, tranh lay nham hoa hong/chi phi.
  final label=RegExp(r'(?:\bgia\b|gia ban|gia chao|ban gia|gia thuong luong)')
      .firstMatch(folded);
  if(label==null){
    // A real listing screenshot may show just "15,5 tỷ" beside the headline.
    // Only propose this when exactly one monetary candidate is present and
    // the surrounding OCR clearly describes a property for sale.
    if(!RegExp(r'(?:ban nha|ban dat|ban can|nha mat tien|nha dat)')
        .hasMatch(folded))return '';
    final possible=RegExp(r'(?<!\d)(\d{1,4}(?:[.,]\d+)?)\s*(ty|ti|trieu)\b')
        .allMatches(folded).where((m){
          final suffix=folded.substring(m.end);
          return !RegExp(r'^\s*/\s*m\s*[²2]').hasMatch(suffix);
        }).toList();
    if(possible.length==1){
      final number=possible.first.group(1)!;
      final unit=possible.first.group(2)=='trieu'?'triệu':'tỷ';
      return '$number $unit';
    }
    return '';
  }
  final matches=unit.allMatches(folded).where((m)=>m.start>=label.end).toList();
  if(matches.isEmpty)return '';
  for(var i=0;i<matches.length;i++){
    final m=matches[i];
    // Chỉ ưu tiên một đơn vị tiền có số đứng sát phía trước.
    final digits=_quantityBeforeUnit(flat,folded,RegExp('(?:${RegExp.escape(m.group(0)!)})'),maxTokens:8);
    if(digits.isEmpty)continue;
    // Tìm số ngay trước đúng occurrence, tránh lấy nhầm từ các giá khác.
    final left=folded.substring(0,m.start);
    final before=RegExp(r'(\d+(?:[.,]\d+)?|[a-z ]{3,45})\s*$').firstMatch(left)?.group(1)??'';
    final originalNum=_numberAtEnd(before);
    if(originalNum.isEmpty)continue;
    final kind=m.group(0)!='trieu'?'tỷ':'triệu';
    var amount='$originalNum $kind';
    if(kind=='tỷ'){
      final next=folded.substring(m.end);
      final extra=RegExp(r'^\s+(\d{1,3}|(?:[a-z]+\s*){1,5})\s+trieu\b').firstMatch(next);
      if(extra!=null){
        final extraNum=_numberAtEnd(extra.group(1)!);
        if(extraNum.isNotEmpty)amount+=' $extraNum triệu';
      }else{
        // Cách nói phổ biến: giá 5 tỷ 2 = 5,2 tỷ; giá 5 tỷ 200 = 5 tỷ 200 triệu.
        final suffix=RegExp(r'^\s+(\d{1,3})(?=\s|$)').firstMatch(next)?.group(1);
        final n=int.tryParse(suffix??'');
        if(n!=null&&n>=1&&n<=9){amount='$originalNum,$n tỷ';}
        else if(n!=null&&n>=10&&n<1000){amount+=' $n triệu';}
      }
    }
    return amount;
  }
  return '';
}

String _numberAtEnd(String phrase) {
  final clean=_tidyVi(_foldVi(phrase));
  final direct=RegExp(r'(\d+(?:[.,]\d+)?)$').firstMatch(clean)?.group(1);
  if(direct!=null)return direct;
  final words=clean.split(' ');
  for(var i=0;i<words.length;i++){
    final n=_viNumber(words.sublist(i).join(' '));
    if(n!=null&&n>0)return '$n';
  }
  return '';
}

String _findPhone(String text) {
  // Hỗ trợ OCR tách từng cụm 090 123 45 67, +84 901 234 567.
  final phoneRegex=RegExp(r'(?<![0-9])(?:\+84|0)(?:[\s.\-()]*\d){9,10}(?![0-9])');
  for(final m in phoneRegex.allMatches(text)){
    var phone=m.group(0)!.replaceAll(RegExp(r'[^0-9+]'),'');
    if(phone.startsWith('+84'))phone='0${phone.substring(3)}';
    if(phone.length==10&&phone.startsWith('0'))return phone;
  }
  // Số điện thoại được đọc thành chữ: "không chín không một hai ..."
  final label=_afterLabel(text,['so dien thoai','dien thoai','sdt','so lien he'],maxLength:85);
  if(label.isEmpty)return '';
  final tokens=_foldVi(label).split(RegExp(r'\s+'));
  final digits=<String>[];
  for(final t in tokens){
    if(_numWords.containsKey(t))digits.add('${_numWords[t]}');
    else if(RegExp(r'^\d+$').hasMatch(t))digits.add(t);
    else if(t=='la'||t=='so'||t=='cua')continue;
    else break;
  }
  final candidate=digits.join();
  return candidate.length==10&&candidate.startsWith('0')?candidate:'';
}

/// Address extraction must distinguish a STREET + ADMINISTRATIVE LOCATION
/// from promotional text such as "khu nhà ở biệt thự".  Web screenshots often
/// show a full street address without the "Địa chỉ" label; the old broad
/// "nha o"/"vi tri" heuristic incorrectly selected the property description.
///
/// Prefer explicitly labeled address fields, then complete unlabelled street
/// addresses, then weaker locality-only fields.  Never invent missing parts.
String _findAddress(String flat,String folded,{String? raw}) {
  final text=raw??flat;
  final lines=text.replaceAll('\r','\n').split('\n')
      .map(_tidyVi).where((x)=>x.isNotEmpty).toList();
  final addresses=<String,int>{};
  final road=RegExp(
      r'\b(?:duong|hem|ngo|ngach|quoc lo|tinh lo|xa lo)\s+(?:so\s+)?[a-z0-9]',
      caseSensitive:false);
  final ward=RegExp(r'\b(?:phuong|xa|thi tran|p\.)\s+[a-z0-9]',
      caseSensitive:false);
  final district=RegExp(r'\b(?:quan|huyen|thu duc|tp\.?|thanh pho)\b',
      caseSensitive:false);
  final cityEnd=RegExp(
      r'\b(?:tp\.?\s*(?:ho\s*chi\s*minh|hcm)|thanh\s*pho\s*ho\s*chi\s*minh|t\.?p\.?\s*hcm)\b',
      caseSensitive:false);
  final addressLabel=RegExp(
      r'^(?:dia chi(?: bat dong san| nha| dat)?|vi tri(?: bat dong san| nha| dat)?|dia diem|toa lac)(?:\s*[:：=–-]\s*|\s+)(.*)$',
      caseSensitive:false);
  final labelOnly=RegExp(
      r'^(?:dia chi(?: bat dong san| nha| dat)?|vi tri(?: bat dong san| nha| dat)?|dia diem|toa lac)\s*[:：=–-]?$',
      caseSensitive:false);
  final otherField=RegExp(
      r'\s+(?:dien tich(?: dat)?|dt|gia(?: ban| chao| moi)?|so dien thoai|sdt|lien he|chu nha|chu dat|chu la|phap ly|mat tien|chieu ngang|chieu dai)\s*(?:[:：=–-]\s*|(?=\d)|(?=(?:anh|chi|ong|ba)\b))',
      caseSensitive:false);

  void collect(String candidate,{bool labeled=false}) {
    var original=_tidyVi(candidate);
    if(original.isEmpty)return;
    var normalized=_foldVi(original);
    // A standalone address without a label may follow a property title or
    // description on the same OCR line.  Cut to the road name only.
    if(!labeled){
      final street=road.firstMatch(normalized);
      if(street!=null&&street.start>0){
        // Preserve the house number before "đường" (23/6c đường số 5).
        final before=normalized.substring(0,street.start);
        final house=RegExp(r'(\d{1,5}(?:[/-]\d+[a-z]?)?)\s+$')
            .firstMatch(before);
        original=_tidyVi(original.substring(house?.start??street.start));
        normalized=_foldVi(original);
      }
    }
    final fieldCut=otherField.firstMatch(normalized);
    if(fieldCut!=null){
      original=_tidyVi(original.substring(0,fieldCut.start));
      normalized=_foldVi(original);
    }
    // When OCR has joined subsequent page text, stop at the end of a full
    // HCMC address rather than swallowing the next advertisement paragraph.
    final city=cityEnd.firstMatch(normalized);
    if(city!=null&&city.end<original.length){
      original=_tidyVi(original.substring(0,city.end));
      normalized=_foldVi(original);
    }
    if(original.length>210)return;
    final hasRoad=road.hasMatch(normalized);
    final hasWard=ward.hasMatch(normalized);
    final hasDistrict=district.hasMatch(normalized);
    // Some Vietnamese street names are published without the word "đường":
    // "68 Bưng Ông Thoàn, Long Trường" is still an explicit address.
    final hasHouseNumber=RegExp(r'^\d{1,5}(?:[/-]\d+[a-z]?)?\s+[a-z]{2,}')
        .hasMatch(normalized);
    // Reject section headings and promotional expressions, even when they
    // contain the words "nhà ở", "vị trí", or "biệt thự".
    if(!hasRoad&&!hasWard&&!hasDistrict&&!hasHouseNumber)return;
    if(!hasRoad&&!labeled&&!(hasHouseNumber&&hasWard))return;
    if(!hasRoad&&!hasWard&&!hasHouseNumber)return;
    if(RegExp(r'^(?:khu nha o|nha o biet thu|biet thu|dan tri cao|dac diem bat dong san)\b')
        .hasMatch(normalized))return;
    if(RegExp(r'\b(?:phut den|phut toi|tu van|xem nha|xem dat|thuong luong)\b')
        .hasMatch(normalized)&&!hasRoad)return;
    if(RegExp(r'^\d+(?:[.,]\d+)?\s*(?:m2|m²|ty|trieu)\b')
        .hasMatch(normalized))return;

    final score=(labeled?35:0)+(hasRoad?50:0)+(hasHouseNumber?25:0)+
        (hasWard?25:0)+(hasDistrict?12:0)+(city!=null?8:0);
    if(score<35||original.length<7)return;
    final previous=addresses[original];
    if(previous==null||previous<score)addresses[original]=score;
  }

  // 1. Explicit label with the value on the same line, or OCR label/value
  // split over consecutive lines.  The next line must itself look geographic.
  for(var i=0;i<lines.length;i++){
    final line=lines[i];
    final normalized=_foldVi(line);
    final matched=addressLabel.firstMatch(normalized);
    if(labelOnly.hasMatch(normalized)){
      if(i+1<lines.length)collect(lines[i+1],labeled:true);
    }else if(matched!=null){
      final tail=_tidyVi(line.substring(matched.end-(matched.group(1)?.length??0)));
      if(tail.isNotEmpty)collect(tail,labeled:true);
      else if(i+1<lines.length)collect(lines[i+1],labeled:true);
    }
    if(road.hasMatch(normalized)){
      // Common mobile display splits a complete address after the ward.
      var block=line;
      var next=i+1;
      while(next<lines.length&&next<=i+2){
        final nxt=_foldVi(lines[next]);
        if(!RegExp(r'^(?:phuong|xa|thi tran|quan|huyen|thanh pho|tp\.?|\(quan)\b')
            .hasMatch(nxt))break;
        block='${block.trim().replaceFirst(RegExp(r'[,;\s]+$'),'')}, ${lines[next]}';
        next++;
      }
      collect(block);
    }
  }

  // 2. A number of OCR readers merge the entire page into a single line.
  // Find street + ward segments directly from the flattened text.  This
  // outranks "vị trí" promotional prose and handles missing newlines.
  for(final m in road.allMatches(folded)){
    final from=m.start;
    final maxEnd=(from+190).clamp(from,flat.length).toInt();
    final sub=_foldVi(flat.substring(from,maxEnd));
    if(!ward.hasMatch(sub))continue;
    var end=maxEnd;
    final city=cityEnd.firstMatch(sub);
    if(city!=null){end=from+city.end;}
    else{
      final stop=otherField.firstMatch(sub);
      if(stop!=null)end=from+stop.start;
    }
    collect(flat.substring(from,end));
  }

  if(addresses.isNotEmpty){
    final sorted=addresses.entries.toList()..sort((a,b)=>b.value.compareTo(a.value));
    return sorted.first.key;
  }
  return '';
}

String _findOwner(String flat) {
  var candidate=_afterLabel(flat,['ten chu','chu nha ten','chu ten','chu nha','chu dat','chu so huu','chu la',
    'nguoi ban','nguoi lien he','ten nguoi lien he','lien he voi'],maxLength:70);
  if(candidate.isEmpty){
    final folded=_foldVi(flat);
    final match=RegExp(r'(?:lien he|gap)\s+((?:anh|chi|ong|ba|co|chu)\s+[a-z ]{2,48})').firstMatch(folded);
    if(match!=null)candidate=flat.substring(match.start+match.group(0)!.indexOf(match.group(1)!),match.end);
  }
  candidate=_tidyVi(candidate);
  if(candidate.isEmpty)return '';
  final norm=_foldVi(candidate);
  if(RegExp(r'^(?:chinh chu|dang ban|ban gap|can ban|ban nha|so dien thoai|\d)').hasMatch(norm))return '';
  if(RegExp(r'\d{4,}|https?').hasMatch(norm))return '';
  if(candidate.length>55)return '';
  return candidate;
}

/// Extract from explicit labels only. Avoid joining unrelated numbers across
/// OCR screen blocks (e.g. "13 tỷ" plus a later "119 triệu/m²").
String _intakeLabeledArea(String input) {
  final lines=input.replaceAll('\r','\n').split('\n');
  for(var i=0;i<lines.length;i++) {
    final text=_foldVi(lines[i].trim());
    if(!RegExp(r'^(?:dien tich(?: dat| cong nhan)?|dt)\s*[:：-]?\s*').hasMatch(text))continue;
    final content=text.replaceFirst(RegExp(r'^(?:dien tich(?: dat| cong nhan)?|dt)\s*[:：-]?\s*'),'');
    String candidate=content;
    if(candidate.isEmpty && i+1<lines.length &&
        RegExp(r'^\s*\d+(?:[.,]\d+)?\s*m\s*[²2]').hasMatch(_foldVi(lines[i+1]))) {
      candidate=_foldVi(lines[i+1]);
    }
    final match=RegExp(r'^[\[\s]*(\d{1,6}(?:[.,]\d+)?)\s*m\s*[²2](?!\s*/)').firstMatch(candidate);
    if(match!=null)return '${match.group(1)} m²';
  }
  return '';
}

String _intakeLabeledPrice(String input) {
  final lines=input.replaceAll('\r','\n').split('\n');
  for(var i=0;i<lines.length;i++) {
    var text=_foldVi(lines[i].trim());
    if(!RegExp(r'^(?:gia ban|gia chao|gia moi|gia)\s*[:：-]?\s*').hasMatch(text))continue;
    text=text.replaceFirst(RegExp(r'^(?:gia ban|gia chao|gia moi|gia)\s*[:：-]?\s*'),'');
    if(text.isEmpty && i+1<lines.length)text=_foldVi(lines[i+1].trim());
    final current=RegExp(r'\bcon\s*(\d{1,4}(?:[.,]\d+)?)\s*(ty|ti|trieu)\b')
        .firstMatch(text);
    if(current!=null && RegExp(r'\b(?:giam|gia cu|gia ban dau)\b').hasMatch(text)){
      return '${current.group(1)} ${current.group(2)=='trieu'?'triệu':'tỷ'}';
    }
    final match=RegExp(r'^[\[\s]*(\d{1,4}(?:[.,]\d+)?)\s*(ty|ti|trieu)\b(?!\s*/\s*m)').firstMatch(text);
    if(match==null)continue;
    if(RegExp(r'\s*/\s*m\s*[²2]').hasMatch(text.substring(match.start,match.end+((text.length-match.end)<6?text.length-match.end:6))))continue;
    return '${match.group(1)} ${match.group(2)=='trieu'?'triệu':'tỷ'}';
  }
  return '';
}

String _intakePosterName(String raw) {
  for(final line in raw.split('\n')) {
    final match=RegExp(r'^(?:người đăng|tên người đăng|người bán|tên người liên hệ)\s*[:：-]\s*(.{3,65})$',caseSensitive:false)
       .firstMatch(line.trim());
    if(match==null)continue;
    final value=_tidyVi(match.group(1)!);
    if(value.length>55||RegExp(r'\d{4,}|https?://').hasMatch(value))continue;
    if(RegExp(r'^(?:bấm|hiện số|đăng tin|tin mới|số tin)',caseSensitive:false).hasMatch(value))continue;
    return value;
  }
  return '';
}

ParsedIntake parseIntake(String input) {
  // Nối xuống dòng giữa nhãn OCR và giá trị bằng một dấu cách.
  final raw=input.replaceAll('\r','\n').trim();
  final flat=raw.replaceAll(RegExp(r'\s+'),' ').trim();
  if(flat.isEmpty)return const ParsedIntake();
  final folded=_foldVi(flat);
  final address=_findAddress(flat,folded,raw:raw);
  final area=_intakeLabeledArea(raw).isNotEmpty
      ?_intakeLabeledArea(raw):_findArea(flat,folded);
  final dimensions=_findDimensions(folded);
  final price=_intakeLabeledPrice(raw).isNotEmpty
      ?_intakeLabeledPrice(raw):_findPrice(flat,folded);
  final phone=_findPhone(flat);
  final owner=_intakePosterName(raw).isNotEmpty
      ?_intakePosterName(raw):_findOwner(flat);
  final url=RegExp(r'https?://[^\s<>]+',caseSensitive:false).firstMatch(flat)?.group(0)??'';
  String type='';
  // Prefer the property headline: a casual mention of an attached store,
  // office or warehouse in the description does not change the listing type.
  const interfaceHeadings=<String>{
    'dac diem bat dong san','thong tin bat dong san','thong tin co ban',
    'thong tin chi tiet','xem tong quan','loai bat dong san',
    'dia chi bat dong san','mo ta chi tiet',
  };
  final substantive=raw.split('\n').map((s)=>_foldVi(s.trim()))
      .firstWhere((s)=>s.isNotEmpty && !interfaceHeadings.contains(s),orElse:()=>_foldVi(raw));
  final head=substantive.length>180 ? substantive.substring(0,180) : substantive;
  // "Bán đất KDC ... khu nhà ở biệt thự" describes a LAND parcel;
  // incidental "nhà ở" must not override the main headline's transaction.
  if(RegExp(r'(ban dat|dat nen|dat rieng|lo dat|dat tho cu)').hasMatch(head))type='Đất nền';
  else if(RegExp(r'(nha mat tien|mat tien duong|nha mt)').hasMatch(head))type='Nhà mặt tiền';
  else if(RegExp(r'(can nha|ban nha|nha rieng|nha o|chinh chu ban nha)').hasMatch(head))type='Nhà riêng';
  else if(RegExp(r'(nha xuong|kho xuong|nha kho)').hasMatch(head))type='Nhà xưởng / kho';
  else if(RegExp(r'(can ho|chung cu)').hasMatch(head))type='Căn hộ';
  else if(RegExp(r'(dat nen|ban dat|dat tho cu|lo dat)').hasMatch(head))type='Đất nền';
  else if(RegExp(r'(nha mat tien|mat tien duong|nha mt)').hasMatch(folded))type='Nhà mặt tiền';
  else if(RegExp(r'(can nha|ban nha|nha rieng|nha o)').hasMatch(folded))type='Nhà riêng';
  else if(RegExp(r'(nha xuong|kho xuong|nha kho)').hasMatch(folded))type='Nhà xưởng / kho';
  else if(RegExp(r'(can ho|chung cu)').hasMatch(folded))type='Căn hộ';
  else if(RegExp(r'(dat nen|ban dat|dat tho cu|lo dat)').hasMatch(folded))type='Đất nền';
  final lines=raw.split('\n').map(_tidyVi).where((e)=>e.isNotEmpty).toList();
  String title='';
  for(final line in lines){
    final norm=_foldVi(line);
    if(RegExp(r'^(?:gia|dien tich|dt|dia chi|sdt|so dien thoai|dien thoai|lien he|ten chu|chu nha|chu la|nguoi ban)\b').hasMatch(norm))continue;
    if(RegExp(r'^(?:dac diem bat dong san|thong tin bat dong san|thong tin co ban|loai hinh|xem tong quan|mo ta chi tiet|dia chi bat dong san|loai bat dong san)$').hasMatch(norm))continue;
    if(!RegExp(r'(nha|dat|can ho|xuong|kho|bat dong san)').hasMatch(norm))continue;
    // Mô tả dài đọc một hơi vẫn chỉ lấy phần tên/địa chỉ tài sản làm tiêu đề.
    final markers=RegExp(r'\s+(?:dien tich|gia ban|gia chao|gia |chu la|chu nha|lien he|sdt|so dien thoai|phap ly)\b');
    final mark=markers.firstMatch(norm);
    title=mark!=null?_tidyVi(line.substring(0,mark.start)):line;
    break;
  }
  if(title.isEmpty&&address.isNotEmpty){title='${type.isNotEmpty?type:'Bất động sản'} tại $address';}
  if(title.length>110)title=title.substring(0,110).trim();
  return ParsedIntake(title:title,address:address,area:area,
    width:dimensions.width,length:dimensions.length,price:price,
    phone:phone,owner:owner,type:type,sourceUrl:url);
}

bool needsOwnerVerification(Listing p) => !p.archived &&
  p.verification!='Đã đối chiếu hồ sơ' && p.verification!='Đã gặp và xác minh trực tiếp';

const feedbackOptions = [
  'Đã gọi – chưa nghe máy',
  'Đã liên hệ – hẹn gọi lại',
  'Chủ đồng ý gặp',
  'Đang thương lượng ký hợp đồng',
  'Đã ký hợp đồng môi giới',
  'Chủ chưa đồng ý ký',
  'Có biến động chào bán',
  'Đã xử lý biến động chào bán',
  'Ngừng khai thác nguồn hàng',
];

/// Tự cập nhật tiến độ sau khi môi giới ghi nhận phản hồi, không tự xác minh chính chủ.
void applyFeedback(Listing p, String outcome, String note, {String? nextAction, DateTime? due}) {
  final now = DateTime.now();
  String suggested='';
  DateTime? suggestedDue;
  switch(outcome) {
    case 'Đã gọi – chưa nghe máy':
      p.contactStatus='Chưa liên hệ được'; suggested='Gọi lại chủ tài sản';
      suggestedDue=now.add(const Duration(days:1));
      break;
    case 'Đã liên hệ – hẹn gọi lại':
      p.contactStatus='Đã liên hệ'; suggested='Liên hệ lại chủ tài sản';
      suggestedDue=now.add(const Duration(days:3));
      break;
    case 'Chủ đồng ý gặp':
      p.contactStatus='Đã hẹn gặp'; suggested='Gặp chủ tài sản';
      suggestedDue=now.add(const Duration(days:1));
      break;
    case 'Đang thương lượng ký hợp đồng':
      p.contactStatus='Đang đàm phán'; suggested='Chốt điều kiện ký môi giới';
      suggestedDue=now.add(const Duration(days:2));
      break;
    case 'Đã ký hợp đồng môi giới':
      p.contactStatus='Đã gặp / làm việc'; p.contractStatus='Đã ký';
      p.saleStatus='Chuẩn bị chào bán'; p.marketingNeedsAttention=false;
      break;
    case 'Chủ chưa đồng ý ký':
      p.contactStatus='Đã liên hệ'; suggested='Hỏi lại chủ về hợp đồng';
      suggestedDue=now.add(const Duration(days:7));
      break;
    case 'Có biến động chào bán':
      p.marketingNeedsAttention=true;
      suggested='Kiểm tra thay đổi giá, trạng thái và nội dung chào bán';
      suggestedDue=now;
      break;
    case 'Đã xử lý biến động chào bán':
      p.marketingNeedsAttention=false; p.saleStatus='Đang chào bán';
      break;
    case 'Ngừng khai thác nguồn hàng':
      p.archived=true;
      break;
  }
  if (p.archived || (p.contractStatus=='Đã ký'&&!p.marketingNeedsAttention)) {
    p.nextAction=''; p.nextDue=null;
  } else {
    p.nextAction=(nextAction??'').trim().isNotEmpty ? nextAction!.trim() : suggested;
    p.nextDue=due ?? suggestedDue;
  }
  p.addLog(outcome,note.trim().isEmpty?'Không có ghi chú thêm':note.trim());
}
