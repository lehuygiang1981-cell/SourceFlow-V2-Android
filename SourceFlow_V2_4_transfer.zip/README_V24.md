# SourceFlow V2.4 - bản thử nghiệm chẩn đoán lỗi OCR Android

## Lỗi đã quan sát
Trên thiết bị Android, OCR trả `PlatformException(error, Attempt to invoke virtual method java.lang.Class java.lang.Object.getClass() on a null object reference, ...)` ở 5/5 ảnh. Ảnh vẫn được lưu, nhưng không có văn bản OCR chuyển sang bộ tách trường. Vì vậy **không thể** kỳ vọng giá/địa chỉ tự điền. Đây là lỗi native Android/Google ML Kit, không phải bằng chứng bộ tách trường tiếng Việt sai.

## Điều chỉnh V2.4
- Đổi nhãn và phiên bản thành `SourceFlow V2.4`, `2.4.0+5`, `applicationId` riêng `vn.sourceflow.sourceflow_android_v24` để cài song song, không ghi đè dữ liệu cũ.
- Trong `scripts/prepare_android.ps1`, bắt buộc đặt `isMinifyEnabled = false`, `isShrinkResources = false` ở `buildTypes.release`. Mục đích là kiểm tra khả năng **R8 loại bỏ các lớp nội bộ ML Kit** trong APK release trước đây. Không thể kết luận chắc chắn nếu chưa thử APK mới trên điện thoại.
- Khi native OCR vẫn lỗi, hiển thị thông báo dễ hiểu để phân biệt lỗi hệ thống nhận dạng với tin đăng không có chữ.
- Giữ nguyên bộ tách trường tiếng Việt, nhiều ảnh, dữ liệu chiều ngang/chiều dài, giọng nói đã hoạt động tốt, ảnh lưu độc lập với OCR.

## Hướng dẫn biên dịch
1. Tải `SourceFlow_V2_4_transfer.zip` vào gốc repository GitHub.
2. Thay `.github/workflows/android-apk.yml` bằng tệp `SourceFlow_V2_4_workflow.yml` ở ngoài ZIP (hoặc sửa phù hợp). Tệp workflow chạy `scripts/prepare_android.ps1` sau khi giải nén và kiểm tra R8 đã tắt.
3. Không tải lên dữ liệu khách hàng thật vào repository. GitHub Actions sẽ chạy `flutter test`, `flutter build apk --release` và lưu Artifacts.
4. Sau khi cài **V2.4** trên Android, kiểm tra ảnh chụp màn hình tin đăng có chữ rõ; xem số ảnh OCR thành công trước, rồi kiểm tra trường tự điền. Không xóa V2.3 hoặc dữ liệu cũ.

## Hạn chế
- Chưa thử được Google ML Kit trên một điện thoại Android thực tế; GitHub Actions không cung cấp thiết bị để tái hiện lỗi native.
- Tắt R8 khiến APK có thể lớn hơn. Khi xác định được nguyên nhân, có thể bật lại shrinking với cấu hình keep rules chính xác.
- Nếu lỗi tiếp diễn, cần logcat/stack trace Android để xác định nơi phát sinh NullPointerException, hoặc thay công cụ OCR.
