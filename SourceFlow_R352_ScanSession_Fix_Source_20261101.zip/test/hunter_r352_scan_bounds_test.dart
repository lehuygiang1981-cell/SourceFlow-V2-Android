import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:sourceflow_android/hunter_models.dart';
import 'package:sourceflow_android/hunter_search.dart';

void main() {
  test('R3.5.2 scan detail requests are bounded even on large list', () async {
    final links=List.generate(120,(i)=>
      '<a href="/mua-ban-nha-dat-thanh-pho-thu-duc-tp-ho-chi-minh/${133081800+i}.htm">'
      '<h3>Bán nhà tại Thủ Đức, 80m², vị trí tốt số $i</h3></a>').join();
    var detailRequests=0;
    final fake=MockClient((request)async{
      if(request.url.path.endsWith('.htm')){
        detailRequests++;
        return http.Response('<html><body>Thông tin tin đăng công khai</body></html>',200);
      }
      return http.Response('<html><body>$links</body></html>',200);
    });
    final scanner=HunterSearch(client:fake);
    final progress=<String>[];
    final result=await scanner.scan(const HunterSettings(
      sites:['nhatot.com'],districts:['Thành phố Thủ Đức'],wards:[]),
      onProgress:(value)async {progress.add(value);});
    expect(result.raw,120);
    expect(result.leads.length,HunterSearch.maxListingsPerSource);
    expect(detailRequests,lessThanOrEqualTo(HunterSearch.maxDetailsPerSource));
    expect(result.sources.single.status,'ok');
    expect(progress,contains('Đang đọc nguồn nhatot.com'));
    scanner.close();
  });

  test('R3.5.2 user cancellation is reported, not a successful empty scan',()async{
    final scanner=HunterSearch(client:MockClient((request)async =>
      http.Response('<html><body></body></html>',200)));
    var cancel=false;
    final result=await scanner.scan(const HunterSettings(sites:['nhatot.com']),
      isCancelled:()=>cancel,
      onProgress:(message)async {cancel=true;});
    expect(result.errors,contains('Người dùng đã dừng quét'));
    expect(result.leads,isEmpty);
    scanner.close();
  });
}
