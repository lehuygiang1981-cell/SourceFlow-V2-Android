import 'dart:async';
import 'dart:convert';
import 'package:html/parser.dart' as html_parser;
import 'package:html/dom.dart' as dom;
import 'package:http/http.dart' as http;
import 'hunter_models.dart';
import 'legacy_admin.dart';

/// Direct public-HTML source connectors (no Bing, Google, proxy or CAPTCHA bypass).
/// An unsupported/blocked site is reported as an ERROR, never as zero listings.
class HunterSearchResult {
  final List<HunterLead> leads;
  final List<String> errors;
  final int searched, discarded, queries, raw;
  final List<SourceScanStat> sources;
  const HunterSearchResult(this.leads,this.errors,this.searched,{
    this.discarded=0,this.queries=0,this.raw=0,this.sources=const []});
}

class DirectSource {
  final String domain;
  final Uri thuDucUrl, cityUrl;
  const DirectSource(this.domain,this.thuDucUrl,this.cityUrl);
}

class HunterSearch {
  final http.Client client;
  HunterSearch({http.Client? client}): client=client??http.Client();
  static const allowedHosts={
    'batdongsan.com.vn','nhatot.com','muaban.net','bds68.com.vn','guland.vn'
  };
  static final directSources=<String,DirectSource>{
    'nhatot.com':DirectSource('nhatot.com',
      Uri.parse('https://www.nhatot.com/mua-ban-nha-dat-thanh-pho-thu-duc-tp-ho-chi-minh'),
      Uri.parse('https://www.nhatot.com/mua-ban-nha-dat-tp-ho-chi-minh')),
    'batdongsan.com.vn':DirectSource('batdongsan.com.vn',
      Uri.parse('https://batdongsan.com.vn/ban-nha-rieng-thu-duc'),
      Uri.parse('https://batdongsan.com.vn/ban-nha-rieng-tp-hcm')),
    'muaban.net':DirectSource('muaban.net',
      Uri.parse('https://muaban.net/bat-dong-san/ban-nha-quan-thu-duc-ho-chi-minh'),
      Uri.parse('https://muaban.net/bat-dong-san/ban-nha-ho-chi-minh')),
    'bds68.com.vn':DirectSource('bds68.com.vn',
      Uri.parse('https://bds68.com.vn/nha-dat-ban/ho-chi-minh/thu-duc'),
      Uri.parse('https://bds68.com.vn/nha-dat-ban/ho-chi-minh')),
    'guland.vn':DirectSource('guland.vn',
      Uri.parse('https://guland.vn/mua-ban-bat-dong-san-thanh-pho-thu-duc-tp-ho-chi-minh'),
      Uri.parse('https://guland.vn/bat-dong-san/tp-ho-chi-minh')),
  };

  static String fold(String value){
    var s=value.toLowerCase().replaceAll('đ','d');
    const accentGroups={
      'a':'àáạảãâầấậẩẫăằắặẳẵ',
      'e':'èéẹẻẽêềếệểễ',
      'i':'ìíịỉĩ',
      'o':'òóọỏõôồốộổỗơờớợởỡ',
      'u':'ùúụủũưừứựửữ',
      'y':'ỳýỵỷỹ',
    };
    for(final entry in accentGroups.entries){
      for(final ch in entry.value.split('')){s=s.replaceAll(ch,entry.key);}
    }
    return s.replaceAll(RegExp(r'\s+'),' ').trim();
  }
  static bool directSourceUrl(String link,String domain){
    final uri=Uri.tryParse(link);
    if(uri==null||!['https','http'].contains(uri.scheme))return false;
    final host=uri.host.toLowerCase();
    return (host==domain||host.endsWith('.$domain'))&&uri.path.length>1;
  }
  static bool _listingPath(Uri uri,String domain){
    final path=uri.path.toLowerCase();
    if(path.startsWith('/wiki/')||path.contains('/dieu-khoan')||path.contains('/tin-da-dang-'))return false;
    switch(domain){
      case 'nhatot.com':return RegExp(r'/\d{7,}\.htm$').hasMatch(path);
      case 'batdongsan.com.vn':return RegExp(r'-pr\d+').hasMatch(path);
      case 'muaban.net':return RegExp(r'-id\d+').hasMatch(path);
      case 'bds68.com.vn':return (path.contains('ban-')||path.contains('/nha-dat-ban/'))&&
        (RegExp(r'\d{5,}').hasMatch(path)||path.endsWith('.html'));
      case 'guland.vn':
        // /tin-da-dang-475813/... is a SELLER PROFILE, not a property.
        if(path.contains('/tin-da-dang-')||path.contains('/nguoi-dang-')||path.contains('/thanh-vien/'))return false;
        return (path.contains('/bat-dong-san/')||path.contains('/mua-ban-'))&&
          (RegExp(r'\d{5,}').hasMatch(path)||RegExp(r'/ban-[^/]{18,}').hasMatch(path));
      default:return false;
    }
  }

  static String _compact(String value)=>value.replaceAll(RegExp(r'\s+'),' ').trim();
  /// DOM .text joins adjacent tags without whitespace.  For example,
  /// </h3><p>14/10/2026 becomes ...2 14/10/2026 only if text-node
  /// boundaries are retained.  Otherwise the preceding title digit can
  /// hide the date from a boundary-aware regex.
  static String _cardText(dom.Element? root){
    if(root==null)return '';
    final parts=<String>[];
    void walk(dom.Node node){
      if(node is dom.Text){
        final value=node.text.trim();
        if(value.isNotEmpty)parts.add(value);
        return;
      }
      if(node is dom.Element &&
          ['script','style','noscript'].contains(node.localName))return;
      for(final child in node.nodes){walk(child);}
    }
    walk(root);
    return _compact(parts.join(' '));
  }
  static bool _looksLikeSellerName(String title){
    final v=fold(title);
    if(RegExp(r'(nha|dat|can ho|xuong|kho|ban|ty|trieu|m2|mat tien)').hasMatch(v))return false;
    return RegExp(r'^[a-z ]+ ?[0-9]{0,3}$').hasMatch(v) && v.split(' ').length<=6;
  }
  static bool _isMarketing(String value){
    final folded=fold(value);
    return RegExp(r'^(trang chu|tin tuc|tim kiem|dang nhap|xem them|mua ban|xem chi tiet)$')
      .hasMatch(folded);
  }

  /// Extract only direct links from server-rendered listing pages; never
  /// fabricate URLs when the page is JS-only or changes its structure.
  static List<HunterLead> parseListingHtml(String rawHtml,Uri page,String domain,
    {DateTime? now}){
    final document=html_parser.parse(rawHtml);
    final byUrl=<String,HunterLead>{};
    for(final a in document.querySelectorAll('a[href]')){
      final href=a.attributes['href']??'';
      Uri uri;
      try{uri=page.resolve(href);}catch(_){continue;}
      if(!directSourceUrl(uri.toString(),domain)||!_listingPath(uri,domain))continue;
      final titleNode=a.querySelector('h1,h2,h3,h4,[itemprop="name"]');
      final rawTitle=(titleNode?.text.isNotEmpty==true ? titleNode!.text
          : (a.attributes['title']??a.attributes['aria-label']??a.text));
      var title=_compact(rawTitle);
      if(title.length<12){
        final alt=a.querySelector('img')?.attributes['alt']??'';
        title=_compact(alt);
      }
      if(title.length<12||_isMarketing(title)||_looksLikeSellerName(title))continue;
      // A seller name is not a property headline. Preserve the lead but
      // show an explicit unverified placeholder until detail is fetched.
      
      if(title.length>240)title=title.substring(0,240);
      final key=canonicalLeadUrl(uri.toString());
      if(key.isEmpty||byUrl.containsKey(key))continue;
      // The nearest card is intentionally bounded; never merge other listing
      // cards into this item's text by climbing into the document body.
      dom.Element? card=a;
      for(var i=0;i<4 && card?.parent!=null;i++){
        final parent=card!.parent!;
        if(['body','html','main'].contains(parent.localName))break;
        if(parent.text.length>1200)break;
        card=parent;
        if(['article','li'].contains(parent.localName))break;
      }
      var snippet=_cardText(card);
      if(snippet.isEmpty)snippet=title;
      if(snippet.length>600)snippet=snippet.substring(0,600);
      byUrl[key]=HunterLead(url:uri.toString(),title:title,snippet:snippet,
        source:domain,queryTarget:'Trang nguồn: $domain',discoveredAt:now,
        posterCountEvidence:_posterEvidence(snippet),
        dateEvidence:_dateEvidence(snippet, domain:domain),
        posterCountSource:'snippet_unverified');
    }
    return byUrl.values.toList();
  }

  /// A date is usable only when it plausibly describes this particular post.
  /// bds68 card markup also exposes an unlabeled DD/MM/YYYY after a title.
  static String _dateEvidence(String text,{String domain=''}){
    final match=RegExp(r'(?:Đăng(?: ngày)?|Ngày bắt đầu|Ngày đăng|Published|Ngày tạo)\s*:?\s*(\d{1,2}/\d{1,2}/\d{4})',
      caseSensitive:false).firstMatch(text);
    if(match!=null)return match.group(1)??'';
    if(domain=='bds68.com.vn'){
      final dates=RegExp(r'(?<![0-9])(\d{1,2}/\d{1,2}/20\d{2})(?![0-9])')
        .allMatches(text).map((m)=>m.group(1)!).toSet().toList();
      if(dates.length==1)return dates.first;
    }
    return '';
  }
  /// Generic mentions of "3 tin" elsewhere on a page MUST NOT be treated as
  /// verified number of listings by the same seller. No guessing from snippets.
  static String _posterEvidence(String text,{bool sellerProfile=false}){
    if(!sellerProfile)return '';
    final normalized=fold(text);
    final matches=[
      RegExp(r'(?:tong so tin(?: dang)?|tong tin dang|so tin dang|da dang)\s*[:：-]?\s*(\d{1,4})\s*(?:tin)?'),
      RegExp(r'(\d{1,4})\s*tin\s*(?:dang|ban|cho thue)')
    ];
    for(final pattern in matches){
      final m=pattern.firstMatch(normalized);
      if(m!=null)return m.group(1)??'';
    }
    return '';
  }

  /// BDS68 exposes "Tổng số tin đăng 8" on the listing's seller card.
  /// Read that seller card, not a generic number from the whole page.
  static String sellerCountOnDetail(dom.Document doc, String domain) {
    if (domain != 'bds68.com.vn') return '';
    // Prefer the smallest element containing the label; this avoids accidentally
    // taking a number from another listing or an unrelated recommendation.
    final nodes = doc.querySelectorAll('span,strong,b,small,p,li,div,section,aside');
    final matches = <String>[];
    for (final element in nodes) {
      final value = _compact(element.text);
      final normalized = fold(value);
      if (!normalized.contains('tong so tin dang') || value.length > 300) continue;
      var count = _posterEvidence(value, sellerProfile:true);
      if (count.isEmpty && normalized.trim() == 'tong so tin dang') {
        // Some templates put the count in the next sibling, not in the label.
        final sibling = element.nextElementSibling;
        final siblingText = _compact(sibling?.text ?? '');
        if (RegExp(r'^\d{1,4}$').hasMatch(siblingText)) count = siblingText;
        if (count.isEmpty && element.parent != null) {
          count = _posterEvidence(_compact(element.parent!.text),sellerProfile:true);
        }
      }
      if (count.isNotEmpty) matches.add(count);
    }
    // If conflicting cards are present, do not certify an ambiguous count.
    return matches.toSet().length == 1 ? matches.first : '';
  }

  /// Read only content connected to one listing. A raw site body contains
  /// recommendation widgets and unrelated price/phone values.
  static String extractDetailText(dom.Document document){
    final parts=<String>[];
    void put(String value){
      final v=_compact(value);
      if(v.isNotEmpty && !parts.contains(v))parts.add(v);
    }
    for(final e in document.querySelectorAll('meta[property="og:description"],meta[name="description"]')){
      put(e.attributes['content']??'');
    }
    // Standard JSON-LD when a website publishes structured real-estate data.
    for(final script in document.querySelectorAll('script[type="application/ld+json"]')){
      try{
        final parsed=jsonDecode(script.text);
        final nodes=<dynamic>[];
        void collect(dynamic v){
          if(v is List){for(final x in v)collect(x);}
          else if(v is Map){nodes.add(v);if(v['@graph']!=null)collect(v['@graph']);}
        }
        collect(parsed);
        for(final item in nodes.whereType<Map>()){
          final type='${item['@type']??''}'.toLowerCase();
          if(!['product','offer','residence','realestate','house','apartment','singlefamilyresidence']
                .any(type.contains))continue;
          if(item['description'] is String)put('${item['description']}');
          final area=item['floorSize']??item['area'];
          if(area is Map && area['value']!=null)put('Diện tích: ${area['value']} m²');
          final address=item['address'];
          if(address is String)put('Địa chỉ: $address');
          if(address is Map){
            final words=['streetAddress','addressLocality','addressRegion'].map((k)=>'${address[k]??''}')
              .where((x)=>x.isNotEmpty).join(', ');
            if(words.isNotEmpty)put('Địa chỉ: $words');
          }
          final offers=item['offers'];
          final offer=offers is Map?offers:offers is List && offers.isNotEmpty?offers.first:null;
          if(offer is Map && offer['price']!=null){
            final raw='${offer['price']}';final number=num.tryParse(raw);
            final currency='${offer['priceCurrency']??''}'.toUpperCase();
            if(number!=null && currency=='VND' && number>=1000000){
              if(number>=1000000000){put('Giá bán: ${(number/1000000000).toStringAsFixed(2)} tỷ');}
              else{put('Giá bán: ${(number/1000000).toStringAsFixed(1)} triệu');}
            }
          }
        }
      }catch(_){ /* malformed schema must not block listing */ }
    }
    // Site-specific visible field blocks, before prose. Keep labels adjacent to
    // values; generic body text alone often loses price/address/dimensions.
    for(final selector in <String>[
      '[itemprop="price"]','[itemprop="address"]','[itemprop="floorSize"]',
      '.price','.product-price','.post-price','.detail-price',
      '.location','.address','.post-address','.detail-address',
      '.post-info','.detail-info','.product-info',
      '.info-attrs','.detail-attrs','.property-info',
    ]){
      for(final el in document.querySelectorAll(selector).take(12)){
        final value=_cardText(el);
        if(value.isEmpty || value.length>350)continue;
        if(selector.contains('price'))put('Giá bán: $value');
        else if(selector.contains('address')||selector=='.location')put('Địa chỉ: $value');
        else put(value);
      }
    }
    // Direct visible labels for muaban.net / bds68.com.vn, including table rows.
    for(final el in document.querySelectorAll('tr,li,dt,dd,p,div,span')){
      if(el.children.length>5)continue;
      final value=_cardText(el);
      if(value.length<5 || value.length>155)continue;
      final label=fold(value);
      if(RegExp(r'^(?:gia(?: ban| chao)?|dia chi|vi tri|dien tich(?: dat)?|ngang|chieu ngang|chieu dai|ngay bat dau|ngay dang|mat tien|so tang|giay to phap ly|phap ly|loai hinh|dang|tong so tin dang)\s*[:：]?').hasMatch(label))put(value);
      if(RegExp(r'^dien tich dat\s*[:：]').hasMatch(label)){
        final dims=RegExp(r'(\d+(?:[.,]\d+)?)\s*[x×]\s*(\d+(?:[.,]\d+)?)').firstMatch(value);
        if(dims!=null){put('Chiều ngang: ${dims.group(1)} m');put('Chiều dài: ${dims.group(2)} m');}
      }
    }
    dom.Element? target;
    for(final selector in ['[itemprop="description"]','.re__detail-content',
      '.re__detail-content','.post-content','.detail-content','.post-detail',
      '.product-detail','.description','.post-description','.product-description','.detail-description','article','main']){
      final matches=document.querySelectorAll(selector);
      for(final el in matches){
        if(el.text.length>30 && (target==null || (el.text.length<target.text.length && el.text.length>200)))target=el;
      }
      if(target!=null)break;
    }
    if(target!=null){
      var body=_cardText(target);
      if(body.length>12000)body=body.substring(0,12000);
      put(body);
    }
    return parts.join('\n');
  }

  /// The detail page, not the seller card, is authoritative for the headline.
  static String extractDetailTitle(dom.Document doc,String fallback){
    for(final selector in ['h1','meta[property="og:title"]','meta[name="twitter:title"]']){
      final element=doc.querySelector(selector);
      final candidate=_compact(selector.startsWith('meta')
        ?(element?.attributes['content']??''):(element?.text??''));
      if(candidate.length>=12 && !_looksLikeSellerName(candidate)
          && !_isMarketing(candidate))return candidate.length>240
            ?candidate.substring(0,240):candidate;
    }
    return fallback;
  }

  static String _sellerProfileUrl(dom.Document doc,Uri base,String domain){
    for(final link in doc.querySelectorAll('a[href]')){
      final raw=link.attributes['href']??'';
      Uri uri;
      try {uri=base.resolve(raw.trim());} catch (_) {continue;}
      if(!directSourceUrl(uri.toString(),domain))continue;
      final path=uri.path.toLowerCase();
      if(domain=='bds68.com.vn' && path.contains('/nguoi-dang-tin/'))return uri.toString();
      if(domain=='nhatot.com' && (path.contains('/user/') || path.contains('/profile/')))return uri.toString();
      if(domain=='guland.vn' && (path.contains('/tin-da-dang-') || path.contains('/nguoi-dang-') || path.contains('/thanh-vien/')))return uri.toString();
    }
    return '';
  }

  static DateTime? dateFromEvidence(String evidence){
    final m=RegExp(r'^(\d{1,2})/(\d{1,2})/(\d{4})$').firstMatch(evidence);
    if(m==null)return null;
    final d=int.parse(m.group(1)!);final month=int.parse(m.group(2)!);
    final y=int.parse(m.group(3)!);
    final date=DateTime(y,month,d);
    return date.year==y&&date.month==month&&date.day==d?date:null;
  }

  /// Strong brokerage indicators, evaluated on the listing itself, not
  /// navigation/footer text. Avoid weak phrases such as "chủ nhà bán".
  static const brokerSignals = <String>[
    'nhan ky gui', 'ky gui nha dat', 'nguon hang ky gui',
    'chinh chu gui', 'chu gui', 'chu gui ban', 'chu nha ban', 'hang chu gui',
    'chu thien chi', 'lam viec chinh chu', 'lam viec truc tiep chinh chu',
    'lien he em dan xem', 'em dan xem nha', 'dan khach xem nha',
    'dan khach xem dat', 'ho tro gap chu', 'ket noi chu nha',
    'nhan ban ho', 'nhan ban nha', 'nhan ban dat',
    'nhan tim nha theo yeu cau', 'nhan tim dat theo yeu cau',
    'con nhieu can', 'con nhieu nha', 'em co nhieu can',
    'em con nhieu can', 'lien he xem them nha',
    'gio hang', 'ro hang', 'kho hang bat dong san',
    'san giao dich bat dong san', 'cong ty bat dong san',
    'chuyen vien moi gioi', 'chuyen vien bat dong san',
    'chuyen vien tu van bat dong san', 'chuyen vien kinh doanh bat dong san',
    'doi ngu sale', 'he thong phan phoi', 'dai ly phan phoi',
    'chuyen nha pho', 'chuyen nha dat', 'chuyen ban nha',
    'chuyen ban dat', 'chuyen nhan ky gui',
    'hoa hong moi gioi', 'phi moi gioi', 'chia hoa hong',
    'hop tac moi gioi', 'phi gioi thieu',
  ];

  static String? brokerEvidence(HunterLead lead){
    final raw='${lead.title} ${lead.snippet} ${lead.detailText}';
    final normalized=fold(raw).replaceAll(RegExp(r'[^a-z0-9\s]'),' ')
        .replaceAll(RegExp(r'\s+'),' ').trim();
    // Negations are not proof of offering brokerage services.
    final cleaned=normalized.replaceAll(
      RegExp(r'\b(?:mien|khong qua|khong tiep|khong nhan|cam)\s+(?:trung gian|moi gioi|co dat)\b'),
      ' ');
    for(final phrase in brokerSignals){
      if(RegExp('(?:^| )${RegExp.escape(phrase)}(?: |\$)').hasMatch(cleaned)){
        return 'Nội dung tin: $phrase';
      }
    }
    // "Môi giới" alone is ambiguous: exclude only when used to advertise
    // brokerage, not "miễn môi giới" or "không tiếp môi giới".
    for(final phrase in <String>[
      'toi la moi gioi', 'em la moi gioi', 'ben moi gioi',
      'dich vu moi gioi', 'nhan moi gioi', 'chuyen moi gioi',
      'moi gioi ban nha', 'moi gioi ban dat', 'co dat ban nha',
      'co dat ban dat', 'tu van bat dong san', 'sale bds', 'sales bds',
    ]){
      if(RegExp('(?:^| )${RegExp.escape(phrase)}(?: |\$)').hasMatch(cleaned)){
        return 'Nội dung tin: $phrase';
      }
    }
    // Contextual brokerage patterns: require a combination to avoid rejecting
    // an owner's standalone phrase "thương lượng trực tiếp với chủ".
    final hasAgentContact=RegExp(r'\b(?:lien he|lh|goi|zalo)\s+(?:em|a|anh|chi)\s+[a-z]{2,}').hasMatch(cleaned);
    final hasViewingService=RegExp(r'\b(?:ho tro|tu van|dan|hen)\s+(?:tu van\s+)?(?:xem|di xem|gap)\s+(?:nha|dat|thuc te)').hasMatch(cleaned)
      ||RegExp(r'\b(?:ho tro|tu van)\s+(?:xem nha|khach hang)\s+24\s*7').hasMatch(cleaned);
    final hasOwnerNegotiation=RegExp(r'\b(?:thuong luong|lam viec|giao dich)\s+truc tiep\s+(?:voi\s+)?chu\s+nha').hasMatch(cleaned);
    if(hasAgentContact && (hasViewingService || hasOwnerNegotiation)){
      return 'Liên hệ nhân viên + hỗ trợ xem nhà / thương lượng với chủ';
    }
    if(RegExp(r'\b(?:xem them|tham khao them|nhieu|kho)\s+(?:nha|nha pho|bat dong san|san pham)\b').hasMatch(cleaned)
        && (RegExp(r'\bhttps?\s*\b|\b[a-z0-9-]+\s+(?:vercel\s+app|com|vn)\b').hasMatch(cleaned)
            ||RegExp(r'\b(?:dau dat ne|gio hang|nguon hang)\b').hasMatch(cleaned))){
      return 'Quảng bá nhiều nguồn hàng và website bên ngoài';
    }
    if(RegExp(r'\b(?:ho tro tu van|ho tro xem nha|ho tro xem dat)\s+(?:thuc te\s+)?24\s*7').hasMatch(cleaned)){
      return 'Dịch vụ tư vấn/xem nhà 24/7';
    }
    // Brokerage brand in seller handle, rather than arbitrary property text.
    if(RegExp(r'\b[a-z0-9_-]*(?:realty|realtor|batdongsan|real(?=[0-9]{2,}))[a-z0-9_-]*\b')
        .hasMatch(raw.toLowerCase())){
      return 'Tài khoản mang tên thương hiệu môi giới';
    }
    if(RegExp(r'\b(hh|mg)\s*[:=]\s*\d+\s*%').hasMatch(normalized)){
      return 'Hoa hồng môi giới theo tỷ lệ';
    }
    return null;
  }

  static bool matchesCriteria(HunterLead lead,HunterSettings settings){
    final text=fold('${lead.title} ${lead.snippet} ${lead.detailText}');
    if(settings.excludedTerms.any((t)=>t.trim().isNotEmpty&&text.contains(fold(t))))return false;
    if(settings.excludeSharedTitle &&
      ['so chung','dong so huu','vi bang'].any(text.contains))return false;
    if(settings.excludeApartments && ['chung cu','can ho'].any(text.contains))return false;
    if(settings.excludeBroker && brokerEvidence(lead)!=null)return false;
    final headline=fold(lead.title);
    if(RegExp(r'^(can mua|tim mua|mua nha|mua dat|can thue|cho thue|sang nhuong hop dong thue)').hasMatch(headline))return false;
    if(text.contains('cho thue')&&!text.contains('ban'))return false;
    if(settings.propertyType=='Nhà xưởng'&&
       !['nha xuong','kho xuong','kho bai'].any(text.contains))return false;
    if(settings.propertyType=='Đất'&&
       !['dat ','ban dat','dat nen','lo dat'].any(text.contains))return false;
    // Reject non-property pages and unreadable detail; never present a seller
    // profile as a qualified property listing.
    if(_looksLikeSellerName(lead.title)||lead.title=='Tin BĐS cần đọc chi tiết')return false;
    if(lead.detailText.trim().length<35)return false;
    // Do not require literal "chính chủ": otherwise genuine owner ads vanish.
    // Poster count unknown remains pending. Positive evidence >limit can exclude.
    final post=int.tryParse(lead.posterCountEvidence);
    if((lead.posterCountSource=='seller_profile_verified' || lead.posterCountSource=='human_verified') &&
       post!=null && post>settings.maxPosterListings)return false;
    final date=dateFromEvidence(lead.dateEvidence);
    if(date==null)return false; // unknown date is not a passed freshness filter
    if(date!=null){final today=DateTime.now();
      final age=DateTime(today.year,today.month,today.day).difference(date).inDays;
      if(age>settings.recentDays || age < 0)return false;}
    if(lead.posterCountSource!='seller_profile_verified' && lead.posterCountSource!='human_verified')return false;
    if(post==null||post>settings.maxPosterListings)return false;
    if(settings.wards.isNotEmpty){
      final wanted=settings.wards.map((w)=>w.contains(' · ')?w.split(' · ').last:w)
        .map(fold).toList();
      if(!wanted.any(text.contains)){
        // Only reject when the page explicitly names another known ward.
        // Missing address details must stay pending rather than disappear.
        final namedOther=LegacyAdmin.formerThuDucWards.any((w)=>
          text.contains('phuong ${fold(w)}') && !wanted.contains(fold(w)));
        if(namedOther)return false;
      }
    } else if(settings.districts.isNotEmpty && !settings.districts.contains(LegacyAdmin.thuDuc)){
      if(!settings.districts.any((d)=>text.contains(fold(d))))return false;
    }
    // A street is a PRIORITY hint; missing OCR/address text is not proof of
    // mismatch and must not silently eliminate the entire source.
    return true;
  }

  /// Three-way assessment: absence of evidence is POTENTIAL, never rejection.
  /// Qualified is only a *preliminary* classification; human verifies ownership.
  static String classifyLead(HunterLead lead,HunterSettings settings){
    // HARD GATES FIRST. Any proven violation rejects immediately, even when
    // other evidence is missing. Missing evidence alone goes to pending.
    final date=dateFromEvidence(lead.dateEvidence);
    if(date!=null){
      final today=DateTime.now();
      final age=DateTime(today.year,today.month,today.day).difference(date).inDays;
      if(age>settings.recentDays || age<0)return 'rejected';
    }
    final count=int.tryParse(lead.posterCountEvidence);
    final verifiedCount=lead.posterCountSource=='seller_profile_verified'||lead.posterCountSource=='human_verified';
    if(verifiedCount && count!=null && count>settings.maxPosterListings)return 'rejected';
    if(verifiedCount && count!=null && count<0)return 'potential';
    final text=fold('${lead.title} ${lead.snippet} ${lead.detailText}');
    if(settings.excludedTerms.any((t)=>t.trim().isNotEmpty&&text.contains(fold(t))))return 'rejected';
    if(settings.excludeSharedTitle && ['so chung','dong so huu','vi bang'].any(text.contains))return 'rejected';
    if(settings.excludeApartments && ['chung cu','can ho'].any(text.contains))return 'rejected';
    if(settings.excludeBroker && brokerEvidence(lead)!=null)return 'rejected';
    if(RegExp(r'^(can mua|tim mua|can thue|cho thue)').hasMatch(fold(lead.title)))return 'rejected';
    if(lead.detailText.trim().length<35 || _looksLikeSellerName(lead.title))return 'potential';
    final parsed=lead.parsed;
    // Generic 'chu nha ban' is broker-style copy, never positive owner evidence.
    final ownerSignal=['chinh chu','mien trung gian','toi la chu','toi ban nha','toi ban dat','gia dinh toi ban'].any(text.contains);
    final hasAddress=parsed.address.trim().isNotEmpty;
    if(date!=null && verifiedCount && count!=null && count<=settings.maxPosterListings &&
       hasAddress && ownerSignal && Uri.tryParse(lead.url)?.hasScheme == true &&
       (Uri.tryParse(lead.url)?.host.isNotEmpty ?? false))return 'qualified';
    return 'potential';
  }

  static int relevanceScore(HunterLead lead,HunterSettings s){
    final text=fold('${lead.title} ${lead.snippet}');
    var score=0;
    if(s.streets.any((x)=>x.trim().isNotEmpty&&text.contains(fold(x))))score+=5;
    if(s.keywords.trim().isNotEmpty&&text.contains(fold(s.keywords)))score+=2;
    if(s.ownerHintsOnly &&
      ['chinh chu','mien trung gian','toi ban'].any(text.contains))score+=3;
    if(lead.posterCountEvidence.isNotEmpty)score++;
    return score;
  }

  /// Read public listing page, then detail pages for available evidence.
  /// Slow down requests (per domain) and stop on 403/429; never bypass blocks.
  /// Bound network work so one large source cannot keep a session alive for
  /// hours. Missing details remain unverified, never silently marked 'owner'.
  static const int maxListingsPerSource=80;
  static const int maxDetailsPerSource=6;
  static const Duration sourceBudget=Duration(seconds:40);
  static const Duration totalBudget=Duration(seconds:150);

  Future<HunterSearchResult> scan(HunterSettings settings,
      {Future<void> Function(String)? onProgress,
       bool Function()? isCancelled})async{
    final deadline=DateTime.now().add(totalBudget);
    final all=<HunterLead>[];
    final errors=<String>[];
    final stats=<SourceScanStat>[];
    final seen=<String>{};
    var queries=0,discarded=0,raw=0;
    for(final domain in settings.sites.toSet()){
      if(isCancelled?.call()==true){
        errors.add('Người dùng đã dừng quét');
        break;
      }
      if (DateTime.now().isAfter(deadline)) {
        errors.add('$domain: vượt giới hạn ${totalBudget.inSeconds} giây cho toàn phiên');
        stats.add(SourceScanStat(domain,'error','Chưa quét: hết thời gian của phiên'));
        continue;
      }
      if (onProgress!=null) await onProgress('Đang đọc nguồn $domain');
      final sourceDeadline=DateTime.now().add(sourceBudget);
      var inspectedDetails=0;
      final adapter=directSources[domain];
      if(adapter==null){errors.add('$domain: không hỗ trợ');
        stats.add(SourceScanStat(domain,'unsupported','Không có bộ kết nối'));continue;}
      final includeThuDuc=settings.districts.isEmpty||settings.districts.contains(LegacyAdmin.thuDuc);
      final includeOther=settings.districts.any((d)=>d!=LegacyAdmin.thuDuc);
      final pages=<Uri>[if(includeThuDuc)adapter.thuDucUrl,if(includeOther)adapter.cityUrl];
      var domainRaw=0,domainMatched=0,domainDiscarded=0;
      var successful=0;
      final notes=<String>[];
      for(final page in pages){
        if(isCancelled?.call()==true){notes.add('Đã dừng theo yêu cầu');break;}
        if(DateTime.now().isAfter(sourceDeadline)||DateTime.now().isAfter(deadline)){
          notes.add('Đã giới hạn thời gian nguồn (40 giây)');
          break;
        }
        queries++;
        try{
          final response=await client.get(page,headers:{
            'Accept':'text/html,application/xhtml+xml',
            'User-Agent':'SourceFlowPersonal/3.0 (+public listing reader; contact via app)',
          }).timeout(const Duration(seconds:18));
          if(response.statusCode==403||response.statusCode==429){
            throw StateError('HTTP ${response.statusCode}: nguồn giới hạn truy cập, không bỏ qua bảo vệ');
          }
          if(response.statusCode!=200)throw StateError('HTTP ${response.statusCode}');
          final body=utf8.decode(response.bodyBytes,allowMalformed:true);
          if(!body.toLowerCase().contains('<html'))throw const FormatException('Không nhận được HTML');
          final hits=parseListingHtml(body,page,domain);
          if(hits.isEmpty)throw const FormatException('Không trích xuất được link tin; website có thể thay đổi HTML hoặc tải bằng JavaScript');
          successful++;
          domainRaw+=hits.length;
          // Inspect a bounded number of public detail pages: dates and poster
          // counts are evidence only when actually present on page content.
          for(var i=0;i<hits.length && i<maxListingsPerSource;i++){
            if(isCancelled?.call()==true){notes.add('Đã dừng theo yêu cầu');break;}
            if (DateTime.now().isAfter(deadline)) {
              notes.add('Đạt giới hạn thời gian phiên');
              break;
            }
            final lead=hits[i];
            if(seen.contains(lead.id))continue; // no duplicate fetch/store within scan
            HunterLead enriched=lead;
            if(inspectedDetails<maxDetailsPerSource &&
                DateTime.now().isBefore(sourceDeadline)){
              inspectedDetails++;
              try{
                await Future<void>.delayed(const Duration(milliseconds:400));
                final detail=await client.get(Uri.parse(lead.url),headers:{
                  'Accept':'text/html','User-Agent':'SourceFlowPersonal/3.0 (public listing reader)',
                }).timeout(const Duration(seconds:8));
                if(detail.statusCode==200){
                  final doc=html_parser.parse(utf8.decode(detail.bodyBytes,allowMalformed:true));
                  // Exclude header/nav/footer before extracting body information.
                  for(final selector in ['script','style','nav','footer']){
                    for(final e in doc.querySelectorAll(selector)){e.remove();}
                  }
                  final detailText=extractDetailText(doc);
                  final detailTitle=extractDetailTitle(doc, lead.title);
                  final sellerProfile=_sellerProfileUrl(doc,Uri.parse(lead.url),domain);
                  var count=sellerCountOnDetail(doc,domain);
                  var countSource=count.isNotEmpty?'seller_profile_verified':'';
                  if(sellerProfile.isNotEmpty){
                    try{
                      await Future<void>.delayed(const Duration(milliseconds:400));
                      final profile=await client.get(Uri.parse(sellerProfile),headers:{
                        'Accept':'text/html',
                        'User-Agent':'SourceFlowPersonal/3.0 (public seller-profile reader)',
                      }).timeout(const Duration(seconds:5));
                      if(profile.statusCode==200){
                        final profileDoc=html_parser.parse(utf8.decode(profile.bodyBytes,allowMalformed:true));
                        for(final e in profileDoc.querySelectorAll('script,style,nav,footer')){e.remove();}
                        final profileCount=_posterEvidence(_compact(profileDoc.body?.text??''),sellerProfile:true);
                        if(profileCount.isNotEmpty){
                          final detailN=int.tryParse(count);
                          final profileN=int.tryParse(profileCount);
                          if(detailN==null || (profileN!=null && profileN>detailN))count=profileCount;
                          countSource='seller_profile_verified';
                        }
                      }
                    }catch(e){notes.add('Không đọc được hồ sơ người đăng: $e');}
                  }
                  enriched=HunterLead(url:lead.url,title:detailTitle,source:lead.source,
                    snippet:lead.snippet,
                    detailText:detailText,
                    posterProfileUrl:sellerProfile,
                    posterCountSource:countSource,
                    queryTarget:lead.queryTarget,discoveredAt:lead.discoveredAt,
                    dateEvidence:_dateEvidence(detailText,domain:domain).isNotEmpty
                      ?_dateEvidence(detailText,domain:domain):lead.dateEvidence,
                    posterCountEvidence:count);
                } else if(detail.statusCode==403||detail.statusCode==429){
                  notes.add('Trang chi tiết giới hạn HTTP ${detail.statusCode}');
                  // Don't spam detail requests after a block.
                  break;
                }
              } catch(e){notes.add('Không đọc được chi tiết: $e');}
            }
            final category=classifyLead(enriched,settings);
            enriched.qualification=category;
            if (category == 'rejected') enriched.status = 'rejected';
            final broker= settings.excludeBroker ? brokerEvidence(enriched) : null;
            enriched.filterReason=broker!=null ? 'Loại vì dấu hiệu môi giới: $broker' :
              category=='qualified'?'Đủ bằng chứng sơ bộ':
              category=='potential'?'Không đạt điều kiện xác minh tự động; chuyển hàng đợi dữ liệu thiếu':'Có điều kiện loại trừ';
            if(seen.add(enriched.id)){
              all.add(enriched);
              if(category=='qualified')domainMatched++;
              if(category=='rejected'){discarded++;domainDiscarded++;}
            }
          }
          // All discovered leads are evaluated; failures remain explicitly unverified.
        } catch(e){notes.add('$page: $e');}
      }
      raw+=domainRaw;
      final status=successful==0?'error':(notes.isNotEmpty?'partial':'ok');
      final summary=notes.isEmpty?'Đã đọc trang công khai':notes.take(4).join(' | ');
      stats.add(SourceScanStat(domain,status,summary,
        raw:domainRaw,matched:domainMatched,discarded:domainDiscarded));
      if(successful==0||notes.isNotEmpty){errors.add('$domain: $summary');}
      if (onProgress!=null) await onProgress(
        'Nguồn $domain: $status · tin thô $domainRaw · loại $domainDiscarded');
    }
    all.sort((a,b)=>relevanceScore(b,settings).compareTo(relevanceScore(a,settings)));
    return HunterSearchResult(all,errors,settings.sites.length,
      discarded:discarded,queries:queries,raw:raw,sources:stats);
  }

  /// Fetch the full detail again just before import, including leads beyond
  /// the first eight scanned per domain. Does not fabricate missing fields.
  Future<HunterLead> fetchDetailForImport(HunterLead lead)async{
    if(!allowedHosts.contains(lead.source))return lead;
    try{
      final response=await client.get(Uri.parse(lead.url),headers:{
        'Accept':'text/html', 'User-Agent':'SourceFlowPersonal/3.0 (public detail reader)',
      }).timeout(const Duration(seconds:15));
      if(response.statusCode!=200)return lead;
      final doc=html_parser.parse(utf8.decode(response.bodyBytes,allowMalformed:true));
      final profile=_sellerProfileUrl(doc,Uri.parse(lead.url),lead.source);
      final detailText=extractDetailText(doc);
                  final detailTitle=extractDetailTitle(doc, lead.title);
      var count=sellerCountOnDetail(doc,lead.source);
      var countSource=count.isNotEmpty?'seller_profile_verified':'';
      if(count.isEmpty){count=lead.posterCountEvidence;countSource=lead.posterCountSource;}
      if(profile.isNotEmpty && countSource!='seller_profile_verified'){
        try{
          await Future<void>.delayed(const Duration(milliseconds:400));
          final sellerResponse=await client.get(Uri.parse(profile),headers:{
            'Accept':'text/html','User-Agent':'SourceFlowPersonal/3.0 (public seller-profile reader)',
          }).timeout(const Duration(seconds:5));
          if(sellerResponse.statusCode==200){
            final sellerDoc=html_parser.parse(utf8.decode(sellerResponse.bodyBytes,allowMalformed:true));
            for(final e in sellerDoc.querySelectorAll('script,style,nav,footer')){e.remove();}
            final evidence=_posterEvidence(_compact(sellerDoc.body?.text??''),sellerProfile:true);
            if(evidence.isNotEmpty){count=evidence;countSource='seller_profile_verified';}
          }
        }catch(_){ /* caller must check seller's count manually */ }
      }
      return HunterLead(url:lead.url,title:detailTitle,source:lead.source,
        snippet:lead.snippet,detailText:detailText.isNotEmpty?detailText:lead.detailText,
        posterProfileUrl:profile.isNotEmpty?profile:lead.posterProfileUrl,
        posterCountEvidence:count,posterCountSource:countSource,
        dateEvidence:_dateEvidence(detailText,domain:lead.source).isNotEmpty
            ?_dateEvidence(detailText,domain:lead.source):lead.dateEvidence,
        queryTarget:lead.queryTarget,discoveredAt:lead.discoveredAt,
        status:lead.status,qualification:lead.qualification,filterReason:lead.filterReason,evidence:lead.evidence,method:lead.method,
        listingId:lead.listingId,reviewNote:lead.reviewNote,reviewedAt:lead.reviewedAt);
    }catch(_){return lead;}
  }

  void close()=>client.close();
}
