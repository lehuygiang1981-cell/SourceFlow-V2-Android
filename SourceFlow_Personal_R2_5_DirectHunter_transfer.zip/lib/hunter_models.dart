import 'models.dart';
import 'legacy_admin.dart';

class HunterLead {
  final String id, url, title, snippet, source, queryTarget;
  final DateTime discoveredAt;
  final DateTime? indexDate;
  /// Facts derived from page body (not a claim of ownership).
  final String dateEvidence, posterCountEvidence, sourceMethod;
  String status, evidence, method, listingId, reviewNote;
  DateTime? reviewedAt;

  HunterLead({required this.url, required this.title, required this.source,
    this.snippet='', this.queryTarget='', DateTime? discoveredAt,
    this.indexDate, String? id, this.dateEvidence='',this.posterCountEvidence='',
    this.sourceMethod='Trang web công khai',this.status='pending',
    this.evidence='',this.method='',this.listingId='',this.reviewNote='',this.reviewedAt})
    : id=id ?? canonicalLeadUrl(url),discoveredAt=discoveredAt??DateTime.now();

  Map<String,dynamic> toJson()=>{
    'id':id,'url':url,'title':title,'snippet':snippet,'source':source,
    'queryTarget':queryTarget,'discoveredAt':discoveredAt.toIso8601String(),
    'indexDate':indexDate?.toIso8601String(),
    'dateEvidence':dateEvidence,'posterCountEvidence':posterCountEvidence,
    'sourceMethod':sourceMethod,'status':status,'evidence':evidence,
    'method':method,'listingId':listingId,'reviewNote':reviewNote,
    'reviewedAt':reviewedAt?.toIso8601String(),
  };
  factory HunterLead.fromJson(Map<String,dynamic> x)=>HunterLead(
    id:'${x['id']??''}',url:'${x['url']??''}',title:'${x['title']??''}',
    snippet:'${x['snippet']??''}',source:'${x['source']??''}',
    queryTarget:'${x['queryTarget']??''}',
    discoveredAt:DateTime.tryParse('${x['discoveredAt']}'),
    indexDate:DateTime.tryParse('${x['indexDate']}'),
    dateEvidence:'${x['dateEvidence']??''}',posterCountEvidence:'${x['posterCountEvidence']??''}',
    sourceMethod:'${x['sourceMethod']??'Trang web công khai'}',
    status:'${x['status']??'pending'}',evidence:'${x['evidence']??''}',
    method:'${x['method']??''}',listingId:'${x['listingId']??''}',
    reviewNote:'${x['reviewNote']??''}',reviewedAt:DateTime.tryParse('${x['reviewedAt']}'),
  );
  ParsedIntake get parsed=>parseIntake('$title\n$snippet');
  List<String> get reviewFlags {
    final content='$title $snippet'.toLowerCase();
    final flags=<String>[];
    if (content.contains('sổ chung')||content.contains('so chung')) flags.add('Có dấu hiệu sổ chung');
    if (['môi giới','ký gửi','chủ gửi','làm việc chính chủ','chủ thiện chí']
        .any(content.contains)) flags.add('Có dấu hiệu trung gian, cần kiểm tra');
    if (dateEvidence.isEmpty) flags.add('Chưa kiểm chứng ngày đăng tại tin gốc');
    if (posterCountEvidence.isEmpty) flags.add('Chưa kiểm tra tổng tin người đăng');
    flags.add('Danh tính và quyền sở hữu chưa được xác minh');
    return flags;
  }
}

String canonicalLeadUrl(String value) {
  final uri=Uri.tryParse(value.trim());
  if(uri==null || (uri.scheme!='https'&&uri.scheme!='http') || uri.host.isEmpty)return '';
  final host=uri.host.toLowerCase().replaceFirst(RegExp(r'^www\.'),'');
  final segments=uri.path.replaceAll(RegExp(r'/+'),'/').replaceFirst(RegExp(r'/$'),'');
  final params=<String,String>{};
  for(final key in ['id','listingId','postId','tin']) {
    if(uri.queryParameters.containsKey(key))params[key]=uri.queryParameters[key]!;
  }
  return Uri(scheme:'https',host:host,path:segments.isEmpty?'/':segments,
    queryParameters:params.isEmpty?null:params).toString();
}

class HunterSettings {
  final String location, keywords, propertyType;
  final List<String> districts, wards, streets, excludedTerms, sites;
  final bool autoScan, excludeBroker, excludeSharedTitle, excludeApartments, ownerHintsOnly;
  final int recentDays, maxPosterListings;
  const HunterSettings({
    this.location='Thành phố Hồ Chí Minh', this.keywords='bán nhà',
    this.propertyType='Tất cả',this.districts=const ['Thành phố Thủ Đức'],
    this.wards=const [],this.streets=const [],this.excludedTerms=const [],
    this.sites=const ['batdongsan.com.vn','nhatot.com','muaban.net','bds68.com.vn','guland.vn'],
    this.autoScan=true,this.recentDays=5,this.maxPosterListings=3,
    this.excludeBroker=false,this.excludeSharedTitle=true,
    this.excludeApartments=false,this.ownerHintsOnly=false,
  });
  /// Legacy helper: older R2 tests/users can still inspect selected locations.
  List<String> get areas => [...districts, ...wards];
  List<String> get targets => [...wards,...streets].toSet().toList();
  Map<String,dynamic> toJson()=>{
    'location':location,'keywords':keywords,'propertyType':propertyType,
    'districts':districts,'wards':wards,'streets':streets,
    'excludedTerms':excludedTerms,'sites':sites,'autoScan':autoScan,
    'recentDays':recentDays,'maxPosterListings':maxPosterListings,
    'excludeBroker':excludeBroker,'excludeSharedTitle':excludeSharedTitle,
    'excludeApartments':excludeApartments,'ownerHintsOnly':ownerHintsOnly,
  };
  factory HunterSettings.fromJson(Map<String,dynamic> x) {
    List<String> sl(String key, List<String> fallback) => x[key] is List
        ? (x[key] as List).whereType<String>().toList() : fallback;
    int positive(String key,int fallback){final p=int.tryParse('${x[key]}');return p!=null&&p>0?p:fallback;}
    // R2.3 location + arbitrary area text are not safe to silently map to
    // checkbox wards. Migrate known ward names only; always show the choices.
    const defaults=['Thành phố Thủ Đức'];
    final legacy=sl('areas',const []);
    final wards=sl('wards',legacy.where((a)=>
      LegacyAdmin.formerThuDucWards.contains(a)).toList());
    final ds=sl('districts', defaults);
    return HunterSettings(
      location:'${x['location']??'Thành phố Hồ Chí Minh'}',
      keywords:'${x['keywords']??'bán nhà'}',
      propertyType:'${x['propertyType']??'Tất cả'}',
      districts:ds,wards:wards,streets:sl('streets',const []),
      excludedTerms:sl('excludedTerms',const []),
      sites:sl('sites',const ['batdongsan.com.vn','nhatot.com','muaban.net','bds68.com.vn','guland.vn']),
      autoScan:x['autoScan']!=false, recentDays:positive('recentDays',5),
      maxPosterListings:positive('maxPosterListings',3),
      excludeBroker:x['excludeBroker']==true,
      excludeSharedTitle:x['excludeSharedTitle']!=false,
      excludeApartments:x['excludeApartments']==true,
      ownerHintsOnly:x['ownerHintsOnly']==true,
    );
  }
}

class SourceScanStat {
  final String domain,status,message;
  final int raw,matched,discarded;
  const SourceScanStat(this.domain,this.status,this.message,{this.raw=0,this.matched=0,this.discarded=0});
  Map<String,dynamic> toJson()=>{'domain':domain,'status':status,'message':message,
      'raw':raw,'matched':matched,'discarded':discarded};
  factory SourceScanStat.fromJson(Map<String,dynamic> x)=>SourceScanStat(
    '${x['domain']??''}','${x['status']??''}','${x['message']??''}',
    raw:(x['raw'] as num?)?.toInt()??0,matched:(x['matched'] as num?)?.toInt()??0,
    discarded:(x['discarded'] as num?)?.toInt()??0);
}
class HunterSnapshot {
  final int total,pending,confirmed,rejected;
  final DateTime? lastScan;
  final String message;
  final List<String> errors;
  final List<SourceScanStat> sources;
  const HunterSnapshot({this.total=0,this.pending=0,this.confirmed=0,
    this.rejected=0,this.lastScan,this.message='',this.errors=const [],this.sources=const []});
}
