import 'dart:async';
import 'dart:convert';
import 'package:html/parser.dart' as html_parser;
import 'package:html/dom.dart' as dom;
import 'package:http/http.dart' as http;
import 'hunter_models.dart';
import 'legacy_admin.dart';

/// Direct public-HTML source connectors (no Bing, Google, proxy or CAPTCHA bypass).
/// An unsupported/blocked site is reported as an ERROR, never as zero listings.
class HunterSearchResult {
  final List<HunterLead> leads;
  final List<String> errors;
  final int searched, discarded, queries, raw;
  final List<SourceScanStat> sources;
  const HunterSearchResult(this.leads,this.errors,this.searched,{
    this.discarded=0,this.queries=0,this.raw=0,this.sources=const []});
}

class DirectSource {
  final String domain;
  final Uri thuDucUrl, cityUrl;
  const DirectSource(this.domain,this.thuDucUrl,this.cityUrl);
}

class HunterSearch {
  final http.Client client;
  HunterSearch({http.Client? client}): client=client??http.Client();
  static const allowedHosts={
    'batdongsan.com.vn','nhatot.com','muaban.net','bds68.com.vn','guland.vn'
  };
  static final directSources=<String,DirectSource>{
    'nhatot.com':DirectSource('nhatot.com',
      Uri.parse('https://www.nhatot.com/mua-ban-nha-dat-thanh-pho-thu-duc-tp-ho-chi-minh'),
      Uri.parse('https://www.nhatot.com/mua-ban-nha-dat-tp-ho-chi-minh')),
    'batdongsan.com.vn':DirectSource('batdongsan.com.vn',
      Uri.parse('https://batdongsan.com.vn/ban-nha-rieng-thu-duc'),
      Uri.parse('https://batdongsan.com.vn/ban-nha-rieng-tp-hcm')),
    'muaban.net':DirectSource('muaban.net',
      Uri.parse('https://muaban.net/bat-dong-san/ban-nha-quan-thu-duc-ho-chi-minh'),
      Uri.parse('https://muaban.net/bat-dong-san/ban-nha-ho-chi-minh')),
    'bds68.com.vn':DirectSource('bds68.com.vn',
      Uri.parse('https://bds68.com.vn/nha-dat-ban/ho-chi-minh/thu-duc'),
      Uri.parse('https://bds68.com.vn/nha-dat-ban/ho-chi-minh')),
    'guland.vn':DirectSource('guland.vn',
      Uri.parse('https://guland.vn/mua-ban-bat-dong-san-thanh-pho-thu-duc-tp-ho-chi-minh'),
      Uri.parse('https://guland.vn/bat-dong-san/tp-ho-chi-minh')),
  };

  static String fold(String value){
    var s=value.toLowerCase().replaceAll('đ','d');
    const accentGroups={
      'a':'àáạảãâầấậẩẫăằắặẳẵ',
      'e':'èéẹẻẽêềếệểễ',
      'i':'ìíịỉĩ',
      'o':'òóọỏõôồốộổỗơờớợởỡ',
      'u':'ùúụủũưừứựửữ',
      'y':'ỳýỵỷỹ',
    };
    for(final entry in accentGroups.entries){
      for(final ch in entry.value.split('')){s=s.replaceAll(ch,entry.key);}
    }
    return s.replaceAll(RegExp(r'\s+'),' ').trim();
  }
  static bool directSourceUrl(String link,String domain){
    final uri=Uri.tryParse(link);
    if(uri==null||!['https','http'].contains(uri.scheme))return false;
    final host=uri.host.toLowerCase();
    return (host==domain||host.endsWith('.$domain'))&&uri.path.length>1;
  }
  static bool _listingPath(Uri uri,String domain){
    final path=uri.path.toLowerCase();
    switch(domain){
      case 'nhatot.com':return RegExp(r'/\d{7,}\.htm$').hasMatch(path);
      case 'batdongsan.com.vn':return RegExp(r'-pr\d+').hasMatch(path);
      case 'muaban.net':return RegExp(r'-id\d+').hasMatch(path);
      case 'bds68.com.vn':return (path.contains('ban-')||path.contains('/nha-dat-ban/'))&&
        (RegExp(r'\d{5,}').hasMatch(path)||path.endsWith('.html'));
      case 'guland.vn':return (path.contains('/bat-dong-san/')||path.contains('/mua-ban-'))&&
        (RegExp(r'\d{5,}').hasMatch(path)||RegExp(r'/ban-[^/]{18,}').hasMatch(path));
      default:return false;
    }
  }

  static String _compact(String value)=>value.replaceAll(RegExp(r'\s+'),' ').trim();
  static bool _isMarketing(String value){
    final folded=fold(value);
    return RegExp(r'^(trang chu|tin tuc|tim kiem|dang nhap|xem them|mua ban|xem chi tiet)$')
      .hasMatch(folded);
  }

  /// Extract only direct links from server-rendered listing pages; never
  /// fabricate URLs when the page is JS-only or changes its structure.
  static List<HunterLead> parseListingHtml(String rawHtml,Uri page,String domain,
    {DateTime? now}){
    final document=html_parser.parse(rawHtml);
    final byUrl=<String,HunterLead>{};
    for(final a in document.querySelectorAll('a[href]')){
      final href=a.attributes['href']??'';
      Uri uri;
      try{uri=page.resolve(href);}catch(_){continue;}
      if(!directSourceUrl(uri.toString(),domain)||!_listingPath(uri,domain))continue;
      final titleNode=a.querySelector('h2,h3,h4,strong');
      final rawTitle=(titleNode?.text.isNotEmpty==true ? titleNode!.text
          : (a.attributes['title']??a.attributes['aria-label']??a.text));
      var title=_compact(rawTitle);
      if(title.length<12){
        final alt=a.querySelector('img')?.attributes['alt']??'';
        title=_compact(alt);
      }
      if(title.length<12||_isMarketing(title))continue;
      if(title.length>240)title=title.substring(0,240);
      final key=canonicalLeadUrl(uri.toString());
      if(key.isEmpty||byUrl.containsKey(key))continue;
      // The nearest card is intentionally bounded; never merge other listing
      // cards into this item's text by climbing into the document body.
      dom.Element? card=a;
      for(var i=0;i<4 && card?.parent!=null;i++){
        final parent=card!.parent!;
        if(['body','html','main'].contains(parent.localName))break;
        if(parent.text.length>1200)break;
        card=parent;
        if(['article','li'].contains(parent.localName))break;
      }
      var snippet=_compact(card?.text??title);
      if(snippet.length>600)snippet=snippet.substring(0,600);
      byUrl[key]=HunterLead(url:uri.toString(),title:title,snippet:snippet,
        source:domain,queryTarget:page.toString(),discoveredAt:now,
        posterCountEvidence:_posterEvidence(snippet),
        dateEvidence:_dateEvidence(snippet));
    }
    return byUrl.values.toList();
  }

  static String _dateEvidence(String text){
    final match=RegExp(r'(?:Đăng(?: ngày)?|Ngày bắt đầu|Ngày đăng)\s*:?\s*(\d{1,2}/\d{1,2}/\d{4})',
      caseSensitive:false).firstMatch(text);
    return match?.group(1)??'';
  }
  static String _posterEvidence(String text){
    final match=RegExp(r'(\d{1,4})\s*tin\s*(?:đăng)?',caseSensitive:false).firstMatch(text);
    return match?.group(1)??'';
  }
  static DateTime? _dateFromEvidence(String evidence){
    final m=RegExp(r'^(\d{1,2})/(\d{1,2})/(\d{4})$').firstMatch(evidence);
    if(m==null)return null;
    final d=int.parse(m.group(1)!);final month=int.parse(m.group(2)!);
    final y=int.parse(m.group(3)!);
    final date=DateTime(y,month,d);
    return date.year==y&&date.month==month&&date.day==d?date:null;
  }

  static bool matchesCriteria(HunterLead lead,HunterSettings settings){
    final text=fold('${lead.title} ${lead.snippet}');
    if(settings.excludedTerms.any((t)=>t.trim().isNotEmpty&&text.contains(fold(t))))return false;
    if(settings.excludeSharedTitle &&
      ['so chung','dong so huu','vi bang'].any(text.contains))return false;
    if(settings.excludeApartments && ['chung cu','can ho'].any(text.contains))return false;
    if(settings.excludeBroker &&
      ['ky gui','chu gui','nhan ky gui','lam viec chinh chu','chu thien chi','hoa hong moi gioi']
       .any(text.contains))return false;
    if(text.contains('cho thue')&&!text.contains('ban'))return false;
    if(settings.propertyType=='Nhà xưởng'&&
       !['nha xuong','kho xuong','kho bai'].any(text.contains))return false;
    if(settings.propertyType=='Đất'&&
       !['dat ','ban dat','dat nen','lo dat'].any(text.contains))return false;
    // Do not require literal "chính chủ": otherwise genuine owner ads vanish.
    // Poster count unknown remains pending. Positive evidence >limit can exclude.
    final post=int.tryParse(lead.posterCountEvidence);
    if(post!=null && post>settings.maxPosterListings)return false;
    final date=_dateFromEvidence(lead.dateEvidence);
    if(date!=null && DateTime.now().difference(date).inDays>settings.recentDays)return false;
    if(settings.wards.isNotEmpty){
      final wanted=settings.wards.map((w)=>w.contains(' · ')?w.split(' · ').last:w)
        .map(fold).toList();
      if(!wanted.any(text.contains)){
        // Only reject when the page explicitly names another known ward.
        // Missing address details must stay pending rather than disappear.
        final namedOther=LegacyAdmin.formerThuDucWards.any((w)=>
          text.contains('phuong ${fold(w)}') && !wanted.contains(fold(w)));
        if(namedOther)return false;
      }
    } else if(settings.districts.isNotEmpty && !settings.districts.contains(LegacyAdmin.thuDuc)){
      if(!settings.districts.any((d)=>text.contains(fold(d))))return false;
    }
    // A street is a PRIORITY hint; missing OCR/address text is not proof of
    // mismatch and must not silently eliminate the entire source.
    return true;
  }

  static int relevanceScore(HunterLead lead,HunterSettings s){
    final text=fold('${lead.title} ${lead.snippet}');
    var score=0;
    if(s.streets.any((x)=>x.trim().isNotEmpty&&text.contains(fold(x))))score+=5;
    if(s.keywords.trim().isNotEmpty&&text.contains(fold(s.keywords)))score+=2;
    if(s.ownerHintsOnly &&
      ['chinh chu','mien trung gian','toi ban'].any(text.contains))score+=3;
    if(lead.posterCountEvidence.isNotEmpty)score++;
    return score;
  }

  /// Read public listing page, then detail pages for available evidence.
  /// Slow down requests (per domain) and stop on 403/429; never bypass blocks.
  Future<HunterSearchResult> scan(HunterSettings settings)async{
    final all=<HunterLead>[];
    final errors=<String>[];
    final stats=<SourceScanStat>[];
    final seen=<String>{};
    var queries=0,discarded=0,raw=0;
    for(final domain in settings.sites.toSet()){
      final adapter=directSources[domain];
      if(adapter==null){errors.add('$domain: không hỗ trợ');
        stats.add(SourceScanStat(domain,'unsupported','Không có bộ kết nối'));continue;}
      final includeThuDuc=settings.districts.isEmpty||settings.districts.contains(LegacyAdmin.thuDuc);
      final includeOther=settings.districts.any((d)=>d!=LegacyAdmin.thuDuc);
      final pages=<Uri>[if(includeThuDuc)adapter.thuDucUrl,if(includeOther)adapter.cityUrl];
      var domainRaw=0,domainMatched=0,domainDiscarded=0;
      var successful=0;
      final notes=<String>[];
      for(final page in pages){
        queries++;
        try{
          final response=await client.get(page,headers:{
            'Accept':'text/html,application/xhtml+xml',
            'User-Agent':'SourceFlowPersonal/2.5 (+public listing reader; contact via app)',
          }).timeout(const Duration(seconds:18));
          if(response.statusCode==403||response.statusCode==429){
            throw StateError('HTTP ${response.statusCode}: nguồn giới hạn truy cập, không bỏ qua bảo vệ');
          }
          if(response.statusCode!=200)throw StateError('HTTP ${response.statusCode}');
          final body=utf8.decode(response.bodyBytes,allowMalformed:true);
          if(!body.toLowerCase().contains('<html'))throw const FormatException('Không nhận được HTML');
          final hits=parseListingHtml(body,page,domain);
          if(hits.isEmpty)throw const FormatException('Không trích xuất được link tin; website có thể thay đổi HTML hoặc tải bằng JavaScript');
          successful++;
          domainRaw+=hits.length;
          // Inspect a bounded number of public detail pages: dates and poster
          // counts are evidence only when actually present on page content.
          for(var i=0;i<hits.length&&i<30;i++){
            final lead=hits[i];
            HunterLead enriched=lead;
            if(i<8){
              try{
                await Future<void>.delayed(const Duration(milliseconds:400));
                final detail=await client.get(Uri.parse(lead.url),headers:{
                  'Accept':'text/html','User-Agent':'SourceFlowPersonal/2.5 (public listing reader)',
                }).timeout(const Duration(seconds:12));
                if(detail.statusCode==200){
                  final doc=html_parser.parse(utf8.decode(detail.bodyBytes,allowMalformed:true));
                  // Exclude header/nav/footer before extracting body information.
                  for(final selector in ['script','style','nav','footer']){
                    for(final e in doc.querySelectorAll(selector)){e.remove();}
                  }
                  var detailText=_compact(doc.body?.text??'');
                  if(detailText.length>6500)detailText=detailText.substring(0,6500);
                  enriched=HunterLead(url:lead.url,title:lead.title,source:lead.source,
                    snippet:'${lead.snippet}\n${detailText.length>900?detailText.substring(0,900):detailText}',
                    queryTarget:lead.queryTarget,discoveredAt:lead.discoveredAt,
                    dateEvidence:_dateEvidence(detailText).isNotEmpty
                      ?_dateEvidence(detailText):lead.dateEvidence,
                    posterCountEvidence:_posterEvidence(detailText).isNotEmpty
                      ?_posterEvidence(detailText):lead.posterCountEvidence);
                } else if(detail.statusCode==403||detail.statusCode==429){
                  notes.add('Trang chi tiết giới hạn HTTP ${detail.statusCode}');
                  // Don't spam detail requests after a block.
                  break;
                }
              } catch(e){notes.add('Không đọc được chi tiết: $e');}
            }
            if(matchesCriteria(enriched,settings)){
              if(seen.add(enriched.id)){all.add(enriched);domainMatched++;}
            }else{discarded++;domainDiscarded++;}
          }
          if(hits.length>30)notes.add('Giới hạn xử lý 30 tin/lượt để tránh tải quá nhiều');
        } catch(e){notes.add('$page: $e');}
      }
      raw+=domainRaw;
      final status=successful==0?'error':(notes.isNotEmpty?'partial':'ok');
      final summary=notes.isEmpty?'Đã đọc trang công khai':notes.take(4).join(' | ');
      stats.add(SourceScanStat(domain,status,summary,
        raw:domainRaw,matched:domainMatched,discarded:domainDiscarded));
      if(successful==0||notes.isNotEmpty){errors.add('$domain: $summary');}
    }
    all.sort((a,b)=>relevanceScore(b,settings).compareTo(relevanceScore(a,settings)));
    return HunterSearchResult(all,errors,settings.sites.length,
      discarded:discarded,queries:queries,raw:raw,sources:stats);
  }
  void close()=>client.close();
}
