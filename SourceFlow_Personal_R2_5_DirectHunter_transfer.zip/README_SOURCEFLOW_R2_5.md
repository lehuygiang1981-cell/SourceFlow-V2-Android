# SourceFlow Personal R2.5 — Direct Hunter & OCR (mã nguồn Flutter)

## Nội dung

Bản này nâng cấp từ SourceFlow Personal R2.3, **chưa phải APK đã kiểm nghiệm trên điện thoại**.

- `lib/hunter_search.dart`: năm bộ kết nối HTML công khai cho Nhà Tốt, Batdongsan.com.vn, Muaban.net, BĐS68 và Guland; không gửi truy vấn tìm kiếm sang Bing RSS. Truy cập trang danh sách và một số trang chi tiết công khai; lưu URL gốc, ghi HTTP error/HTML không hỗ trợ, không vượt CAPTCHA hoặc giới hạn của website.
- `lib/legacy_admin.dart`, `lib/hunter_page.dart`: thành phố mặc định TP.HCM, 22 đơn vị quận/huyện/TP Thủ Đức theo địa giới cũ; chọn nhiều quận và nhiều phường/xã bằng dấu tích; 34 phường thuộc TP Thủ Đức có sẵn ngoại tuyến. Danh mục phường/xã ngoài Thủ Đức tải khi mở bộ chọn từ dịch vụ danh mục công khai và được cache trong SQLite. Đường/địa điểm ưu tiên vẫn nhập dạng nhiều dòng.
- `lib/hunter_models.dart`: tương thích cấu hình cũ, phân biệt tin *ứng viên chờ kiểm tra* với tài sản đã được người dùng xác minh. Không yêu cầu tin nhất thiết chứa chữ “chính chủ”. Không khẳng định ngày đăng/tổng tin người đăng nếu thiếu bằng chứng.
- `lib/hunter_storage.dart`: giữ nguyên file SQLite `sourceflow_hunter.sqlite` và các bảng leads/settings; tạo bổ sung bảng `scan_history` nếu chưa có, lưu 100 phiên gần nhất, theo dõi lỗi, số tin thô và kết quả từng website. Giữ kết nối riêng giữa tác vụ nền và giao diện.
- `lib/main.dart`, `lib/models.dart`: bảo tồn toàn văn OCR gốc, phân tích bản OCR gợi ý riêng. Cải thiện trường điện thoại đầy đủ, chiều ngang/dài, diện tích, giá; sửa một số nhãn trường dễ nhầm. Không bịa các chữ số bị che, không tự suy ra chiều ngang/dài từ diện tích, không sửa tên đường hay chủ sở hữu tùy tiện.
- `lib/hunter_worker.dart`: giữ WorkManager khoảng 2 giờ/lần và quét bù khi mở ứng dụng. Android không đảm bảo lịch đúng phút khi app ở nền.

## Biên dịch APK bằng GitHub Actions

1. Upload nguyên tệp `SourceFlow_Personal_R2_5_DirectHunter_transfer.zip` vào **thư mục gốc** của repository GitHub `SourceFlow-V2-Android` trên nhánh `main`. **Không giải nén** file ZIP lên kho.
2. Upload riêng file `SourceFlow_Personal_R2_5_workflow.yml` vào `.github/workflows/` (không phải thư mục gốc).
3. Tại tab **Actions**, chọn **SourceFlow Personal R2.5 - Direct Hunter Android APK**. Workflow có thể tự chạy sau push hoặc chọn **Run workflow**.
4. Workflow `flutter analyze`, `flutter test`, và `flutter build apk --release` trước khi xuất artifact `SourceFlow-Personal-R2.5-DirectHunter-APK` chứa `app-release.apk`.
5. **Sao lưu dữ liệu cũ** và xác nhận chữ ký APK trước khi cài đè; không gỡ app đang có dữ liệu chỉ vì hiện lỗi xung đột chữ ký.

## Khả năng và giới hạn — cần kiểm thử bắt buộc

1. Website có thể thay đổi đường dẫn, cấu trúc HTML, tải nội dung bằng JavaScript hoặc trả 403/429. Bộ quét chỉ truy cập trang HTML công khai ở mức nhẹ, không qua cơ chế bảo vệ. Lúc đó nguồn phải hiện ERROR/PARTIAL và **không được coi 0 tin là không có tin đăng**.
2. Bộ kết nối ban đầu dùng trang danh sách theo địa bàn Thủ Đức và TP.HCM. Lựa chọn từng phường/tuyến đường chủ yếu giúp **phân loại và ưu tiên** trong tin thu về; **chưa đảm bảo bao phủ toàn bộ từng phường**, đặc biệt với website chỉ có nội dung tải động. Cần kiểm thử và bổ sung adapter theo nguồn khi website cho phép.
3. Ngày đăng và số lượng tin/người chỉ lọc khi trang gốc thực sự có bằng chứng. Thiếu dữ liệu thì ghi chờ kiểm, không loại. Nội dung xác nhận “chính chủ” luôn cần người dùng kiểm chứng.
4. Nguồn data phường ngoài Thủ Đức đến từ một API công khai bên thứ ba, có thể ngừng cung cấp hoặc đổi cấu trúc, khi đó hiển thị lỗi/đọc cache. 34 phường Thủ Đức cũ được đóng gói sẵn.
5. OCR/ML Kit cần đánh giá bằng ảnh thực tế: số điện thoại (đủ 10 số), kích thước, đơn giá, diện tích. Độ chính xác có thể thay đổi theo chất lượng ảnh/nguồn.
6. Môi trường tạo gói ZIP chưa có Flutter/Android SDK nên **chưa chạy được `flutter test`, `flutter analyze`, hay build APK**. Github Actions ở trên dùng để xác minh build tự động, có thể cần sửa thêm nếu kiểm thử báo lỗi.
7. Mã nguồn giả định `scripts/prepare_android.ps1` chuẩn bị Android project giống các phiên bản trước. Nếu ký bằng khóa phát triển khác khóa bản R2.3, bản mới có thể không cài đè trực tiếp.

## Kiểm tra sau khi cài

- Quét thủ công một nguồn (chọn Nhà Tốt) và xem mục **Nhật ký theo website**: `OK`, `PARTIAL` hay `ERROR`, tổng tin thô và lý do lỗi.
- Thử chọn Thủ Đức rồi đánh dấu 2–3 phường. Lưu cài đặt, đóng và mở app lại để kiểm tra vẫn giữ các dấu tích.
- Chụp/sử dụng một ảnh chứa `SĐT: 0901 234 567`, `ngang 5,5m`, `dài 20m`, `diện tích 110 m²`, `giá 15,5 tỷ`; xác nhận gợi ý, sửa trước khi lưu.
- Đối chiếu 30–50 tin thực theo từng website (nguồn và URL trực tiếp). Đánh dấu lỗi adapter thay vì tuyên bố tin không có.

## Bảo vệ dữ liệu

SQLite offline là nguồn lưu trữ chính. Không thay thế file database hiện có. Chỉ thêm bảng lịch sử quét và khóa cache tên phường. Trước khi nâng cấp vẫn nên sao lưu dữ liệu hiện tại.
