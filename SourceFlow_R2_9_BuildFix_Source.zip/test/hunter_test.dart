import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:sourceflow_android/hunter_models.dart';
import 'package:sourceflow_android/hunter_search.dart';
import 'package:sourceflow_android/legacy_admin.dart';

const listingHtml='''<html><body>
<article><a href="/mua-ban-nha-dat-thanh-pho-thu-duc-tp-ho-chi-minh/133081800.htm">
<h3>Chính chủ bán nhà mặt tiền Đường 23, Hiệp Bình Chánh 64m²</h3></a>
<p>Phường Hiệp Bình Chánh, Thủ Đức · 2,5 tỷ · 1 tin đăng</p></article>
<article><a href="https://www.nhatot.com/mua-ban-nha-dat-thanh-pho-thu-duc-tp-ho-chi-minh/133081800.htm?utm_source=foo">
<h3>Chính chủ bán nhà mặt tiền Đường 23, Hiệp Bình Chánh 64m²</h3></a></article>
<a href="/mua-ban-nha-dat-thanh-pho-thu-duc-tp-ho-chi-minh">Danh mục</a>
<a href="https://example.com/a">Tin ngoài</a>
</body></html>''';

void main(){
 test('34 phường cũ Thành phố Thủ Đức không bị trùng',(){
   expect(LegacyAdmin.formerThuDucWards.length,34);
   expect(LegacyAdmin.formerThuDucWards.toSet().length,34);
   expect(LegacyAdmin.districtList.length,22);
 });
 test('Trích HTML công khai trực tiếp và loại liên kết ngoài/trùng',(){
   final found=HunterSearch.parseListingHtml(listingHtml,
      Uri.parse('https://www.nhatot.com/mua-ban-nha-dat-thanh-pho-thu-duc-tp-ho-chi-minh'),
      'nhatot.com');
   expect(found.length,1);
   expect(found.single.url,contains('133081800.htm'));
   expect(found.single.status,'pending');
 });
 test('Không bắt buộc chữ chính chủ',(){
   const config=HunterSettings();
   final lead=HunterLead(url:'https://www.nhatot.com/test/133081800.htm',
      title:'Bán nhà Hiệp Bình Chánh, 64m2',source:'nhatot.com');
   expect(HunterSearch.matchesCriteria(lead,config),isFalse);
   expect(lead.evidence,isEmpty);
 });
 test('Loại sổ chung và thiếu ngày/tin/người',(){
   const config=HunterSettings();
   final lead=HunterLead(url:'https://www.nhatot.com/test/133081801.htm',
      title:'Bán nhà sổ chung, Bình Chiểu',source:'nhatot.com');
   expect(HunterSearch.matchesCriteria(lead,config),isFalse);
   final missing=HunterLead(url:'https://www.nhatot.com/test/133081802.htm',
      title:'Nhà Bình Chiểu 70m²',source:'nhatot.com');
   expect(HunterSearch.matchesCriteria(missing,config),isFalse);
 });
 test('Không còn gửi yêu cầu qua Bing',()async{
   final requested=<Uri>[];
   final fake=MockClient((req)async{
     requested.add(req.url);
     if(req.url.path.endsWith('133081800.htm')){
       return http.Response('<html><body>1 tin đăng</body></html>',200,headers:{'content-type':'text/html; charset=utf-8'});
     }
     return http.Response(listingHtml,200,headers:{'content-type':'text/html; charset=utf-8'});
   });
   final service=HunterSearch(client:fake);
   final result=await service.scan(const HunterSettings(sites:['nhatot.com'],
      districts:['Thành phố Thủ Đức'],wards:[]));
   expect(result.raw,1);
   // R2.9 retains incomplete listings as potential rather than discarding them.
   expect(result.leads.length,1);
   expect(result.leads.single.qualification,'potential');
   expect(result.sources.single.status,'ok');
   expect(requested.any((u)=>u.host.contains('bing.com')),isFalse);
   service.close();
 });
 test('Cấu hình lưu và khôi phục nhiều quận/phường',(){
   const settings=HunterSettings(districts:['Thành phố Thủ Đức','Quận 1'],
      wards:['Linh Xuân','Quận 1 · Bến Nghé'],streets:['Ka Vạn Cân']);
   final again=HunterSettings.fromJson(settings.toJson());
   expect(again.districts.length,2);expect(again.wards.length,2);
   expect(again.streets,['Ka Vạn Cân']);
 });
}
