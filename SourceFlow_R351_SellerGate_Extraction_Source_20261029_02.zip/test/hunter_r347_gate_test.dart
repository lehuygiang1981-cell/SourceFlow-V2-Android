import 'package:flutter_test/flutter_test.dart';
import 'package:sourceflow_android/hunter_search.dart';
import 'package:sourceflow_android/hunter_models.dart';

void main(){
  HunterLead make({String date='',String count='',String source=''})=>HunterLead(
    url:'https://bds68.com.vn/ban-nha-pr31338208',source:'bds68.com.vn',
    title:'Bán nhà Quốc lộ 13',dateEvidence:date,posterCountEvidence:count,
    posterCountSource:source);
  test('8 verified posts rejects even without date or details',(){
    expect(HunterSearch.classifyLead(make(count:'8',source:'seller_profile_verified'),const HunterSettings()),'rejected');
  });
  test('old post rejects even when poster count is unknown',(){
    expect(HunterSearch.classifyLead(make(date:'14/10/2026'),const HunterSettings()),'rejected');
  });
  test('missing evidence is pending, never qualified',(){
    expect(HunterSearch.classifyLead(make(),const HunterSettings()),'potential');
  });
  test('canonical duplicate urls have same id',(){
    final a=make();
    final b=HunterLead(url:'http://www.bds68.com.vn/ban-nha-pr31338208?utm_source=abc',source:'bds68.com.vn',title:'Bán nhà');
    expect(a.id,b.id);
  });
}
