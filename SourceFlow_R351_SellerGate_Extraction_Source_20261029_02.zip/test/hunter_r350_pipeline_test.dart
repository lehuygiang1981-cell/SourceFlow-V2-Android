import 'package:flutter_test/flutter_test.dart';
import 'package:html/parser.dart' as html;
import 'package:sourceflow_android/hunter_models.dart';
import 'package:sourceflow_android/hunter_search.dart';

void main(){
  HunterLead lead(String text)=>HunterLead(url:'https://bds68.com.vn/ban-nha-pr12345678',
    source:'bds68.com.vn',title:'Bán nhà tại Thủ Đức',detailText:text);
  test('broker intermediary at bottom of description',(){
    expect(HunterSearch.brokerEvidence(lead('Chủ nhà cần bán gấp. Giá bán 29.5 tỷ thương lượng trực tiếp với chủ nhà. Liên hệ em Lợi Vạn Phúc City. Hỗ trợ xem nhà thực tế 24/7.')),isNotNull);
  });
  test('external brokerage portfolio advertising',(){
    expect(HunterSearch.brokerEvidence(lead('Bán nhà Hiệp Bình 93m2. Xem thêm nhà phố tại Đầu Đất Nè https://daudat.vercel.app')),isNotNull);
  });
  test('owner selling without broker is not rejected',(){
    expect(HunterSearch.brokerEvidence(lead('Chính chủ bán nhà, miễn môi giới, không tiếp môi giới.')),isNull);
  });
  test('structured Muaban-like fields map to correct columns',(){
    final doc=html.parse('''<html><body><main><h1>Bán nhà nguyên căn</h1><div>Địa chỉ: 171, Đường Lê Thị Hoa, Phường Bình Chiểu, Thành phố Thủ Đức</div><div>Giá bán: 10,3 tỷ</div><div>Diện tích đất: 150 m² (5.0x30.0)</div><article><p>Nhà 3PN, 11 phòng trọ cho thuê, thu nhập 25tr/tháng.</p></article></main></body></html>''');
    final text=HunterSearch.extractDetailText(doc);
    final parsed=lead(text).parsed;
    expect(parsed.address,contains('Lê Thị Hoa'));
    expect(parsed.price,contains('10,3'));
    expect(parsed.width,contains('5.0'));
    expect(parsed.length,contains('30.0'));
  });
}
