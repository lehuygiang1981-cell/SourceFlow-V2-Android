import 'package:flutter_test/flutter_test.dart';
import 'package:html/parser.dart' as html;
import 'package:sourceflow_android/hunter_search.dart';

void main() {
  test('BDS68 seller 25 listings is recognized', () {
    final doc = html.parse('<section><div>Huong</div><div>Tổng số tin đăng <strong>25</strong></div></section>');
    expect(HunterSearch.sellerCountOnDetail(doc,'bds68.com.vn'), '25');
  });
  test('BDS68 seller 1 listing is recognized', () {
    final doc = html.parse('<section><div>Lê Nhi</div><span>Tổng số tin đăng</span><b>1</b></section>');
    expect(HunterSearch.sellerCountOnDetail(doc,'bds68.com.vn'), '1');
  });
  test('Unrelated site text must not be certified as seller count', () {
    final doc = html.parse('<main><div>Đã đăng 25 tin khác</div></main>');
    expect(HunterSearch.sellerCountOnDetail(doc,'bds68.com.vn'), '');
  });
  test('Detail fields include labeled date and address', () {
    final doc=html.parse('<main><div>Ngày Đăng: 29/10/2026 - 05/11/2026</div><div>Địa chỉ: Đường Số 1, Phường Hiệp Bình Phước</div><div>Chiều ngang: 5</div><div>Chiều dài: 21.5</div></main>');
    final result=HunterSearch.extractDetailText(doc);
    expect(result,contains('Ngày Đăng: 29/10/2026'));
    expect(result,contains('Địa chỉ: Đường Số 1'));
  });
}
