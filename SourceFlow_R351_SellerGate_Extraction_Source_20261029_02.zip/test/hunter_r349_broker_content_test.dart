import 'package:flutter_test/flutter_test.dart';
import 'package:sourceflow_android/hunter_search.dart';
import 'package:sourceflow_android/hunter_models.dart';

void main() {
  HunterLead lead(String body) => HunterLead(
    url: 'https://bds68.com.vn/ban-nha-pr12345678',
    source: 'bds68.com.vn',
    title: 'Bán nhà Thủ Đức',
    detailText: body,
  );
  test('reject explicit owner intermediary phrase', () {
    final x=lead('Bán nhà 80m2, làm việc trực tiếp chính chủ, liên hệ em dẫn xem nhà');
    expect(HunterSearch.brokerEvidence(x), isNotNull);
    expect(HunterSearch.classifyLead(x,const HunterSettings()), 'rejected');
  });
  test('reject brokerage portfolio and consignment', () {
    expect(HunterSearch.brokerEvidence(lead('Nhận ký gửi nhà đất, còn nhiều căn cùng khu vực')),isNotNull);
  });
  test('do not reject direct owner or anti-broker notices', () {
    expect(HunterSearch.brokerEvidence(lead('Chính chủ bán nhà 80m2, miễn môi giới, không tiếp môi giới')),isNull);
  });
  test('unknown evidence remains pending', () {
    expect(HunterSearch.classifyLead(lead('Gia đình tôi cần bán căn nhà đang ở, diện tích 80m2.'),const HunterSettings()),'potential');
  });
  test('hard gate of 8 posts still rejects', () {
    final x=HunterLead(url:'https://bds68.com.vn/pr31338208',source:'bds68.com.vn',title:'Bán nhà',posterCountEvidence:'8',posterCountSource:'seller_profile_verified');
    expect(HunterSearch.classifyLead(x,const HunterSettings()),'rejected');
  });
}
