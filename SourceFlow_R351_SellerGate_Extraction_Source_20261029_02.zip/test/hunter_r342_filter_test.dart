import 'package:flutter_test/flutter_test.dart';
import 'package:html/parser.dart' as html_parser;
import 'package:sourceflow_android/hunter_search.dart';
import 'package:sourceflow_android/hunter_models.dart';

void main() {
  HunterLead lead(String t) => HunterLead(url: 'https://bds68.com.vn/ban-nha/example', source: 'bds68.com.vn', title: 'Bán nhà tại Thủ Đức', detailText: t);
  test('BDS68 seller card with 8 posts is extracted and rejected', () {
    final doc=html_parser.parse('<html><body><section><h3>PHẠM VĂN HUYỀN</h3><div>Tổng số tin đăng <b>8</b></div></section></body></html>');
    final count=HunterSearch.sellerCountOnDetail(doc,'bds68.com.vn');
    expect(count,'8');
    final x=HunterLead(url:'https://bds68.com.vn/ban-nha-rieng/ho-chi-minh/thu-duc/ban-nha-pr31338208',
      source:'bds68.com.vn',title:'Bán nhà Quốc lộ 13',
      detailText:'Bán nhà 3 tầng diện tích 60m2 sổ hồng riêng tại Hiệp Bình Phước',
      dateEvidence:'27/10/2026',posterCountEvidence:count,posterCountSource:'seller_profile_verified');
    expect(HunterSearch.classifyLead(x,const HunterSettings()),'rejected');
  });
  test('unrelated page number must not be interpreted as seller count', () {
    final doc=html_parser.parse('<html><body><div>8 phòng ngủ</div><div>Giá 8 tỷ</div></body></html>');
    expect(HunterSearch.sellerCountOnDetail(doc,'bds68.com.vn'),'');
  });
  test('broker signal at end of description is detected', () {
    expect(HunterSearch.brokerEvidence(lead('Nhà đẹp. Làm việc chính chủ')), isNotNull);
  });
  test('broker signal in middle of description is detected', () {
    expect(HunterSearch.brokerEvidence(lead('Nhận ký gửi nhà đất, giá tốt')), isNotNull);
  });
  test('broker account name detected', () {
    expect(HunterSearch.brokerEvidence(lead('Liên hệ hungthinhvuongrealty167')), isNotNull);
  });
  test('numeric real estate seller handle is rejected', () {
    expect(HunterSearch.brokerEvidence(lead('Nguyễn Hoàng Mỹ Tiên hungthinhvuongreal167')), isNotNull);
  });
  test('ordinary real word does not trigger broker rejection', () {
    expect(HunterSearch.brokerEvidence(lead('Nhà thật, hình real 100%, gia đình tự bán')), isNull);
  });
  test('plain direct seller not rejected', () {
    expect(HunterSearch.brokerEvidence(lead('Tôi bán căn nhà của gia đình, địa chỉ rõ ràng')), isNull);
  });
  test('verified seller with four listings is rejected', () {
    final x=HunterLead(url:'https://bds68.com.vn/ban-nha/123456.html',source:'bds68.com.vn',
      title:'Bán nhà Thủ Đức',detailText:'Nhà gia đình đang bán, diện tích 100 m2, sổ riêng',
      posterCountSource:'seller_profile_verified',posterCountEvidence:'4');
    expect(HunterSearch.classifyLead(x,const HunterSettings()),'rejected');
  });
  test('unverified seller count must not qualify or be treated as verified', () {
    final x=HunterLead(url:'https://bds68.com.vn/ban-nha/123456.html',source:'bds68.com.vn',
      title:'Bán nhà Thủ Đức',detailText:'Chính chủ bán nhà gia đình, diện tích 100 m2, sổ riêng',
      posterCountSource:'snippet_unverified',posterCountEvidence:'2');
    expect(HunterSearch.classifyLead(x,const HunterSettings()),'potential');
  });
  test('invalid future date is not accepted as evidence', () {
    expect(HunterSearch.dateFromEvidence('31/02/2026'),isNull);
  });
  test('generic owner wording does not qualify a listing', () {
    final x=HunterLead(url:'https://bds68.com.vn/ban-nha/123456.html',source:'bds68.com.vn',
      title:'Bán nhà Thủ Đức',detailText:'Chủ nhà bán căn nhà tại số 12 đường 5, Thủ Đức, sổ riêng đầy đủ',
      posterCountSource:'seller_profile_verified',posterCountEvidence:'1',dateEvidence:'27/10/2026');
    expect(HunterSearch.brokerEvidence(x),isNotNull);
    expect(HunterSearch.classifyLead(x,const HunterSettings()),'rejected');
  });
  test('four verified posts rejected even when seller says direct owner', () {
    final x=HunterLead(url:'https://bds68.com.vn/ban-nha/123456.html',source:'bds68.com.vn',
      title:'Bán nhà Thủ Đức',detailText:'Tôi là chủ căn nhà, bán trực tiếp, có sổ riêng',
      posterCountSource:'human_verified',posterCountEvidence:'4');
    expect(HunterSearch.classifyLead(x,const HunterSettings()),'rejected');
  });

  test('old date is rejected even when detail is incomplete', () {
    final x=HunterLead(url:'https://bds68.com.vn/ban-nha-pr31183143',
      source:'bds68.com.vn',title:'Bán biệt thự Thủ Đức',
      dateEvidence:'19/10/2026',detailText:'');
    expect(HunterSearch.classifyLead(x,const HunterSettings()),'rejected');
  });
  test('seller count parser accepts nested BDS68 seller card', () {
    final doc=html_parser.parse('<div class="seller"><h3>PHẠM VĂN HUYỀN</h3><div>Tổng số tin đăng <span>8</span></div></div>');
    expect(HunterSearch.sellerCountOnDetail(doc,'bds68.com.vn'),'8');
  });

}
