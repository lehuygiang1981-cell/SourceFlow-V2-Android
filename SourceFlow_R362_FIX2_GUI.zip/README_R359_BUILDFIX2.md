# SourceFlow R3.5.9 BuildFix2 — fix CI regression test

GitHub Actions run 41580381943 failed at `flutter test test/hunter_test.dart`:
expected an empty list when detail page had only `1 tin đăng`, while current
R3.5.4+ workflow intentionally keeps a potential, unverified lead under
`Thiếu dữ liệu` for manual review.

Changes:
- Update the stale smoke test to expect one potential (pending) lead and
  explicitly assert it is NOT qualified, with a direct original URL.
- Keep the same scan behavior and existing exclusion/verification rules.
- Update comment on bounded detail scan to describe current logic.
- Increment build version 3.5.9+65.
- Preserve all previous test cases in GitHub Actions. No test skipped.

Validation: source archive and YAML checked locally. Flutter tests and
Android build must be confirmed by GitHub Actions, not assumed here.
