# SourceFlow R3.6.2 Fix2 — sửa kiểm thử build

Run 42221924064 dừng tại test/hunter_test.dart:70: kiểm thử smoke cũ
mong thông báo "Không đạt điều kiện xác minh tự động", trong khi quy tắc địa chỉ R3.6.2
trả về "Thiếu số nhà hoặc tên đường; không được vào Đạt bộ lọc".

Chỉnh đúng kỳ vọng của test/hunter_test.dart. Không thay đổi mã lọc môi giới
hay điều kiện số nhà + tên đường. Giữ nguyên toàn bộ kiểm thử và phân tích mã.
Phiên bản 3.6.2+72. Chưa xác nhận APK khi chưa có CI thành công.
