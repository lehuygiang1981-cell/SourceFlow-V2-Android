# SourceFlow R3.6.0: targeted recovery from R3.5.9 BuildFix2

## Root causes addressed
1. Manual verification of a temporarily saved lead was incorrectly blocked by the AUTO seller-count gate if the website did not disclose a verified 1–3 count. When a draft already exists, manual confirmation now updates the SAME inventory item, without re-fetching the site or applying the automatic filter. Any known broker/count conflict is preserved in verification evidence; no website count is fabricated.
2. Broker evidence missed intermediary-style calls such as "Liên hệ chị Phương xem nhà", "LH Uyên xem nhà", "Liên hệ Tiến để xem nhà và làm việc trực tiếp với chủ", and operator-specified marketing phrases including "Hàng VIP", "sinh lời ngay". Matching evaluates the listing title, snippet, full detail, and seller handle.
3. Seller name could be absent from a site's detail markup even when it was in a user-profile widget or the unique linked profile. The scanner and late import now carry the profile name forward where available, WITHOUT upgrading the listing-count to verified if the listing identity is not independently matched.
4. Nha Tot's initial result page sometimes uses image-only links or JSON hydration. The public link extractor now handles a sibling headline within ONE listing card and public embedded JSON with a real URL. High-count and brokerage-labeled sellers detected on the outer listing card are rejected without consuming a limited detail fetch; candidates remaining get first priority. This does not bypass site access restrictions, private APIs, logins, 403/429, or CAPTCHAs.
5. Adds regression tests using the user's reported screenshots and a 2-listing Nha Tot fixture.

## Preservation
- SQLite database and package name unchanged; no destructive migration.
- 'Thiếu dữ liệu', 'Đã lưu tạm', deduplication, original links and existing verification logs retained.
- Existing CI tests remain enabled. New test suite added to CI.
- Public seller-count <=3 remains mandatory for AUTOMATIC acceptance only; direct human confirmation does not mislabel website evidence.

## Verification limitations
- ZIP consistency and YAML parsing checked locally.
- Flutter SDK not available locally; passing GitHub CI and Android-device testing are still required.
- A public website may return 403/429 or JS-only pages; never claim successful scraping without a real read. Its failure should remain visible as a source error rather than zero matching owners.
