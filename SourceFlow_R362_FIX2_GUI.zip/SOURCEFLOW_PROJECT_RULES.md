# SOURCEFLOW - QUY TRÌNH LÀM VIỆC VÀ ĐỐI CHIẾU BẮT BUỘC

Cập nhật: 2026-11-03. Đây là tài liệu đi cùng mã nguồn; không được xóa trong bản nâng cấp.

## Quy trình giao file (không thay đổi)
- Bàn giao đúng HAI file đồng bộ, không ghép ZIP và YML vào một file: 1 ZIP mã nguồn, 1 workflow .yml độc lập.
- Tên ZIP trong workflow phải trùng CHÍNH XÁC với tên ZIP được giao, kể cả chữ hoa/chữ thường.
- Tạo file tại thư mục gốc /mnt/data, kiểm tra tồn tại/dung lượng/SHA256, mở ZIP testzip, kiểm tra YAML và đầy đủ test/path.
- Không đổi tên sau kiểm tra và gửi đường dẫn tải trực tiếp ChatGPT từ chính các file đã xác minh. Không khẳng định tải được trên thiết bị nếu người dùng chưa xác nhận.
- User tự upload ZIP vào gốc nhánh main của repo lehuygiang1981-cell/SourceFlow-V2-Android và YML vào .github/workflows/; không yêu cầu sửa mã nguồn thủ công trong GitHub.
- Trigger tự chạy khi push, chạy test và analyze TRƯỚC build; không được bỏ test đang fail để lấy APK.
- Chỉ gọi build thành công sau khi xem kết quả GitHub Actions; chỉ giao APK sau khi có artifact và kiểm tra tính toàn vẹn tệp cài đặt.

## Quy tắc lọc không thay đổi
- Tin quá 5 ngày theo ngày đăng được xác minh: loại. Người đăng có trên 3 tin được xác minh: loại ngay, kể cả khi điều kiện khác chưa biết.
- Đọc số lượng tin ở khối từng người đăng trên DANH SÁCH, ở CHI TIẾT và khi cần ở HỒ SƠ NGƯỜI ĐĂNG; không nhầm lượt xem/tổng kết quả tìm kiếm/số thứ tự thành số tin. Mâu thuẫn hoặc không đọc được: Thiếu dữ liệu.
- Kiểm tra toàn bộ tiêu đề, mô tả, tên tài khoản, đường dẫn quảng bá, cụm môi giới theo bộ quy tắc thống nhất. Ví dụ: 'làm việc trực tiếp chính chủ', 'liên hệ để xem nhà', 'thương lượng chính chủ', 'nhận ký gửi', 'dòng tiền', 'thu nhập hàng tháng' (dấu hiệu theo quy tắc kinh doanh của người dùng; lưu bằng chứng cụ thể).
- Thiếu dữ liệu KHÔNG đồng nghĩa bị loại. Giữ tab Thiếu dữ liệu để con người kiểm tra; không mặc định đạt bộ lọc.
- Chống lặp URL/tin/sản phẩm; một tin chỉ thuộc một tab trạng thái hiển thị; lưu tạm không tạo bản ghi nguồn chính trùng.
- Sau lưu tạm phải có hành động 'Đã xác minh & lưu', cập nhật hồ sơ đã lưu; chỉ người dùng cấp trạng thái đã xác minh chính chủ. Người đăng chưa chứng minh là chính chủ không tự động trở thành chủ sở hữu.

## Trích xuất & tính ổn định
- Trích xuất đúng tên nguồn, địa chỉ, diện tích, kích thước ngang/dài, giá, pháp lý, số điện thoại, link trực tiếp, tên người đăng và nguồn dữ liệu; không gán tiêu đề UI, đoạn mô tả hay kích thước vào trường sai.
- Ưu tiên trường có nhãn và cấu trúc rõ ràng, bảo tồn văn bản gốc, không tự bịa dữ liệu; dữ liệu mâu thuẫn phải ghi rõ và để chỉnh sửa.
- Giữ SQLite offline, OCR nhập ảnh, voice nhập liệu, quản lý nguồn, các bộ lọc/nhóm, nhắc việc và tính năng đã ổn định; ưu tiên sửa đúng lỗi, không thay luồng tốt.
- Nhập camera tự quét thời gian thực rồi mới chụp là yêu cầu tiếp theo, không chèn vào bản vá pipeline chưa kiểm thử.

## Đối chiếu thất bại và nguyên nhân
- 2026-11-03, GitHub Actions Run 41578796116, R3.5.9 bàn giao lại: 9/10 bài kiểm thử core đầu đạt; lỗi `parseIntake('Diện tích 10x17m (CN 145m²)')` trả `width=''` thay vì `10 m`.
- Build bị chặn đúng tại bước test, không tạo APK. Bản vá này bổ sung 'dien tich' vào nhãn regex kích thước và thêm hồi quy đa dạng định dạng; phải kiểm thử lại trên GitHub, không được tuyên bố thành công trước khi CI xác nhận.
- Các bài toán tồn đọng khác: đọc số tin trên website dựng DOM bằng JavaScript, dấu hiệu môi giới theo từng website, OCR nhập địa chỉ/diện tích/giá; cần đối chiếu dữ liệu thực tế, không suy từ CI là tất cả đã hết lỗi.


## R3.6.2 — Điều kiện bắt buộc của nhóm Đạt bộ lọc
- Người dùng quy định: chỉ tin có **số nhà thật + tên đường** (không phải số đường, số hẻm, số phường hay diện tích) mới được đánh dấu "Đạt bộ lọc". Tin thiếu một thành phần đưa vào "Thiếu dữ liệu" để kiểm tra thủ công; không tự loại chỉ vì thiếu số nhà.
- Mọi cách viết dấu hoặc không dấu của "giảm ngộp/giảm ngợp", "thương lượng chính chủ", "liên hệ xem nhà"/"LH xem nhà" và các biến thể liên quan là dấu hiệu **loại theo bộ lọc môi giới** do người sử dụng thiết lập. Áp dụng trước khi xét đạt; giữ lý do loại.
- Khi người dùng đã lưu tạm và tự xác minh chủ, vẫn có quyền dùng "Đã xác minh & lưu" bất kể website chưa đọc được số tin; không đảo ngược quy tắc đã thống nhất này.
- Khi mở danh sách sau nâng cấp, tái đánh giá các tin pending từng được đánh dấu đạt theo quy tắc mới.
