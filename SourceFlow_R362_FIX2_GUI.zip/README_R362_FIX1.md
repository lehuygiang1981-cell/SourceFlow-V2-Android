# SourceFlow R3.6.2 Fix1 — regression consistency

## Original CI failure
- GitHub run 42217158177, job 127889921570: R3.5.6 historical test expected `hẹn lịch xem nhà` to be *soft*, but the new owner-only rules in R3.6.2 explicitly hard-reject that phrase.
- The hard broker check and new house-number/street qualification tests passed.

## Changes
- Updated the outdated R3.5.6 test to require hard exclusion of `hẹn lịch xem nhà` (without disabling it).
- Added a separate regression confirming that `nhận tư vấn miễn phí` alone remains a *potential* manual-review signal (not hard exclusion).
- Retained all the preexisting Flutter regression test commands and static analysis in GitHub Actions.
- Did not alter application runtime logic; version advanced to 3.6.2+71.

## Quality status
Source code and workflow are consistency-checked before delivery. Flutter tests/build still require GitHub Actions and actual device verification.
