# SourceFlow R3.6.0 Fix1 — regression gate repaired without disabling tests

## Verified failure from GitHub run 41865637549
- 6 tests passed in R3.6.0 regression suite.
- R3.5.9 core pipeline: 10 passed, 1 failed at test/hunter_r359_core_pipeline_test.dart:112.
- The stale assertion expected brokerEvidence(“Liên hệ em Phương xem nhà ngay”) == null.
- Current user-approved broker rule explicitly REJECTS contact-for-viewing advertising.
- The scanner was already returning “Người liên hệ đóng vai trò dẫn khách xem nhà/đất”, hence the old assertion conflicted with the new policy.

## Fix
- Update R3.5.9 test to assert broker evidence and rejection for the exact phrase.
- Update R3.5.5 test to assert rejection, rather than potential, for the identical phrase.
- Add exact example to policy regression list.
- Update stale commentary in hunter_search.dart; keep real broker detection unchanged.
- Increment build number to 3.6.0+67; preserve SQLite database, UI workflow and all other rules.
- Keep all previous Flutter tests and static analysis in GitHub Actions; no skips.

## Acceptance
Only report build success after GitHub Actions passes all regression tests and uploads a real release APK. ZIP/YAML validation is not Flutter/Android testing.
