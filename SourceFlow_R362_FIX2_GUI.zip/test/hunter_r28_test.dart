import 'package:flutter_test/flutter_test.dart';
import 'package:sourceflow_android/hunter_search.dart';
import 'package:sourceflow_android/hunter_models.dart';
void main() {
  test('Guland seller profile cannot be a property lead', () {
    final html='<a href="/tin-da-dang-475813/mua-ban-bat-dong-san-thanh-pho-thu-duc-tp-ho-chi-minh"><h3>Đinh Ngọc Trung 16</h3></a>';
    final leads=HunterSearch.parseListingHtml(html,Uri.parse('https://guland.vn/mua-ban-bat-dong-san-thanh-pho-thu-duc-tp-ho-chi-minh'),'guland.vn');
    expect(leads,isEmpty);
  });
  test('No unverified date or seller count can pass filter', () {
    final lead=HunterLead(url:'https://bds68.com.vn/ban-nha-rieng/pr12345678',title:'Bán nhà đường số 9 Thủ Đức',source:'bds68.com.vn',detailText:'Bán nhà riêng 90 m² đường số 9 thành phố Thủ Đức giá 8 tỷ');
    expect(HunterSearch.matchesCriteria(lead,const HunterSettings()),isFalse);
  });
  test('Verified count and dated detail pass', () {
    final now=DateTime.now();
    final date='${now.day.toString().padLeft(2,'0')}/${now.month.toString().padLeft(2,'0')}/${now.year}';
    final lead=HunterLead(url:'https://bds68.com.vn/ban-nha-rieng/pr12345678',title:'Bán nhà đường số 9 Thủ Đức',source:'bds68.com.vn',detailText:'Chính chủ bán nhà riêng 90 m². Địa chỉ: 29 đường số 9, Phường Linh Đông, thành phố Thủ Đức. Giá 8 tỷ',dateEvidence:date,posterCountEvidence:'2',posterCountSource:'seller_profile_verified');
    expect(HunterSearch.matchesCriteria(lead,const HunterSettings()),isTrue);
  });
}
