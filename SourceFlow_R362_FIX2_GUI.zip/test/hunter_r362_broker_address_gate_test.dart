import 'package:flutter_test/flutter_test.dart';
import 'package:sourceflow_android/hunter_models.dart';
import 'package:sourceflow_android/hunter_search.dart';

void main() {
  String today() {
    final n=DateTime.now();
    return '${n.day.toString().padLeft(2,'0')}/'
      '${n.month.toString().padLeft(2,'0')}/${n.year}';
  }

  HunterLead lead(String address, {String extra=''}) => HunterLead(
    url:'https://bds68.com.vn/ban-nha-31293476.html',
    title:'Tôi là chủ bán nhà sổ hồng tại Thủ Đức',
    source:'bds68.com.vn',
    detailText:'Tôi là chủ bán nhà có sổ hồng riêng. '
      'Địa chỉ: $address\nGiá bán: 8 tỷ. '
      'Tôi tự đăng bán tài sản này. $extra',
    dateEvidence:today(),
    posterCountEvidence:'2',
    posterCountSource:'listing_card_verified',
  );

  test('R3.6.2: strong broker signals from operator are rejected', () {
    final phrases=<String>[
      'Chủ bán giảm ngộp mạnh', 'Giảm ngợp cần bán nhanh',
      'Giảm sâu vì ngộp', 'Ngộp ngân hàng',
      'Thương lượng chính chủ', 'Phương lượng chính chủ',
      'Thương lượng trực tiếp với chính chủ',
      'Thương lượng giá với chủ nhà', 'Liên hệ xem nhà',
      'LH xem nhà ngay', 'Liên hệ để được xem nhà',
      'LH chị Phương xem nhà ngay',
      'Hẹn lịch xem nhà', 'Liên hệ em Thảo xem thêm nhiều căn khác',
    ];
    for(final phrase in phrases) {
      final item=lead('28 đường số 6, phường Hiệp Bình Chánh',extra:phrase);
      expect(HunterSearch.brokerEvidence(item),isNotNull,reason:phrase);
      expect(HunterSearch.classifyLead(item,const HunterSettings()),'rejected',
        reason:phrase);
      expect(HunterSearch.matchesCriteria(item,const HunterSettings()),isFalse,
        reason:phrase);
    }
  });

  test('R3.6.2: require house number AND actual named road', () {
    for(final address in [
      '46/16B Đường Linh Đông, phường Linh Đông, TP Thủ Đức',
      '28 đường số 6, phường Hiệp Bình Chánh, TP Thủ Đức',
      '68 Bưng Ông Thoàn, Long Trường, TP Thủ Đức',
      'Số nhà 12A, đường Lã Xuân Oai, phường Long Trường',
    ]) {
      expect(HunterSearch.hasHouseNumberAndStreet(address),isTrue,
        reason:address);
    }
    for(final address in [
      'Đường số 12, phường Hiệp Bình Chánh, TP Thủ Đức',
      'Phường Linh Đông, TP Thủ Đức',
      'Hẻm 46, đường số 6, Thủ Đức',
      '12 phường Linh Đông, Thủ Đức',
      '45 m², mặt tiền đường Linh Đông',
      'Khu dân cư 45, Long Trường, Thủ Đức',
    ]) {
      expect(HunterSearch.hasHouseNumberAndStreet(address),isFalse,
        reason:address);
    }
  });

  test('R3.6.2: absent house number stays missing-data; complete one qualifies', () {
    final missing=lead('Đường số 12, phường Hiệp Bình Chánh, TP Thủ Đức');
    expect(HunterSearch.classifyLead(missing,const HunterSettings()),'potential');
    expect(HunterSearch.matchesCriteria(missing,const HunterSettings()),isFalse);
    final complete=lead('28 đường số 6, phường Hiệp Bình Chánh, TP Thủ Đức');
    expect(HunterSearch.hasHouseNumberAndStreet(complete.parsed.address),isTrue,
      reason:complete.parsed.address);
    expect(HunterSearch.classifyLead(complete,const HunterSettings()),'qualified');
    expect(HunterSearch.matchesCriteria(complete,const HunterSettings()),isTrue);
  });

  test('R3.6.2: historical qualification does not override new address gate', () {
    final item=lead('Đường số 12, phường Hiệp Bình Chánh');
    item.qualification='qualified';
    expect(HunterSearch.classifyLead(item,const HunterSettings()),'potential');
    // User-driven verification of an already stored draft remains independent
    // from the automatic qualification gate.
    item.status='saved_for_review';
    expect(canHumanConfirmSavedDraft(item,true),isTrue);
  });
}
