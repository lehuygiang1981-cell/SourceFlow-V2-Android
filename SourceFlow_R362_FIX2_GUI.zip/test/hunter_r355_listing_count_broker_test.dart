import 'package:flutter_test/flutter_test.dart';
import 'package:html/parser.dart' as html;
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:sourceflow_android/hunter_models.dart';
import 'package:sourceflow_android/hunter_search.dart';

void main() {
  final today=DateTime.now();
  final date='${today.day.toString().padLeft(2,'0')}/'
      '${today.month.toString().padLeft(2,'0')}/${today.year}';
  const domain='bds68.com.vn';
  const root='https://bds68.com.vn/nha-dat-ban/ho-chi-minh/thu-duc';
  String card(int id, String name, String count, {String extra=''}) =>
      '<article class="listing-card"><a href="/ban-nha-$id.html">'
      '<h3>Bán nhà riêng tại Thủ Đức $id giá 8 tỷ, diện tích 90m2</h3></a>'
      '<div class="poster-info">Người đăng: $name · $count</div>$extra</article>';

  test('list cards with distinct sellers never contaminate one another', () {
    final result=HunterSearch.parseListingHtml('''<main>
      ${card(31293473,'A','Tổng số tin đăng 10')}
      ${card(31293474,'B','2 tin')}
      <div class="recommendations">Có 990 tin bất động sản</div>
      </main>''',Uri.parse(root),domain);
    expect(result.length,2);
    expect(result[0].posterCountEvidence,'10');
    expect(result[1].posterCountEvidence,'2');
    expect(result[0].posterCountSource,'listing_card_verified');
    expect(result[1].posterCountSource,'listing_card_verified');
    expect(HunterSearch.classifyLead(result[0],const HunterSettings()),'rejected');
  });

  test('numbers in property area, views or unrelated recommendations are not seller totals', () {
    final result=HunterSearch.parseListingHtml('''<main>
      <article class="listing-card">
      <a href="/ban-nha-31293475.html"><h3>Bán nhà Thủ Đức 100m2 3 tỷ</h3></a>
      <div class="price">100m2, 3 tỷ, có 88 lượt xem</div>
      <div class="recommended">Xem thêm 24 tin khác</div>
      </article></main>''',Uri.parse(root),domain);
    expect(result.length,1);
    expect(result.single.posterCountEvidence,isEmpty);
    expect(result.single.posterCountSource,'snippet_unverified');
  });

  test('seller card supports unlabeled 24 tin and more N posts', () {
    final node=html.parse('<article><div class="seller-profile">Nguyễn A · 24 tin</div></article>');
    expect(HunterSearch.sellerCountFromListingCard(node.querySelector('article')),'24');
    final other=html.parse('<article><div class="user-info">Người đăng A. Xem thêm 2 tin khác</div></article>');
    expect(HunterSearch.sellerCountFromListingCard(other.querySelector('article')),'3');
  });

  test('list count survives details without poster count', () {
    final item=HunterLead(url:'https://bds68.com.vn/ban-nha-31293474.html',
        title:'Chính chủ bán nhà đường số 6 Hiệp Bình Chánh',source:domain,
        dateEvidence:date,
        posterCountEvidence:'2',posterCountSource:'listing_card_verified',
        detailText:'Địa chỉ: Số 28 đường số 6 phường Hiệp Bình Chánh TP Thủ Đức. Diện tích 90 m2 giá 8 tỷ.');
    final rec=HunterSearch.reconcileSellerCounts(item,'');
    expect(rec.count,'2');
    expect(rec.source,'listing_card_verified');
    expect(HunterSearch.classifyLead(item,const HunterSettings()),'qualified');
  });

  test('conflicting card/detail count stays in missing-data tab, not qualified', () {
    final item=HunterLead(url:'https://bds68.com.vn/ban-nha-31293474.html',
        title:'Bán nhà đường số 6',source:domain,
        posterCountEvidence:'2',posterCountSource:'listing_card_verified');
    final rec=HunterSearch.reconcileSellerCounts(item,'9',detailSource:'seller_profile_verified');
    expect(rec.source,'count_conflict');
    expect(rec.count,'');
    final conflict=HunterLead(url:item.url,title:item.title,source:domain,
        dateEvidence:date,detailText:'Địa chỉ: 28 đường số 6 phường Hiệp Bình Chánh. Chính chủ bán nhà 90m2.',
        posterCountEvidence:rec.count,posterCountSource:rec.source);
    expect(HunterSearch.classifyLead(conflict,const HunterSettings()),'potential');
    final later=HunterSearch.reconcileSellerCounts(conflict,'2',detailSource:'seller_profile_verified');
    expect(later.source,'count_conflict');
  });

  test('zero active listings never certifies a seller as within <=3', () {
    final lead=HunterLead(url:'https://bds68.com.vn/ban-nha-12345678.html',
        title:'Chính chủ bán nhà đường số 6',source:domain,
        dateEvidence:date,posterCountEvidence:'0',
        posterCountSource:'seller_profile_verified',
        detailText:'Địa chỉ: 28 đường số 6 phường Hiệp Bình Chánh, diện tích 90m2 giá 8 tỷ.');
    expect(HunterSearch.trustedSellerCount(lead),isFalse);
    expect(HunterSearch.classifyLead(lead,const HunterSettings()),'potential');
  });

  test('marketing/consulting and separate catalogue is broker evidence', () {
    final item=HunterLead(url:'https://muaban.net/bat-dong-san/ban-nha-id12345567',
      source:'muaban.net',title:'Bán nhà 220m2 giá 14 tỷ',detailText:
      'Liên hệ Nguyen Kyei để được tư vấn và xem nhà thực tế. '
      'Tham khảo thêm nhà phố tại https://daudat.vercel.app/');
    expect(HunterSearch.brokerEvidence(item),isNotNull);
    expect(HunterSearch.classifyLead(item,const HunterSettings()),'rejected');
  });

  test('operator-defined contact-for-viewing is broker exclusion', () {
    final item=HunterLead(url:'https://muaban.net/bat-dong-san/ban-nha-id12345568',
      source:'muaban.net',title:'Bán nhà 55m2 giá 3,6 tỷ',detailText:
      'Nhà chính chủ sổ riêng. Liên hệ em Phương xem nhà ngay.');
    expect(HunterSearch.brokerEvidence(item),isNotNull);
    expect(HunterSearch.possibleBrokerEvidence(item),isNull);
    expect(HunterSearch.classifyLead(item,const HunterSettings()),'rejected');
  });

  test('integrated scan accepts list seller count when detail has no seller box', () async {
    final mock=MockClient((r)async{
      if(r.url.path.contains('/ban-nha-31293474.html')){
        return http.Response('<html><body><h1>Chính chủ bán nhà Thủ Đức đường số 6</h1>'
          '<div class="detail-info">Địa chỉ: 28 đường số 6 phường Hiệp Bình Chánh. '
          'Diện tích: 90m2. Giá: 8 tỷ.</div>'
          '<section class="detail-description">Chính chủ bán căn nhà đường số 6, nhà hoàn công sổ riêng.</section>'
          '<p>Ngày đăng: $date</p></body></html>',200,
          headers:{'content-type':'text/html; charset=utf-8'});
      }
      return http.Response('<html><body>${card(31293474,'Nguyễn A','2 tin đăng')}</body></html>',200,
        headers:{'content-type':'text/html; charset=utf-8'});
    });
    final scanner=HunterSearch(client:mock);
    final result=await scanner.scan(const HunterSettings(sites:[domain]));
    expect(result.leads.length,1);
    expect(result.leads.single.posterCountEvidence,'2');
    expect(result.leads.single.posterCountSource,'listing_card_verified');
    scanner.close();
  });
}
