import 'package:flutter_test/flutter_test.dart';
import 'package:html/parser.dart' as html;
import 'package:sourceflow_android/hunter_models.dart';
import 'package:sourceflow_android/hunter_search.dart';
import 'package:sourceflow_android/models.dart';

void main() {
  test('OCR titles never use real-estate section heading as the property name', () {
    final p=parseIntake('''Đặc điểm bất động sản
    Chính chủ bán nhà Rio Vista hai mặt tiền
    Diện tích đất: 119 m²
    Giá bán: 13 tỷ
    Chiều ngang: 5 m
    Người đăng: Nguyễn Thị Ngọc Phương
    Điện thoại: 0903 917 322''');
    expect(p.title, 'Chính chủ bán nhà Rio Vista hai mặt tiền');
    expect(p.area, '119 m²');
    expect(p.price, '13 tỷ');
    expect(p.width, '5 m');
    expect(p.owner, 'Nguyễn Thị Ngọc Phương');
    expect(p.phone, '0903917322');
  });

  test('price and area do not bleed across OCR lines', () {
    final p=parseIntake('''Bán nhà Rio Vista 119m²
    Giá bán: 13 tỷ
    Giá/m²: 109,24 triệu/m²
    Diện tích đất: 119m²
    Chiều ngang: 5m''');
    expect(p.area,'119 m²');
    expect(p.price,'13 tỷ');
    expect(p.width,'5 m');
  });

  test('list seller identity belongs to each individual property', () {
    final document=html.parse('''<main>
      <article class="listing-card"><a href="/ban-nha-31293473.html"><h3>Bán nhà riêng Thủ Đức diện tích 90m²</h3></a>
      <div class="poster-info">Người đăng: Nguyễn Thị Ngọc Phương · 2 tin</div></article>
      <article class="listing-card"><a href="/ban-nha-31293474.html"><h3>Bán nhà đường số 6 Hiệp Bình 80m²</h3></a>
      <div class="poster-info">Người đăng: Trần Văn Hai · 19 tin</div></article>
    </main>''');
    final elements=document.querySelectorAll('article');
    expect(HunterSearch.sellerNameFromCard(elements[0]),'Nguyễn Thị Ngọc Phương');
    expect(HunterSearch.sellerCountFromListingCard(elements[0]),'2');
    expect(HunterSearch.sellerNameFromCard(elements[1]),'Trần Văn Hai');
    expect(HunterSearch.sellerCountFromListingCard(elements[1]),'19');
  });

  test('contact to arrange house viewing is a hard broker exclusion in R3.6.2',(){
    // Explicit R3.6.2 rule: arranging a house viewing is a hard exclusion.
    // Keep this regression when adding future broker signal variants.
    final lead=HunterLead(url:'https://muaban.net/bat-dong-san/ban-nha-id71328944',
      title:'Bán nhà Hiệp Bình Chánh 55m²',source:'muaban.net',
      detailText:'Nhà bán giá 3,6 tỷ; nhận tư vấn miễn phí và hẹn lịch xem nhà.');
    expect(HunterSearch.brokerEvidence(lead),isNotNull);
    expect(HunterSearch.classifyLead(lead,const HunterSettings()),'rejected');
  });

  test('generic consulting language alone stays reviewable without claiming brokerage proof',(){
    final lead=HunterLead(url:'https://muaban.net/bat-dong-san/ban-nha-id71328945',
      title:'Bán nhà Hiệp Bình Chánh 55m²',source:'muaban.net',
      detailText:'Nhà bán giá 3,6 tỷ; nhận tư vấn miễn phí.');
    expect(HunterSearch.brokerEvidence(lead),isNull);
    expect(HunterSearch.possibleBrokerEvidence(lead),isNotNull);
    expect(HunterSearch.classifyLead(lead,const HunterSettings()),'potential');
  });

  test('qualified and missing-data tabs never duplicate the same lead',(){
    HunterLead mk(String type) => HunterLead(
      url:'https://bds68.com.vn/ban-nha-${type=='qualified'?'31293473':'31293474'}.html',
      title:'Bán nhà riêng đường số 6',source:'bds68.com.vn',
      qualification:type);
    final qualified=mk('qualified');
    final missing=mk('potential');
    expect(hunterLeadInView(qualified,'qualified'),isTrue);
    expect(hunterLeadInView(qualified,'needs_data'),isFalse);
    expect(hunterLeadInView(missing,'needs_data'),isTrue);
    expect(hunterLeadInView(missing,'qualified'),isFalse);
  });

  test('poster identity is persisted separately from verified ownership',(){
    final lead=HunterLead(url:'https://bds68.com.vn/ban-nha-31293473.html',
      title:'Bán nhà đường số 6',source:'bds68.com.vn',
      posterName:'Nguyễn Thị Ngọc Phương',
      posterCountEvidence:'2',posterCountSource:'listing_card_verified');
    final decoded=HunterLead.fromJson(lead.toJson());
    expect(decoded.posterName,'Nguyễn Thị Ngọc Phương');
    expect(decoded.status,'pending');
  });
}
