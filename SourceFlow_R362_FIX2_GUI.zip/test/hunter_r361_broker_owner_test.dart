import 'package:flutter_test/flutter_test.dart';
import 'package:html/parser.dart' as html;
import 'package:sourceflow_android/hunter_search.dart';
import 'package:sourceflow_android/hunter_models.dart';

void main() {
  HunterLead ad(String text, {String account = ''}) => HunterLead(
    url: 'https://muaban.net/bat-dong-san/ban-nha-id71336432',
    source: 'muaban.net',
    title: 'Nhà riêng Thủ Đức 65m²',
    detailText: text,
    posterName: account,
  );

  test('R3.6.1: brokerage variants from real screenshot are hard excluded', () {
    const cases = <String>[
      'LH: *** xem nhà ngay',
      'LH: Uyên xem nhà',
      'Liên hệ em Phương xem nhà ngay kẻo lỡ',
      'Liên hệ Phương xem nhà thực tế',
      'Liên hệ *** (Ngọc Phương) để xem nhà và làm việc với chủ',
      'Liên hệ em Phương để xem thêm nhiều căn khác trong khu vực',
      'CG- nhà HXH đường số 8, phường Linh Xuân',
      'Liên hệ để cập nhật bảng giá, giỏ hàng và chính sách bán hàng',
      'Hotline PKD 24/7',
      'Mr. Lăng: phục vụ 24/7',
      'Chủ gửi, thương lượng chính chủ',
      'Dòng tiền từ cho thuê hàng tháng',
    ];
    for (final text in cases) {
      final lead = ad(text);
      expect(HunterSearch.brokerEvidence(lead), isNotNull,
          reason: 'Missed brokerage: $text');
      expect(HunterSearch.classifyLead(lead, const HunterSettings()),
          'rejected', reason: text);
    }
  });

  test('Broker-style seller account is separate from property title', () {
    for (final name in ['Ngân Nhà Phố', 'Hoàng Anh chuyên nhà Thủ Đức']) {
      expect(HunterSearch.brokerEvidence(ad('Bán nhà chính chủ', account: name)),
          isNotNull, reason: name);
    }
    expect(HunterSearch.brokerEvidence(ad(
      'Bán nhà riêng 65m² tại đường số 4, phường Hiệp Bình, sổ hồng riêng',
      account: 'Nguyễn Quang Linh')),
      isNull);
  });

  test('Seller identity extraction preserves accents and ignores notification UI', () {
    final detail = html.parse('''<html><body><h1>Bán nhà Hồng Long 105m²</h1>
      <section class="poster-info">
        <div><strong>Nguyễn Quang Linh</strong></div>
        <div>Nhận email tin mới</div>
      </section></body></html>''');
    expect(HunterSearch.sellerNameFromDetail(detail), 'Nguyễn Quang Linh');

    final mobile = html.parse('''<html><body><h1>Nhà riêng 65m²</h1>
      <section class="account"><div class="account-name">Ngân Nhà Phố</div>
      <div>Nhận email tin mới</div></section></body></html>''');
    expect(HunterSearch.sellerNameFromDetail(mobile), 'Ngân Nhà Phố');
  });

  test('Seller profile title retains original Vietnamese spelling', () {
    final profile = html.parse('''<html><head>
      <title>Trang cá nhân của Nguyễn Gia Hưng | MuaBan</title>
      </head><body></body></html>''');
    expect(HunterSearch.sellerNameFromProfilePage(profile), 'Nguyễn Gia Hưng');
  });

  test('Seller profile in a listing footer is not lost', () {
    final page=html.parse('''<html><body>
      <h1>Bán nhà riêng Hồng Long 105m²</h1>
      <article><footer class="poster-footer">
        <div class="poster-info"><b>Nguyễn Quang Linh</b></div>
      </footer></article></body></html>''');
    expect(HunterSearch.sellerNameFromDetail(page), 'Nguyễn Quang Linh');
  });

  test('R3.6.1 Fix1: Vietnamese names containing price/ward-like words stay intact', () {
    for (final name in <String>[
      'Nguyễn Gia Hưng',
      'Nguyễn Thị Ngọc Phương',
      'Triệu Minh Tý',
    ]) {
      final doc = html.parse('<html><head><title>Trang cá nhân của $name | MuaBan</title></head><body></body></html>');
      expect(HunterSearch.sellerNameFromProfilePage(doc), name, reason: name);
      final account = html.parse('<html><body><div class="poster-name">$name</div></body></html>');
      expect(HunterSearch.sellerNameFromDetail(account), name, reason: name);
    }
  });

  test('R3.6.1 Fix1: unaccented profile heading does not strip seller accents', () {
    final doc = html.parse('<html><head><title>Trang ca nhan cua Nguyễn Gia Hưng | MuaBan</title></head><body></body></html>');
    expect(HunterSearch.sellerNameFromProfilePage(doc), 'Nguyễn Gia Hưng');
  });
}
