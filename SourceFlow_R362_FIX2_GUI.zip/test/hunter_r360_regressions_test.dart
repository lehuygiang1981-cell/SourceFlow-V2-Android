import 'package:flutter_test/flutter_test.dart';
import 'package:html/parser.dart' as html;
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:sourceflow_android/hunter_models.dart';
import 'package:sourceflow_android/hunter_search.dart';

void main() {
  nhatotHydrationTest();
  test('Manual verified saved source is not blocked by missing public 3-post count', () {
    final saved=HunterLead(url:'https://muaban.net/bat-dong-san/ban-nha-id71334189',
        title:'Nhà riêng khu Hồng Long 105m2 giá 13 tỷ',source:'muaban.net',
        status:'saved_for_review',posterCountSource:'snippet_unverified');
    expect(canHumanConfirmSavedDraft(saved,true),isTrue);
    expect(canHumanConfirmSavedDraft(saved,false),isFalse);
    expect(canHumanConfirmSavedDraft(HunterLead(url:saved.url,title:saved.title,
        source:saved.source,status:'pending'),true),isFalse);
    expect(HunterSearch.trustedSellerCount(saved),isFalse);
  });

  test('Broker copy from actual listing screenshots is excluded', () {
    const examples=[
      'Liên hệ chị Phương xem nhà ngay kẻo lỡ!',
      'LH Uyên xem nhà, giá giảm còn 2 tỷ 90 triệu.',
      'Liên hệ Tiến để xem nhà và làm việc trực tiếp với chủ!',
      'Hàng Vip - Ngang 5M - Ngay QL13 Cũ',
      'Vị trí đắc địa - Sinh lời ngay',
      'Dòng tiền thu nhập hàng tháng tốt',
      'Thương lượng chính chủ khi gặp',
    ];
    for(final ad in examples){
      final lead=HunterLead(url:'https://muaban.net/ban-nha-id71336432',
          title:'Bán nhà 65m2 tại Hiệp Bình',detailText:ad,source:'muaban.net');
      expect(HunterSearch.brokerEvidence(lead),isNotNull,reason:ad);
      expect(HunterSearch.classifyLead(lead,const HunterSettings()),'rejected',reason:ad);
    }
  });

  test('Seller name can be read from detail bottom user profile', () {
    final doc=html.parse('''<html><body><h1>Bán nhà KDC Hồng Long 105m2</h1>
      <div class="user-profile"><span class="user-name">Nguyễn Quang Linh</span></div>
      </body></html>''');
    expect(HunterSearch.sellerNameFromDetail(doc),'Nguyễn Quang Linh');
  });

  test('Nha Tot: image-only anchor + sibling title + seller count in listing card',(){
    const raw='''<html><body><main><article class="listing-card">
      <a href="/134059503.htm"><img src="a.jpg" alt="Ảnh nhà" /></a>
      <h3>Nhà hẻm đường 18 Hiệp Bình Chánh 79m² giá 7 tỷ</h3>
      <div class="user-info"><span class="user-name">quốcanh</span><small>1 tin</small></div>
      </article><article class="listing-card">
      <a href="/134059504.htm"><h3>Nhà phố Linh Đông 80m² giá 10 tỷ</h3></a>
      <div class="user-info"><span class="user-name">Bao Long</span><small>27 tin</small></div>
      </article></main></body></html>''';
    final leads=HunterSearch.parseListingHtml(raw,Uri.parse(
       'https://www.nhatot.com/mua-ban-nha-dat-thanh-pho-thu-duc-tp-ho-chi-minh'),'nhatot.com');
    expect(leads.length,2);
    expect(leads[0].title,contains('Hiệp Bình Chánh'));
    expect(leads[0].posterName,'quốcanh');
    expect(leads[0].posterCountEvidence,'1');
    expect(leads[1].posterCountEvidence,'27');
    expect(HunterSearch.classifyLead(leads[1],const HunterSettings()),'rejected');
  });

  test('Nha Tot skips 27-post seller before requesting detail; keeps 1-post for review', () async {
    var detailCalls=0;
    final now=DateTime.now();
    final date='${now.day}/${now.month}/${now.year}';
    final client=MockClient((req) async {
      if(req.url.path.endsWith('/134059503.htm')){
        detailCalls++;
        return http.Response('''<html><body><h1>Nhà hẻm đường 18 Hiệp Bình Chánh 79m² giá 7 tỷ</h1>
         <section class="description">Nhà riêng sổ hồng diện tích 79m²,
           đường số 18 phường Hiệp Bình Chánh, liên hệ để biết thêm thông tin.</section>
         <p>Ngày đăng: $date</p></body></html>''',200,
         headers:{'content-type':'text/html; charset=utf-8'});
      }
      if(req.url.path.endsWith('/134059504.htm')){
        detailCalls++;
        return http.Response('''<html><body>Không nên đọc tin này</body></html>''',200);
      }
      return http.Response('''<html><body><main>
       <article class="listing-card">
         <a href="/134059504.htm"><h3>Nhà phố Linh Đông 80m² giá 10 tỷ</h3></a>
         <div class="user-info"><span class="user-name">Bao Long</span><span>27 tin</span></div>
       </article>
       <article class="listing-card">
         <a href="/134059503.htm"><h3>Nhà hẻm đường 18 Hiệp Bình Chánh 79m² giá 7 tỷ</h3></a>
         <div class="user-info"><span class="user-name">quốcanh</span><span>1 tin</span></div>
       </article></main></body></html>''',200,
       headers:{'content-type':'text/html; charset=utf-8'});
    });
    final scanner=HunterSearch(client:client);
    try{
      final result=await scanner.scan(const HunterSettings(sites:['nhatot.com']));
      expect(result.leads.length,2);
      expect(result.leads.where((p)=>p.status=='rejected').length,1);
      expect(result.leads.where((p)=>p.status=='pending').length,1);
      expect(detailCalls,1);
    }finally{scanner.close();}
  });
}

// Public Nha Tot hydration data can carry actual ad URLs when initial HTML
// has no anchors. Never infer a URL from ad_id alone.
void nhatotHydrationTest() {
  test('Nha Tot public JSON yields only URLs actually present',(){
    const htmlText='''<html><body><script id="__NEXT_DATA__" type="application/json">
      {"props":{"pageProps":{"ads":[
        {"subject":"Nhà riêng đường số 18 Hiệp Bình Chánh 79m²","url":"/134059503.htm"},
        {"subject":"Tin không có liên kết","ad_id":134059504}
      ]}}}
    </script></body></html>''';
    final hits=HunterSearch.parseListingHtml(htmlText,
       Uri.parse('https://www.nhatot.com/mua-ban-nha-dat-thanh-pho-thu-duc-tp-ho-chi-minh'),'nhatot.com');
    expect(hits.length,1);
    expect(hits.single.url,endsWith('/134059503.htm'));
    expect(hits.single.posterCountEvidence,isEmpty);
  });
}
