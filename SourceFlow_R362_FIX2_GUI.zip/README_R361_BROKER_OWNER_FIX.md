# SourceFlow R3.6.1 — broker terms and posting account identity

Built from the exact R3.6.0 Fix1 source used for successful GitHub Actions run 41876492987.

Fixes:
- Hard reject the operator's documented broker markers: "LH: *** xem nhà ngay", "Liên hệ Phương xem nhà thực tế", "Liên hệ ... xem thêm nhiều căn khác", "CG- nhà HXH", "làm việc với chủ", catalogue/price-list and PKD hotline copy.
- Recognize broker-branded posting account names such as "Ngân Nhà Phố", and still distinguish an ordinary personal name.
- Read seller name from specifically scoped account-name widgets, seller profile links, metadata or adjacent mobile notification panels; keep accent marks from public seller profile title.
- Preserve seller blocks in article footers, while omitting page-level navigation/footer chrome when scanning.
- On provisional inventory import, prefill the *person who posted* in the owner/contact field. `verification` stays **Chưa xác minh**, and review evidence explicitly says name is unverified; only the human-verified flow can mark ownership verified.
- No change to 3-post verification gate, temporary review queue, Nha Tot query logic, existing SQLite records, voice or background scan controls.

New tests: `test/hunter_r361_broker_owner_test.dart`. All existing Flutter regression tests retained in the GitHub workflow.

**Build limitation:** Source and YAML integrity are checked locally, but the Flutter/Android tests and actual public-website behavior are not verified until GitHub Actions reports results and the APK is tested on-device.
