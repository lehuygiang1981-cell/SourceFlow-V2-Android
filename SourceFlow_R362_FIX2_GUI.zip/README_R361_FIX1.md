# SourceFlow R3.6.1 Fix1

GitHub run 41906839399 failed at the R3.6.1 seller identity regression.
Expected `Nguyễn Gia Hưng`; actual `nguyen gia hung`. Root cause: `_validSellerName` excluded common Vietnamese name components `gia`, `phuong`, `trieu`, `ty`, leading to a normalized fallback.

Fix:
- Reject property labels by structural patterns, not by words that can occur in a person's name.
- Never return a lowercased/unaccented name from a normalized document title when the original HTML contains accents.
- Add regression coverage for names containing Gia, Phương, Triệu and Tý and for unaccented page headings.
- Keep broker filtering, Nha Tot scanning, provisional inventory and manual verification behavior unchanged.

ZIP and YML are independently packaged. Flutter must still run in GitHub Actions; archive check does not imply a successful APK build.
