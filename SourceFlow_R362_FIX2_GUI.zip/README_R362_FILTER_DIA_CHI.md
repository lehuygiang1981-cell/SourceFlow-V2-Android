# SourceFlow R3.6.2 — Bổ sung lọc môi giới và địa chỉ cụ thể

Nguồn: kế thừa toàn bộ mã nguồn SourceFlow R3.6.1 Fix1 (`3.6.1+69`), tăng lên `3.6.2+70`.

## Thay đổi
1. `HunterSearch.brokerEvidence`: nhận diện tiếng Việt có dấu và không dấu cho `giảm ngộp/giảm ngợp`, `phương lượng/thương lượng chính chủ`, `thương lượng với chủ`, `liên hệ xem nhà`, `LH xem nhà`, `hẹn lịch xem nhà`, các biến thể lời dẫn khách và quảng cáo nhiều nguồn.
2. `HunterSearch.hasHouseNumberAndStreet`: cổng kiểm tra riêng bắt buộc số nhà + tên đường. Không nhầm "Đường số 12", "Hẻm 46", số phường, diện tích với số nhà.
3. `HunterSearch.classifyLead` và `matchesCriteria`: chỉ tự động đánh dấu Đạt bộ lọc khi đạt đầy đủ cổng địa chỉ và các điều kiện cũ. Tin thiếu số nhà giữ trong "Thiếu dữ liệu".
4. Trang quét: thông báo cụ thể lý do thiếu số nhà/tên đường; tự tái đánh giá tin pending đã lưu khi mở màn hình.
5. Giữ nguyên luồng đã lưu tạm -> xác minh thủ công; không chặn xác minh người dùng chỉ vì số tin website chưa đọc được.
6. `test/hunter_r362_broker_address_gate_test.dart`: kiểm thử mới cho câu môi giới, địa chỉ có/không có số nhà, phân nhóm và xác minh thủ công; giữ kiểm thử cũ. Một trường hợp kiểm thử đời cũ được cập nhật địa chỉ thành có số nhà cho phù hợp quy tắc mới.

## Chất lượng
- Tệp ZIP và YAML được kiểm tra tính toàn vẹn / khớp tên và phiên bản.
- Chưa tuyên bố Flutter build hoặc lọc live Nhà Tốt thành công trước khi GitHub Actions chạy.
