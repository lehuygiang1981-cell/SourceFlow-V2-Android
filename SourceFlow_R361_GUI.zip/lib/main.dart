import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:file_picker/file_picker.dart';
import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path/path.dart' as path;
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:speech_to_text/speech_to_text.dart';
import 'package:url_launcher/url_launcher.dart';
import 'models.dart';
import 'personal_metrics.dart';
import 'hunter_models.dart';
import 'hunter_storage.dart';
import 'hunter_worker.dart';
import 'hunter_page.dart';
import 'storage.dart';
import 'reminders.dart';

const brand=Color(0xff0a746a);
const bg=Color(0xfff5f8f7);

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const SourceFlowApp());
}

class SourceFlowApp extends StatelessWidget {
  const SourceFlowApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title:'SourceFlow Personal R3.0', debugShowCheckedModeBanner:false,
    theme:ThemeData(useMaterial3:true,colorScheme:ColorScheme.fromSeed(seedColor:brand),
      scaffoldBackgroundColor:bg,
      appBarTheme:const AppBarTheme(backgroundColor:Colors.white,foregroundColor:Color(0xff19322e),centerTitle:false),
      cardTheme:CardThemeData(color:Colors.white,elevation:0,shape:RoundedRectangleBorder(
        borderRadius:BorderRadius.circular(16),side:const BorderSide(color:Color(0xffe0e8e5)))),
      inputDecorationTheme:InputDecorationTheme(border:OutlineInputBorder(borderRadius:BorderRadius.circular(12))),
    ),
    home:const Workspace(),
  );
}

class Workspace extends StatefulWidget {
  const Workspace({super.key});
  @override State<Workspace> createState()=>_WorkspaceState();
}

class _WorkspaceState extends State<Workspace> with WidgetsBindingObserver {
  final ListingStorage store=ListingStorage();
  final HunterStorage hunterStore=HunterStorage();
  HunterSnapshot hunterSnapshot=const HunterSnapshot();
  final MorningReminder reminder=MorningReminder();
  List<Listing> listings=[];
  bool loading=true;
  int tab=0;
  String search='';
  int dashboardDays=7;
  @override void initState(){super.initState();WidgetsBinding.instance.addObserver(this);_init();}
  @override void didChangeAppLifecycleState(AppLifecycleState state){
    if(state==AppLifecycleState.resumed){
      hunterStore.snapshot().then((value){if(mounted)setState(()=>hunterSnapshot=value);}).catchError((_){ });
    }
  }
  @override void dispose(){WidgetsBinding.instance.removeObserver(this);hunterStore.close();store.close();super.dispose();}
  Future<void> _init() async {
    try {
      await store.open();
      final data=await store.all(); // Keep original property inventory available even if Hunter initialization fails.
      var snap=const HunterSnapshot();
      var options=const HunterSettings();
      var hunterReady=false;
      try{
        await hunterStore.open();
        snap=await hunterStore.snapshot();
        options=await hunterStore.settings();
        hunterReady=true;
      }catch(_){ // Hunter is an optional module; never block existing listings.
        hunterReady=false;
      }
      await reminder.initialize();
      await reminder.refresh(data);
      if(mounted) setState(() {listings=data;hunterSnapshot=snap;loading=false;});
      // A failure to register a background job must never prevent normal use.
      if(hunterReady)configureHunterBackground(options.autoScan).catchError((_){});
    } catch(e) {
      if(mounted){setState(()=>loading=false);message('Không mở được dữ liệu: $e');}
    }
  }
  void message(String msg) {if(mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(msg)));}
  Future<void> save(Listing item) async {
    await store.save(item);
    final latest=await store.all();
    await reminder.refresh(latest);
    if(mounted) setState(()=>listings=latest);
  }
  Future<void> add() async {
    final result=await Navigator.push<Listing>(context,MaterialPageRoute(builder:(_)=>IntakePage(existing:listings)));
    if(result!=null){await save(result);message('Đã thêm nguồn hàng. Có thể mở hồ sơ để xử lý công việc.');}
  }
  Future<Listing?> edit(Listing p) async {
    final result=await Navigator.push<Listing>(context,MaterialPageRoute(builder:(_)=>IntakePage(existing:listings,original:p)));
    if(result!=null){await save(result);message('Đã cập nhật thông tin nguồn hàng');}
    return result;
  }
  Future<void> detail(Listing item) async {
    await Navigator.push(context,MaterialPageRoute(builder:(_)=>ListingDetail(listing:item,onSave:save,onEdit:edit)));
    if(mounted) setState(() {});
  }
  List<Attention> get attention=>attentionForAll(listings,DateTime.now());
  void showFiltered(String heading,bool Function(Listing) filter) {
    Navigator.push(context,MaterialPageRoute(builder:(_)=>FilteredListingPage(
      heading:heading,select:()=>listings.where(filter).toList(),onOpen:detail,
    ))).then((_){if(mounted)setState((){});});
  }
  @override Widget build(BuildContext context) {
    final titles=['Tổng quan','Nguồn hàng','Quét web','Công việc','Dữ liệu'];
    return Scaffold(
      appBar:AppBar(title:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        const Text('SourceFlow R3.6.1',style:TextStyle(fontWeight:FontWeight.w800)),
        Text(titles[tab],style:const TextStyle(fontSize:12,fontWeight:FontWeight.w400)),
      ]),actions:[IconButton(onPressed:add,tooltip:'Thêm nguồn hàng',icon:const Icon(Icons.add_circle_outline)),const SizedBox(width:8)]),
      body:loading?const Center(child:CircularProgressIndicator()):
        IndexedStack(index:tab,children:[_dashboard(),_inventory(),
          HunterPage(storage:hunterStore,onImport:save,
            sourceExists:(url)=>listings.any((p)=>canonicalLeadUrl(p.sourceUrl)==canonicalLeadUrl(url)),
            findStoredSource:(url){
              final key=canonicalLeadUrl(url);
              for(final item in listings){
                if(canonicalLeadUrl(item.sourceUrl)==key)return item;
              }
              return null;
            },
            onChanged:(snap){if(mounted)setState(()=>hunterSnapshot=snap);},
            onAutoChanged:configureHunterBackground),
          _tasks(),_settings()]),
      floatingActionButton:tab==4||tab==2?null:FloatingActionButton.extended(
        onPressed:add,icon:const Icon(Icons.add),label:const Text('Nhập nguồn')),
      bottomNavigationBar:NavigationBar(selectedIndex:tab,onDestinationSelected:(v)=>setState(()=>tab=v),
        destinations:const [
          NavigationDestination(icon:Icon(Icons.space_dashboard_outlined),selectedIcon:Icon(Icons.space_dashboard),label:'Tổng quan'),
          NavigationDestination(icon:Icon(Icons.home_work_outlined),selectedIcon:Icon(Icons.home_work),label:'Nguồn hàng'),
          NavigationDestination(icon:Icon(Icons.travel_explore_outlined),selectedIcon:Icon(Icons.travel_explore),label:'Quét web'),
          NavigationDestination(icon:Icon(Icons.event_note_outlined),selectedIcon:Icon(Icons.event_note),label:'Công việc'),
          NavigationDestination(icon:Icon(Icons.settings_outlined),selectedIcon:Icon(Icons.settings),label:'Dữ liệu'),
        ]),
    );
  }
  Widget _dashboard() {
    final unsigned=listings.where((p)=>!p.archived&&p.contractStatus!='Đã ký').length;
    final uncalled=listings.where((p)=>!p.archived&&p.contactStatus=='Chưa liên hệ').length;
    final selling=listings.where((p)=>p.contractStatus=='Đã ký').length;
    return RefreshIndicator(onRefresh:()async {
      final data=await store.all();await reminder.refresh(data);if(mounted)setState(()=>listings=data);
    },child:ListView(padding:const EdgeInsets.all(16),children:[
      const Text('Dashboard hiệu quả cá nhân',style:TextStyle(fontSize:22,fontWeight:FontWeight.bold)),
      const SizedBox(height:5),
      const Text('Cập nhật theo từng thao tác đã lưu trên thiết bị. Không dùng tài khoản nhóm.',style:TextStyle(color:Colors.black54)),
      const SizedBox(height:14),
      Row(children:[
      Expanded(child:_stat('Tổng nguồn',listings.length,Icons.inventory_2_outlined,()=>showFiltered('Tất cả nguồn hàng',(_)=>true))),
      const SizedBox(width:8),
      Expanded(child:_stat('Chưa liên hệ',uncalled,Icons.call_outlined,()=>showFiltered('Chưa liên hệ chủ',(p)=>!p.archived&&p.contactStatus=='Chưa liên hệ'))),
    ]),
    const SizedBox(height:8),
    Row(children:[
      Expanded(child:_stat('Chưa ký HĐ',unsigned,Icons.edit_document,()=>showFiltered('Nguồn chưa ký hợp đồng',(p)=>!p.archived&&p.contractStatus!='Đã ký'))),
      const SizedBox(width:8),
      Expanded(child:_stat('Đã ký HĐ',selling,Icons.verified_outlined,()=>showFiltered('Nguồn đã ký hợp đồng',(p)=>p.contractStatus=='Đã ký'))),
    ]),
    const SizedBox(height:8),
    _stat('Chưa xác minh chủ',listings.where(needsOwnerVerification).length,Icons.fact_check_outlined,
      ()=>showFiltered('Nguồn chưa xác minh chính chủ',needsOwnerVerification)),
    const SizedBox(height:16),
    _personalDashboard(),
    const SizedBox(height:16),
    Card(child:Padding(padding:const EdgeInsets.all(15),child:Column(
      crossAxisAlignment:CrossAxisAlignment.start,children:[
        const Text('SUPPLY HUNTER · KIỂM TRA NGUỒN WEB',style:TextStyle(fontWeight:FontWeight.w700)),
        const SizedBox(height:10),Wrap(spacing:8,runSpacing:8,children:[
          _metricChip('Tin chờ kiểm tra',hunterSnapshot.pending,Icons.fact_check_outlined),
          _metricChip('Lưu tạm chờ xác minh',hunterSnapshot.savedForReview,Icons.bookmark_add_outlined),
          _metricChip('Nguồn đã xác minh & lưu',hunterSnapshot.confirmed,Icons.inventory_2_outlined),
          _metricChip('Tin đã loại',hunterSnapshot.rejected,Icons.block_outlined),
        ]),
        const SizedBox(height:7),Text(hunterSnapshot.message,style:const TextStyle(fontSize:12,color:Colors.black54)),
        TextButton.icon(onPressed:()=>setState(()=>tab=2),icon:const Icon(Icons.open_in_new),label:const Text('Mở báo cáo nguồn web')),
      ]))),
    const SizedBox(height:16),
      Card(child:Padding(padding:const EdgeInsets.all(15),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        Row(children:[const Icon(Icons.notifications_active_outlined,color:brand),const SizedBox(width:8),
          Expanded(child:Text('Nguồn cần theo dõi buổi sáng (${attention.length})',style:const TextStyle(fontWeight:FontWeight.bold,fontSize:16)))]),
        const SizedBox(height:5),
        const Text('Đã ký, chào bán ổn định: không nhắc. Hồ sơ chưa ký: vẫn theo dõi, dù lịch hẹn ở ngày sau.',
          style:TextStyle(fontSize:12,color:Colors.black54)),
        const SizedBox(height:10),
        if(attention.isEmpty)const Text('Không có hồ sơ nào cần nhắc.',style:TextStyle(color:brand)),
        ...attention.take(12).map(_attentionTile),
        if(attention.length>12)TextButton(onPressed:()=>setState(()=>tab=3),child:Text('Xem toàn bộ ${attention.length} hồ sơ →')),
      ]))),
      const SizedBox(height:80),
    ]));
  }
  Widget _personalDashboard(){
    final metrics=PersonalMetrics.fromListings(listings,DateTime.now(),days:dashboardDays);
    final today=DateTime.now();
    final maxDay=metrics.newByDay.fold<int>(1,(max,v)=>v>max?v:max);
    return Card(child:Padding(padding:const EdgeInsets.all(15),child:Column(
      crossAxisAlignment:CrossAxisAlignment.start,children:[
        Row(children:[const Icon(Icons.query_stats_outlined,color:brand),const SizedBox(width:8),
          const Expanded(child:Text('KẾT QUẢ CÔNG VIỆC CỦA TÔI',style:TextStyle(fontWeight:FontWeight.w700))) ]),
        const SizedBox(height:10),
        Wrap(spacing:6,runSpacing:6,children:[for(final span in [1,7,30])
          ChoiceChip(label:Text(span==1?'Hôm nay':span==7?'7 ngày':'30 ngày'),
            selected:dashboardDays==span,onSelected:(_)=>setState(()=>dashboardDays=span))]),
        const SizedBox(height:12),
        Wrap(spacing:8,runSpacing:8,children:[
          _metricChip('Nguồn mới',metrics.created,Icons.add_home_work_outlined),
          _metricChip('Lượt thao tác',metrics.activities,Icons.touch_app_outlined),
          _metricChip('Hồ sơ chỉnh sửa',metrics.modified,Icons.edit_note_outlined),
          _metricChip('Nhập từ ảnh OCR',metrics.ocrInputs,Icons.document_scanner_outlined),
          _metricChip('Nhập bằng giọng nói',metrics.voiceInputs,Icons.mic_none_outlined),
          _metricChip('Đã xác minh (tổng)',metrics.verifiedTotal,Icons.fact_check_outlined),
          _metricChip('Lượt xác minh kỳ này',metrics.verifiedInPeriod,Icons.check_circle_outline),
          _metricChip('Tương tác liên hệ',metrics.contacts,Icons.call_outlined),
          _metricChip('Tin đã đăng',metrics.posts,Icons.campaign_outlined),
          _metricChip('Khách quan tâm',metrics.buyers,Icons.people_outline),
          _metricChip('Việc đến hạn',metrics.due,Icons.event_busy_outlined),
        ]),
        const SizedBox(height:12),
        Text('Tỷ lệ hồ sơ được xác minh có căn cứ: ${metrics.total==0?0:(metrics.verifiedTotal*100/metrics.total).round()}% (${metrics.verifiedTotal}/${metrics.total})',
          style:const TextStyle(fontSize:12,fontWeight:FontWeight.w600)),
        const SizedBox(height:5),
        LinearProgressIndicator(value:metrics.total==0?0:metrics.verifiedTotal/metrics.total,minHeight:7,
          borderRadius:BorderRadius.circular(6)),
        const SizedBox(height:10),
        Text('Biểu đồ nguồn nhập mới (${dashboardDays==1?'hôm nay':dashboardDays==7?'7 ngày':'30 ngày'})',
          style:const TextStyle(fontSize:13,fontWeight:FontWeight.w600)),
        const SizedBox(height:9),
        SizedBox(height:84,child:Row(crossAxisAlignment:CrossAxisAlignment.end,
          children:[for(var i=0;i<metrics.newByDay.length;i++)
            Expanded(child:Padding(padding:const EdgeInsets.symmetric(horizontal:1),child:Column(
              mainAxisAlignment:MainAxisAlignment.end,children:[
                Text('${metrics.newByDay[i]}',style:const TextStyle(fontSize:9)),
                const SizedBox(height:2),
                Container(height:metrics.newByDay[i]==0?3:47*metrics.newByDay[i]/maxDay,
                  decoration:BoxDecoration(color:brand.withValues(alpha:0.75),borderRadius:BorderRadius.circular(3))),
                if(dashboardDays<=7)Text('${today.subtract(Duration(days:dashboardDays-1-i)).day}',
                  style:const TextStyle(fontSize:9,color:Colors.black54)),
              ])))])),
        const SizedBox(height:6),
        const Text('Tính theo nhật ký công việc và hồ sơ đã lưu. Xác minh chính chủ chỉ được tính khi có bằng chứng do người dùng nhập.',
          style:TextStyle(fontSize:11,color:Colors.black54)),
      ])));
  }
  Widget _metricChip(String title,int count,IconData icon)=>Container(
    width:135,padding:const EdgeInsets.all(9),
    decoration:BoxDecoration(color:const Color(0xfff0f6f4),borderRadius:BorderRadius.circular(12)),
    child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Icon(icon,size:18,color:brand),const SizedBox(height:4),
      Text('$count',style:const TextStyle(fontSize:21,fontWeight:FontWeight.bold)),
      Text(title,style:const TextStyle(fontSize:11)),
    ]));
  Widget _stat(String label,int value,IconData icon,VoidCallback onTap)=>Card(
    clipBehavior:Clip.antiAlias,child:InkWell(onTap:onTap,child:Padding(padding:const EdgeInsets.all(13),child:Column(
    crossAxisAlignment:CrossAxisAlignment.start,children:[Icon(icon,color:brand),const SizedBox(height:7),
      Text('$value',style:const TextStyle(fontSize:28,fontWeight:FontWeight.w800)),
      Row(children:[Expanded(child:Text(label,style:const TextStyle(fontSize:12,color:Colors.black54))),
        const Icon(Icons.chevron_right,size:18,color:brand)])]))));
  Widget _attentionTile(Attention a) => Column(children:[
    ListTile(contentPadding:EdgeInsets.zero,dense:true,
      leading:CircleAvatar(backgroundColor:a.priority==0?const Color(0xffffe9d5):const Color(0xffe6f3f0),
        child:Icon(a.priority==0?Icons.priority_high:Icons.assignment_outlined,color:brand)),
      title:Text(a.listing.title,style:const TextStyle(fontWeight:FontWeight.w600),maxLines:2),
      subtitle:Text(a.reason,maxLines:2,overflow:TextOverflow.ellipsis),
      trailing:const Icon(Icons.chevron_right),onTap:()=>detail(a.listing)),
    const Divider(height:1)
  ]);
  Widget _inventory()=>ListView(padding:const EdgeInsets.all(16),children:[
    TextField(decoration:const InputDecoration(prefixIcon:Icon(Icons.search),hintText:'Tìm địa chỉ, tên chủ, số điện thoại...'),
      onChanged:(x)=>setState(()=>search=x)),const SizedBox(height:10),
    Text('${listings.length} nguồn hàng',style:const TextStyle(fontWeight:FontWeight.bold)),
    ...listings.where((p)=>('${p.title} ${p.address} ${p.owner} ${p.phone}').toLowerCase().contains(search.toLowerCase())).map((p)=>Card(
      child:ListTile(title:Text(p.title,style:const TextStyle(fontWeight:FontWeight.w600)),
        subtitle:Text('${p.address}\n${p.price.isEmpty?'Chưa có giá':p.price} • ${p.contractStatus}${p.archived?' • Dừng khai thác':''}'),
        isThreeLine:true,trailing:const Icon(Icons.chevron_right),onTap:()=>detail(p)))),
    const SizedBox(height:90),
  ]);
  Widget _tasks()=>ListView(padding:const EdgeInsets.all(16),children:[
    Text('${attention.length} nguồn hàng cần theo dõi',style:const TextStyle(fontSize:20,fontWeight:FontWeight.bold)),
    const SizedBox(height:5),
    const Text('Chọn từng hồ sơ để xem việc chưa làm và gửi phản hồi sau khi thực hiện.',style:TextStyle(color:Colors.black54)),
    const SizedBox(height:12),
    if(attention.isEmpty)const Card(child:Padding(padding:EdgeInsets.all(20),child:Text('Đã xử lý hết các nguồn cần theo dõi.'))),
    ...attention.map((e)=>Card(child:_attentionTile(e))),const SizedBox(height:90),
  ]);
  /// Portable compressed backup including photos (legacy V2 JSON remains readable).
  Future<void> backup() async {
    try {
      final dir=await getApplicationDocumentsDirectory();
      final photos=<String,String>{};
      for(final listing in listings){
        for(var i=0;i<listing.imagePaths.length;i++){
          final f=File(listing.imagePaths[i]);
          if(await f.exists())photos['${listing.id}/$i']=base64Encode(await f.readAsBytes());
        }
      }
      final payload=jsonEncode({'schema':3,'createdAt':DateTime.now().toIso8601String(),
        'listings':listings.map((x)=>x.toJson()).toList(),'photos':photos,
        'hunterLeads':(await hunterStore.leads()).map((x)=>x.toJson()).toList(),
        'hunterSettings':(await hunterStore.settings()).toJson()});
      final file=File(path.join(dir.path,'sourceflow_personal_${DateTime.now().millisecondsSinceEpoch}.sfbackup'));
      await file.writeAsBytes(gzip.encode(utf8.encode(payload)));
      await SharePlus.instance.share(ShareParams(files:[XFile(file.path)],
        text:'SourceFlow Personal: bản sao lưu gồm hồ sơ và ảnh. Lưu riêng tại nơi an toàn.'));
    }catch(e){message('Không xuất được sao lưu: $e');}
  }
  Future<void> restore() async {
    try {
      final picked=await FilePicker.platform.pickFiles(type:FileType.custom,
        allowedExtensions:['json','sfbackup'],withData:false);
      if(picked==null)return;
      final entry=picked.files.single;
      if(entry.size>160*1024*1024){message('Tệp quá lớn (>160 MB).');return;}
      final bytes=entry.bytes??(entry.path==null?null:await File(entry.path!).readAsBytes());
      if(bytes==null){message('Không truy cập được tệp đã chọn.');return;}
      final isGzip=bytes.length>=2&&bytes[0]==0x1f&&bytes[1]==0x8b;
      final payload=utf8.decode(isGzip?gzip.decode(bytes):bytes);
      final root=jsonDecode(payload);
      if(root is! Map || !(root['schema']==2||root['schema']==3)||root['listings'] is! List){
        message('Không phải tệp sao lưu SourceFlow V2/V2.1/V2.2 hợp lệ.');return;
      }
      final incoming=(root['listings'] as List).whereType<Map>()
        .map((e)=>Listing.fromJson(Map<String,dynamic>.from(e))).toList();
      if(incoming.length>50000){message('Số lượng hồ sơ vượt giới hạn.');return;}
      if(!mounted)return;
      final yes=await showDialog<bool>(context:context,builder:(ctx)=>AlertDialog(
        title:const Text('Khôi phục bản sao lưu?'),
        content:Text('Sẽ thêm/cập nhật ${incoming.length} nguồn hàng. Nếu tệp có ảnh đi kèm, ảnh sẽ được phục hồi vào bộ nhớ ứng dụng.'),
        actions:[TextButton(onPressed:()=>Navigator.pop(ctx,false),child:const Text('Hủy')),
          FilledButton(onPressed:()=>Navigator.pop(ctx,true),child:const Text('Đồng ý'))]));
      if(yes!=true)return;
      final restoredPhotos=root['photos'] is Map ? Map<String,dynamic>.from(root['photos'] as Map):<String,dynamic>{};
      final folder=Directory(path.join((await getApplicationDocumentsDirectory()).path,'photos'));
      await folder.create(recursive:true);
      for(final listing in incoming){
        final mapped=<String>[];
        for(var i=0;i<listing.imagePaths.length;i++){
          final blob=restoredPhotos['${listing.id}/$i'];
          if(blob is String){
            final suffix=path.extension(listing.imagePaths[i]).toLowerCase();
            final ext=['.jpg','.jpeg','.png','.webp'].contains(suffix)?suffix:'.jpg';
            final dest=path.join(folder.path,'${newId()}$ext');
            await File(dest).writeAsBytes(base64Decode(blob));
            mapped.add(dest);
          }else if(await File(listing.imagePaths[i]).exists()){
            mapped.add(listing.imagePaths[i]);
          }
        }
        listing.imagePaths=mapped;
        listing.imagePath=mapped.isEmpty?'':mapped.first;
        await store.save(listing);
      }
      if(root['hunterLeads'] is List){
        final restored=(root['hunterLeads'] as List).whereType<Map>().map((e)=>
          HunterLead.fromJson(Map<String,dynamic>.from(e))).toList();
        await hunterStore.addDiscovered(restored);
        for(final lead in restored){if(lead.status!='pending')await hunterStore.updateLead(lead);}
      }
      if(root['hunterSettings'] is Map){
        await hunterStore.saveSettings(HunterSettings.fromJson(Map<String,dynamic>.from(root['hunterSettings'] as Map)));
      }
      final snap=await hunterStore.snapshot();
      final loaded=await store.all();await reminder.refresh(loaded);
      if(mounted)setState((){listings=loaded;hunterSnapshot=snap;});
      message('Đã khôi phục ${incoming.length} hồ sơ cùng ${restoredPhotos.length} ảnh có trong bản sao lưu.');
    }catch(e){message('Không khôi phục được tệp: $e');}
  }
  Widget _settings()=>ListView(padding:const EdgeInsets.all(16),children:[
    const Text('Dữ liệu & an toàn',style:TextStyle(fontSize:21,fontWeight:FontWeight.bold)),
    const SizedBox(height:10),
    Card(child:Column(children:[
      ListTile(leading:const Icon(Icons.download_outlined),title:const Text('Sao lưu hồ sơ kèm toàn bộ ảnh'),
        subtitle:const Text('Xuất file .sfbackup gồm thông tin, lịch sử và ảnh; lưu ngoài điện thoại.'),onTap:backup),
      const Divider(height:1),
      ListTile(leading:const Icon(Icons.upload_file_outlined),title:const Text('Khôi phục sao lưu V2 / V2.1 / V2.2'),
        subtitle:const Text('Đọc .sfbackup có ảnh hoặc .json V2 cũ (không có ảnh).'),onTap:restore),
    ])),const SizedBox(height:8),
    const Card(child:Padding(padding:EdgeInsets.all(16),child:Text(
      'SourceFlow Personal R1 lưu cục bộ trên Android (SQLite). Dashboard tự cập nhật khi thao tác được lưu. Quét web công khai chỉ trả về ứng viên chưa xác minh. Lịch quét nền phụ thuộc Android và dịch vụ RSS tìm kiếm; chưa đồng bộ Windows/iOS, chưa mã hóa dữ liệu với khóa riêng. Không lưu ảnh giấy tờ định danh nhạy cảm nếu thiết bị chưa được bảo vệ. \n\nThông báo buổi sáng dự kiến vào khoảng 08:00; Android có thể trì hoãn do chế độ tiết kiệm pin, và phải cấp quyền thông báo. Mở ứng dụng sẽ luôn cập nhật danh sách theo trạng thái mới nhất.',
      style:TextStyle(height:1.5)))),const SizedBox(height:90),
  ]);
}

/// Tap any dashboard statistic to open the corresponding live, searchable list.
class FilteredListingPage extends StatefulWidget {
  final String heading;
  final List<Listing> Function() select;
  final Future<void> Function(Listing) onOpen;
  const FilteredListingPage({super.key,required this.heading,required this.select,required this.onOpen});
  @override State<FilteredListingPage> createState()=>_FilteredListingPageState();
}
class _FilteredListingPageState extends State<FilteredListingPage>{
  String query='';
  @override Widget build(BuildContext context){
    final all=widget.select();
    final shown=all.where((p)=>('${p.title} ${p.address} ${p.owner} ${p.phone} ${p.verification}')
      .toLowerCase().contains(query.toLowerCase())).toList();
    return Scaffold(appBar:AppBar(title:Text(widget.heading)),body:ListView(
      padding:const EdgeInsets.all(16),children:[
        Text('${all.length} nguồn hàng',style:const TextStyle(fontSize:18,fontWeight:FontWeight.bold)),
        const SizedBox(height:12),
        TextField(decoration:const InputDecoration(prefixIcon:Icon(Icons.search),hintText:'Tìm địa chỉ, nguồn hàng, người liên hệ'),
          onChanged:(v)=>setState(()=>query=v)),const SizedBox(height:12),
        if(shown.isEmpty)const Padding(padding:EdgeInsets.all(20),child:Text('Không có nguồn hàng phù hợp.')),
        ...shown.map((p)=>Card(child:ListTile(
          title:Text(p.title.isEmpty?'Nguồn chưa đặt tên':p.title,style:const TextStyle(fontWeight:FontWeight.w600)),
          subtitle:Text('${p.address.isEmpty?'Chưa có địa chỉ':p.address}\n${p.verification} • ${p.contractStatus}',maxLines:3),
          isThreeLine:true,trailing:const Icon(Icons.chevron_right),
          onTap:() async{await widget.onOpen(p);if(mounted)setState((){});},
        ))),
      ]));
  }
}

/// Open images fullscreen with swipe and pinch zoom; no longer a dead thumbnail.
class PhotoGalleryPage extends StatefulWidget {
  final List<String> paths;
  final int initialIndex;
  const PhotoGalleryPage({super.key,required this.paths,this.initialIndex=0});
  @override State<PhotoGalleryPage> createState()=>_PhotoGalleryPageState();
}
class _PhotoGalleryPageState extends State<PhotoGalleryPage>{
  late final PageController controller;
  late int current;
  @override void initState(){super.initState();current=widget.initialIndex;controller=PageController(initialPage:current);}
  @override void dispose(){controller.dispose();super.dispose();}
  @override Widget build(BuildContext context)=>Scaffold(
    backgroundColor:Colors.black,appBar:AppBar(backgroundColor:Colors.black,foregroundColor:Colors.white,
      title:Text('Ảnh ${current+1}/${widget.paths.length}')),
    body:PageView.builder(controller:controller,itemCount:widget.paths.length,
      onPageChanged:(i)=>setState(()=>current=i),itemBuilder:(_,index){
        final file=File(widget.paths[index]);
        return Center(child:file.existsSync()
          ?InteractiveViewer(minScale:0.7,maxScale:5,child:Image.file(file,fit:BoxFit.contain,
              errorBuilder:(_,__,___)=>const Text('Không đọc được ảnh',style:TextStyle(color:Colors.white))))
          :const Padding(padding:EdgeInsets.all(20),child:Text('Tệp ảnh không còn trên thiết bị. Hãy chọn lại trong phần Chỉnh sửa nguồn hàng.',
              style:TextStyle(color:Colors.white),textAlign:TextAlign.center)));
      }));
}

class ListingDetail extends StatefulWidget {
  final Listing listing;
  final Future<void> Function(Listing) onSave;
  final Future<Listing?> Function(Listing) onEdit;
  const ListingDetail({super.key,required this.listing,required this.onSave,required this.onEdit});
  @override State<ListingDetail> createState()=>_ListingDetailState();
}

class _ListingDetailState extends State<ListingDetail> {
  late Listing p;
  @override void initState(){super.initState();p=widget.listing;}
  Future<void> _feedback() async {
    final result=await showModalBottomSheet<FeedbackResult>(context:context,isScrollControlled:true,showDragHandle:true,
      builder:(_)=>const FeedbackSheet());
    if(result==null)return;
    applyFeedback(p,result.outcome,result.note,nextAction:result.nextAction,due:result.due);
    await widget.onSave(p);
    if(mounted)setState((){});
  }
  Future<void> _verify() async {
    String status=p.verification;
    final evidence=TextEditingController(text:p.verificationEvidence);
    final result=await showDialog<bool>(context:context,builder:(dialogContext)=>StatefulBuilder(builder:(ctx,setLocal)=>AlertDialog(
      title:const Text('Xác minh chủ tài sản'),content:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,children:[
        DropdownButtonFormField<String>(value:status,isExpanded:true,decoration:const InputDecoration(labelText:'Mức độ xác minh'),
          items:const ['Chưa xác minh','Đã trao đổi, chưa đối chiếu','Cần kiểm tra thêm','Đã đối chiếu hồ sơ','Đã gặp và xác minh trực tiếp','Có dấu hiệu môi giới'].map((e)=>DropdownMenuItem(value:e,child:Text(e,overflow:TextOverflow.ellipsis))).toList(),
          onChanged:(v)=>setLocal(()=>status=v??status)),
        const SizedBox(height:14),TextField(controller:evidence,maxLines:3,decoration:const InputDecoration(labelText:'Căn cứ xác minh (khi có)')),
      ])),actions:[TextButton(onPressed:()=>Navigator.pop(ctx,false),child:const Text('Hủy')),
        FilledButton(onPressed:()=>Navigator.pop(ctx,true),child:const Text('Lưu'))])));
    if(!mounted){evidence.dispose();return;}
    if(result==true){
      final proof=evidence.text.trim();
      if((status=='Đã đối chiếu hồ sơ'||status=='Đã gặp và xác minh trực tiếp')&&proof.isEmpty){
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Cần ghi rõ căn cứ để xác nhận chính chủ')));
      } else {
        p.verification=status;p.verificationEvidence=proof;p.addLog('Cập nhật xác minh chính chủ', '$status. $proof');
        await widget.onSave(p);if(mounted)setState((){});
      }
    }
    evidence.dispose();
  }
  Future<void> _editContract() async {
    final number=TextEditingController(text:p.contractNumber);
    final fee=TextEditingController(text:p.contractFee);
    bool signed=p.contractStatus=='Đã ký', exclusive=p.exclusive;
    DateTime? expiry=p.contractExpires;
    final ok=await showDialog<bool>(context:context,builder:(ctx)=>StatefulBuilder(builder:(c,update)=>AlertDialog(
      title:const Text('Hợp đồng môi giới'),content:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,children:[
        SwitchListTile(contentPadding:EdgeInsets.zero,title:const Text('Đã ký hợp đồng'),value:signed,onChanged:(v)=>update(()=>signed=v)),
        TextField(controller:number,decoration:const InputDecoration(labelText:'Số hợp đồng')),
        const SizedBox(height:9),TextField(controller:fee,decoration:const InputDecoration(labelText:'Phí môi giới (%)')),
        SwitchListTile(contentPadding:EdgeInsets.zero,title:const Text('Độc quyền'),value:exclusive,onChanged:(v)=>update(()=>exclusive=v)),
        OutlinedButton.icon(onPressed:()async{
          final x=await showDatePicker(context:ctx,initialDate:expiry??DateTime.now().add(const Duration(days:90)),
            firstDate:DateTime(2020),lastDate:DateTime(2100));
          if(x!=null)update(()=>expiry=x);
        },icon:const Icon(Icons.calendar_month),label:Text('Hết hạn: ${dateLabel(expiry)}')),
      ])),actions:[TextButton(onPressed:()=>Navigator.pop(ctx,false),child:const Text('Hủy')),
        FilledButton(onPressed:()=>Navigator.pop(ctx,true),child:const Text('Lưu hợp đồng'))])));
    if(ok==true){
      p.contractNumber=number.text.trim();p.contractFee=fee.text.trim();p.exclusive=exclusive;p.contractExpires=expiry;
      p.contractStatus=signed?'Đã ký':'Chưa ký';
      if(signed){p.marketingNeedsAttention=false;p.nextAction='';p.nextDue=null;
        if(p.saleStatus=='Chưa chào bán')p.saleStatus='Chuẩn bị chào bán';}
      p.addLog('Cập nhật hợp đồng', '${p.contractStatus}; Số: ${p.contractNumber}; Phí: ${p.contractFee}%');
      await widget.onSave(p);if(mounted)setState((){});
    }
    number.dispose();fee.dispose();
  }
  Future<void> _addMarketing() async {
    final channel=TextEditingController(),url=TextEditingController();
    final ok=await showDialog<bool>(context:context,builder:(ctx)=>AlertDialog(
      title:const Text('Ghi nhận đăng tin chào bán'),
      content:Column(mainAxisSize:MainAxisSize.min,children:[
        TextField(controller:channel,decoration:const InputDecoration(labelText:'Kênh đăng (website, mạng xã hội...)')),
        const SizedBox(height:9),TextField(controller:url,decoration:const InputDecoration(labelText:'Link tin đăng')),
      ]),actions:[TextButton(onPressed:()=>Navigator.pop(ctx,false),child:const Text('Hủy')),
        FilledButton(onPressed:()=>Navigator.pop(ctx,true),child:const Text('Lưu'))]));
    if(ok==true&&channel.text.trim().isNotEmpty){
      p.posts.insert(0,MarketingPost(channel:channel.text.trim(),url:url.text.trim()));
      p.saleStatus='Đang chào bán';
      p.addLog('Đã đăng tin chào bán', '${channel.text.trim()}: ${url.text.trim()}');
      await widget.onSave(p);if(mounted)setState((){});
    }
    channel.dispose();url.dispose();
  }
  Future<void> _addOffer() async {
    final buyer=TextEditingController(),contact=TextEditingController(),price=TextEditingController(),note=TextEditingController();
    final ok=await showDialog<bool>(context:context,builder:(ctx)=>AlertDialog(
      title:const Text('Ghi khách quan tâm / trả giá'),
      content:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,children:[
        TextField(controller:buyer,decoration:const InputDecoration(labelText:'Tên khách hoặc mã khách')),
        const SizedBox(height:8),TextField(controller:contact,decoration:const InputDecoration(labelText:'SĐT khách (nếu có)')),
        const SizedBox(height:8),TextField(controller:price,decoration:const InputDecoration(labelText:'Giá đề nghị')),
        const SizedBox(height:8),TextField(controller:note,decoration:const InputDecoration(labelText:'Phản hồi / nhu cầu'),maxLines:2),
      ])),actions:[TextButton(onPressed:()=>Navigator.pop(ctx,false),child:const Text('Hủy')),
        FilledButton(onPressed:()=>Navigator.pop(ctx,true),child:const Text('Lưu'))]));
    if(ok==true&&buyer.text.trim().isNotEmpty){
      p.offers.insert(0,BuyerOffer(buyer:buyer.text.trim(),contact:contact.text.trim(),offer:price.text.trim(),note:note.text.trim()));
      p.saleStatus='Có khách quan tâm';p.marketingNeedsAttention=true;
      p.nextAction='Phản hồi chủ tài sản về khách quan tâm/giá đề nghị';p.nextDue=DateTime.now();
      p.addLog('Có khách quan tâm / đề nghị mua','${buyer.text.trim()}: ${price.text.trim()}. ${note.text.trim()}');
      await widget.onSave(p);if(mounted)setState((){});
    }
    buyer.dispose();contact.dispose();price.dispose();note.dispose();
  }
  Future<void> _call() async {
    final tel=p.phone.replaceAll(RegExp(r'[^\d+]'),'');
    if(tel.isEmpty)return;
    final u=Uri(scheme:'tel',path:tel);
    if(await canLaunchUrl(u)){await launchUrl(u);}
  }
  @override Widget build(BuildContext context) {
    final att=attentionFor(p,DateTime.now());
    return Scaffold(appBar:AppBar(title:const Text('Hồ sơ nguồn hàng'),actions:[IconButton(onPressed:() async {final edited=await widget.onEdit(p); if(mounted&&edited!=null)setState(()=>p=edited);},icon:const Icon(Icons.edit_outlined),tooltip:'Sửa nguồn')]),
      body:ListView(padding:const EdgeInsets.all(16),children:[
        Text(p.title,style:const TextStyle(fontSize:22,fontWeight:FontWeight.bold)),
        const SizedBox(height:5),Text(p.address.isEmpty?'Địa chỉ chưa nhập':p.address,style:const TextStyle(color:Colors.black54)),
        const SizedBox(height:10),Wrap(spacing:7,runSpacing:7,children:[Chip(label:Text(p.contractStatus)),Chip(label:Text('NV: ${p.saleStatus}')),if(p.sourceUrl.isNotEmpty)const Chip(label:Text('Có tin nguồn trên web')),Chip(label:Text(p.verification))]),
        const SizedBox(height:8),Align(alignment:Alignment.centerRight,child:TextButton.icon(
          onPressed:() async {final result=await widget.onEdit(p);if(mounted&&result!=null)setState(()=>p=result);},
          icon:const Icon(Icons.edit_note),label:const Text('Sửa / bổ sung thông tin nguồn'))),
        if(p.imagePaths.isNotEmpty)Padding(padding:const EdgeInsets.only(top:10),child:Column(
          crossAxisAlignment:CrossAxisAlignment.start,children:[
          Text('Ảnh nguồn hàng (${p.imagePaths.length}) — nhấn để xem lớn',style:const TextStyle(fontWeight:FontWeight.w600)),
          const SizedBox(height:7),SizedBox(height:120,child:ListView.separated(scrollDirection:Axis.horizontal,
            itemCount:p.imagePaths.length,separatorBuilder:(_,__)=>const SizedBox(width:8),itemBuilder:(ctx,index){
              final f=File(p.imagePaths[index]);
              return InkWell(onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>PhotoGalleryPage(
                paths:p.imagePaths,initialIndex:index))),child:ClipRRect(borderRadius:BorderRadius.circular(12),
                child:f.existsSync()?Image.file(f,width:150,height:115,fit:BoxFit.cover,
                  errorBuilder:(_,__,___)=>const SizedBox(width:150,child:Icon(Icons.broken_image_outlined)))
                  :const SizedBox(width:150,child:Center(child:Icon(Icons.broken_image_outlined)))));
            })),
        ])),
        const SizedBox(height:12),
        Card(child:Padding(padding:const EdgeInsets.all(15),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
          Row(children:[const Icon(Icons.pending_actions,color:brand),const SizedBox(width:7),
            const Expanded(child:Text('CÔNG VIỆC CHƯA THỰC HIỆN',style:TextStyle(fontWeight:FontWeight.bold)))]),
          const SizedBox(height:8),Text(att?.reason??'Không có việc cần nhắc buổi sáng. Nếu có thay đổi chào bán, hãy ghi phản hồi.',
            style:const TextStyle(height:1.45)),
          if(p.nextDue!=null)Text('Lịch dự kiến: ${dateLabel(p.nextDue)}',style:const TextStyle(color:Colors.black54)),
          const SizedBox(height:12),SizedBox(width:double.infinity,child:FilledButton.icon(
            onPressed:_feedback,icon:const Icon(Icons.rate_review_outlined),label:const Text('Đã thực hiện → Gửi phản hồi'))),
        ]))),
        Card(child:Column(children:[
          ListTile(leading:const Icon(Icons.person_outline),title:Text(p.owner.isEmpty?'Chưa có tên chủ':p.owner),
            subtitle:Text(p.phone.isEmpty?'Chưa có điện thoại (nhấn để bổ sung)':p.phone),
            onTap:() async {final result=await widget.onEdit(p);if(mounted&&result!=null)setState(()=>p=result);},
            trailing:p.phone.isEmpty?const Icon(Icons.edit_outlined):IconButton(onPressed:_call,icon:const Icon(Icons.call,color:brand))),
          const Divider(height:1),
          ListTile(leading:const Icon(Icons.fact_check_outlined),title:const Text('Xác minh chủ sở hữu'),
            subtitle:Text('${p.verification}${p.verificationEvidence.isEmpty?'':'\nCăn cứ: ${p.verificationEvidence}'}'),
            trailing:const Icon(Icons.edit_outlined),onTap:_verify),
          const Divider(height:1),
          ListTile(title:const Text('Diện tích / Giá / Nguồn (nhấn để sửa)'),subtitle:Text(
            '${p.area.isEmpty?'Chưa có diện tích':p.area} • ${p.price.isEmpty?'Chưa có giá':p.price}\n'
            'Ngang: ${p.width.isEmpty?'Chưa nhập':p.width} • Dài: ${p.length.isEmpty?'Chưa nhập':p.length}\nNguồn: ${p.source}'),
            trailing:const Icon(Icons.edit_outlined),onTap:() async {
              final result=await widget.onEdit(p);if(mounted&&result!=null)setState(()=>p=result);
            }),
          if(p.sourceUrl.isNotEmpty)ListTile(leading:const Icon(Icons.link),title:const Text('Mở tin nguồn'),
            subtitle:Text(p.sourceUrl,maxLines:1,overflow:TextOverflow.ellipsis),onTap:()async{
              final u=Uri.tryParse(p.sourceUrl);if(u!=null&&(u.scheme=='https'||u.scheme=='http')) await launchUrl(u,mode:LaunchMode.externalApplication);
            }),
        ])),
        Card(child:Padding(padding:const EdgeInsets.all(12),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
          Row(children:[const Expanded(child:Text('HỢP ĐỒNG MÔI GIỚI',style:TextStyle(fontWeight:FontWeight.bold))),
            TextButton.icon(onPressed:_editContract,icon:const Icon(Icons.edit,size:18),label:const Text('Cập nhật'))]),
          Text('${p.contractStatus} • Số: ${p.contractNumber.isEmpty?'Chưa ghi':p.contractNumber}'),
          Text('Phí: ${p.contractFee.isEmpty?'Chưa ghi':p.contractFee+'%'} • ${p.exclusive?'Độc quyền':'Không độc quyền'} • Hết hạn: ${dateLabel(p.contractExpires)}',
            style:const TextStyle(fontSize:12,color:Colors.black54)),
        ]))),
        Card(child:Padding(padding:const EdgeInsets.all(12),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
          Row(children:[const Expanded(child:Text('KÊNH CHÀO BÁN',style:TextStyle(fontWeight:FontWeight.bold))),
            TextButton.icon(onPressed:_addMarketing,icon:const Icon(Icons.add,size:18),label:const Text('Đăng tin'))]),
          if(p.posts.isEmpty)const Text('Chưa ghi nhận tin chào bán.'),
          ...p.posts.map((post)=>ListTile(dense:true,contentPadding:EdgeInsets.zero,
            title:Text(post.channel),subtitle:Text('${post.status} • ${dateLabel(post.added)}\n${post.url}',maxLines:3))),
        ]))),
        Card(child:Padding(padding:const EdgeInsets.all(12),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
          Row(children:[const Expanded(child:Text('KHÁCH QUAN TÂM / TRẢ GIÁ',style:TextStyle(fontWeight:FontWeight.bold))),
            TextButton.icon(onPressed:_addOffer,icon:const Icon(Icons.add,size:18),label:const Text('Ghi khách'))]),
          if(p.offers.isEmpty)const Text('Chưa ghi nhận khách quan tâm.'),
          ...p.offers.map((offer)=>ListTile(dense:true,contentPadding:EdgeInsets.zero,
            title:Text('${offer.buyer} • ${offer.offer}'),subtitle:Text('${offer.contact}\n${offer.note}',maxLines:3))),
        ]))),
        if(p.rawCapture.isNotEmpty)Card(child:ExpansionTile(title:const Text('Dữ liệu gốc từ ảnh/giọng nói'),children:[
          Padding(padding:const EdgeInsets.all(14),child:SelectableText(p.rawCapture))])),
        const Padding(padding:EdgeInsets.symmetric(vertical:12),child:Text('NHẬT KÝ THEO THỜI GIAN',style:TextStyle(fontWeight:FontWeight.bold))),
        if(p.logs.isEmpty)const Text('Chưa có phản hồi nào.'),
        ...p.logs.map((e)=>Card(child:ListTile(leading:const Icon(Icons.history,color:brand),
          title:Text(e.action),subtitle:Text('${dateLabel(e.at)} • ${e.note}')))),
        const SizedBox(height:40),
      ]),
    );
  }
}

class FeedbackResult {
  final String outcome,note,nextAction;
  final DateTime? due;
  const FeedbackResult(this.outcome,this.note,this.nextAction,this.due);
}
class FeedbackSheet extends StatefulWidget {
  const FeedbackSheet({super.key});
  @override State<FeedbackSheet> createState()=>_FeedbackSheetState();
}
class _FeedbackSheetState extends State<FeedbackSheet> {
  String outcome=feedbackOptions.first;
  final note=TextEditingController(),next=TextEditingController();
  DateTime? due;
  @override void dispose(){note.dispose();next.dispose();super.dispose();}
  @override Widget build(BuildContext context) => Padding(
    padding:EdgeInsets.only(bottom:MediaQuery.viewInsetsOf(context).bottom+18,left:18,right:18),
    child:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,crossAxisAlignment:CrossAxisAlignment.start,children:[
      const Text('Phản hồi kết quả công việc',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold)),
      const SizedBox(height:12),DropdownButtonFormField<String>(isExpanded:true,value:outcome,
        decoration:const InputDecoration(labelText:'Kết quả thực hiện'),
        items:feedbackOptions.map((e)=>DropdownMenuItem(value:e,child:Text(e,overflow:TextOverflow.ellipsis))).toList(),
        onChanged:(v)=>setState(()=>outcome=v??outcome)),const SizedBox(height:12),
      TextField(controller:note,maxLines:3,decoration:const InputDecoration(labelText:'Ghi chú phản hồi',hintText:'Chủ nói gì? Có đồng ý? Điều kiện nào?')),
      const SizedBox(height:12),TextField(controller:next,decoration:const InputDecoration(labelText:'Việc tiếp theo (để trống = phần mềm gợi ý)')),
      const SizedBox(height:7),OutlinedButton.icon(onPressed:()async{
        final d=await showDatePicker(context:context,initialDate:due??DateTime.now(),firstDate:DateTime(2020),lastDate:DateTime(2100));
        if(d!=null)setState(()=>due=d);
      },icon:const Icon(Icons.calendar_today_outlined),label:Text(due==null?'Chọn hạn xử lý':dateLabel(due))),
      const SizedBox(height:12),SizedBox(width:double.infinity,child:FilledButton(onPressed:()=>Navigator.pop(context,
        FeedbackResult(outcome,note.text,next.text,due)),child:const Text('Ghi nhận & cập nhật tiến độ'))),
    ])),
  );
}

class IntakePage extends StatefulWidget {
  final List<Listing> existing;
  final Listing? original;
  const IntakePage({super.key,required this.existing,this.original});
  @override State<IntakePage> createState()=>_IntakePageState();
}

class _IntakePageState extends State<IntakePage> {
  late Listing draft;
  final formKey=GlobalKey<FormState>();
  final title=TextEditingController(),address=TextEditingController(),area=TextEditingController();
  final width=TextEditingController(),length=TextEditingController();
  final price=TextEditingController(),owner=TextEditingController(),phone=TextEditingController();
  final sourceUrl=TextEditingController(),raw=TextEditingController();
  final verificationEvidence=TextEditingController(),nextAction=TextEditingController();
  final contractNumber=TextEditingController(),contractFee=TextEditingController();
  final SpeechToText speech=SpeechToText();
  final List<String> stagedPhotos=[];
  bool recognizing=false, listening=false, saving=false, committed=false;
  bool didExtractOcr=false,didExtractVoice=false;
  int mode=0,photoCount=0,voiceMinutes=3;
  String photoScanStatus='';
  int photoScanned=0,photoWithText=0,photoFailed=0;
  String autoFillStatus='';
  Timer? voiceTicker;
  DateTime? voiceDeadline;
  Duration elapsed=Duration.zero;
  String voiceBaseline='', voiceCurrent='';
  final List<String> completedVoiceSegments=[];
  bool voiceWanted=false, voiceStarting=false, restartQueued=false;
  int runToken=0;

  @override void initState(){
    super.initState();
    draft=widget.original==null?Listing():Listing.fromJson(widget.original!.toJson());
    title.text=draft.title;address.text=draft.address;area.text=draft.area;
    width.text=draft.width;length.text=draft.length;price.text=draft.price;
    owner.text=draft.owner;phone.text=draft.phone;sourceUrl.text=draft.sourceUrl;
    raw.text=draft.rawCapture;verificationEvidence.text=draft.verificationEvidence;
    nextAction.text=draft.nextAction;contractNumber.text=draft.contractNumber;contractFee.text=draft.contractFee;
  }
  @override void dispose(){
    voiceWanted=false;voiceTicker?.cancel();speech.stop();
    if(!committed){
      for(final p in stagedPhotos){
        File(p).delete().catchError((_)=>File(p));
      }
    }
    for(final c in [title,address,area,width,length,price,owner,phone,sourceUrl,raw,
      verificationEvidence,nextAction,contractNumber,contractFee]){c.dispose();}
    super.dispose();
  }
  void message(String value){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(value)));}

  /// Tự điền trực tiếp vào biểu mẫu khi OCR hoặc nhận dạng giọng nói có dữ liệu.
  /// Chỉ điền ô chưa có giá trị, không thay đổi dữ liệu người dùng đã chỉnh sửa.
  int fillFrom(String text,{bool notify=false,String origin='Văn bản'}){
    final parsed=parseIntake(text);
    final changed=<String>[];
    void apply(TextEditingController field,String guess,String label){
      if(field.text.trim().isEmpty&&guess.trim().isNotEmpty){
        field.text=guess.trim();changed.add(label);
      }
    }
    if(!mounted)return 0;
    setState((){
      apply(title,parsed.title,'Tên nguồn hàng');
      apply(address,parsed.address,'Địa chỉ');
      apply(area,parsed.area,'Diện tích');
      apply(width,parsed.width,'Chiều ngang');
      apply(length,parsed.length,'Chiều dài');
      apply(price,parsed.price,'Giá chào');
      apply(phone,parsed.phone,'Điện thoại');
      apply(owner,parsed.owner,'Tên chủ/người liên hệ');
      apply(sourceUrl,parsed.sourceUrl,'Link nguồn');
      if(parsed.type.isNotEmpty&&draft.type=='Nhà riêng'&&parsed.type!='Nhà riêng'){
        draft.type=parsed.type;changed.add('Loại bất động sản');
      }
      if(draft.source=='Khảo sát thực tế' &&
          (parsed.sourceUrl.isNotEmpty || RegExp(
            r'(?:batdongsan\.com\.vn|bds68\.com\.vn|guland\.vn|nhatot\.com|muaban\.net)',
            caseSensitive:false).hasMatch(text)))draft.source='Trang web';
      if(changed.isNotEmpty){
        autoFillStatus='$origin đã tự điền ${changed.length} trường: ${changed.join(', ')}. '
            'Bạn có thể sửa từng ô trước khi lưu.';
      }else if(notify){
        autoFillStatus='Chưa tìm được trường trống có dữ liệu đủ rõ để tự điền. '
            'Bạn có thể chỉnh văn bản nhận dạng và thử lại.';
      }
    });
    if(changed.isNotEmpty){
      if(origin.startsWith('Ảnh')||origin.startsWith('Hình ảnh')||origin.startsWith('Quét lại')||origin=='OCR')didExtractOcr=true;
      if(origin=='Giọng nói')didExtractVoice=true;
    }
    if(notify)message(changed.isNotEmpty?autoFillStatus:
        'Chưa tìm được thông tin phù hợp hoặc các trường đã có giá trị.');
    return changed.length;
  }

  /// Quét OCR theo từng ảnh, cập nhật biểu mẫu ngay khi có văn bản.
  /// Việc lưu ảnh độc lập với OCR để ảnh vẫn được giữ nếu ML Kit bị lỗi.
  Future<int> _recognizePhotos(List<String> paths,{String origin='OCR', List<String>? originalPaths}) async {
    if(paths.isEmpty)return 0;
    final recognizer=TextRecognizer(script:TextRecognitionScript.latin);
    var found=0;
    var failures=0;
    var addedFields=0;
    String lastError='';
    try {
      for(var i=0;i<paths.length;i++) {
        final photo=paths[i];
        if(!mounted)return addedFields;
        setState(() => photoScanStatus='Đang đọc chữ ảnh ${i+1}/${paths.length}…');
        try {
          if(!await File(photo).exists())throw Exception('Không tìm thấy tệp ảnh');
          // Đọc từ đường dẫn ảnh gốc của bộ chọn trước; nếu Android không
          // giải mã được đường dẫn tạm thì thử lại từ bản sao trong ứng dụng.
          String ocr='';
          Object? firstError;
          final original=originalPaths!=null&&i<originalPaths.length?originalPaths[i]:null;
          if(original!=null && original.isNotEmpty) {
            try {
              final scan=await recognizer.processImage(InputImage.fromFilePath(original));
              ocr=retainAllOcrLines(scan.blocks.expand((block)=>block.lines.map((l)=>l.text)));
            } catch(e) {firstError=e;}
          }
          if(ocr.isEmpty) {
            try {
              final scan=await recognizer.processImage(InputImage.fromFilePath(photo));
              ocr=retainAllOcrLines(scan.blocks.expand((block)=>block.lines.map((l)=>l.text)));
            } catch(e) {
              if(firstError!=null)debugPrint('SourceFlow OCR original photo failed: $firstError');
              rethrow;
            }
          }
          if(ocr.isNotEmpty) {
            found++;
            // Có thể kiểm tra/sửa văn bản OCR trong phần ghi chú mở rộng.
            raw.text=[raw.text.trim(),'[OCR Ảnh ${i+1}]',ocr]
              .where((e)=>e.isNotEmpty).join('\n');
            final hints=ocrFieldsText(ocr.split('\n'));
            addedFields+=fillFrom(hints,origin:'Ảnh ${i+1}');
            // Dùng toàn văn từ nhiều ảnh khi giá trị và nhãn tách ảnh.
            addedFields+=fillFrom(ocrFieldsText(raw.text.split('\n')),origin:origin);
          }
        } catch(e) {
          failures++;
          lastError=e.toString();
          debugPrint('SourceFlow OCR error, photo=$photo: $e');
        }
      }
    } finally {await recognizer.close();}
    if(!mounted)return addedFields;
    setState(() {
      photoScanned=paths.length;
      photoWithText=found;
      photoFailed=failures;
      if(found>0){
        photoScanStatus='OCR nhận dạng được chữ trong $found/${paths.length} ảnh. '
            'Đã điền $addedFields trường còn trống. '
            'Kiểm tra các ô và mở mục văn bản để đối chiếu.';
      }else if(failures>0){
        // A native ML Kit failure is not a failure of parsing the listing.
        // Do not imply that retaking an otherwise readable image fixes this.
        final nativeInitProblem=lastError.contains('NullPointerException') ||
            lastError.contains('null object reference');
        photoScanStatus=nativeInitProblem
            ?'Bộ nhận dạng chữ Android gặp lỗi nội bộ (ML Kit) ở '
                '$failures/${paths.length} ảnh. Không phải do bạn nhập sai; '
                'hãy báo lỗi này để kiểm tra cấu hình APK. Ảnh đã được lưu.'
            :'OCR gặp lỗi ở $failures/${paths.length} ảnh: '
                '${lastError.length>160?lastError.substring(0,160):lastError}. '
                'Ảnh vẫn được lưu; có thể bấm Quét lại chữ.';
      }else{
        photoScanStatus='Không tìm thấy dòng có nhãn dữ liệu cần nhập trong ${paths.length} ảnh. '
            'Chụp rõ các dòng như Ngang, Dài, Diện tích, Giá, Địa chỉ; ảnh vẫn được lưu.';
      }
      // Trả thông tin kể cả khi người dùng đã điền đủ các ô (0 trường mới).
      autoFillStatus=photoScanStatus;
    });
    message(photoScanStatus);
    return addedFields;
  }

  Future<void> scanExistingPhotos() async {
    if(recognizing||draft.imagePaths.isEmpty)return;
    setState(()=>recognizing=true);
    try {await _recognizePhotos(List<String>.from(draft.imagePaths),origin:'Quét lại ảnh');}
    finally {if(mounted)setState(()=>recognizing=false);}
  }

  Future<void> addPhotos({bool camera=false}) async {
    if(recognizing)return;
    try{
      final picker=ImagePicker();
      final List<XFile> selected;
      if(camera){
        final photo=await picker.pickImage(source:ImageSource.camera,imageQuality:95,maxWidth:3000);
        selected=photo==null?<XFile>[]:<XFile>[photo];
      }else{
        selected=await picker.pickMultiImage(imageQuality:95,maxWidth:3000);
      }
      if(selected.isEmpty)return;
      if(draft.imagePaths.length+selected.length>40){message('Giới hạn 40 ảnh mỗi hồ sơ.');return;}
      if(!mounted)return;
      setState(()=>recognizing=true);
      final docs=await getApplicationDocumentsDirectory();
      final dir=Directory(path.join(docs.path,'photos'));
      await dir.create(recursive:true);
      final newPhotos=<String>[];
      for(final pic in selected){
        // Không giả định mọi ảnh là JPEG: đổi phần mở rộng có thể làm OCR thất bại
        // với ảnh WEBP, HEIC, PNG được Android cung cấp.
        final suffix=path.extension(pic.path).toLowerCase();
        final ext=RegExp(r'^\.(?:jpg|jpeg|png|webp|heic|heif|bmp)$').hasMatch(suffix)
            ?suffix:'.jpg';
        final dest=path.join(dir.path,'${newId()}$ext');
        await File(pic.path).copy(dest);
        stagedPhotos.add(dest);
        draft.imagePaths.add(dest);
        newPhotos.add(dest);
        draft.imagePath=draft.imagePaths.first;
        photoCount++;
      }
      if(mounted)setState((){});
      await _recognizePhotos(newPhotos,origin:'Hình ảnh OCR',
        originalPaths:selected.map((x)=>x.path).toList());
    } catch(e){message('Không chọn/đọc được ảnh: $e');}
    finally {if(mounted)setState(()=>recognizing=false);}
  }

  void removePhoto(int index){
    if(index<0||index>=draft.imagePaths.length)return;
    final removed=draft.imagePaths.removeAt(index);
    draft.imagePath=draft.imagePaths.isEmpty?'':draft.imagePaths.first;
    // Keep previously saved original files until the edited record is saved.
    if(stagedPhotos.remove(removed))File(removed).delete().catchError((_)=>File(removed));
    setState((){});
  }

  void _updateTranscript(){
    final parts=<String>[voiceBaseline.trim(),...completedVoiceSegments,voiceCurrent.trim()]
      .where((x)=>x.isNotEmpty).toList();
    if(mounted)setState(()=>raw.text=normalizeVoiceTranscript(parts.join('\n')));
  }
  void _sealSegment(){
    final segment=normalizeVoiceTranscript(voiceCurrent);
    if(segment.isNotEmpty)completedVoiceSegments.add(segment);
    voiceCurrent='';
    _updateTranscript();
    if(segment.isNotEmpty)fillFrom(raw.text,origin:'Giọng nói');
  }
  void _queueVoiceRestart(){
    if(!voiceWanted||restartQueued)return;
    restartQueued=true;
    final token=runToken;
    Future.delayed(const Duration(milliseconds:650),()async{
      restartQueued=false;
      if(!mounted||!voiceWanted||runToken!=token)return;
      if(speech.isListening){return;} // Wait for the next service status callback.
      _sealSegment();
      await _beginVoiceSegment();
    });
  }
  Future<void> _beginVoiceSegment() async {
    if(!mounted||!voiceWanted||voiceStarting||speech.isListening)return;
    final remaining=voiceDeadline?.difference(DateTime.now())??Duration.zero;
    if(remaining<=Duration.zero){await stopVoice();return;}
    voiceStarting=true;
    try{
      final seconds=remaining.inSeconds.clamp(1,50).toInt();
      await speech.listen(localeId:'vi_VN',listenFor:Duration(seconds:seconds),
        pauseFor:const Duration(seconds:12),onResult:(result){
          if(!mounted||!voiceWanted)return;
          voiceCurrent=result.recognizedWords.trim();
          _updateTranscript();
          if(result.finalResult){_sealSegment();_queueVoiceRestart();}
        });
    }catch(e){message('Nhận dạng giọng nói bị gián đoạn: $e');_queueVoiceRestart();}
    finally{voiceStarting=false;}
  }
  Future<void> startVoice() async {
    if(listening)return;
    try{
      final available=await speech.initialize(onStatus:(status){
        if(!mounted||!voiceWanted)return;
        if(status=='done'||status=='notListening')_queueVoiceRestart();
      },onError:(error){
        if(!mounted||!voiceWanted)return;
        if(error.permanent){stopVoice();message('Dịch vụ nhận dạng giọng nói bị dừng: ${error.errorMsg}');}
        else _queueVoiceRestart();
      });
      if(!available){message('Chưa cấp quyền micro hoặc thiếu dịch vụ nhận dạng giọng nói.');return;}
      runToken++;
      voiceBaseline=raw.text;
      completedVoiceSegments.clear();voiceCurrent='';
      voiceDeadline=DateTime.now().add(Duration(minutes:voiceMinutes));
      elapsed=Duration.zero;voiceWanted=true;
      setState(()=>listening=true);
      voiceTicker?.cancel();
      voiceTicker=Timer.periodic(const Duration(seconds:1),(timer){
        if(!mounted||!voiceWanted){timer.cancel();return;}
        final seconds=Duration(minutes:voiceMinutes).inSeconds-(voiceDeadline?.difference(DateTime.now()).inSeconds??0);
        setState(()=>elapsed=Duration(seconds:seconds.clamp(0,voiceMinutes*60).toInt()));
        if(DateTime.now().isAfter(voiceDeadline!)){stopVoice();}
      });
      await _beginVoiceSegment();
    }catch(e){message('Không thể khởi động micro: $e');await stopVoice();}
  }
  Future<void> stopVoice() async {
    if(!voiceWanted&&!listening)return;
    voiceWanted=false;runToken++;
    voiceTicker?.cancel();
    await speech.stop();
    if(!mounted)return;
    _sealSegment();
    fillFrom(raw.text,origin:'Giọng nói',notify:true);
    setState(()=>listening=false);
  }

  String _normalized(String text)=>text.toLowerCase().replaceAll(RegExp(r'\s+'),' ').trim();
  Future<void> save() async {
    if(listening)await stopVoice();
    if(!formKey.currentState!.validate()||saving)return;
    final proof=verificationEvidence.text.trim();
    if((draft.verification=='Đã đối chiếu hồ sơ'||draft.verification=='Đã gặp và xác minh trực tiếp')&&proof.isEmpty){
      message('Muốn xác nhận chính chủ, cần ghi căn cứ xác minh.');return;
    }
    final number=phone.text.replaceAll(RegExp(r'[^0-9+]'),'');
    final loc=_normalized(address.text);
    final duplicate=widget.existing.where((x)=>x.id!=draft.id&&
      ((number.isNotEmpty&&x.phone.replaceAll(RegExp(r'[^0-9+]'),'')==number)||
        (loc.isNotEmpty&&_normalized(x.address)==loc))).toList();
    if(duplicate.isNotEmpty){
      final ok=await showDialog<bool>(context:context,builder:(ctx)=>AlertDialog(
        title:const Text('Có nguồn hàng trùng'),content:Text('Phát hiện ${duplicate.length} hồ sơ trùng số điện thoại hoặc địa chỉ. Bạn vẫn muốn lưu?'),
        actions:[TextButton(onPressed:()=>Navigator.pop(ctx,false),child:const Text('Kiểm tra lại')),
          FilledButton(onPressed:()=>Navigator.pop(ctx,true),child:const Text('Vẫn lưu'))]));
      if(ok!=true)return;
    }
    setState(()=>saving=true);
    draft.title=title.text.trim();draft.address=address.text.trim();draft.area=area.text.trim();
    draft.width=width.text.trim();draft.length=length.text.trim();draft.price=price.text.trim();
    draft.owner=owner.text.trim();draft.phone=phone.text.trim();draft.sourceUrl=sourceUrl.text.trim();
    draft.rawCapture=raw.text.trim();draft.verificationEvidence=proof;draft.nextAction=nextAction.text.trim();
    draft.contractNumber=contractNumber.text.trim();draft.contractFee=contractFee.text.trim();
    draft.imagePath=draft.imagePaths.isEmpty?'':draft.imagePaths.first;
    draft.updatedAt=DateTime.now();
    draft.addLog(widget.original==null?'Tạo nguồn hàng':'Chỉnh sửa thông tin',
      'Nhập bằng ${['tay','hình ảnh','giọng nói'][mode]}; OCR: ${didExtractOcr?'có':'không'}; Giọng nói: ${didExtractVoice?'có':'không'}; ${draft.imagePaths.length} ảnh; nguồn: ${draft.source}.');
    committed=true;
    if(mounted)Navigator.pop(context,draft);
  }

  Widget editField(TextEditingController controller,String label,{TextInputType? keyboard,int lines=1,
      String? hint,bool required=false})=>Padding(padding:const EdgeInsets.only(bottom:12),
    child:TextFormField(controller:controller,keyboardType:keyboard,maxLines:lines,
      decoration:InputDecoration(labelText:label,hintText:hint,suffixIcon:const Icon(Icons.edit_outlined,size:16)),
      validator:required?(v)=>(v??'').trim().isEmpty?'Vui lòng nhập $label':null:null));
  Widget dropdown(String name,String current,List<String> choices,ValueChanged<String> onChanged)=>
    Padding(padding:const EdgeInsets.only(bottom:12),child:DropdownButtonFormField<String>(
      value:choices.contains(current)?current:choices.first,isExpanded:true,
      decoration:InputDecoration(labelText:name),items:choices.map((e)=>DropdownMenuItem(value:e,
        child:Text(e,overflow:TextOverflow.ellipsis))).toList(),
      onChanged:(v){if(v!=null)setState(()=>onChanged(v));}));

  Widget _photoSection()=>Card(child:Padding(padding:const EdgeInsets.all(14),child:Column(
    crossAxisAlignment:CrossAxisAlignment.start,children:[
      Text('Ảnh nguồn hàng (${draft.imagePaths.length})',style:const TextStyle(fontWeight:FontWeight.bold)),
      const SizedBox(height:7),const Text('Chọn ảnh có chữ rõ. OCR dò nhãn và chỉ lấy thông tin khớp với ô dữ liệu, không nhập toàn bộ chữ trong ảnh.'),
      const SizedBox(height:11),Row(children:[
        Expanded(child:OutlinedButton.icon(onPressed:recognizing?null:()=>addPhotos(camera:true),
          icon:const Icon(Icons.camera_alt_outlined),label:const Text('Chụp thêm'))),
        const SizedBox(width:7),Expanded(child:OutlinedButton.icon(onPressed:recognizing?null:()=>addPhotos(),
          icon:const Icon(Icons.photo_library_outlined),label:const Text('Chọn nhiều ảnh'))),
      ]),
      if(draft.imagePaths.isNotEmpty)Padding(padding:const EdgeInsets.only(top:8),child:
        SizedBox(width:double.infinity,child:OutlinedButton.icon(onPressed:recognizing?null:scanExistingPhotos,
          icon:const Icon(Icons.document_scanner_outlined),label:const Text('Quét lại chữ từ tất cả ảnh')))),
      if(photoScanStatus.isNotEmpty)Padding(padding:const EdgeInsets.only(top:8),
        child:Text(photoScanStatus,style:const TextStyle(fontSize:12,color:brand))),
      if(recognizing)const Padding(padding:EdgeInsets.all(10),child:LinearProgressIndicator()),
      if(draft.imagePaths.isNotEmpty)Padding(padding:const EdgeInsets.only(top:12),
        child:SizedBox(height:148,child:ListView.separated(scrollDirection:Axis.horizontal,
          itemCount:draft.imagePaths.length,separatorBuilder:(_,__)=>const SizedBox(width:8),
          itemBuilder:(_,i){
            final f=File(draft.imagePaths[i]);
            return Stack(children:[
              InkWell(onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>PhotoGalleryPage(
                paths:draft.imagePaths,initialIndex:i))),
                child:ClipRRect(borderRadius:BorderRadius.circular(12),child:f.existsSync()
                  ?Image.file(f,width:126,height:138,fit:BoxFit.cover,
                      errorBuilder:(_,__,___)=>const SizedBox(width:126,height:138,child:Icon(Icons.broken_image)))
                  :const SizedBox(width:126,height:138,child:Icon(Icons.broken_image)))),
              Positioned(right:1,top:1,child:IconButton.filledTonal(
                tooltip:'Bỏ ảnh này',onPressed:()=>removePhoto(i),icon:const Icon(Icons.close,size:18))),
            ]);
          }))),
      const SizedBox(height:7),
      const Text('OCR giữ toàn văn gốc để đối chiếu; nhận dạng số điện thoại, ngang, dài, diện tích và giá từ ngữ cảnh. Luôn kiểm tra các trường trước khi lưu; không tự xác minh chính chủ.',
        style:TextStyle(fontSize:12,color:Colors.black54)),
    ])));

  Widget _voiceSection()=>Card(child:Padding(padding:const EdgeInsets.all(14),child:Column(
    crossAxisAlignment:CrossAxisAlignment.start,children:[
      const Text('Đọc đầy đủ thông tin nguồn hàng bằng tiếng Việt',style:TextStyle(fontWeight:FontWeight.bold)),
      const SizedBox(height:6),const Text('Chọn thời lượng tổng 2–5 phút. Nếu Android tự ngắt phiên nghe ngắn, ứng dụng sẽ thử khởi động lại; các đoạn đã nhận vẫn được giữ.'),
      const SizedBox(height:8),Wrap(spacing:7,children:[for(final m in [2,3,5])
        ChoiceChip(label:Text('$m phút'),selected:voiceMinutes==m,onSelected:listening?null:(_)=>setState(()=>voiceMinutes=m))]),
      const SizedBox(height:8),SizedBox(width:double.infinity,child:FilledButton.icon(
        onPressed:listening?stopVoice:startVoice,
        icon:Icon(listening?Icons.stop_circle_outlined:Icons.mic_none),
        label:Text(listening?'Dừng đọc • ${elapsed.inMinutes.toString().padLeft(2,'0')}:${(elapsed.inSeconds%60).toString().padLeft(2,'0')}':'Bắt đầu đọc ($voiceMinutes phút)'))),
      const Text('Mỗi đoạn giọng nói được tự động phân tích và điền vào các ô trống. Android có thể tự ngắt phiên, ứng dụng sẽ thử nối các đoạn; hãy kiểm tra giá, diện tích và số điện thoại trước khi lưu.',
        style:TextStyle(fontSize:12,color:Colors.black54)),
    ])));

  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:Text(widget.original==null?'Tạo nguồn hàng mới':'Chỉnh sửa nguồn hàng')),
    body:Form(key:formKey,child:ListView(padding:const EdgeInsets.all(16),children:[
      const Text('Nhập thông tin bằng',style:TextStyle(fontSize:19,fontWeight:FontWeight.bold)),
      const SizedBox(height:8),Wrap(spacing:7,runSpacing:7,children:[
        ChoiceChip(label:const Text('Nhập tay'),avatar:const Icon(Icons.edit_note,size:18),selected:mode==0,
          onSelected:(_)=>setState(()=>mode=0)),
        ChoiceChip(label:const Text('Hình ảnh'),avatar:const Icon(Icons.camera_alt_outlined,size:18),selected:mode==1,
          onSelected:(_)=>setState(()=>mode=1)),
        ChoiceChip(label:const Text('Giọng nói'),avatar:const Icon(Icons.mic_none,size:18),selected:mode==2,
          onSelected:(_)=>setState(()=>mode=2)),
      ]),
      const SizedBox(height:10),
      if(mode==1)_photoSection(),
      if(mode==2)_voiceSection(),
      if(mode==0&&draft.imagePaths.isNotEmpty)_photoSection(),
      const SizedBox(height:8),
      if(autoFillStatus.isNotEmpty)Padding(padding:const EdgeInsets.symmetric(vertical:8),
        child:Row(crossAxisAlignment:CrossAxisAlignment.start,children:[
          const Icon(Icons.auto_awesome_outlined,size:20,color:brand),
          const SizedBox(width:8),Expanded(child:Text(autoFillStatus,
            style:const TextStyle(fontSize:13,fontWeight:FontWeight.w500))),
        ])),
      ExpansionTile(initiallyExpanded:raw.text.isNotEmpty||mode!=0,
        title:const Text('Nội dung trích xuất / ghi chú bổ sung (có thể sửa)'),
        children:[Padding(padding:const EdgeInsets.only(top:8),child:editField(raw,'Các dòng ảnh phù hợp, giọng nói và ghi chú',lines:6)),
          Align(alignment:Alignment.centerRight,child:TextButton.icon(onPressed:()=>fillFrom(raw.text,notify:true,origin:'Văn bản'),
            icon:const Icon(Icons.auto_fix_high),label:const Text('Điền gợi ý vào các ô trống')))]),
      const SizedBox(height:12),const Text('Thông tin tài sản — có thể sửa tất cả các ô',
        style:TextStyle(fontSize:17,fontWeight:FontWeight.bold)),const SizedBox(height:12),
      editField(title,'Tên nguồn hàng *',required:true,hint:'Ví dụ: Nhà mặt tiền đường 13'),
      dropdown('Loại bất động sản',draft.type,
        const ['Nhà riêng','Nhà mặt tiền','Đất nền','Căn hộ','Nhà xưởng / kho','Khác'],(v)=>draft.type=v),
      editField(address,'Địa chỉ bất động sản'),
      Row(children:[Expanded(child:editField(area,'Diện tích',hint:'120 m²')),
        const SizedBox(width:8),Expanded(child:editField(price,'Giá chào',hint:'12 tỷ'))]),
      Row(children:[Expanded(child:editField(width,'Chiều ngang',hint:'5 m')),
        const SizedBox(width:8),Expanded(child:editField(length,'Chiều dài',hint:'20 m'))]),
      dropdown('Nguồn phát hiện',draft.source,
        const ['Khảo sát thực tế','Trang web','Người quen giới thiệu','Mạng xã hội','Khác'],(v)=>draft.source=v),
      editField(sourceUrl,'Link tin gốc',keyboard:TextInputType.url),
      editField(owner,'Tên người đăng / người liên hệ (chưa xác minh)'),
      editField(phone,'Số điện thoại',keyboard:TextInputType.phone),
      if(mode!=1&&mode!=0)_photoSection(),
      const SizedBox(height:6),
      ExpansionTile(title:const Text('Bổ sung xác minh và tiến độ xử lý'),initiallyExpanded:widget.original!=null,children:[
        dropdown('Trạng thái liên hệ',draft.contactStatus,
          const ['Chưa liên hệ','Chưa liên hệ được','Đã liên hệ','Đã hẹn gặp','Đang đàm phán','Đã gặp / làm việc'],
          (v)=>draft.contactStatus=v),
        dropdown('Xác minh chính chủ',draft.verification,
          const ['Chưa xác minh','Đã trao đổi, chưa đối chiếu','Cần kiểm tra thêm','Đã đối chiếu hồ sơ','Đã gặp và xác minh trực tiếp','Có dấu hiệu môi giới'],
          (v)=>draft.verification=v),
        editField(verificationEvidence,'Căn cứ xác minh / thông tin cần kiểm tra',lines:2),
        editField(nextAction,'Công việc tiếp theo'),
        OutlinedButton.icon(onPressed:()async{
          final selected=await showDatePicker(context:context,
            initialDate:draft.nextDue??DateTime.now(),firstDate:DateTime(2020),lastDate:DateTime(2100));
          if(selected!=null)setState(()=>draft.nextDue=selected);
        },icon:const Icon(Icons.event_note),label:Text('Hạn công việc: ${dateLabel(draft.nextDue)}')),
        if(draft.nextDue!=null)TextButton(onPressed:()=>setState(()=>draft.nextDue=null),child:const Text('Bỏ hạn công việc')),
        dropdown('Trạng thái hợp đồng',draft.contractStatus,const ['Chưa ký','Đã ký'],(v){
          draft.contractStatus=v;
          if(v=='Đã ký'){draft.marketingNeedsAttention=false;draft.nextAction='';draft.nextDue=null;nextAction.clear();}
        }),
        editField(contractNumber,'Số hợp đồng môi giới'),
        editField(contractFee,'Phí môi giới (%)'),
        OutlinedButton.icon(onPressed:()async{
          final selected=await showDatePicker(context:context,
            initialDate:draft.contractExpires??DateTime.now().add(const Duration(days:90)),
            firstDate:DateTime(2020),lastDate:DateTime(2100));
          if(selected!=null)setState(()=>draft.contractExpires=selected);
        },icon:const Icon(Icons.event),label:Text('Hợp đồng hết hạn: ${dateLabel(draft.contractExpires)}')),
        SwitchListTile(title:const Text('Hợp đồng độc quyền'),value:draft.exclusive,
          onChanged:(v)=>setState(()=>draft.exclusive=v)),
        dropdown('Trạng thái chào bán của nhân viên',draft.saleStatus,
          const ['Chưa chào bán','Chuẩn bị chào bán','Đang chào bán','Có khách quan tâm','Đã giao dịch'],
          (v)=>draft.saleStatus=v),
        SwitchListTile(title:const Text('Có biến động cần xử lý'),value:draft.marketingNeedsAttention,
          onChanged:(v)=>setState(()=>draft.marketingNeedsAttention=v)),
      ]),
      const Text('Thông tin ảnh/giọng nói chỉ là gợi ý. Xác minh chủ sở hữu phải có căn cứ do người dùng kiểm tra.',
        style:TextStyle(fontSize:12,color:Colors.black54)),
      const SizedBox(height:16),FilledButton.icon(onPressed:saving?null:save,
        icon:const Icon(Icons.save_outlined),label:Text(widget.original==null?'Lưu nguồn hàng':'Cập nhật hồ sơ')),
      const SizedBox(height:35),
    ])),
  );
}
