import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';
import 'hunter_models.dart';
import 'hunter_search.dart';
import 'hunter_storage.dart';
import 'models.dart';
import 'legacy_admin.dart';

class HunterPage extends StatefulWidget {
  final HunterStorage storage;
  final Future<void> Function(Listing) onImport;
  final bool Function(String) sourceExists;
  final Listing? Function(String) findStoredSource;
  final ValueChanged<HunterSnapshot> onChanged;
  final Future<void> Function(bool) onAutoChanged;
  const HunterPage({super.key,required this.storage,required this.onImport,
    required this.sourceExists,required this.findStoredSource,
    required this.onChanged,required this.onAutoChanged});
  @override State<HunterPage> createState()=>_HunterPageState();
}

class _HunterPageState extends State<HunterPage> with WidgetsBindingObserver {
  List<HunterLead> leads=[];
  HunterSettings settings=const HunterSettings();
  HunterSnapshot snapshot=const HunterSnapshot();
  List<Map<String,dynamic>> scanHistory=[];
  final location = TextEditingController();
  final keywords = TextEditingController();
  Set<String> selectedDistricts={LegacyAdmin.thuDuc};
  Set<String> selectedWards={};
  final streets = TextEditingController();
  final excluded = TextEditingController();
  final Set<String> selectedSites = {};
  String propertyType = 'Tất cả';
  int recentDays = 5, maxPosterListings = 3;
  bool excludeBroker = true, excludeSharedTitle = true;
  bool excludeApartments = false, ownerHintsOnly = false;
  bool busy = false, loaded = false, stopRequested = false;
  HunterSearch? activeScanner;
  // Exclusive categories only: avoid displaying the same pending record in
  // both a broad 'Chờ xác minh' tab and a specific 'Thiếu dữ liệu' tab.
  String filter = 'needs_data', notice = '';
  bool showScannerSettings = false;

  @override void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    refresh(initial: true);
  }

  @override void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) refresh(catchUp: true);
  }

  @override void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    for (final controller in [location, keywords, streets, excluded]) {
      controller.dispose();
    }
    super.dispose();
  }

  String when(DateTime? d) {
    if (d == null) return 'Chưa có';
    String two(int n) => n.toString().padLeft(2, '0');
    return '${two(d.day)}/${two(d.month)}/${d.year} ${two(d.hour)}:${two(d.minute)}';
  }

  void message(String value) {
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(value)));
  }

  List<String> parseLines(String source) => source.split(RegExp(r'[\n;]+'))
    .map((s) => s.trim()).where((s) => s.isNotEmpty).toSet().toList();

  void loadEditors(HunterSettings s) {
    location.text = LegacyAdmin.province;
    keywords.text = s.keywords;
    selectedDistricts=s.districts.toSet();
    selectedWards=s.wards.toSet();
    streets.text = s.streets.join('\n');
    excluded.text = s.excludedTerms.join('\n');
    propertyType = s.propertyType;
    recentDays = s.recentDays;
    maxPosterListings = s.maxPosterListings;
    excludeBroker = s.excludeBroker;
    excludeSharedTitle = s.excludeSharedTitle;
    excludeApartments = s.excludeApartments;
    ownerHintsOnly = s.ownerHintsOnly;
    selectedSites..clear()..addAll(s.sites);
  }

  HunterSettings editorSettings({bool? autoScan}) => HunterSettings(
    location: LegacyAdmin.province, keywords: keywords.text.trim(),
    districts: selectedDistricts.toList(),wards:selectedWards.toList(),
    streets: parseLines(streets.text),
    excludedTerms: parseLines(excluded.text),
    propertyType: propertyType, recentDays: recentDays,
    maxPosterListings: maxPosterListings,
    sites: selectedSites.toList(),
    autoScan: autoScan ?? settings.autoScan,
    excludeBroker: excludeBroker,
    excludeSharedTitle: excludeSharedTitle,
    excludeApartments: excludeApartments, ownerHintsOnly: ownerHintsOnly,
  );

  String? checkCriteria(HunterSettings s) {
    if(s.districts.isEmpty)return 'Chọn ít nhất một quận/huyện hoặc Thành phố Thủ Đức.';
    if (s.sites.isEmpty) return 'Hãy chọn ít nhất một website nguồn.';
    return null;
  }

  /// Separate multi-select dialogues avoid long editable place-name text.
  Future<void> _chooseDistricts()async{
    final draft=selectedDistricts.toSet();
    final result=await showDialog<Set<String>>(context:context,builder:(ctx)=>
      StatefulBuilder(builder:(ctx,update)=>AlertDialog(
        title:const Text('Chọn quận/huyện cũ – TP.HCM'),
        content:SizedBox(width:330,height:380,child:ListView(children:[
          for(final d in LegacyAdmin.districtList)
            CheckboxListTile(dense:true,contentPadding:EdgeInsets.zero,
              title:Text(d.name),value:draft.contains(d.name),
              onChanged:(v)=>update(() {if(v==true){draft.add(d.name);}else{draft.remove(d.name);}})),
        ])),
        actions:[TextButton(onPressed:()=>Navigator.pop(ctx),child:const Text('Hủy')),
          FilledButton(onPressed:()=>Navigator.pop(ctx,draft),child:const Text('Xong'))],
      )));
    if(result!=null&&mounted){setState((){
      selectedDistricts=result;
      // Remove stale checked wards from unchecked districts.
      selectedWards.removeWhere((w)=>w.contains(' · ') &&
        !result.contains(w.split(' · ').first));
      if(!result.contains(LegacyAdmin.thuDuc)){
        selectedWards.removeWhere((w)=>!w.contains(' · '));
      }
    });}
  }

  Future<void> _chooseWards()async{
    if(selectedDistricts.isEmpty){message('Chọn quận/huyện trước.');return;}
    final available=<String>[];
    final notices=<String>[];
    for(final district in selectedDistricts){
      List<String> entries=[];
      try{
        if(district==LegacyAdmin.thuDuc){
          entries=LegacyAdmin.formerThuDucWards;
        }else{
          entries=await widget.storage.cachedWards(district)??[];
          if(entries.isEmpty){
            entries=await LegacyAdmin.loadWards(district);
            await widget.storage.cacheWards(district,entries);
          }
        }
      }catch(e){notices.add('$district: $e');}
      for(final w in entries){
        available.add(district==LegacyAdmin.thuDuc?w:'$district · $w');
      }
    }
    if(!mounted)return;
    if(available.isEmpty){message('Không tải được danh mục phường; cần mạng cho các quận ngoài Thủ Đức. ${notices.join(' | ')}');return;}
    if(notices.isNotEmpty)message('Một số quận chưa tải được phường; dùng cache hoặc thử lại.');
    final chosen=selectedWards.where(available.contains).toSet();
    final result=await showDialog<Set<String>>(context:context,builder:(ctx)=>
      StatefulBuilder(builder:(ctx,update)=>AlertDialog(
        title:Text('Chọn phường/xã (${chosen.length}/${available.length})'),
        content:SizedBox(width:340,height:380,child:ListView(children:[
          Row(children:[TextButton(onPressed:()=>update(()=>chosen.addAll(available)),
              child:const Text('Chọn tất cả')),
            TextButton(onPressed:()=>update(chosen.clear),child:const Text('Bỏ chọn'))]),
          for(final w in available)
            CheckboxListTile(dense:true,contentPadding:EdgeInsets.zero,
              title:Text(w),value:chosen.contains(w),
              onChanged:(v)=>update(() {if(v==true){chosen.add(w);}else{chosen.remove(w);}})),
        ])),
        actions:[TextButton(onPressed:()=>Navigator.pop(ctx),child:const Text('Hủy')),
          FilledButton(onPressed:()=>Navigator.pop(ctx,chosen),child:const Text('Xong'))],
      )));
    if(result!=null&&mounted)setState(()=>selectedWards=result);
  }

  Future<void> refresh({bool initial = false, bool catchUp = false}) async {
    try {
      final s = await widget.storage.settings();
      final l = await widget.storage.leads();
      // Reclassify ALL historical pending leads under the current hard gates.
      // This also downgrades records that an older release prematurely marked
      // qualified before it had verified the seller's total listing count.
      for (final lead in l) {
        if (lead.status != 'pending') continue;
        final current = HunterSearch.classifyLead(lead,s);
        if(current==lead.qualification && current!='rejected')continue;
        lead.qualification=current;
        if(current=='rejected'){
          lead.status='rejected';
          final count=int.tryParse(lead.posterCountEvidence);
          final over=HunterSearch.trustedSellerCount(lead) &&
              count!=null && count>s.maxPosterListings;
          lead.filterReason=over
              ? 'Người đăng có $count tin, vượt giới hạn ${s.maxPosterListings}'
              : HunterSearch.brokerEvidence(lead) ?? 'Không đạt điều kiện lọc';
        }
        await widget.storage.updateLead(lead);
      }
      await widget.storage.recoverInterruptedScan();
      final snap = await widget.storage.snapshot();
      final history = await widget.storage.scanHistory();
      if (!mounted) return;
      setState(() {
        settings = s; leads = l; snapshot = snap; scanHistory=history; loaded = true;
        if (initial) loadEditors(s);
      });
      widget.onChanged(snap);
      // On first open or app resume, catch up if Android postponed the task.
      if ((initial || catchUp) && s.autoScan && !busy &&
          (snap.lastScan == null || DateTime.now().difference(snap.lastScan!) >=
            const Duration(hours: 2))) {
        Future<void>.microtask(scan);
      }
    } catch (e) {
      if (mounted) {
        setState(() { loaded = true; notice = 'Lỗi tải nguồn web: $e'; });
      }
    }
  }

  Future<void> saveSettings() async {
    final options = editorSettings();
    final validation = checkCriteria(options);
    if (validation != null) { message(validation); return; }
    try {
      await widget.storage.saveSettings(options);
      if (mounted) setState(() => settings = options);
      if (options.autoScan) await widget.onAutoChanged(true);
      message('Đã lưu tiêu chí và khu vực quét.');
    } catch (e) { message('Chưa lưu được tiêu chí: $e'); }
  }

  Future<void> autoToggle(bool enabled) async {
    final options = editorSettings(autoScan: enabled);
    final validation = checkCriteria(options);
    if (validation != null) { message(validation); return; }
    try {
      await widget.storage.saveSettings(options);
      if (mounted) setState(() => settings = options);
      await widget.onAutoChanged(enabled);
      message(enabled ? 'Đã đăng ký tác vụ quét nền (theo lịch Android).' :
        'Đã tắt tác vụ quét nền.');
    } catch (e) {
      message('Không cập nhật được lịch tự quét: $e');
    }
  }

  void stopScan() {
    if(!busy)return;
    stopRequested=true;
    activeScanner?.close();
    if(mounted)setState(()=>notice='Đang dừng quét; dữ liệu đã thu thập sẽ được ghi lại…');
  }

  Future<void> scan() async {
    if (busy || !mounted) return;
    final options = editorSettings();
    final validation = checkCriteria(options);
    if (validation != null) { message(validation); return; }
    setState(() {busy = true; stopRequested=false; notice = 'Đang khởi tạo phiên quét…';});
    final scanner = HunterSearch();
    activeScanner=scanner;
    int? sessionId;
    try {
      await widget.storage.saveSettings(options);
      sessionId=await widget.storage.beginScan(mode:'manual');
      final id=sessionId;
      if(id==null){
        if(mounted)setState(()=>notice='Đang có phiên quét khác.');
        await refresh();
        return;
      }
      await refresh(); // Session exists even before the first HTTP request.
      final outcome = await scanner.scan(options,
        isCancelled:()=>stopRequested,
        onProgress:(progress) async {
          await widget.storage.updateScanProgress(id,progress);
          if(mounted){
            final snap=await widget.storage.snapshot();
            final history=await widget.storage.scanHistory();
            if(mounted)setState((){notice='Đang quét…';snapshot=snap;scanHistory=history;});
          }
        }).timeout(const Duration(minutes:4));
      final added = await widget.storage.addDiscovered(outcome.leads);
      await widget.storage.finishScan(id, found:outcome.leads.length,
        added:added,searched:outcome.queries,discarded:outcome.discarded,
        raw:outcome.raw,sources:outcome.sources,errors:outcome.errors);
      await refresh();
      if (!mounted) return;
      setState(() {
        filter='needs_data';
        notice='Quét xong · ${outcome.leads.length} tin đã đọc · $added tin mới · ${outcome.leads.where((p)=>p.status=='pending').length} tin chờ xác minh · ${outcome.discarded} tin loại';
      });
    } catch (e) {
      scanner.close(); // Stop outstanding HTTP work on timeout/error.
      if(sessionId!=null){
        try {
          await widget.storage.finishScan(sessionId!,found:0,added:0,
            errors:['Lỗi quét: $e'],failed:true);
          await refresh();
        }catch(recordError){
          if(mounted)setState(()=>notice='Không hoàn tất được lượt quét.');
        }
      }
      if (mounted) setState(() => notice = 'Lượt quét không hoàn tất.');
    } finally {
      scanner.close();
      activeScanner=null;
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> openSource(HunterLead lead)async{
    final uri=Uri.tryParse(lead.url);
    if(uri==null||!await launchUrl(uri,mode:LaunchMode.externalApplication)){
      message('Không mở được liên kết nguồn.');
    }
  }
  Future<void> reject(HunterLead lead)async{
    final reason=TextEditingController();
    final ok=await showDialog<bool>(context:context,builder:(ctx)=>AlertDialog(
      title:const Text('Loại khỏi danh sách chờ'),
      content:Column(mainAxisSize:MainAxisSize.min,children:[
        const Text('Tin này sẽ được giữ trong lịch sử, không hiện lại như tin mới khi quét trùng.'),
        const SizedBox(height:10),TextField(controller:reason,decoration:const InputDecoration(labelText:'Lý do (không bắt buộc)'))]),
      actions:[TextButton(onPressed:()=>Navigator.pop(ctx,false),child:const Text('Hủy')),
        FilledButton(onPressed:()=>Navigator.pop(ctx,true),child:const Text('Loại tin'))]));
    if(ok==true){lead.status='rejected';lead.reviewNote=reason.text.trim();lead.reviewedAt=DateTime.now();
      await widget.storage.updateLead(lead);await refresh();}
    reason.dispose();
  }
  /// Promote a pending lead OR an already temporarily saved lead into
  /// verified inventory. Reuse the original Listing ID — no duplicates.
  /// Missing web seller counts require the user to attest an exact number.
  Future<void> approve(HunterLead lead) async {
    final prior = widget.findStoredSource(lead.url);
    if (lead.status == 'saved_for_review' && prior == null) {
      message('Không tìm thấy hồ sơ đã lưu tạm. Kiểm tra lại kho Nguồn hàng trước khi xác minh.');
      return;
    }
    if (lead.status != 'saved_for_review' && widget.sourceExists(lead.url)) {
      message('Tin đã có trong kho nguồn hàng. Không tạo bản ghi trùng.');
      return;
    }
    final savedDraft = canHumanConfirmSavedDraft(lead, prior != null);
    // A user verifying a previously saved draft is not an automatic filter
    // decision. Do not demand public seller-count evidence or network access.
    HunterLead enriched = lead;
    if (!savedDraft) {
      final scanner = HunterSearch();
      try {
        enriched = await scanner.fetchDetailForImport(lead);
      } catch (error) {
        message('Không đọc được tin gốc: $error. Dùng dữ liệu đã quét.');
      } finally {
        scanner.close();
      }
    }
    if (!mounted) return;
    // Automatic exclusion applies only before manual verification of saved drafts.
    final latestClass = HunterSearch.classifyLead(enriched, settings);
    if (!savedDraft && latestClass == 'rejected') {
      final reason = HunterSearch.brokerEvidence(enriched) ??
          'Không đạt điều kiện số tin / ngày đăng / tiêu chí lọc';
      enriched.filterReason = reason;
      if (lead.status != 'saved_for_review') {
        lead.status = 'rejected';
        lead.qualification = 'rejected';
        lead.filterReason = reason;
        await widget.storage.updateLead(lead);
        if (mounted) await refresh();
      }
      message('Không thể xác minh và lưu: $reason');
      return;
    }
    final count = int.tryParse(enriched.posterCountEvidence);
    final reliable = HunterSearch.trustedSellerCount(enriched);
    final validWebCount = reliable && count != null && count >= 1 &&
        count <= settings.maxPosterListings;
    final manualCount = TextEditingController();
    final response = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Xác minh chính chủ và lưu nguồn'),
        content: SingleChildScrollView(child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(enriched.title,style:const TextStyle(fontWeight:FontWeight.bold)),
            const SizedBox(height:8),
            Text('Người đăng: ${enriched.posterName.isEmpty ? "Chưa đọc được" : enriched.posterName}'),
            Text('Số tin/người: ${reliable && count != null ? count.toString() : "Chưa xác minh qua website"}'),
            const SizedBox(height:8),
            if(savedDraft && latestClass=='rejected')
              const Text('Lưu ý: tin có dấu hiệu không đạt bộ lọc tự động. Bạn vẫn có thể xác nhận thủ công nếu đã kiểm tra trực tiếp chủ tài sản. Kết quả lọc gốc được giữ trong lịch sử.'),
            if (!validWebCount) ...[
              Text(savedDraft
                ? 'Bạn đã lưu tạm nguồn này. Nếu đã trực tiếp xác minh quyền sở hữu, bạn có thể xác nhận và lưu ngay cả khi website chưa công khai số tin. Nhập số tin nếu biết (không bắt buộc).'
                : 'Bạn phải tự kiểm tra hồ sơ người đăng và điền đúng số tin (1 đến 3). Chỉ xác nhận khi đã có bằng chứng.'),
              const SizedBox(height:8),
              TextField(controller:manualCount,keyboardType:TextInputType.number,
                decoration:const InputDecoration(labelText:'Số tin đã kiểm tra thủ công',hintText:'1, 2 hoặc 3')),
              const SizedBox(height:8),
            ],
            const Text('Chỉ xác nhận khi bạn đã liên hệ và xác minh người đăng thật sự là chủ tài sản.'),
            if (prior != null) const Text('Hồ sơ đã lưu tạm sẽ được cập nhật, không tạo nguồn hàng mới.'),
          ],
        )),
        actions: [
          TextButton(onPressed:()=>Navigator.pop(ctx,false),child:const Text('Hủy')),
          FilledButton(onPressed:()=>Navigator.pop(ctx,true),child:const Text('Đã xác minh & lưu')),
        ],
      ),
    );
    final attested = int.tryParse(manualCount.text.trim());
    manualCount.dispose();
    if (response != true || !mounted) return;
    final verifiedCount = validWebCount ? count : attested;
    if (!savedDraft && (verifiedCount == null || verifiedCount < 1 ||
        verifiedCount > settings.maxPosterListings)) {
      message('Chưa đủ bằng chứng số tin/người đăng (tối đa ${settings.maxPosterListings}); chưa chuyển trạng thái.');
      return;
    }
    final evidence = reliable && count != null
      ? 'Số tin $count đọc từ ${enriched.posterCountSource}${count>settings.maxPosterListings ? " (vượt bộ lọc tự động)" : ""}'
      : (attested != null && attested >= 1
          ? 'Người dùng tự ghi nhận số tin: $attested (chưa được hệ thống đối chiếu)'
          : 'Số tin người đăng chưa được website xác minh; người dùng đã xác minh trực tiếp chủ tài sản');
    final exclusion = savedDraft ? HunterSearch.brokerEvidence(enriched) : null;
    final overrideNote = savedDraft && (latestClass=='rejected'||
        (count!=null && reliable && count>settings.maxPosterListings))
       ? ' Kiểm tra thủ công ghi nhận ngoại lệ bộ lọc: ${exclusion??enriched.filterReason}. '
       : '';
    final parsed = enriched.parsed;
    final property = prior ?? Listing(
      title: parsed.title.isEmpty ? enriched.title : parsed.title,
      type: parsed.type.isEmpty ? 'Nhà riêng' : parsed.type,
      address: parsed.address, area: parsed.area, width: parsed.width,
      length: parsed.length, price: parsed.price, phone: parsed.phone,
      source: 'Supply Hunter: ${enriched.source}',sourceUrl:enriched.url,
      rawCapture: '${enriched.title}\n${enriched.snippet}\n${enriched.detailText}',
      contactStatus: 'Đã gặp / làm việc',
    );
    // Never overwrite manually corrected properties in a saved draft.
    if (property.owner.trim().isEmpty && enriched.posterName.trim().isNotEmpty) {
      property.owner = enriched.posterName.trim();
    }
    property.verification = 'Đã xác minh trực tiếp với chủ tài sản';
    property.verificationEvidence = 'Người dùng xác nhận trực tiếp chủ tài sản. $evidence.$overrideNote';
    property.nextAction = 'Bổ sung thông tin còn thiếu và xử lý nguồn hàng đã xác minh';
    property.addLog('Chuyển nguồn lưu tạm sang đã xác minh',
      'Người dùng xác nhận chủ tài sản và $evidence.$overrideNote Link gốc: ${enriched.url}');
    try {
      await widget.onImport(property); // Same Listing.id when source was saved.
      lead.status = 'imported';
      lead.listingId = property.id;
      lead.method = 'Đã xác minh trực tiếp với chủ tài sản';
      lead.evidence = evidence;
      lead.reviewedAt = DateTime.now();
      await widget.storage.updateLead(lead);
      if (mounted) { await refresh(); message('Đã xác minh & lưu. Không tạo nguồn hàng trùng.'); }
    } catch (error) {
      message('Không lưu được xác minh: $error');
    }
  }
  /// Save incomplete candidates as UNVERIFIED inventory at the user's explicit
  /// request. This never claims ownership has been checked or bypasses a known
  /// brokerage, listing-count, age or other hard exclusion.
  Future<void> saveForVerification(HunterLead lead) async {
    if (lead.status != 'pending') return;
    if (widget.sourceExists(lead.url)) {
      message('Tin đã có trong kho nguồn hàng.');
      return;
    }
    final current = HunterSearch.classifyLead(lead, settings);
    if (current == 'rejected') {
      lead.status = 'rejected';
      lead.qualification = 'rejected';
      lead.filterReason = HunterSearch.brokerEvidence(lead) ??
          'Không đạt điều kiện lọc đã xác minh';
      await widget.storage.updateLead(lead);
      if (mounted) { await refresh(); message('Tin đã được chuyển sang Đã loại.'); }
      return;
    }
    final proceed = await showDialog<bool>(context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Lưu tạm để xác minh'),
        content: Text('Tin này chưa được xác minh là chính chủ và có thể thiếu '
          'ngày đăng, số tin của người đăng hoặc thông tin tài sản. '
          'Lưu tạm vào Nguồn hàng với trạng thái Chưa xác minh để bạn '
          'kiểm tra trực tiếp?\n\n${lead.title}'),
        actions: [
          TextButton(onPressed:()=>Navigator.pop(ctx,false),child:const Text('Hủy')),
          FilledButton(onPressed:()=>Navigator.pop(ctx,true),child:const Text('Lưu chờ xác minh')),
        ],
      ),
    );
    if (proceed != true || !mounted) return;
    // No automatic enrichment guesses; incomplete fields stay incomplete.
    final parsed = lead.parsed;
    final property = Listing(
      title: parsed.title.isEmpty ? lead.title : parsed.title,
      type: parsed.type.isEmpty ? 'Nhà riêng' : parsed.type,
      address: parsed.address, area: parsed.area, width: parsed.width,
      length: parsed.length, price: parsed.price, phone: parsed.phone,
      // Carry the *source account name* into the owner/contact field so it
      // is available for follow-up. This is NOT owner verification: the
      // separate verification status remains “Chưa xác minh”.
      owner: lead.posterName.trim(), source: 'Supply Hunter: ${lead.source}',
      sourceUrl: lead.url,
      verification: 'Chưa xác minh',
      verificationEvidence: 'Tin web chưa đủ dữ liệu để xác minh chính chủ.'
          '${lead.posterName.isEmpty ? '' : ' Người đăng tin: ${lead.posterName} (chưa xác minh là chủ).'}',
      contactStatus: 'Chưa liên hệ',
      rawCapture: '${lead.title}\n${lead.snippet}\n${lead.detailText}',
      nextAction: 'Mở tin gốc, kiểm tra người đăng, số tin và liên hệ xác minh chủ tài sản',
    );
    property.addLog('Lưu tạm nguồn web',
      'Chưa xác minh chính chủ. Ngày đăng: '
      '${lead.dateEvidence.isEmpty ? "chưa có bằng chứng" : lead.dateEvidence}; '
      'số tin: ${HunterSearch.trustedSellerCount(lead) ? lead.posterCountEvidence : "chưa xác minh"}. '
      'Link nguồn: ${lead.url}');
    try {
      await widget.onImport(property);
      lead.status = 'saved_for_review';
      lead.listingId = property.id;
      lead.method = 'Lưu tạm chờ xác minh';
      lead.evidence = 'Chưa xác minh chính chủ';
      lead.reviewedAt = DateTime.now();
      await widget.storage.updateLead(lead);
      await refresh();
      message('Đã lưu tạm vào Nguồn hàng để xác minh trực tiếp.');
    } catch (error) {
      message('Không lưu được nguồn tạm: $error');
    }
  }

  Future<void> copyReport() async {
    final header='SOURCEFLOW SUPPLY HUNTER — BÁO CÁO TIN CHỜ KIỂM TRA\n'
      'Địa bàn: TP.HCM | Quận/huyện: ${settings.districts.join(', ')} | Phường: ${settings.wards.join(', ')} | Đường: ${settings.streets.join(', ')}\n'
      'Từ khóa: ${settings.keywords} | Ngày đăng cần kiểm: ${settings.recentDays} | Tối đa tin/người: ${settings.maxPosterListings}\n'
      'Thời điểm báo cáo: ${DateTime.now()}\n'
      'Ứng viên lấy từ website công khai; chính chủ và danh tính phải do người dùng xác minh.\n\n';
    final lines=leads.where((p)=>p.status=='pending').toList();
    final text=header+lines.asMap().entries.map((entry){
      final l=entry.value;final p=l.parsed;
      return '${entry.key+1}. ${l.title}\nNguồn: ${l.source}\n'
        '${p.area.isEmpty?'':'Diện tích: ${p.area}\n'}'
        '${p.price.isEmpty?'':'Giá: ${p.price}\n'}'
        'Link: ${l.url}\nTrạng thái: ${l.qualification=='qualified' ? 'Đạt sơ bộ, chờ xác minh' : 'Thiếu dữ liệu, chờ xác minh'}\n';
    }).join('\n');
    await Clipboard.setData(ClipboardData(text:text));message('Đã sao chép ${lines.length} tin chờ xác minh (gồm tin thiếu dữ liệu).');
  }
  String unresolvedReasons(HunterLead lead) {
    final reasons=<String>[];
    if (!HunterSearch.trustedSellerCount(lead))
      reasons.add('Chưa xác minh số tin/người đăng');
    if (lead.dateEvidence.isEmpty)
      reasons.add('Chưa xác minh ngày đăng');
    if (lead.parsed.address.isEmpty)
      reasons.add('Thiếu địa chỉ cụ thể');
    final signal=HunterSearch.possibleBrokerEvidence(lead);
    if (signal!=null) reasons.add('Nghi vấn trung gian: $signal');
    if (HunterSearch.brokerEvidence(lead)==null && lead.qualification!='qualified')
      reasons.add('Chưa đủ bằng chứng chính chủ');
    return reasons.isEmpty ? 'Cần kiểm tra các điều kiện trước khi xác nhận' : reasons.join(' • ');
  }
  Widget _leadCard(HunterLead lead)=>Card(child:Padding(padding:const EdgeInsets.all(12),child:Column(
    crossAxisAlignment:CrossAxisAlignment.start,children:[
      Text(lead.title,style:const TextStyle(fontWeight:FontWeight.w700)),
      Text(lead.status=='saved_for_review'?'ĐÃ LƯU TẠM — CHỜ XÁC MINH':
        lead.status=='imported'?'ĐÃ XÁC MINH & LƯU':
        lead.qualification=='qualified'?'ĐẠT SƠ BỘ':
        lead.qualification=='rejected'?'LOẠI THEO BỘ LỌC':'THIẾU DỮ LIỆU',
        style:TextStyle(color:lead.qualification=='rejected'?Colors.deepOrange:Colors.teal,
          fontWeight:FontWeight.bold)),
      if(lead.status=='pending' && lead.qualification!='qualified')
        Padding(padding:const EdgeInsets.only(top:4),child:Text(
          unresolvedReasons(lead),
          style:const TextStyle(fontSize:11,color:Colors.black54))),
      const SizedBox(height:5),Text('${lead.source} • Tìm thấy: ${when(lead.discoveredAt)}',style:const TextStyle(fontSize:12,color:Colors.black54)),
      
      if(lead.dateEvidence.isNotEmpty)Text('Ngày đăng: ${lead.dateEvidence}',style:const TextStyle(fontSize:11)),
      if(lead.posterCountEvidence.isNotEmpty && HunterSearch.trustedSellerCount(lead))
        Text('Số tin người đăng: ${lead.posterCountEvidence} (${lead.posterCountSource=="listing_card_verified"?"trang danh sách":"trang chi tiết/hồ sơ"})',style:const TextStyle(fontSize:11)),
      if(lead.parsed.address.isNotEmpty || lead.parsed.area.isNotEmpty || lead.parsed.price.isNotEmpty)
        Padding(padding:const EdgeInsets.only(top:7),child:Text([
          if(lead.parsed.address.isNotEmpty)'Địa chỉ: ${lead.parsed.address}',
          if(lead.parsed.area.isNotEmpty)'Diện tích: ${lead.parsed.area}',
          if(lead.parsed.price.isNotEmpty)'Giá: ${lead.parsed.price}',
        ].join(' • '))),
      if(lead.detailText.isNotEmpty)Padding(padding:const EdgeInsets.only(top:7),child:Text(lead.detailText,maxLines:5,overflow:TextOverflow.ellipsis))
      else if(lead.snippet.isNotEmpty)Padding(padding:const EdgeInsets.only(top:7),child:Text(lead.snippet,maxLines:4,overflow:TextOverflow.ellipsis)),
      if(lead.posterName.isNotEmpty)Text('Người đăng: ${lead.posterName} (chưa xác minh chính chủ)',style:const TextStyle(fontSize:12)),
      Text('Số tin người đăng: ${HunterSearch.trustedSellerCount(lead) ? lead.posterCountEvidence : "Chưa xác minh"}',style:const TextStyle(fontSize:12)),
      const SizedBox(height:7),SelectableText(lead.url,style:const TextStyle(fontSize:12,color:Colors.teal)),
      if(lead.status=='saved_for_review')Padding(
        padding:const EdgeInsets.only(top:5),child:Text(
        'Chờ xác minh: ${unresolvedReasons(lead)}',
        style:const TextStyle(color:Colors.teal,fontSize:11))),
      if(lead.status=='imported')const Padding(padding:EdgeInsets.only(top:5),child:Text('Đã xác minh và lưu vào kho',style:TextStyle(color:Colors.green,fontWeight:FontWeight.bold))),
      // Filtering reasons are retained in the record, not repeated on each card.

      if(lead.status=='rejected')const Padding(padding:EdgeInsets.only(top:5),child:Text('Đã loại',style:TextStyle(color:Colors.deepOrange))),
      const SizedBox(height:10),Wrap(spacing:6,runSpacing:6,children:[
        OutlinedButton.icon(onPressed:()=>openSource(lead),icon:const Icon(Icons.open_in_new,size:17),label:const Text('Xem tin gốc')),
        if(lead.status=='saved_for_review')
          FilledButton.icon(onPressed:()=>approve(lead),
            icon:const Icon(Icons.verified_user_outlined,size:17),
            label:const Text('Đã xác minh & lưu')),
        if(lead.status=='pending')...[
          if(lead.qualification=='qualified')
            FilledButton.icon(onPressed:()=>approve(lead),icon:const Icon(Icons.verified_user_outlined,size:17),label:const Text('Xác minh & lưu')),
          if(lead.qualification!='qualified')
            FilledButton.icon(onPressed:()=>saveForVerification(lead),icon:const Icon(Icons.bookmark_add_outlined,size:17),label:const Text('Lưu chờ xác minh')),
          TextButton.icon(onPressed:()=>reject(lead),icon:const Icon(Icons.close,size:17),label:const Text('Loại')),
        ],
      ]),
    ])));
  @override Widget build(BuildContext context) {
    final visible = leads.where((lead) => hunterLeadInView(lead,filter))
      .toList(growable:false);
    final settingsWidgets = <Widget>[

        const Text('Supply Hunter · Nguồn web',style:TextStyle(fontSize:21,fontWeight:FontWeight.w800)),
        const SizedBox(height:12),Wrap(spacing:8,runSpacing:8,children:[
          Chip(label:Text('Chưa xử lý (tổng): ${leads.where((l)=>l.status=='pending').length}')),
          Chip(label:Text('Đạt bộ lọc: ${leads.where((l)=>l.status=='pending'&&l.qualification=='qualified').length}')),
          Chip(label:Text('Thiếu dữ liệu: ${leads.where((l)=>l.status=='pending'&&l.qualification!='qualified').length}')),
          Chip(label:Text('Đã lưu tạm: ${snapshot.savedForReview}')),
          Chip(label:Text('Đã xác minh & lưu: ${snapshot.confirmed}')),
          Chip(label:Text('Đã loại: ${snapshot.rejected}')),
        ]),
        // Keep scan sessions and source diagnostics in SQLite for audits, but
        // keep the public scanner UI uncluttered.
        Text('Lần quét: ${snapshot.lastScan==null?'Chưa có':when(snapshot.lastScan)}'
            ' · ${snapshot.lastScan==null?'Chưa có phiên quét':
              snapshot.errors.isEmpty?'Hoàn tất':'Có nguồn bị lỗi'}',
            maxLines:2,style:const TextStyle(fontSize:12)),
        const SizedBox(height:8),
        Card(child:Padding(padding: const EdgeInsets.all(12), child: Column(
          crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('THIẾT LẬP BỘ QUÉT', style: TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height:12),
          const InputDecorator(decoration:InputDecoration(labelText:'Tỉnh/thành phố (mặc định)'),
            child:Text('Thành phố Hồ Chí Minh')),
          const SizedBox(height:10),
          OutlinedButton.icon(onPressed:_chooseDistricts,icon:const Icon(Icons.map_outlined),
            label:Text('Quận/huyện/Thủ Đức: ${selectedDistricts.length} mục ✓')),
          if(selectedDistricts.isNotEmpty)Text(selectedDistricts.join(', '),
            style:const TextStyle(fontSize:11,color:Colors.black54)),
          const SizedBox(height:6),
          OutlinedButton.icon(onPressed:_chooseWards,icon:const Icon(Icons.checklist_outlined),
            label:Text('Chọn phường/xã: ${selectedWards.length} mục ✓')),
          if(selectedWards.isNotEmpty)Text(selectedWards.join(', '),
            style:const TextStyle(fontSize:11,color:Colors.black54)),
          const Text('Không chọn phường = quét toàn quận đã chọn. Danh mục cũ (trước 07/2025).',
            style:TextStyle(fontSize:11,color:Colors.black54)),
          const SizedBox(height:10),
          TextField(controller: streets, minLines: 2, maxLines: 4,
            decoration: const InputDecoration(
              labelText: 'Địa điểm / tuyến đường ưu tiên',
              hintText: 'Ka Vạn Cân\nLã Xuân Oai',
              helperText: 'Ưu tiên các tin có tên đường này; không bỏ tin thiếu địa chỉ')),
          const SizedBox(height:10),
          TextField(controller: keywords, decoration: const InputDecoration(
            labelText: 'Từ khóa ưu tiên (không bắt buộc)', prefixIcon: Icon(Icons.search))),
          const SizedBox(height:10),
          DropdownButtonFormField<String>(value: propertyType,
            decoration: const InputDecoration(labelText: 'Loại bất động sản'),
            items: const ['Tất cả','Nhà','Đất','Nhà xưởng'].map((v) =>
              DropdownMenuItem(value: v, child: Text(v))).toList(),
            onChanged: (v) { if (v != null) setState(() => propertyType = v); }),
          const SizedBox(height:12),
          const Text('NGUỒN WEBSITE', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 12)),
          Wrap(spacing: 5, runSpacing: 0, children: [
            for (final site in HunterSearch.allowedHosts)
              FilterChip(label: Text(site, style: const TextStyle(fontSize: 11)),
                selected: selectedSites.contains(site),
                onSelected: (v) => setState(() {
                  if (v) {selectedSites.add(site);} else {selectedSites.remove(site);}
                })),
          ]),
          const SizedBox(height:8),
          Row(children: [
            Expanded(child: DropdownButtonFormField<int>(value: recentDays,
              decoration: const InputDecoration(labelText: 'Tin trong N ngày'),
              items: const [3,5,7,14,30].map((v) =>
                DropdownMenuItem(value: v, child: Text('$v ngày'))).toList(),
              onChanged: (v) {if (v != null) setState(() => recentDays = v);})),
            const SizedBox(width:8),
            Expanded(child: DropdownButtonFormField<int>(value: maxPosterListings,
              decoration: const InputDecoration(labelText: 'Số tin/người tối đa'),
              items: const [1,2,3,5].map((v) =>
                DropdownMenuItem(value: v, child: Text('$v tin'))).toList(),
              onChanged: (v) {if (v != null) setState(() => maxPosterListings = v);})),
          ]),
          const SizedBox(height:9),
          TextField(controller: excluded, minLines: 1, maxLines: 3,
            decoration: const InputDecoration(labelText: 'Từ khóa loại trừ (mỗi dòng một cụm)',
              hintText: 'Ví dụ: vi bằng')),
          SwitchListTile(contentPadding: EdgeInsets.zero, dense: true,
            title: const Text('Loại dấu hiệu môi giới'),
            value: excludeBroker,
            onChanged: busy ? null : (v) => setState(() => excludeBroker = v)),
          SwitchListTile(contentPadding: EdgeInsets.zero, dense: true,
            title: const Text('Loại dấu hiệu sổ chung'),
            value: excludeSharedTitle,
            onChanged: (v) => setState(() => excludeSharedTitle = v)),
          SwitchListTile(contentPadding: EdgeInsets.zero, dense: true,
            title: const Text('Loại chung cư, căn hộ'),
            value: excludeApartments,
            onChanged: (v) => setState(() => excludeApartments = v)),
          SwitchListTile(contentPadding: EdgeInsets.zero, dense: true,
            title: const Text('Ưu tiên tin có dấu hiệu chính chủ (không loại tin khác)'),
            value: ownerHintsOnly,
            onChanged: (v) => setState(() => ownerHintsOnly = v)),
          const SizedBox(height:10),
          Row(children: [
            const Expanded(child: Text('Quét trang web trực tiếp khoảng 2 giờ/lần khi có mạng',
              style: TextStyle(fontSize: 12))),
            Switch(value: settings.autoScan, onChanged: busy ? null : autoToggle),
          ]),
          const Text('Android có thể trì hoãn hoặc bỏ lỡ lịch do tiết kiệm pin. Ứng dụng sẽ quét bù khi được mở lại nếu đã quá 2 giờ.',
            style: TextStyle(fontSize: 11, color: Colors.black54)),
          const SizedBox(height:12),
          Row(children: [
            OutlinedButton(onPressed: busy ? null : saveSettings,
              child: const Text('Lưu tiêu chí')),
            const SizedBox(width:8),
            Expanded(child: FilledButton.icon(onPressed: busy ? stopScan : scan,
              icon: busy ? const Icon(Icons.stop_circle_outlined) : const Icon(Icons.travel_explore),
              label: Text(busy ? 'Dừng quét' : 'Quét web ngay'))),
          ]),
        ]))),
        // Diagnostic history is kept in storage but not rendered below the
        // scanner form. On some devices these legacy ExpansionTiles caused a
        // large grey Flutter error widget / overflow placeholder.
        if (notice.isNotEmpty) Padding(
          padding: const EdgeInsets.symmetric(vertical: 8),
          child: SelectableText(notice, style: const TextStyle(fontSize: 12)),
        ),
    ];
    // R3.3: independent result and scanner views. No nested/fixed-height
    // viewport and no eager construction of every result card.
    final controls = <Widget>[
      Row(children: [
        for (final option in const [(false, 'Tin đã quét'), (true, 'Thiết lập & quét')])
          Expanded(child: InkWell(
            onTap: () => setState(() => showScannerSettings = option.$1),
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 15, horizontal: 4),
              decoration: BoxDecoration(
                color: showScannerSettings == option.$1
                    ? const Color(0xFFE1F2EF) : Colors.transparent,
                border: Border(bottom: BorderSide(
                  color: showScannerSettings == option.$1
                      ? const Color(0xFF006B60) : Colors.transparent,
                  width: 3,
                )),
              ),
              child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                Icon(option.$1 ? Icons.tune : Icons.list_alt,
                  color: showScannerSettings == option.$1
                    ? const Color(0xFF006B60) : Colors.grey),
                const SizedBox(width: 6),
                Flexible(child: Text(option.$2, textAlign: TextAlign.center,
                  style: TextStyle(
                    fontWeight: showScannerSettings == option.$1
                      ? FontWeight.w800 : FontWeight.w400,
                    color: showScannerSettings == option.$1
                      ? const Color(0xFF006B60) : Colors.black54,
                  ))),
              ]),
            ),
          )),
      ]),
    ];
    if (!loaded) return const Center(child: CircularProgressIndicator());
    if (showScannerSettings) {
      return RefreshIndicator(
        onRefresh: refresh,
        child: ListView(
          key: const PageStorageKey<String>('r33-scanner-settings'),
          padding: const EdgeInsets.all(12),
          children: [...controls, const SizedBox(height: 10), ...settingsWidgets],
        ),
      );
    }
    final header = <Widget>[
      ...controls,
      const SizedBox(height: 12),
      const Text('DANH SÁCH TIN ĐÃ QUÉT',
          style: TextStyle(fontSize: 19, fontWeight: FontWeight.w800)),
      Text('Tổng bản ghi: ${leads.length} · Nhóm đang xem: ${visible.length}',
          style: const TextStyle(fontSize: 12)),
      Wrap(spacing: 6, runSpacing: 6, children: [
        for (final state in const [
          ('qualified', 'Đạt bộ lọc'),
          ('needs_data', 'Thiếu dữ liệu'),
          ('saved_for_review', 'Đã lưu tạm'),
          ('imported', 'Đã xác minh & lưu'),
          ('rejected', 'Đã loại'),
          ('all', 'Tất cả')
        ])
          ChoiceChip(
            label: Text(state.$2),
            selected: filter == state.$1,
            onSelected: (_) => setState(() => filter = state.$1),
          ),
      ]),
      Row(children: [
        Expanded(child: Text('Có ${visible.length} tin trong nhóm',
            style: const TextStyle(fontSize: 12))),
        IconButton(onPressed: copyReport,
            tooltip: 'Sao chép danh sách',
            icon: const Icon(Icons.copy_all_outlined)),
        IconButton(onPressed: refresh,
            tooltip: 'Tải lại dữ liệu',
            icon: const Icon(Icons.refresh)),
      ]),
      if (notice.isNotEmpty) SelectableText(notice,
          style: const TextStyle(fontSize: 12)),
    ];
    return RefreshIndicator(
      onRefresh: refresh,
      child: ListView.builder(
        key: const PageStorageKey<String>('r33-results-list'),
        padding: const EdgeInsets.all(12),
        itemCount: header.length + (visible.isEmpty ? 1 : visible.length) + 1,
        itemBuilder: (context, index) {
          if (index < header.length) return header[index];
          final resultIndex = index - header.length;
          if (visible.isEmpty && resultIndex == 0) {
            return const Padding(
              padding: EdgeInsets.all(20),
              child: Text('Chưa có tin trong nhóm này. Chọn Tất cả hoặc mở Thiết lập & quét.'),
            );
          }
          if (resultIndex >= visible.length) {
            return const SizedBox(height: 90);
          }
          final lead = visible[resultIndex];
          return KeyedSubtree(
            key: ValueKey<String>(lead.id),
            child: _leadCard(lead),
          );
        },
      ),
    );
  }
}
