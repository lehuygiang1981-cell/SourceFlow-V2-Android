# SourceFlow Personal — Supply Hunter R2 (Android)

## Phạm vi bản mã nguồn

Kế thừa **SourceFlow V2.2 Personal R1**, giữ nguyên `lib/storage.dart` và cấu trúc JSON `Listing`, đồng thời bổ sung `Supply Hunter` cho một môi giới BĐS độc lập:

1. Tìm kiếm định kỳ nguồn công khai qua kết quả RSS của Bing theo `site:...`, khu vực và từ khóa. Bộ lọc mặc định: Thành phố Thủ Đức, "bán nhà chính chủ"; 5 nguồn đã cấu hình: batdongsan.com.vn, nhatot.com, muaban.net, bds68.com.vn, guland.vn. **Không khẳng định đã kết nối API chính thức của 5 website.** Các nguồn có thể bị chặn, không được chỉ mục hoặc trả kết quả rỗng.
2. Chế độ thủ công **Quét web ngay** và chế độ quét tự động khoảng **2 giờ/lần** qua Android WorkManager khi có mạng; tự quét một lần khi mở ứng dụng và chưa có báo cáo. Android có thể dời/lược bỏ phiên nền tùy chế độ tiết kiệm pin, quyền chạy nền và kết nối. Không phải lịch quét bảo đảm chính xác từng phút.
3. Các tin phát hiện lưu trong cơ sở dữ liệu SQLite **RIÊNG** `sourceflow_hunter.sqlite`, trạng thái ban đầu `pending`; có nguồn, link, tiêu đề, mô tả, thời điểm tìm được và cờ cần kiểm tra. Tin này chỉ là **ứng viên chưa xác minh**.
4. Ngăn tin trùng URL và bỏ thông số tracking `utm_*`; tái quét không đưa tin đã loại / đã duyệt trở lại hàng chờ.
5. Màn hình **Quét web** có: báo cáo chờ kiểm tra, mở link gốc, đánh dấu loại, xác minh & lưu, lọc danh sách, sao chép báo cáo có link trực tiếp.
6. Chỉ khi người dùng tự xác minh **và ghi căn cứ** mới chuyển tin thành `Listing` trong kho cũ, có `sourceUrl`, thông tin trích xuất sơ bộ, trạng thái `Đã đối chiếu hồ sơ` / `Đã gặp và xác minh trực tiếp`, nhật ký thao tác.
7. Dashboard cá nhân hiển thị số tin chờ, đã duyệt, đã loại; cập nhật sau các thao tác lưu.
8. Sao lưu `.sfbackup` vẫn tương thích schema=3 hiện tại, nay bổ sung tùy chọn `hunterLeads` và `hunterSettings` để giữ danh sách nguồn web và quyết định duyệt/loại khi chuyển máy. Không thay đổi bảng `listings` đang hoạt động.

## Giới hạn quan trọng

- Không có API riêng hay bộ trích xuất trang chi tiết cho mỗi nền tảng trong R2. Bing RSS có thể trả ít hoặc không trả link trực tiếp; ứng dụng không vượt CAPTCHA, đăng nhập, không lấy số điện thoại ẩn và không cố lấy dữ liệu riêng tư.
- **Ngày từ RSS là ngày chỉ mục, không đồng nghĩa ngày người bán đăng**; chưa thể lọc chính xác tin trong 5 ngày gần đây khi tin gốc không xác nhận thời gian đăng. **Số lượng tin của từng người đăng (≤3)** và **chính chủ** cũng chưa thể tự xác thực từ chỉ mục. Những điểm này được hiển thị để kiểm tra thủ công; hệ thống không tự nhận định đã xác minh.
- Đánh giá nội dung ảnh và nhập giọng nói vẫn dựa trên R1, không hứa hoàn hảo. Mục tiêu duy trì ổn định là ưu tiên.
- Kết quả được lưu trực tiếp trên thiết bị; không hỗ trợ đa tài khoản, doanh nghiệp hoặc iOS Safari trong giai đoạn này.
- **Chưa biên dịch và chưa thử trực tiếp trên Android** trong môi trường hiện tại (không có Flutter SDK/Android SDK và không có truy cập kiểm thử các website). Cần chạy `flutter test`, build và thử thực tế trước khi dùng dữ liệu quan trọng.

## Cài đặt / build

1. Tạo repository GitHub **private**. Đưa `SourceFlow_Personal_R2_SupplyHunter_transfer.zip` và `SourceFlow_Personal_R2_workflow.yml` vào repository; đặt YAML workflow vào `.github/workflows/android-apk.yml`.
2. Trên GitHub Actions chạy workflow (Windows, Flutter stable), giải nén ZIP và chạy `scripts/prepare_android.ps1`.
3. Chờ kết quả `flutter test`, `flutter build apk --release`. Tải artifact `SourceFlow-Personal-R2-SupplyHunter-APK` nếu build thành công.
4. Bản R2 dùng Android package `vn.sourceflow.sourceflow_personal_r2` nhằm **cài song song** với bản R1 / bản đang dùng; không tự thấy dữ liệu trong ứng dụng cũ vì sandbox Android khác nhau. Xuất sao lưu `.sfbackup`, sao chép ra nơi an toàn, nhập lại trong R2 và đối chiếu trước khi cân nhắc gỡ bản cũ.
5. Vào tab **Quét web**, kiểm tra khu vực, từ khóa, nhấn **Quét web ngay** hoặc bật quét nền. Mở link gốc, ghi căn cứ xác minh rồi lưu. Kiểm tra Dashboard và kho Nguồn hàng.

## Kiểm thử nghiệm thu ưu tiên

- `test/hunter_test.dart`: lọc URL đúng host, không lưu trang tìm kiếm rõ ràng, loại UTM, chống trùng RSS, lưu trạng thái xác minh qua JSON, mô phỏng lỗi mạng từng nguồn.
- `test/personal_test.dart`, `test/workflow_test.dart`: OCR, giọng nói, hiệu suất và nghiệp vụ R1 còn phải chạy lại.
- Thử điện thoại: internet tắt, RSS trả lỗi/không có kết quả, lịch nền sau khóa máy, mở URL, duyệt nguồn và đối chiếu không trùng, backup/restore đầy đủ.

## Nguyên tắc sử dụng

Tin hệ thống tìm thấy không phải bằng chứng chính chủ. Chỉ người môi giới tự kiểm tra nguồn mới có quyền xác nhận; căn cứ cần được mô tả cụ thể. Không gọi hoặc nhắn hàng loạt vào số cá nhân lấy từ web.
