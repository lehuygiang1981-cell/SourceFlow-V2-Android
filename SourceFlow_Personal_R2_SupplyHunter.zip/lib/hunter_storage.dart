import 'dart:convert';
import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';
import 'hunter_models.dart';

/// Independent local database. Does not modify existing sourceflow_v2.sqlite.
class HunterStorage {
  Database? _db;
  Future<void> open() async {
    final root=await getDatabasesPath();
    _db=await openDatabase(p.join(root,'sourceflow_hunter.sqlite'),version:1,
      onCreate:(db,version) async {
        await db.execute('CREATE TABLE leads (id TEXT PRIMARY KEY, url_key TEXT UNIQUE NOT NULL, discovered INTEGER NOT NULL, status TEXT NOT NULL, content TEXT NOT NULL)');
        await db.execute('CREATE TABLE settings (key TEXT PRIMARY KEY, value TEXT NOT NULL)');
      });
  }
  Future<HunterSettings> settings() async {
    final rows=await _db!.query('settings',where:'key=?',whereArgs:['options'],limit:1);
    if(rows.isEmpty)return const HunterSettings();
    return HunterSettings.fromJson(Map<String,dynamic>.from(jsonDecode(rows.first['value'] as String)));
  }
  Future<void> saveSettings(HunterSettings value)=>_db!.insert('settings',
    {'key':'options','value':jsonEncode(value.toJson())},conflictAlgorithm:ConflictAlgorithm.replace);

  Future<List<HunterLead>> leads() async {
    final rows=await _db!.query('leads',orderBy:'discovered DESC');
    return rows.map((e)=>HunterLead.fromJson(Map<String,dynamic>.from(jsonDecode(e['content'] as String)))).toList();
  }
  Future<int> addDiscovered(Iterable<HunterLead> items) async {
    var count=0;
    await _db!.transaction((tx)async{
      for(final item in items){
        final key=canonicalLeadUrl(item.url);
        if(key.isEmpty)continue;
        // INSERT OR IGNORE preserves user approval/rejection across subsequent scans.
        final existing=await tx.query('leads',columns:['id'],where:'url_key=?',whereArgs:[key],limit:1);
        if(existing.isNotEmpty)continue;
        await tx.insert('leads',{'id':item.id,'url_key':key,
          'discovered':item.discoveredAt.millisecondsSinceEpoch,'status':item.status,
          'content':jsonEncode(item.toJson())},conflictAlgorithm:ConflictAlgorithm.ignore);
        count++;
      }
    });
    return count;
  }
  Future<void> updateLead(HunterLead item) async {
    await _db!.update('leads',{'status':item.status,'content':jsonEncode(item.toJson())},
      where:'id=?',whereArgs:[item.id]);
  }
  Future<void> recordScan({required int found,required int added,required List<String> errors}) async{
    final report={'timestamp':DateTime.now().toIso8601String(), 'found':found,
      'added':added,'errors':errors};
    await _db!.insert('settings',{'key':'lastScan','value':jsonEncode(report)},
      conflictAlgorithm:ConflictAlgorithm.replace);
  }
  Future<HunterSnapshot> snapshot() async {
    final counts=await _db!.rawQuery('SELECT status, COUNT(*) AS total FROM leads GROUP BY status');
    final totals=<String,int>{};
    for(final row in counts)totals['${row['status']}']=(row['total'] as int?)??0;
    final rows=await _db!.query('settings',where:'key=?',whereArgs:['lastScan'],limit:1);
    DateTime? at;String message='Chưa có phiên quét';
    if(rows.isNotEmpty){
      final report=Map<String,dynamic>.from(jsonDecode(rows.first['value'] as String));
      at=DateTime.tryParse('${report['timestamp']}');
      final errors=(report['errors'] is List ? report['errors'] as List:[]);
      message='Phát hiện ${report['found']??0} · Mới ${report['added']??0}'
        '${errors.isEmpty?'':' · ${errors.length} nguồn lỗi'}';
    }
    return HunterSnapshot(total:totals.values.fold<int>(0,(a,b)=>a+b),
      pending:totals['pending']??0,confirmed:totals['imported']??0,
      rejected:totals['rejected']??0,lastScan:at,message:message);
  }
  Future<void> close()async{await _db?.close();_db=null;}
}
