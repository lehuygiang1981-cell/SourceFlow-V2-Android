import 'package:http/http.dart' as http;
import 'package:xml/xml.dart';
import 'hunter_models.dart';

/// Search provider uses an RSS endpoint (no login/captcha bypass or private data).
/// Search index timestamps are NOT website listing publication timestamps.
class HunterSearchResult {
  final List<HunterLead> leads;
  final List<String> errors;
  final int searched;
  const HunterSearchResult(this.leads,this.errors,this.searched);
}

class HunterSearch {
  final http.Client client;
  HunterSearch({http.Client? client}):client=client??http.Client();

  static const allowedHosts={
    'batdongsan.com.vn','nhatot.com','muaban.net','bds68.com.vn','guland.vn',
  };
  static bool directSourceUrl(String link,String expectedHost){
    final url=Uri.tryParse(link);
    if(url==null || !['http','https'].contains(url.scheme))return false;
    final host=url.host.toLowerCase();
    if(!(host==expectedHost||host.endsWith('.$expectedHost')))return false;
    if(url.path=='/'||url.path.isEmpty)return false;
    final lower=url.path.toLowerCase();
    if(RegExp(r'/(tim-kiem|search|dang-nhap|login|thanh-vien|tin-tuc)(/|$)').hasMatch(lower))return false;
    return true; // Is a source-domain candidate; user checks whether it is a listing.
  }

  static Uri queryUrl(HunterSettings settings,String domain){
    final q='site:$domain ${settings.location.trim()} ${settings.keywords.trim()}';
    return Uri.https('www.bing.com','/search',{'q':q,'format':'rss'});
  }

  static String textContent(String html){
    final withoutTags=html.replaceAll(RegExp(r'<[^>]+>'),' ');
    return withoutTags.replaceAll('&nbsp;',' ').replaceAll('&amp;','&')
      .replaceAll('&quot;','"').replaceAll('&#39;',"'")
      .replaceAll(RegExp(r'\s+'),' ').trim();
  }

  static List<HunterLead> readRss(String xml,String domain,{DateTime? now}){
    final document=XmlDocument.parse(xml);
    final out=<HunterLead>[];
    final seen=<String>{};
    for(final item in document.findAllElements('item')){
      String field(String name){
        final tags=item.findElements(name);
        return tags.isEmpty?'':tags.first.innerText.trim();
      }
      final url=field('link');
      if(!directSourceUrl(url,domain))continue;
      final canonical=canonicalLeadUrl(url);
      if(canonical.isEmpty||!seen.add(canonical))continue;
      final title=textContent(field('title'));
      if(title.length<8)continue;
      final date=DateTime.tryParse(field('pubDate')); // Usually RSS index, not seller posting date.
      out.add(HunterLead(url:url,title:title,snippet:textContent(field('description')),
        source:domain,indexDate:date,discoveredAt:now));
    }
    return out;
  }

  Future<HunterSearchResult> scan(HunterSettings settings) async {
    final leads=<HunterLead>[];
    final errors=<String>[];
    final seen=<String>{};
    var searched=0;
    for(final domain in settings.sites){
      if(!allowedHosts.contains(domain)){
        errors.add('$domain: nguồn chưa được hỗ trợ');continue;
      }
      searched++;
      try {
        final response=await client.get(queryUrl(settings,domain),headers:{
          'Accept':'application/rss+xml, application/xml, text/xml',
          'User-Agent':'SourceFlowPersonal/2.2 (RSS candidate discovery)'
        }).timeout(const Duration(seconds:12));
        if(response.statusCode!=200)throw Exception('HTTP ${response.statusCode}');
        if(!response.body.contains('<rss') && !response.body.contains('<item')){
          throw const FormatException('Phản hồi không phải RSS');
        }
        for(final item in readRss(response.body,domain)){
          if(seen.add(item.id))leads.add(item);
        }
      }catch(e){errors.add('$domain: $e');}
    }
    return HunterSearchResult(leads,errors,searched);
  }
  void close()=>client.close();
}
