import 'package:flutter/widgets.dart';
import 'package:workmanager/workmanager.dart';
import 'hunter_search.dart';
import 'hunter_storage.dart';

const hunterJob='sourceflow_hunter_r2_scan';

@pragma('vm:entry-point')
void hunterCallbackDispatcher(){
  Workmanager().executeTask((task,inputData)async{
    if(task!=hunterJob)return true;
    WidgetsFlutterBinding.ensureInitialized();
    final storage=HunterStorage();
    final search=HunterSearch();
    try{
      await storage.open();
      final settings=await storage.settings();
      if(!settings.autoScan)return true;
      final result=await search.scan(settings);
      final added=await storage.addDiscovered(result.leads);
      await storage.recordScan(found:result.leads.length,added:added,errors:result.errors);
      // Partial provider failures are documented; do not retry them aggressively.
      return true;
    }catch(_){return false;}
    finally{search.close();await storage.close();}
  });
}

Future<void> configureHunterBackground(bool enabled)async{
  final manager=Workmanager();
  await manager.initialize(hunterCallbackDispatcher);
  if(enabled){
    await manager.registerPeriodicTask('sourceflow_personal_r2_hunter',hunterJob,
      frequency:const Duration(hours:2),
      constraints:Constraints(networkType:NetworkType.connected),
      existingWorkPolicy:ExistingPeriodicWorkPolicy.keep);
  }else{
    await manager.cancelByUniqueName('sourceflow_personal_r2_hunter');
  }
}
