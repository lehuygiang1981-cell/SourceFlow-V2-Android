import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';
import 'hunter_models.dart';
import 'hunter_search.dart';
import 'hunter_storage.dart';
import 'models.dart';

class HunterPage extends StatefulWidget {
  final HunterStorage storage;
  final Future<void> Function(Listing) onImport;
  final bool Function(String) sourceExists;
  final ValueChanged<HunterSnapshot> onChanged;
  final Future<void> Function(bool) onAutoChanged;
  const HunterPage({super.key,required this.storage,required this.onImport,
    required this.sourceExists,required this.onChanged,required this.onAutoChanged});
  @override State<HunterPage> createState()=>_HunterPageState();
}

class _HunterPageState extends State<HunterPage> with WidgetsBindingObserver {
  List<HunterLead> leads=[];
  HunterSettings settings=const HunterSettings();
  HunterSnapshot snapshot=const HunterSnapshot();
  final location=TextEditingController();
  final keywords=TextEditingController();
  bool busy=false,loaded=false;
  String filter='pending',notice='';
  @override void initState(){super.initState();WidgetsBinding.instance.addObserver(this);refresh(initial:true);}
  @override void didChangeAppLifecycleState(AppLifecycleState state){
    if(state==AppLifecycleState.resumed)refresh();
  }
  @override void dispose(){WidgetsBinding.instance.removeObserver(this);location.dispose();keywords.dispose();super.dispose();}

  String when(DateTime? d){
    if(d==null)return 'Chưa có';
    String two(int n)=>n.toString().padLeft(2,'0');
    return '${two(d.day)}/${two(d.month)}/${d.year} ${two(d.hour)}:${two(d.minute)}';
  }
  void message(String value){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(value)));}
  Future<void> refresh({bool initial=false})async {
    try{
      final s=await widget.storage.settings();
      final l=await widget.storage.leads();
      final snap=await widget.storage.snapshot();
      if(!mounted)return;
      setState((){
        settings=s;leads=l;snapshot=snap;loaded=true;
        if(initial){location.text=s.location;keywords.text=s.keywords;}
      });
      widget.onChanged(snap);
      // First discovery runs without the user needing to press the scan button.
      if(initial && s.autoScan && (snap.lastScan==null ||
          DateTime.now().difference(snap.lastScan!).inHours>=2)){
        Future<void>.microtask(scan);
      }
    }catch(e){if(mounted){setState(()=>loaded=true);message('Lỗi tải nguồn web: $e');}}
  }
  Future<void> saveSettings()async{
    final newSettings=HunterSettings(location:location.text.trim(),keywords:keywords.text.trim(),
      sites:settings.sites,autoScan:settings.autoScan);
    if(newSettings.location.isEmpty||newSettings.keywords.isEmpty){message('Nhập khu vực và từ khóa tìm kiếm.');return;}
    await widget.storage.saveSettings(newSettings);
    if(mounted)setState(()=>settings=newSettings);
    message('Đã lưu bộ lọc nguồn hàng.');
  }
  Future<void> autoToggle(bool enabled)async{
    final updated=HunterSettings(location:settings.location,keywords:settings.keywords,
      sites:settings.sites,autoScan:enabled);
    await widget.storage.saveSettings(updated);
    if(mounted)setState(()=>settings=updated);
    try{await widget.onAutoChanged(enabled);}
    catch(e){message('Lịch quét nền chưa được kích hoạt: $e');}
  }
  Future<void> scan()async {
    if(busy)return;
    setState((){busy=true;notice='Đang tìm tin từ các nguồn công khai…';});
    final scanner=HunterSearch();
    try{
      // Save current search filters before scanning.
      final options=HunterSettings(location:location.text.trim().isEmpty?settings.location:location.text.trim(),
        keywords:keywords.text.trim().isEmpty?settings.keywords:keywords.text.trim(),
        sites:settings.sites,autoScan:settings.autoScan);
      await widget.storage.saveSettings(options);
      final outcome=await scanner.scan(options);
      final added=await widget.storage.addDiscovered(outcome.leads);
      await widget.storage.recordScan(found:outcome.leads.length,added:added,errors:outcome.errors);
      await refresh();
      if(!mounted)return;
      setState((){filter='pending';notice='Đã tìm ${outcome.leads.length} kết quả từ ${outcome.searched} nguồn; $added tin mới.'
        '${outcome.errors.isNotEmpty?' ${outcome.errors.length} nguồn lỗi: ${outcome.errors.join(' | ')}':''}';});
    }catch(e){if(mounted)setState(()=>notice='Không thực hiện được lượt quét: $e');}
    finally{scanner.close();if(mounted)setState(()=>busy=false);}
  }
  Future<void> openSource(HunterLead lead)async{
    final uri=Uri.tryParse(lead.url);
    if(uri==null||!await launchUrl(uri,mode:LaunchMode.externalApplication)){
      message('Không mở được liên kết nguồn.');
    }
  }
  Future<void> reject(HunterLead lead)async{
    final reason=TextEditingController();
    final ok=await showDialog<bool>(context:context,builder:(ctx)=>AlertDialog(
      title:const Text('Loại khỏi danh sách chờ'),
      content:Column(mainAxisSize:MainAxisSize.min,children:[
        const Text('Tin này sẽ được giữ trong lịch sử, không hiện lại như tin mới khi quét trùng.'),
        const SizedBox(height:10),TextField(controller:reason,decoration:const InputDecoration(labelText:'Lý do (không bắt buộc)'))]),
      actions:[TextButton(onPressed:()=>Navigator.pop(ctx,false),child:const Text('Hủy')),
        FilledButton(onPressed:()=>Navigator.pop(ctx,true),child:const Text('Loại tin'))]));
    if(ok==true){lead.status='rejected';lead.reviewNote=reason.text.trim();lead.reviewedAt=DateTime.now();
      await widget.storage.updateLead(lead);await refresh();}
    reason.dispose();
  }
  Future<void> approve(HunterLead lead)async {
    if(widget.sourceExists(lead.url)){
      message('Tin này đã có trong kho nguồn hàng. Không nhập trùng.');return;
    }
    final method=ValueNotifier<String>('Đã đối chiếu hồ sơ');
    final evidence=TextEditingController();
    final note=TextEditingController();
    final confirmed=await showDialog<bool>(context:context,builder:(ctx)=>AlertDialog(
      title:const Text('Xác nhận nguồn hàng chính chủ'),
      content:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,
        crossAxisAlignment:CrossAxisAlignment.start,children:[
        Text(lead.title,style:const TextStyle(fontWeight:FontWeight.w600)),
        const SizedBox(height:9),const Text('Hãy đối chiếu tin gốc và liên hệ trước khi xác nhận. Dấu hiệu từ web KHÔNG đủ để kết luận chính chủ.',style:TextStyle(fontSize:12)),
        const SizedBox(height:13),ValueListenableBuilder<String>(valueListenable:method,builder:(_,value,__)=>
          DropdownButtonFormField<String>(value:value,decoration:const InputDecoration(labelText:'Cách xác minh'),
            items:const [DropdownMenuItem(value:'Đã đối chiếu hồ sơ',child:Text('Đã đối chiếu hồ sơ')),
              DropdownMenuItem(value:'Đã gặp và xác minh trực tiếp',child:Text('Đã gặp chủ trực tiếp'))],
            onChanged:(v){if(v!=null)method.value=v;})),
        const SizedBox(height:12),TextField(controller:evidence,maxLines:3,
          decoration:const InputDecoration(labelText:'Căn cứ xác minh (bắt buộc)',
            hintText:'Ví dụ: Đã đối chiếu sổ và căn cước với chủ tại địa chỉ...')),
        const SizedBox(height:12),TextField(controller:note,maxLines:2,
          decoration:const InputDecoration(labelText:'Ghi chú kiểm tra / thông tin cần bổ sung')),
      ])),actions:[TextButton(onPressed:()=>Navigator.pop(ctx,false),child:const Text('Hủy')),
        FilledButton(onPressed:()=>Navigator.pop(ctx,true),child:const Text('Xác nhận & lưu'))]));
    if(confirmed!=true){method.dispose();evidence.dispose();note.dispose();return;}
    if(evidence.text.trim().length<8){
      message('Cần ghi căn cứ xác minh cụ thể, tối thiểu 8 ký tự.');
      method.dispose();evidence.dispose();note.dispose();return;
    }
    final parsed=lead.parsed;
    final property=Listing(title:parsed.title.isEmpty?lead.title:parsed.title,
      type:parsed.type.isEmpty?'Nhà riêng':parsed.type,address:parsed.address,
      area:parsed.area,width:parsed.width,length:parsed.length,price:parsed.price,
      phone:parsed.phone,owner:parsed.owner,source:'Supply Hunter: ${lead.source}',
      sourceUrl:lead.url,verification:method.value,verificationEvidence:evidence.text.trim(),
      rawCapture:'${lead.title}\n${lead.snippet}',nextAction:'Kiểm tra bổ sung thông tin nguồn hàng',
      contactStatus:'Đã liên hệ');
    property.addLog('Nhập nguồn đã xác minh qua Supply Hunter',
      '${method.value}: ${evidence.text.trim()}. ${note.text.trim()} | ${lead.url}');
    try{
      await widget.onImport(property); // Never claim imported before successful source-flow save.
      lead.status='imported';lead.listingId=property.id;lead.method=method.value;
      lead.evidence=evidence.text.trim();lead.reviewNote=note.text.trim();
      lead.reviewedAt=DateTime.now();
      await widget.storage.updateLead(lead);
      await refresh();message('Đã lưu nguồn hàng đã xác minh vào kho cá nhân.');
    }catch(e){message('Chưa lưu được nguồn hàng: $e');}
    method.dispose();evidence.dispose();note.dispose();
  }
  Future<void> copyReport() async {
    final header='SOURCEFLOW SUPPLY HUNTER — BÁO CÁO TIN CHỜ KIỂM TRA\n'
      'Khu vực: ${settings.location} | Từ khóa: ${settings.keywords}\n'
      'Thời điểm báo cáo: ${DateTime.now()}\n'
      'Ngày đăng và danh tính chủ sở hữu chưa được xác minh từ kết quả tìm kiếm.\n\n';
    final lines=leads.where((p)=>p.status=='pending').toList();
    final text=header+lines.asMap().entries.map((entry){
      final l=entry.value;final p=l.parsed;
      return '${entry.key+1}. ${l.title}\nNguồn: ${l.source}\n'
        '${p.area.isEmpty?'':'Diện tích: ${p.area}\n'}'
        '${p.price.isEmpty?'':'Giá: ${p.price}\n'}'
        'Link: ${l.url}\nTrạng thái: Chờ kiểm tra\n';
    }).join('\n');
    await Clipboard.setData(ClipboardData(text:text));message('Đã sao chép ${lines.length} nguồn chờ kiểm tra.');
  }
  Widget _leadCard(HunterLead lead)=>Card(child:Padding(padding:const EdgeInsets.all(12),child:Column(
    crossAxisAlignment:CrossAxisAlignment.start,children:[
      Text(lead.title,style:const TextStyle(fontWeight:FontWeight.w700)),
      const SizedBox(height:5),Text('${lead.source} • Tìm thấy: ${when(lead.discoveredAt)}',style:const TextStyle(fontSize:12,color:Colors.black54)),
      if(lead.indexDate!=null)const Text('Có ngày từ chỉ mục RSS; KHÔNG phải ngày đăng đã xác minh.',style:TextStyle(fontSize:11,color:Colors.deepOrange)),
      if(lead.snippet.isNotEmpty)Padding(padding:const EdgeInsets.only(top:7),child:Text(lead.snippet,maxLines:4,overflow:TextOverflow.ellipsis)),
      for(final flag in lead.reviewFlags)Padding(padding:const EdgeInsets.only(top:3),child:Text('• $flag',style:const TextStyle(fontSize:11,color:Colors.deepOrange))),
      const SizedBox(height:7),SelectableText(lead.url,style:const TextStyle(fontSize:12,color:Colors.teal)),
      if(lead.status=='imported')const Padding(padding:EdgeInsets.only(top:5),child:Text('Đã xác minh và lưu vào kho',style:TextStyle(color:Colors.green,fontWeight:FontWeight.bold))),
      if(lead.status=='rejected')const Padding(padding:EdgeInsets.only(top:5),child:Text('Đã loại',style:TextStyle(color:Colors.deepOrange))),
      const SizedBox(height:10),Wrap(spacing:6,runSpacing:6,children:[
        OutlinedButton.icon(onPressed:()=>openSource(lead),icon:const Icon(Icons.open_in_new,size:17),label:const Text('Xem tin gốc')),
        if(lead.status=='pending')...[
          FilledButton.icon(onPressed:()=>approve(lead),icon:const Icon(Icons.verified_user_outlined,size:17),label:const Text('Xác minh & lưu')),
          TextButton.icon(onPressed:()=>reject(lead),icon:const Icon(Icons.close,size:17),label:const Text('Loại')),
        ],
      ]),
    ])));
  @override Widget build(BuildContext context) {
    final visible=leads.where((p)=>filter=='all'||p.status==filter).toList();
    return !loaded?const Center(child:CircularProgressIndicator()):RefreshIndicator(onRefresh:refresh,child:ListView(
      padding:const EdgeInsets.all(14),children:[
        const Text('Supply Hunter · Nguồn web',style:TextStyle(fontSize:21,fontWeight:FontWeight.w800)),
        const SizedBox(height:5),const Text('Tin từ kết quả tìm kiếm chỉ là ứng viên. Mở link gốc, kiểm tra và tự xác minh trước khi lưu.',style:TextStyle(color:Colors.black54)),
        const SizedBox(height:12),Wrap(spacing:8,runSpacing:8,children:[
          Chip(label:Text('Chờ kiểm tra: ${snapshot.pending}')),
          Chip(label:Text('Đã lưu: ${snapshot.confirmed}')),
          Chip(label:Text('Đã loại: ${snapshot.rejected}')),
        ]),
        Text('Lần quét: ${snapshot.lastScan==null?'Chưa có':when(snapshot.lastScan)} • ${snapshot.message}',style:const TextStyle(fontSize:12)),
        const SizedBox(height:8),Card(child:Padding(padding:const EdgeInsets.all(12),child:Column(children:[
          TextField(controller:location,decoration:const InputDecoration(labelText:'Khu vực quét',prefixIcon:Icon(Icons.location_on_outlined))),
          const SizedBox(height:8),TextField(controller:keywords,decoration:const InputDecoration(labelText:'Từ khóa (ví dụ: bán nhà chính chủ)',prefixIcon:Icon(Icons.search))),
          const SizedBox(height:8),Row(children:[
            const Expanded(child:Text('Tự quét khoảng 2 giờ/lần khi có mạng',style:TextStyle(fontSize:12))),
            Switch(value:settings.autoScan,onChanged:autoToggle),
          ]),
          const Text('Android có thể trì hoãn tác vụ chạy nền. Kết quả phụ thuộc RSS/công cụ tìm kiếm; không bảo đảm phủ kín mọi trang hoặc lọc chính xác ngày đăng.',style:TextStyle(fontSize:11,color:Colors.black54)),
          const SizedBox(height:10),Row(children:[
            OutlinedButton(onPressed:saveSettings,child:const Text('Lưu bộ lọc')),
            const SizedBox(width:8),Expanded(child:FilledButton.icon(onPressed:busy?null:scan,
              icon:busy?const SizedBox(height:15,width:15,child:CircularProgressIndicator(strokeWidth:2)):const Icon(Icons.travel_explore),
              label:Text(busy?'Đang quét':'Quét web ngay'))),
          ]),
        ]))),
        if(notice.isNotEmpty)Padding(padding:const EdgeInsets.symmetric(vertical:8),child:SelectableText(notice,style:const TextStyle(fontSize:12))),
        const SizedBox(height:7),Row(children:[
          const Expanded(child:Text('BÁO CÁO NGUỒN TÌM ĐƯỢC',style:TextStyle(fontWeight:FontWeight.w700))),
          IconButton(onPressed:copyReport,tooltip:'Sao chép danh sách có link',icon:const Icon(Icons.copy_all_outlined)),
          IconButton(onPressed:refresh,tooltip:'Tải lại dữ liệu',icon:const Icon(Icons.refresh)),
        ]),
        Wrap(spacing:6,children:[
          for(final state in const [('pending','Chờ kiểm tra'),('imported','Đã lưu'),('rejected','Đã loại'),('all','Tất cả')])
            ChoiceChip(label:Text(state.$2),selected:filter==state.$1,
              onSelected:(_)=>setState(()=>filter=state.$1)),
        ]),
        if(visible.isEmpty)const Card(child:Padding(padding:EdgeInsets.all(20),child:Text('Chưa có tin trong nhóm này. Bấm Quét web ngay, hoặc mở lại để nhận kết quả từ tác vụ nền.'))),
        ...visible.map(_leadCard),
        const SizedBox(height:90),
      ]));
  }
}
