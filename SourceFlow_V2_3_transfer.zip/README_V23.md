# SourceFlow V2.3 — Android thử nghiệm

Bản nâng cấp dành cho thử nghiệm cá nhân, dựa trên V2.2.

## Những thay đổi của V2.3

- Đúng tên **SourceFlow V2.3** khi cài và trên tiêu đề ứng dụng, phiên bản `2.3.0+4`.
- Trong biểu mẫu tạo/chỉnh sửa nguồn hàng có thêm trường **Chiều ngang** và **Chiều dài** ngay dưới diện tích, đều có thể chỉnh sửa.
- Lưu `width`, `length` vào hồ sơ JSON, sao lưu và khôi phục; hồ sơ cũ không có trường này vẫn mở được.
- Bộ tách trường nhận diện các dạng `ngang 5m dài 20m`, `rộng 6,5m sâu 18m`, `KT: 5x20` và `6×18,5`; không suy ra chiều ngang/chiều dài từ diện tích nếu nguồn không ghi rõ.
- Khi chọn hoặc chụp ảnh, phần OCR thử đọc từ ảnh gốc rồi từ bản sao trong ứng dụng. Nếu nhận dạng được chữ, tự phân tích/điền vào các ô trống. Dữ liệu đã nhập bằng tay không bị ghi đè.
- Có nút **Quét lại chữ từ tất cả ảnh**; thông báo đếm ảnh đọc được chữ, số trường điền mới và lỗi cụ thể khi OCR không hoạt động. Văn bản nhận dạng hiển thị trong **Nội dung trích xuất / ghi chú bổ sung** để người dùng kiểm tra.
- Giữ nguyên tính năng nhập thông tin bằng giọng nói của V2.2.

## Giới hạn cần kiểm tra trên điện thoại

Máy chủ GitHub có thể biên dịch và chạy kiểm thử bộ tách trường, nhưng không thể chứng minh OCR của Google ML Kit hoạt động trên mọi thiết bị Android hoặc từng ảnh cụ thể. Cần kiểm tra trực tiếp bằng ảnh có chữ rõ. Nếu OCR báo lỗi, chụp màn hình lỗi hoặc gửi phần văn bản nhận dạng để hiệu chỉnh. Ảnh không chứa chữ nhìn thấy sẽ không được AI suy ra giá, địa chỉ hay tình trạng pháp lý.

## Dữ liệu và cài đặt

Bản V2.3 có `applicationId` riêng `vn.sourceflow.sourceflow_android_v23`, cho phép cài song song V2.2 mà không gỡ bản cũ. Dữ liệu không tự di chuyển giữa các ứng dụng; dùng sao lưu ở bản cũ và khôi phục trong bản mới khi cần. Không đưa thông tin nhạy cảm lên bản thử khi thiết bị chưa được bảo vệ.

## Biên dịch với GitHub Actions hiện có

1. Tải `SourceFlow_V2_3_transfer.zip` lên thư mục gốc của kho GitHub `SourceFlow-V2-Android`.
2. Sửa dòng `Expand-Archive` của `.github/workflows/android-apk.yml` thành `Expand-Archive -LiteralPath 'SourceFlow_V2_3_transfer.zip' -DestinationPath '.' -Force` và thay tên artifact nếu muốn thành `SourceFlow-V2-3-Android-APK`.
3. Để nguyên cấu hình Java 17 / Flutter stable, `kotlin.jvm.target.validation.mode=warning`, `kotlin.incremental=false`, và ML Kit R8 `dontwarn` của V2.2.
4. Commit thay đổi vào nhánh `main`, đợi run kết thúc, tải Artifacts khi build và test thành công.
