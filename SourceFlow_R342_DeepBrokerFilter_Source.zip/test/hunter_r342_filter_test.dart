import 'package:flutter_test/flutter_test.dart';
import 'package:sourceflow_android/hunter_search.dart';
import 'package:sourceflow_android/hunter_models.dart';

void main() {
  HunterLead lead(String t) => HunterLead(url: 'https://bds68.com.vn/ban-nha/example', source: 'bds68.com.vn', title: 'Bán nhà tại Thủ Đức', detailText: t);
  test('broker signal at end of description is detected', () {
    expect(HunterSearch.brokerEvidence(lead('Nhà đẹp. Làm việc chính chủ')), isNotNull);
  });
  test('broker signal in middle of description is detected', () {
    expect(HunterSearch.brokerEvidence(lead('Nhận ký gửi nhà đất, giá tốt')), isNotNull);
  });
  test('broker account name detected', () {
    expect(HunterSearch.brokerEvidence(lead('Liên hệ hungthinhvuongrealty167')), isNotNull);
  });
  test('plain direct seller not rejected', () {
    expect(HunterSearch.brokerEvidence(lead('Tôi bán căn nhà của gia đình, địa chỉ rõ ràng')), isNull);
  });
}
